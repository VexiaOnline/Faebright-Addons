local ADDON = ...
local FW = CreateFrame("Frame", "FaebrightWhoEventFrame")

local floor, min, max = math.floor, math.min, math.max
local strlower, strfind, strformat = string.lower, string.find, string.format
local tinsert, tsort = table.insert, table.sort

local ACCENT = {0.62, 0.82, 1.00}
local BG = {0.035, 0.045, 0.065, 0.97}
local PANEL = {0.07, 0.085, 0.115, 0.98}
local MUTED = {0.58, 0.64, 0.72}
local ROWS = 12
local ROW_H = 20
local SEARCH_COOLDOWN = 5
local FULL_SCAN_DELAY = 5.2
local WHO_CAP = 49

local SCAN_CLASSES = {"Warrior","Paladin","Hunter","Rogue","Priest","Death Knight","Shaman","Mage","Warlock","Druid"}
local SCAN_RACES = {"Human","Orc","Dwarf","Night Elf","Undead","Tauren","Gnome","Troll","Blood Elf","Draenei"}

local defaults = {
  point = "CENTER", x = 0, y = 20,
  width = 780, height = 560,
  minimapAngle = 225,
  sortKey = "name", sortAsc = true,
  filters = {
    name = "", minLevel = "", maxLevel = "", zone = "", class = "", race = "",
    includeGuild = "", excludeGuilds = "", unguildedOnly = false, excludeMyGuild = false,
  },
  presets = {},
}

local db
local frame
local results = {}
local filtered = {}
local selectedName
local lastServerQuery = nil
local lastTotalCount = 0
local lastSearchAt = -999
local pendingSearch = false
local scrollOffset = 0
local statusText
local refreshButton
local resultCountText
local minimapButton
local hideBlizzardAt
local fullScanButton
local cancelScanButton
local resultMap = {}
local resultMode = "quick"
local scan = {active=false, queue={}, waiting=false, current=nil, nextSendAt=0, queries=0, initialTotal=0, unresolved=0}
local rows = {}
local fields = {}

local function trim(s)
  if not s then return "" end
  return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function copyTable(src)
  local t = {}
  for k,v in pairs(src or {}) do
    if type(v) == "table" then t[k] = copyTable(v) else t[k] = v end
  end
  return t
end

local function applyDefaults(dst, src)
  for k,v in pairs(src) do
    if dst[k] == nil then
      dst[k] = type(v) == "table" and copyTable(v) or v
    elseif type(v) == "table" and type(dst[k]) == "table" then
      applyDefaults(dst[k], v)
    end
  end
end

local function makeBackdrop(f, r,g,b,a)
  f:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Buttons\\WHITE8X8",
    tile = true, tileSize = 16, edgeSize = 1,
    insets = {left=1,right=1,top=1,bottom=1}
  })
  f:SetBackdropColor(r,g,b,a)
  f:SetBackdropBorderColor(0.16,0.20,0.28,1)
end

local function addText(parent, text, size, r,g,b)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  fs:SetText(text or "")
  fs:SetFont(GameFontNormal:GetFont(), size or 12)
  fs:SetTextColor(r or 0.9, g or 0.92, b or 0.96)
  return fs
end

local function makeButton(parent, text, w, h)
  local b = CreateFrame("Button", nil, parent)
  b:SetSize(w, h)
  makeBackdrop(b, 0.10,0.12,0.16,1)
  b.label = addText(b, text, 11)
  b.label:SetPoint("CENTER", 0, 0)
  b:SetScript("OnEnter", function(self) self:SetBackdropColor(0.15,0.18,0.24,1) end)
  b:SetScript("OnLeave", function(self) self:SetBackdropColor(0.10,0.12,0.16,1) end)
  b:SetScript("OnMouseDown", function(self) self.label:SetPoint("CENTER", 1, -1) end)
  b:SetScript("OnMouseUp", function(self) self.label:SetPoint("CENTER", 0, 0) end)
  return b
end

local function makeEdit(parent, label, key, w, numeric)
  local holder = CreateFrame("Frame", nil, parent)
  holder:SetSize(w, 43)
  local l = addText(holder, label, 10, MUTED[1],MUTED[2],MUTED[3])
  l:SetPoint("TOPLEFT", 1, -1)
  local e = CreateFrame("EditBox", nil, holder)
  e:SetAutoFocus(false)
  e:SetSize(w, 22)
  e:SetPoint("BOTTOMLEFT")
  makeBackdrop(e, 0.045,0.055,0.075,1)
  e:SetTextInsets(7, 7, 0, 0)
  e:SetFontObject("GameFontHighlightSmall")
  e:SetMaxLetters(80)
  if numeric then e:SetNumeric(true) e:SetMaxLetters(2) end
  e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  e:SetScript("OnEnterPressed", function(self) self:ClearFocus(); FW:Search() end)
  e:SetScript("OnTextChanged", function(self, user)
    if user and db and db.filters then db.filters[key] = self:GetText() end
    if user then FW:ApplyFilters() end
  end)
  fields[key] = e
  return holder, e
end

local function makeCheck(parent, text, key)
  local b = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
  b:SetSize(24,24)
  local l = addText(b, text, 10)
  l:SetPoint("LEFT", b, "RIGHT", -1, 0)
  b.label = l
  b:SetScript("OnClick", function(self)
    db.filters[key] = self:GetChecked() and true or false
    FW:ApplyFilters()
  end)
  fields[key] = b
  return b
end

local function matchesText(value, needle)
  needle = trim(needle)
  if needle == "" then return true end
  return strfind(strlower(value or ""), strlower(needle), 1, true) ~= nil
end

local function excludedGuildSet(text)
  local set = {}
  for token in string.gmatch(text or "", "[^;]+") do
    token = strlower(trim(token))
    if token ~= "" then set[token] = true end
  end
  return set
end

function FW:ApplyFilters()
  if not db then return end
  filtered = {}
  local f = db.filters
  local myGuild = GetGuildInfo("player") or ""
  local excluded = excludedGuildSet(f.excludeGuilds)
  local minL = tonumber(f.minLevel)
  local maxL = tonumber(f.maxLevel)

  for _,r in ipairs(results) do
    local ok = true
    if f.name ~= "" and not matchesText(r.name, f.name) then ok = false end
    if minL and r.level < minL then ok = false end
    if maxL and r.level > maxL then ok = false end
    if f.zone ~= "" and not matchesText(r.zone, f.zone) then ok = false end
    if f.class ~= "" and not matchesText(r.class, f.class) then ok = false end
    if f.race ~= "" and not matchesText(r.race, f.race) then ok = false end
    if f.includeGuild ~= "" and not matchesText(r.guild, f.includeGuild) then ok = false end
    if f.unguildedOnly and trim(r.guild) ~= "" then ok = false end
    if f.excludeMyGuild and myGuild ~= "" and strlower(r.guild or "") == strlower(myGuild) then ok = false end
    if excluded[strlower(trim(r.guild or ""))] then ok = false end
    if ok then tinsert(filtered, r) end
  end

  local key, asc = db.sortKey, db.sortAsc
  tsort(filtered, function(a,b)
    local av, bv = a[key], b[key]
    if key == "level" then av, bv = tonumber(av) or 0, tonumber(bv) or 0
    else av, bv = strlower(av or ""), strlower(bv or "") end
    if av == bv then return strlower(a.name or "") < strlower(b.name or "") end
    if asc then return av < bv else return av > bv end
  end)

  local maxOffset = max(0, #filtered - ROWS)
  scrollOffset = min(scrollOffset, maxOffset)
  self:UpdateRows()
end

function FW:BuildServerQuery(task)
  local f = db.filters
  local parts = {}
  local minL = task and task.minLevel or tonumber(f.minLevel)
  local maxL = task and task.maxLevel or tonumber(f.maxLevel)
  if minL or maxL then
    minL = minL or 1
    maxL = maxL or (MAX_PLAYER_LEVEL or 80)
    if minL > maxL then minL,maxL = maxL,minL end
    if minL == maxL then tinsert(parts, tostring(minL)) else tinsert(parts, minL.."-"..maxL) end
  else
    tinsert(parts, "1-"..tostring(MAX_PLAYER_LEVEL or 80))
  end

  -- n- without quotes is a partial-name match on 3.3.5, unlike an exact quoted name.
  if trim(f.name) ~= "" then tinsert(parts, 'n-'..trim(f.name)) end
  if trim(f.zone) ~= "" then tinsert(parts, 'z-"'..trim(f.zone)..'"') end

  local classFilter = task and task.classFilter or nil
  if classFilter then
    tinsert(parts, 'c-"'..classFilter..'"')
  elseif trim(f.class) ~= "" then
    tinsert(parts, 'c-"'..trim(f.class)..'"')
  end

  local raceFilter = task and task.raceFilter or nil
  if raceFilter then
    tinsert(parts, 'r-"'..raceFilter..'"')
  elseif trim(f.race) ~= "" then
    tinsert(parts, 'r-"'..trim(f.race)..'"')
  end

  if trim(f.includeGuild) ~= "" then tinsert(parts, 'g-"'..trim(f.includeGuild)..'"') end
  return table.concat(parts, " ")
end

local function clearResults()
  results = {}
  resultMap = {}
end

local function addWhoResult(name, guild, level, race, class, zone, classFile)
  if not name then return false end
  local key = strlower(name)
  if resultMap[key] then return false end
  local row = {name=name, guild=guild or "", level=level or 0, race=race or "", class=class or "", zone=zone or "", classFile=classFile}
  resultMap[key] = row
  tinsert(results, row)
  return true
end

function FW:Search(force)
  if scan.active then return end
  local now = GetTime()
  local remaining = SEARCH_COOLDOWN - (now - lastSearchAt)
  if remaining > 0 and not force then
    statusText:SetText(strformat("Ready in %.1fs", remaining))
    return
  end
  resultMode = "quick"
  local q = self:BuildServerQuery()
  lastServerQuery = q
  lastSearchAt = now
  pendingSearch = true
  SetWhoToUI(1)
  SendWho(q)
  statusText:SetText("Quick search…")
  refreshButton:Disable()
end

local function enqueueTask(task)
  tinsert(scan.queue, task)
end

local function splitTask(task)
  local f = db.filters
  if task.minLevel < task.maxLevel then
    local mid = floor((task.minLevel + task.maxLevel) / 2)
    enqueueTask({minLevel=task.minLevel, maxLevel=mid, classFilter=task.classFilter, raceFilter=task.raceFilter})
    enqueueTask({minLevel=mid+1, maxLevel=task.maxLevel, classFilter=task.classFilter, raceFilter=task.raceFilter})
    return true
  end

  if not task.classFilter and trim(f.class) == "" then
    for _,className in ipairs(SCAN_CLASSES) do
      enqueueTask({minLevel=task.minLevel, maxLevel=task.maxLevel, classFilter=className, raceFilter=task.raceFilter})
    end
    return true
  end

  if not task.raceFilter and trim(f.race) == "" then
    for _,raceName in ipairs(SCAN_RACES) do
      enqueueTask({minLevel=task.minLevel, maxLevel=task.maxLevel, classFilter=task.classFilter, raceFilter=raceName})
    end
    return true
  end

  return false
end

local function scanTaskLabel(task)
  if not task then return "" end
  local bits = {}
  if task.minLevel == task.maxLevel then tinsert(bits, "Lv "..task.minLevel) else tinsert(bits, "Lv "..task.minLevel.."-"..task.maxLevel) end
  if task.classFilter then tinsert(bits, task.classFilter) end
  if task.raceFilter then tinsert(bits, task.raceFilter) end
  return table.concat(bits, " • ")
end

function FW:StartFullScan()
  if scan.active then return end
  local f = db.filters
  local minL = tonumber(f.minLevel) or 1
  local maxL = tonumber(f.maxLevel) or (MAX_PLAYER_LEVEL or 80)
  if minL > maxL then minL,maxL=maxL,minL end

  clearResults()
  filtered = {}
  resultMode = "scan"
  lastTotalCount = 0
  scan.active = true
  scan.queue = {}
  scan.waiting = false
  scan.current = nil
  scan.queries = 0
  scan.initialTotal = 0
  scan.unresolved = 0
  scan.nextSendAt = GetTime()
  enqueueTask({minLevel=minL, maxLevel=maxL})
  if fullScanButton then fullScanButton:Disable() end
  if refreshButton then refreshButton:Disable() end
  if cancelScanButton then cancelScanButton:Show() end
  statusText:SetText("Full scan starting…")
  self:ApplyFilters()
end

function FW:CancelFullScan()
  if not scan.active then return end
  scan.active = false
  scan.queue = {}
  scan.waiting = false
  scan.current = nil
  statusText:SetText(strformat("Scan cancelled • %d collected", #results))
  if fullScanButton then fullScanButton:Enable() end
  if cancelScanButton then cancelScanButton:Hide() end
  lastSearchAt = GetTime()
  self:ApplyFilters()
end

function FW:SendNextScanTask()
  if not scan.active or scan.waiting then return end
  local task = table.remove(scan.queue, 1)
  if not task then
    scan.active = false
    scan.current = nil
    statusText:SetText(strformat("Full scan complete • %d collected", #results))
    if fullScanButton then fullScanButton:Enable() end
    if refreshButton then refreshButton:Enable() end
    if cancelScanButton then cancelScanButton:Hide() end
    lastSearchAt = GetTime()
    self:ApplyFilters()
    return
  end

  scan.current = task
  scan.waiting = true
  scan.queries = scan.queries + 1
  local q = self:BuildServerQuery(task)
  lastServerQuery = q
  lastSearchAt = GetTime()
  SetWhoToUI(1)
  SendWho(q)
  statusText:SetText(strformat("Scanning • %d collected • %s", #results, scanTaskLabel(task)))
end

function FW:CaptureWho()
  local num, total = GetNumWhoResults()
  num, total = tonumber(num) or 0, tonumber(total) or 0

  if scan.active and scan.waiting then
    for i=1,min(num,WHO_CAP) do
      local name, guild, level, race, class, zone, classFile = GetWhoInfo(i)
      if name then addWhoResult(name, guild, level, race, class, zone, classFile) end
    end

    if scan.initialTotal == 0 then scan.initialTotal = total end
    local task = scan.current
    scan.waiting = false
    scan.current = nil

    if total > WHO_CAP then
      if not splitTask(task) then
        scan.unresolved = scan.unresolved + 1
      end
    end

    scan.nextSendAt = GetTime() + FULL_SCAN_DELAY
    statusText:SetText(strformat("Scanning • %d/%s collected • %d queued", #results, scan.initialTotal > 0 and tostring(scan.initialTotal) or "?", #scan.queue))
    if frame and frame:IsShown() then hideBlizzardAt = GetTime() + 0.05 end
    self:ApplyFilters()
    return
  end

  clearResults()
  for i=1,min(num,WHO_CAP) do
    local name, guild, level, race, class, zone, classFile = GetWhoInfo(i)
    if name then addWhoResult(name, guild, level, race, class, zone, classFile) end
  end

  pendingSearch = false
  resultMode = "quick"
  lastTotalCount = total
  statusText:SetText("Ready")
  if frame and frame:IsShown() then hideBlizzardAt = GetTime() + 0.05 end
  self:ApplyFilters()
end

local function getTRP3UnitID(name)
  if not name or name == "" then return nil end
  if TRP3_API and TRP3_API.utils and TRP3_API.utils.str and type(TRP3_API.utils.str.unitInfoToID) == "function" then
    local ok, unitID = pcall(TRP3_API.utils.str.unitInfoToID, name)
    if ok and unitID and unitID ~= "" then return unitID end
  end
  -- The Faebright/WotLK TRP3 fork is single-realm and uses character names as IDs.
  return name
end

local function hasTRP3ProfileOpener()
  if not TRP3_API then return false end

  -- Native path used by the WotLK fork itself.
  if TRP3_API.register and type(TRP3_API.register.openPageByUnitID) == "function"
      and TRP3_API.navigation and type(TRP3_API.navigation.openMainFrame) == "function" then
    return true
  end

  -- Conservative compatibility fallbacks for other backports.
  if TRP3_API.register then
    if type(TRP3_API.register.openProfile) == "function" or type(TRP3_API.register.open) == "function" then return true end
  end
  return false
end

local function trpProfileIsKnown(unitID)
  if not (TRP3_API and TRP3_API.register and unitID) then return false end
  local reg = TRP3_API.register

  if type(reg.isUnitIDKnown) == "function" then
    local ok, known = pcall(reg.isUnitIDKnown, unitID)
    if not ok or not known then return false end
  end

  if type(reg.hasProfile) == "function" then
    local ok, profileID = pcall(reg.hasProfile, unitID)
    if not ok or not profileID then return false end
  elseif type(reg.profileExists) == "function" then
    local ok, profile = pcall(reg.profileExists, unitID)
    if not ok or not profile then return false end
  end

  return true
end

local function openTRP3Native(unitID)
  if not unitID or not TRP3_API then return false end
  local reg = TRP3_API.register
  local nav = TRP3_API.navigation
  if not (reg and nav and type(reg.openPageByUnitID) == "function" and type(nav.openMainFrame) == "function") then
    return false
  end
  if not trpProfileIsKnown(unitID) then return false end

  -- This is the same two-step path the fork's own target-frame profile button uses.
  local okFrame = pcall(nav.openMainFrame)
  if not okFrame then return false end
  local okPage = pcall(reg.openPageByUnitID, unitID)
  return okPage
end

local trpRequest = {
  unitID = nil,
  name = nil,
  deadline = 0,
  nextCheck = 0,
}

local trpRequestFrame = CreateFrame("Frame")
trpRequestFrame:Hide()
trpRequestFrame:SetScript("OnUpdate", function(self, elapsed)
  if not trpRequest.unitID then self:Hide() return end
  local now = GetTime()
  if now < trpRequest.nextCheck then return end
  trpRequest.nextCheck = now + 0.20

  if openTRP3Native(trpRequest.unitID) then
    print("|cff9fd4ffFaebrightWho:|r Opened TRP3 profile for |cffffffff"..(trpRequest.name or trpRequest.unitID).."|r.")
    trpRequest.unitID, trpRequest.name = nil, nil
    self:Hide()
    return
  end

  if now >= trpRequest.deadline then
    print("|cff9fd4ffFaebrightWho:|r TRP3 did not receive a profile for |cffffffff"..(trpRequest.name or trpRequest.unitID).."|r. They may not be running a compatible RP addon, or their profile did not answer the request.")
    trpRequest.unitID, trpRequest.name = nil, nil
    self:Hide()
  end
end)

local function tryTRPProfile(name)
  if not name or name == "" or not TRP3_API then return false end
  local unitID = getTRP3UnitID(name)
  if not unitID then return false end

  -- Ask TRP3 to refresh/request this character first. This mirrors the query
  -- TRP3 normally performs when you target or mouse over another player.
  if TRP3_API.r and type(TRP3_API.r.sendQuery) == "function" then
    pcall(TRP3_API.r.sendQuery, unitID)
  end

  -- If TRP3 already knows the profile (common for chat senders), open it now.
  if openTRP3Native(unitID) then
    return true
  end

  -- Otherwise wait briefly for the query response, then open automatically.
  if TRP3_API.register and type(TRP3_API.register.openPageByUnitID) == "function"
      and TRP3_API.navigation and type(TRP3_API.navigation.openMainFrame) == "function"
      and TRP3_API.r and type(TRP3_API.r.sendQuery) == "function" then
    trpRequest.unitID = unitID
    trpRequest.name = name
    trpRequest.deadline = GetTime() + 6.0
    trpRequest.nextCheck = GetTime() + 0.15
    trpRequestFrame:Show()
    print("|cff9fd4ffFaebrightWho:|r Requesting TRP3 profile for |cffffffff"..name.."|r...")
    return true
  end

  -- Compatibility fallbacks for other TRP3 backports. Deliberately no slash
  -- command fallback: this WotLK fork does not implement /trp3 open.
  local reg = TRP3_API.register
  if reg then
    if type(reg.openProfile) == "function" then
      local ok = pcall(reg.openProfile, unitID)
      if ok then return true end
    end
    if type(reg.open) == "function" then
      local ok = pcall(reg.open, unitID)
      if ok then return true end
    end
  end

  return false
end

local menuFrame = CreateFrame("Frame", "FaebrightWhoResultMenu", UIParent, "UIDropDownMenuTemplate")
local function showResultMenu(data)
  if not data then return end
  local menu = {
    {text=data.name, isTitle=true, notCheckable=true},
    {text="Whisper", notCheckable=true, func=function() ChatFrame_SendTell(data.name) end},
    {text="Invite to Group", notCheckable=true, func=function() InviteUnit(data.name) end},
    {text="Target (if nearby)", notCheckable=true, func=function() TargetByName(data.name, true) end},
    {text="Add Friend", notCheckable=true, func=function() AddFriend(data.name) end},
  }
  if hasTRP3ProfileOpener() then
    tinsert(menu, {text="Open TRP3 Profile", notCheckable=true, func=function()
      if not tryTRPProfile(data.name) then print("|cff9fd4ffFaebrightWho:|r Could not hand this character to TRP3. TRP3 is loaded, but FaebrightWho could not use its profile API for "..data.name..".") end
    end})
  end
  tinsert(menu, {text="Cancel", notCheckable=true, func=function() CloseDropDownMenus() end})
  EasyMenu(menu, menuFrame, "cursor", 0, 0, "MENU", 2)
end

local function savePreset(name)
  name = trim(name)
  if name == "" then print("|cff9fd4ffFaebrightWho:|r Enter a preset name first.") return end
  db.presets[name] = copyTable(db.filters)
  print("|cff9fd4ffFaebrightWho:|r Saved preset |cffffffff"..name.."|r.")
end

local presetMenu = CreateFrame("Frame", "FaebrightWhoPresetMenu", UIParent, "UIDropDownMenuTemplate")
local function showPresetMenu()
  local menu = {{text="Saved Presets", isTitle=true, notCheckable=true}}
  local names = {}
  for name in pairs(db.presets) do tinsert(names,name) end
  tsort(names)
  if #names == 0 then
    tinsert(menu, {text="No presets saved", disabled=true, notCheckable=true})
  else
    for _,name in ipairs(names) do
      tinsert(menu, {text=name, hasArrow=true, notCheckable=true, menuList={
        {text="Load", notCheckable=true, func=function() FW:LoadPreset(name) end},
        {text="Delete", notCheckable=true, func=function() db.presets[name]=nil print("|cff9fd4ffFaebrightWho:|r Deleted preset "..name..".") end},
      }})
    end
  end
  EasyMenu(menu, presetMenu, "cursor", 0,0,"MENU",2)
end

function FW:LoadPreset(name)
  local p = db.presets[name]
  if not p then return end
  db.filters = copyTable(p)
  self:SyncFields()
  self:ApplyFilters()
end

function FW:SyncFields()
  local f = db.filters
  for k,e in pairs(fields) do
    if e.SetChecked and type(f[k]) == "boolean" then e:SetChecked(f[k])
    elseif e.SetText and f[k] ~= nil then e:SetText(tostring(f[k])) end
  end
end

function FW:ResetFilters()
  db.filters = copyTable(defaults.filters)
  self:SyncFields()
  self:ApplyFilters()
end

local function updateMinimapButtonPosition()
  if not minimapButton or not db then return end
  local angle = math.rad(db.minimapAngle or 225)
  local radius = 80
  minimapButton:ClearAllPoints()
  minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle)*radius, math.sin(angle)*radius)
end

local function createMinimapButton()
  minimapButton = CreateFrame("Button", "FaebrightWhoMinimapButton", Minimap)
  minimapButton:SetSize(31,31)
  minimapButton:SetFrameStrata("MEDIUM")
  minimapButton:SetFrameLevel(8)
  minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  minimapButton:RegisterForDrag("LeftButton")

  local icon = minimapButton:CreateTexture(nil,"BACKGROUND")
  icon:SetTexture("Interface\\Icons\\INV_Misc_Spyglass_03")
  icon:SetSize(20,20)
  icon:SetPoint("CENTER")
  icon:SetTexCoord(0.08,0.92,0.08,0.92)
  minimapButton.icon = icon

  local border = minimapButton:CreateTexture(nil,"OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  border:SetSize(52,52)
  border:SetPoint("TOPLEFT",0,0)

  local highlight = minimapButton:CreateTexture(nil,"HIGHLIGHT")
  highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
  highlight:SetBlendMode("ADD")
  highlight:SetSize(31,31)
  highlight:SetPoint("CENTER")

  minimapButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self,"ANCHOR_LEFT")
    GameTooltip:AddLine("Faebright Who", ACCENT[1],ACCENT[2],ACCENT[3])
    GameTooltip:AddLine("Left-click: Open / close", 1,1,1)
    GameTooltip:AddLine("Right-click: Full roster scan", 0.75,0.78,0.84)
    GameTooltip:AddLine("Drag: Move around minimap", 0.55,0.60,0.68)
    GameTooltip:Show()
  end)
  minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

  minimapButton:SetScript("OnDragStart", function(self)
    self.dragging = true
    self:SetScript("OnUpdate", function(btn)
      local mx,my = Minimap:GetCenter()
      local scale = Minimap:GetEffectiveScale()
      local cx,cy = GetCursorPosition()
      cx,cy = cx/scale,cy/scale
      local angle = math.deg(math.atan2(cy-my,cx-mx))
      db.minimapAngle = angle
      updateMinimapButtonPosition()
    end)
  end)
  minimapButton:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate",nil)
    self.dragging = false
    self.justDragged = true
  end)
  minimapButton:SetScript("OnClick", function(self,button)
    if self.justDragged then self.justDragged=nil return end
    if button=="RightButton" then
      if not frame:IsShown() then frame:Show() end
      FW:StartFullScan()
    else
      if frame:IsShown() then frame:Hide() else frame:Show(); FW:Search() end
    end
  end)
  updateMinimapButtonPosition()
end

local function createUI()
  -- Migrate the oversized 1.0 window once while preserving user position.
  if db.width == 790 and db.height == 610 then db.width,db.height = 780,560 end

  frame = CreateFrame("Frame", "FaebrightWhoFrame", UIParent)
  frame:SetSize(db.width, db.height)
  frame:SetPoint(db.point, UIParent, db.point, db.x, db.y)
  frame:SetFrameStrata("DIALOG")
  frame:SetClampedToScreen(true)
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", frame.StartMoving)
  frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local p,_,_,x,y = self:GetPoint(1)
    db.point,db.x,db.y = p,x,y
  end)
  makeBackdrop(frame, BG[1],BG[2],BG[3],BG[4])
  tinsert(UISpecialFrames, "FaebrightWhoFrame")

  local titleBar = CreateFrame("Frame", nil, frame)
  titleBar:SetPoint("TOPLEFT",1,-1); titleBar:SetPoint("TOPRIGHT",-1,-1); titleBar:SetHeight(44)
  makeBackdrop(titleBar, 0.05,0.068,0.098,1)
  local title = addText(titleBar, "FAEBRIGHT WHO", 17, ACCENT[1],ACCENT[2],ACCENT[3])
  title:SetPoint("LEFT",14,5)
  local sub = addText(titleBar, "Quick /who when you need it. Full roster scan when you want everyone.", 9, MUTED[1],MUTED[2],MUTED[3])
  sub:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -2)
  local close = makeButton(titleBar, "×", 26,26); close:SetPoint("RIGHT",-10,0); close.label:SetFont(GameFontNormal:GetFont(),17)
  close:SetScript("OnClick", function() frame:Hide() end)

  local filtersPanel = CreateFrame("Frame", nil, frame)
  filtersPanel:SetPoint("TOPLEFT",10,-54); filtersPanel:SetPoint("TOPRIGHT",-10,-54); filtersPanel:SetHeight(142)
  makeBackdrop(filtersPanel, 0.055,0.066,0.09,0.98)

  local specs = {
    {"Name","name",128,false}, {"Min","minLevel",54,true}, {"Max","maxLevel",54,true},
    {"Zone","zone",134,false}, {"Class","class",102,false}, {"Race","race",98,false},
  }
  local last
  for i,spec in ipairs(specs) do
    local h = makeEdit(filtersPanel,spec[1],spec[2],spec[3],spec[4])
    if i==1 then h:SetPoint("TOPLEFT",12,-8) else h:SetPoint("LEFT",last,"RIGHT",7,0) end
    last=h
  end

  local hGuild = makeEdit(filtersPanel,"Include guild","includeGuild",168,false); hGuild:SetPoint("TOPLEFT",12,-53)
  local hEx = makeEdit(filtersPanel,"Exclude guilds  ; separated","excludeGuilds",292,false); hEx:SetPoint("LEFT",hGuild,"RIGHT",7,0)
  local current = makeButton(filtersPanel,"Current Zone",92,22); current:SetPoint("LEFT",hEx,"RIGHT",7,-10)
  current:SetScript("OnClick", function() db.filters.zone=GetZoneText() or ""; fields.zone:SetText(db.filters.zone); FW:ApplyFilters() end)

  local c1 = makeCheck(filtersPanel,"Unguilded","unguildedOnly"); c1:SetPoint("BOTTOMLEFT",10,8)
  local c2 = makeCheck(filtersPanel,"Exclude my guild","excludeMyGuild"); c2:SetPoint("LEFT",c1,"RIGHT",92,0)

  local presetEdit = CreateFrame("EditBox",nil,filtersPanel); presetEdit:SetSize(104,22); presetEdit:SetPoint("LEFT",c2,"RIGHT",128,0); presetEdit:SetAutoFocus(false); presetEdit:SetTextInsets(7,7,0,0); presetEdit:SetFontObject("GameFontHighlightSmall"); makeBackdrop(presetEdit,0.04,0.05,0.07,1)
  presetEdit:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
  presetEdit:SetScript("OnEnterPressed",function(self) savePreset(self:GetText()); self:ClearFocus() end)
  local save = makeButton(filtersPanel,"Save",46,22); save:SetPoint("LEFT",presetEdit,"RIGHT",5,0); save:SetScript("OnClick",function() savePreset(presetEdit:GetText()) end)
  local presets = makeButton(filtersPanel,"Presets ▾",72,22); presets:SetPoint("LEFT",save,"RIGHT",5,0); presets:SetScript("OnClick",showPresetMenu)

  local reset = makeButton(filtersPanel,"Clear",52,22); reset:SetPoint("LEFT",current,"RIGHT",6,0); reset:SetScript("OnClick", function() FW:ResetFilters() end)
  fullScanButton = makeButton(filtersPanel,"Full Scan",76,26); fullScanButton:SetPoint("BOTTOMRIGHT",-86,6)
  fullScanButton:SetScript("OnClick",function() FW:StartFullScan() end)
  refreshButton = makeButton(filtersPanel,"Quick",68,26); refreshButton:SetPoint("BOTTOMRIGHT",-10,6)
  refreshButton:SetScript("OnClick",function() FW:Search() end)
  cancelScanButton = makeButton(filtersPanel,"Cancel",58,22); cancelScanButton:SetPoint("BOTTOMRIGHT",-174,8); cancelScanButton:SetScript("OnClick",function() FW:CancelFullScan() end); cancelScanButton:Hide()
  statusText = addText(filtersPanel,"Ready",9,MUTED[1],MUTED[2],MUTED[3]); statusText:SetPoint("BOTTOMRIGHT",-10,36); statusText:SetWidth(390); statusText:SetJustifyH("RIGHT")

  local listPanel = CreateFrame("Frame",nil,frame)
  listPanel:SetPoint("TOPLEFT",10,-206); listPanel:SetPoint("BOTTOMRIGHT",-10,36); makeBackdrop(listPanel,0.023,0.03,0.044,1)
  resultCountText = addText(listPanel,"0 shown  •  0 received",9,MUTED[1],MUTED[2],MUTED[3]); resultCountText:SetPoint("TOPRIGHT",-10,-8)

  local headers = {
    {"Name","name",8,166,"LEFT"}, {"Lvl","level",178,36,"CENTER"}, {"Guild","guild",218,178,"LEFT"},
    {"Zone","zone",400,158,"LEFT"}, {"Class","class",562,156,"LEFT"},
  }
  for _,h in ipairs(headers) do
    local b=makeButton(listPanel,h[1],h[4],20); b:SetPoint("TOPLEFT",h[3],-24); b.label:SetJustifyH(h[5])
    b:SetScript("OnClick",function()
      if db.sortKey==h[2] then db.sortAsc=not db.sortAsc else db.sortKey=h[2]; db.sortAsc=true end
      FW:ApplyFilters()
    end)
  end

  for i=1,ROWS do
    local row=CreateFrame("Button",nil,listPanel); row:SetHeight(ROW_H); row:SetPoint("TOPLEFT",7,-46-(i-1)*ROW_H); row:SetPoint("TOPRIGHT",-20,-46-(i-1)*ROW_H); makeBackdrop(row,0.038,0.047,0.065,0.86); row:RegisterForClicks("LeftButtonUp","RightButtonUp")
    row.name=addText(row,"",10); row.name:SetPoint("LEFT",7,0); row.name:SetWidth(158); row.name:SetJustifyH("LEFT")
    row.level=addText(row,"",10); row.level:SetPoint("LEFT",170,0); row.level:SetWidth(34); row.level:SetJustifyH("CENTER")
    row.guild=addText(row,"",9); row.guild:SetPoint("LEFT",210,0); row.guild:SetWidth(170); row.guild:SetJustifyH("LEFT")
    row.zone=addText(row,"",9); row.zone:SetPoint("LEFT",392,0); row.zone:SetWidth(150); row.zone:SetJustifyH("LEFT")
    row.class=addText(row,"",9); row.class:SetPoint("LEFT",554,0); row.class:SetWidth(145); row.class:SetJustifyH("LEFT")
    row:SetScript("OnClick",function(self,button)
      if not self.data then return end
      selectedName=self.data.name; FW:UpdateRows()
      if button=="RightButton" then showResultMenu(self.data) end
    end)
    row:SetScript("OnDoubleClick",function(self) if self.data then ChatFrame_SendTell(self.data.name) end end)
    row:SetScript("OnEnter",function(self) if self.data and selectedName~=self.data.name then self:SetBackdropColor(0.085,0.11,0.155,0.96) end end)
    row:SetScript("OnLeave",function() FW:UpdateRows() end)
    rows[i]=row
  end

  local scroll = CreateFrame("Slider",nil,listPanel,"OptionsSliderTemplate")
  scroll:SetOrientation("VERTICAL"); scroll:SetWidth(16); scroll:SetPoint("TOPRIGHT",-3,-47); scroll:SetPoint("BOTTOMRIGHT",-3,7); scroll:SetMinMaxValues(0,0); scroll:SetValueStep(1); scroll:SetValue(0)
  scroll:SetScript("OnValueChanged",function(self,val) scrollOffset=floor(val+0.5); FW:UpdateRows() end)
  listPanel:EnableMouseWheel(true)
  listPanel:SetScript("OnMouseWheel",function(_,delta)
    local maxOffset=max(0,#filtered-ROWS); scrollOffset=max(0,min(maxOffset,scrollOffset-delta*3)); scroll:SetMinMaxValues(0,maxOffset); scroll:SetValue(scrollOffset); FW:UpdateRows()
  end)
  FW.scroll=scroll

  local hint=addText(frame,"Right-click for actions  •  Double-click to whisper  •  /fwho scan = full roster",9,MUTED[1],MUTED[2],MUTED[3]); hint:SetPoint("BOTTOMLEFT",14,13)

  frame:SetScript("OnShow",function() FW:SyncFields(); FW:ApplyFilters() end)
  frame:Hide()
  FW:SyncFields()
  createMinimapButton()
end

function FW:UpdateRows()
  if not frame then return end
  local maxOffset=max(0,#filtered-ROWS)
  if FW.scroll then FW.scroll:SetMinMaxValues(0,maxOffset); FW.scroll:SetValue(min(scrollOffset,maxOffset)) end
  if resultMode == "scan" then
    if scan.active then
      resultCountText:SetText(strformat("%d shown  •  %d collected  •  target %s", #filtered, #results, scan.initialTotal > 0 and tostring(scan.initialTotal) or "?"))
    elseif scan.unresolved and scan.unresolved > 0 then
      resultCountText:SetText(strformat("%d shown  •  %d collected  •  %d capped bucket(s)", #filtered, #results, scan.unresolved))
    else
      resultCountText:SetText(strformat("%d shown  •  %d collected  •  full scan", #filtered, #results))
    end
  elseif lastTotalCount > #results then
    resultCountText:SetText(strformat("%d shown  •  %d returned  •  %d matched", #filtered, #results, lastTotalCount))
  else
    resultCountText:SetText(strformat("%d shown  •  %d returned", #filtered, #results))
  end
  for i=1,ROWS do
    local row=rows[i]; local data=filtered[scrollOffset+i]
    if data then
      row.data=data; row:Show(); row.name:SetText(data.name); row.level:SetText(data.level); row.guild:SetText(data.guild~="" and data.guild or "—"); row.zone:SetText(data.zone); row.class:SetText(data.class)
      if data.classFile and RAID_CLASS_COLORS[data.classFile] then local c=RAID_CLASS_COLORS[data.classFile]; row.class:SetTextColor(c.r,c.g,c.b) else row.class:SetTextColor(0.9,0.9,0.9) end
      if selectedName==data.name then row:SetBackdropColor(0.13,0.22,0.32,0.92) elseif i%2==0 then row:SetBackdropColor(0.055,0.067,0.09,0.82) else row:SetBackdropColor(0.04,0.05,0.07,0.82) end
    else row.data=nil; row:Hide() end
  end
end

FW:RegisterEvent("ADDON_LOADED")
FW:RegisterEvent("WHO_LIST_UPDATE")
FW:SetScript("OnEvent",function(self,event,arg1)
  if event=="ADDON_LOADED" and arg1==ADDON then
    FaebrightWhoDB=FaebrightWhoDB or {}; db=FaebrightWhoDB; applyDefaults(db,defaults); createUI()
    SLASH_FAEBRIGHTWHO1="/fwho"; SLASH_FAEBRIGHTWHO2="/faebrightwho"
    SlashCmdList.FAEBRIGHTWHO=function(msg)
      msg=trim(msg)
      if strlower(msg)=="scan" then
        if not frame:IsShown() then frame:Show() end
        FW:StartFullScan()
        return
      end
      if msg~="" then fields.name:SetText(msg); db.filters.name=msg end
      if frame:IsShown() then frame:Hide() else frame:Show(); FW:Search() end
    end
    -- Preserve normal /who searches, but make bare /who open the polished browser.
    if SlashCmdList.WHO and not FW.originalWhoSlash then
      FW.originalWhoSlash=SlashCmdList.WHO
      SlashCmdList.WHO=function(msg)
        msg=trim(msg)
        if msg=="" then
          if not frame:IsShown() then frame:Show() end
          FW:Search()
        else
          FW.originalWhoSlash(msg)
        end
      end
    end
  elseif event=="WHO_LIST_UPDATE" and db then
    FW:CaptureWho()
  end
end)

FW:SetScript("OnUpdate",function(self,elapsed)
  if hideBlizzardAt and GetTime() >= hideBlizzardAt then
    hideBlizzardAt = nil
    if frame and frame:IsShown() and FriendsFrame and FriendsFrame:IsShown() and WhoFrame and WhoFrame:IsShown() then
      HideUIPanel(FriendsFrame)
    end
  end
  if scan.active and not scan.waiting and GetTime() >= (scan.nextSendAt or 0) then
    FW:SendNextScanTask()
  end
  if not db or not frame or not frame:IsShown() then return end
  if scan.active then
    if refreshButton then refreshButton:Disable() end
    if fullScanButton then fullScanButton:Disable() end
    return
  end
  local remaining=SEARCH_COOLDOWN-(GetTime()-lastSearchAt)
  if remaining<=0 then
    if refreshButton and not refreshButton:IsEnabled() then refreshButton:Enable() end
    if fullScanButton and not fullScanButton:IsEnabled() then fullScanButton:Enable() end
    if statusText and pendingSearch==false and statusText:GetText():find("Ready in") then statusText:SetText("Ready") end
  else
    if refreshButton then refreshButton:Disable() end
    if not pendingSearch and statusText then statusText:SetText(strformat("Ready in %.1fs",remaining)) end
  end
end)
