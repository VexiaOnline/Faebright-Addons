FaebrightWho v1.2.2
===================

A focused replacement-style /who browser for WoW 3.3.5a, designed for RP QoL.

INSTALL
-------
Copy the FaebrightWho folder into:
  World of Warcraft/Interface/AddOns/

Then restart WoW or /reload.

OPEN
----
/fwho
/faebrightwho
/fwho scan      Starts a full roster scan

Bare /who opens FaebrightWho. Normal /who <query> remains available.

SEARCH MODES
------------
QUICK
  Normal server /who search. Fast, but the 3.3.5 /who system caps a result set
  at 49 returned players.

FULL SCAN
  Builds a much larger local roster by automatically subdividing broad /who
  queries into smaller level ranges. If a single level is still capped, it
  subdivides further by class, then race. Every returned player is merged into
  one deduplicated local list.

  The scan is intentionally paced to avoid hammering the server. Results appear
  progressively while the scan is running and remain available for instant
  local filtering/sorting after completion.

  Use Cancel to stop a scan while keeping everything collected so far.

MINIMAP BUTTON
--------------
Left-click: Open / close FaebrightWho
Right-click: Start a Full Scan
Drag: Reposition around the minimap

FEATURES
--------
- Full-roster crawler beyond the normal 49-player /who result cap
- Progressive collected/target display
- Automatic recursive level-range splitting
- Class and race subdivision for crowded single-level buckets
- Session-local merged/deduplicated roster
- Quick search mode
- Name filter
- Level min/max
- Zone filter + Current Zone shortcut
- Class filter
- Race filter
- Include Guild filter
- Exclude one or more guilds (semicolon-separated)
- Unguilded Only toggle
- Exclude My Guild toggle
- Sortable Name / Level / Guild / Zone / Class columns
- Saved presets
- Right-click results: Whisper, Invite, Target if nearby, Add Friend
- TRP3 profile opening through the WotLK fork's native register/navigation API
- Movable compact UI
- Draggable minimap button
- Suppresses the duplicate Blizzard Who window for addon searches

FULL-SCAN NOTES
---------------
The normal WoW 3.3.5 /who interface returns at most 49 players per query. A Full
Scan works around that display/query cap by issuing multiple narrower legal /who
queries and stitching the results together locally.

A scan is a snapshot, not a continuously synchronized census. People can log in,
log out, change zones, or level while it is running, so a very busy server can
produce a small amount of natural drift.

In an unusually dense bucket that is still above 49 after level + class + race
subdivision, FaebrightWho reports a capped bucket rather than pretending the
scan is complete.

EXCLUDE GUILDS
--------------
Enter guild names separated with semicolons, for example:
  Guild One; Guild Two; Guild Three

These exclusions are applied locally to the collected roster.


V1.2.2
------
- Replaced the invalid /trp3 open integration with the exact internal API used
  by the Total-RP-3-WotLK fork itself.
- Opens known profiles through TRP3_API.navigation.openMainFrame() followed by
  TRP3_API.register.openPageByUnitID().
- If a /who player is not cached yet, FaebrightWho asks TRP3 to query them via
  TRP3_API.r.sendQuery(), waits briefly for the response, and opens the profile
  automatically when it arrives.
- Removed the slash-command fallback that caused TRP3 to print its help list.

V1.2.1
------
- Attempted slash-command based TRP3 compatibility. Superseded by v1.2.2.
