-------------------------------------------------------------------------------
-- Rofaetion Configuration
--
-- Creates the Interface Options panel with shared settings and
-- dynamically injected class-specific options.
-------------------------------------------------------------------------------

Rofaetion = Rofaetion or {}

function Rofaetion:CreateCheckButton(name, parent, table, field, radio)
	local button
	if radio then
		button = CreateFrame('CheckButton', parent:GetName() .. name, parent, 'SendMailRadioButtonTemplate')
	else
		button = CreateFrame('CheckButton', parent:GetName() .. name, parent, 'OptionsCheckButtonTemplate')
	end
	local frame = _G[button:GetName() .. 'Text']
	frame:SetText(name)
	frame:SetTextColor(1, 1, 1, 1)
	frame:SetFontObject(GameFontNormal)
	button:SetScript("OnShow",
		function(self)
			self:SetChecked(table[field])
			self.origValue = table[field] or self.origValue
		end
	)
	if radio then
		button:SetScript("OnClick",
			function(self, button, down)
				this:SetChecked(1)
				table[field] = not table[field]
			end
		)
	else
		button:SetScript("OnClick",
			function(self, button, down)
				table[field] = not table[field]
			end
		)
	end

	function button:Restore()
		table[field] = self.origValue
	end
	return button
end

function Rofaetion:CreateSlider(text, parent, low, high, step)
	local name = parent:GetName() .. text
	local slider = CreateFrame('Slider', name, parent, 'OptionsSliderTemplate')
	slider:SetScript('OnMouseWheel', Slider_OnMouseWheel)
	slider:SetMinMaxValues(low, high)
	slider:SetValueStep(step)
	slider:EnableMouseWheel(true)
	_G[name .. 'Text']:SetText(text)
	_G[name .. 'Low']:SetText('')
	_G[name .. 'High']:SetText('')
	local text = slider:CreateFontString(nil, 'BACKGROUND')
	text:SetFontObject('GameFontHighlightSmall')
	text:SetPoint('LEFT', slider, 'RIGHT', 7, 0)
	slider.valText = text
	return slider
end

function Rofaetion:CreateButton(text, parent)
	local name = parent:GetName() .. text
	local button = CreateFrame('Button', name, parent, 'UIPanelButtonTemplate')
	_G[name .. 'Text']:SetText(text)
	local text = button:CreateFontString(nil, 'BACKGROUND')
	text:SetFontObject('GameFontHighlightSmall')
	text:SetPoint('LEFT', button, 'RIGHT', 7, 0)
	button.valText = text
	return button
end

function Rofaetion:CreateDropDownMenu(text, parent, dbTree, varName, itemList, width)
	local name = parent:GetName() .. text
	local menu = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
	menu.displayMode = "MENU"

	local frame = _G[menu:GetName() .. 'Text']
	frame:SetText(text)
	frame:SetTextColor(1, 1, 1, 1)
	frame:SetFontObject(GameFontNormal)

	menu:EnableMouse(true)
	if width then
		_G.UIDropDownMenu_SetWidth(menu, width)
	end
	menu.itemList = itemList or {}
	menu.init = function()
		for i = 1, #menu.itemList do
			if not menu.itemList[i].hooked then
				local func = menu.itemList[i].func or function(self) end
				menu.itemList[i].func = function(self, arg1, arg2)
					self = self or _G.this
					dbTree[varName] = self.value
					_G.UIDropDownMenu_SetSelectedValue(menu, self.value)
					func(self, arg1, arg2)
				end
				menu.itemList[i].hooked = true
			end
			local info = _G.UIDropDownMenu_CreateInfo()
			for k, v in pairs(menu.itemList[i]) do
				info[k] = v
			end
			_G.UIDropDownMenu_AddButton(info, _G.UIDROPDOWNMENU_MENU_LEVEL)
		end
	end
	menu:SetScript("OnShow", function(self)
		_G.UIDropDownMenu_Initialize(self, self.init)
		_G.UIDropDownMenu_SetSelectedValue(self, dbTree[varName])
	end)
	menu.SetValue = function(self, value)
		_G.UIDropDownMenu_SetSelectedValue(self, value)
	end
	menu:Hide()
	menu:Show()
	return menu
end

function Rofaetion:StoreUIValues()
	local prev = Rofaetion.prevDB
	prev.scale = RofaetionDB.scale
	prev.debuffscale = RofaetionDB.debuffscale
	prev.alpha = RofaetionDB.alpha
	prev.debuffalpha = RofaetionDB.debuffalpha
	prev.locked = RofaetionDB.locked
	prev.enabled = RofaetionDB.enabled
	prev.debuffdisabled = RofaetionDB.debuffdisabled
	prev.ThreatWarning = RofaetionDB.ThreatWarning
	prev.x = RofaetionDB.x
	prev.y = RofaetionDB.y
	prev.debuffx = RofaetionDB.debuffx
	prev.debuffy = RofaetionDB.debuffy
	prev.relativePoint = RofaetionDB.relativePoint
	prev.debuffrelativePoint = RofaetionDB.debuffrelativePoint

	-- Store class-specific settings
	if Rofaetion.activeModule and Rofaetion.activeSpec then
		local key = Rofaetion.activeModule.englishClass .. "_" .. Rofaetion.activeSpec
		prev.classConfig = prev.classConfig or {}
		prev.classConfig[key] = prev.classConfig[key] or {}
		if RofaetionDB.classConfig and RofaetionDB.classConfig[key] then
			for k, v in pairs(RofaetionDB.classConfig[key]) do
				prev.classConfig[key][k] = v
			end
		end
	end
end

function Rofaetion:ReStoreUIValues()
	local prev = Rofaetion.prevDB
	RofaetionDB.scale = prev.scale
	RofaetionDB.alpha = prev.alpha
	RofaetionDB.debuffscale = prev.debuffscale
	RofaetionDB.debuffalpha = prev.debuffalpha
	RofaetionDB.locked = prev.locked
	RofaetionDB.enabled = prev.enabled
	RofaetionDB.debuffdisabled = prev.debuffdisabled
	RofaetionDB.ThreatWarning = prev.ThreatWarning
	RofaetionDB.x = prev.x
	RofaetionDB.y = prev.y
	RofaetionDB.debuffx = prev.debuffx
	RofaetionDB.debuffy = prev.debuffy
	RofaetionDB.relativePoint = prev.relativePoint
	RofaetionDB.debuffrelativePoint = prev.debuffrelativePoint

	if Rofaetion.activeModule and Rofaetion.activeSpec then
		local key = Rofaetion.activeModule.englishClass .. "_" .. Rofaetion.activeSpec
		if prev.classConfig and prev.classConfig[key] then
			RofaetionDB.classConfig = RofaetionDB.classConfig or {}
			RofaetionDB.classConfig[key] = {}
			for k, v in pairs(prev.classConfig[key]) do
				RofaetionDB.classConfig[key][k] = v
			end
		end
	end
end

function Rofaetion:GetClassConfig(key)
	RofaetionDB.classConfig = RofaetionDB.classConfig or {}
	local classKey = Rofaetion.activeModule.englishClass .. "_" .. Rofaetion.activeSpec
	RofaetionDB.classConfig[classKey] = RofaetionDB.classConfig[classKey] or {}
	return RofaetionDB.classConfig[classKey]
end

function Rofaetion:CreateConfig()
	Rofaetion.configPanel = CreateFrame("Frame", "RofaetionConfigPanel", UIParent)
	Rofaetion.configPanel.name = "Rofaetion"

	local L = Rofaetion.Locals

	-- Base settings
	local EnableBtn = Rofaetion:CreateCheckButton(L.CONFIG_ENABLED, Rofaetion.configPanel, RofaetionDB, "enabled", false)
	EnableBtn:SetPoint('TOPLEFT', 10, -8)

	local LockBtn = Rofaetion:CreateCheckButton(L.CONFIG_LOCK_FRAMES, Rofaetion.configPanel, RofaetionDB, "locked", false)
	LockBtn:SetPoint('TOPLEFT', 10, -38)

	local Scale = Rofaetion:CreateSlider(L.CONFIG_SPELL_ADV_SCALE, Rofaetion.configPanel, 0.25, 3, 0.1)
	Scale:SetScript('OnShow', function(self)
		self.onShow = true
		Rofaetion:StoreUIValues()
		self:SetValue(RofaetionDB.scale)
		self.onShow = nil
	end)
	Scale:SetScript('OnValueChanged', function(self, value)
		self.valText:SetText(format('%.1f', value))
		if not self.onShow then
			RofaetionDB.scale = value
			Rofaetion.displayFrame:SetScale(value)
		end
	end)
	Scale:SetPoint("TOPLEFT", 10, -78)
	Scale:Show()

	local Alpha = Rofaetion:CreateSlider(L.CONFIG_SPELL_ADV_ALPHA, Rofaetion.configPanel, 0.0, 1, 0.1)
	Alpha:SetScript('OnShow', function(self)
		self.onShow = true
		self:SetValue(RofaetionDB.alpha)
		self.onShow = nil
	end)
	Alpha:SetScript('OnValueChanged', function(self, value)
		self.valText:SetText(format('%.1f', value))
		if not self.onShow then
			RofaetionDB.alpha = value
			Rofaetion.displayFrame:SetAlpha(value)
		end
	end)
	Alpha:SetPoint("TOPLEFT", 10, -118)
	Alpha:Show()

	local DebuffDisableBtn = Rofaetion:CreateCheckButton(L.CONFIG_DISABLE_DEBUFF_TRACKER, Rofaetion.configPanel, RofaetionDB, "debuffdisabled", false)
	DebuffDisableBtn:SetPoint('TOPLEFT', 10, -138)

	local DebuffScale = Rofaetion:CreateSlider(L.CONFIG_DEBUFF_TRACKER_SCALE, Rofaetion.configPanel, 0.25, 3, 0.1)
	DebuffScale:SetScript('OnShow', function(self)
		self.onShow = true
		Rofaetion:StoreUIValues()
		self:SetValue(RofaetionDB.debuffscale)
		self.onShow = nil
	end)
	DebuffScale:SetScript('OnValueChanged', function(self, value)
		self.valText:SetText(format('%.1f', value))
		if not self.onShow then
			RofaetionDB.debuffscale = value
			Rofaetion.debuffTracker:SetScale(value)
		end
	end)
	DebuffScale:SetPoint("TOPLEFT", 10, -178)
	DebuffScale:Show()

	local DebuffAlpha = Rofaetion:CreateSlider(L.CONFIG_DEBUFF_TRACKER_ALPHA, Rofaetion.configPanel, 0.0, 1, 0.1)
	DebuffAlpha:SetScript('OnShow', function(self)
		self.onShow = true
		self:SetValue(RofaetionDB.debuffalpha)
		self.onShow = nil
	end)
	DebuffAlpha:SetScript('OnValueChanged', function(self, value)
		self.valText:SetText(format('%.1f', value))
		if not self.onShow then
			RofaetionDB.debuffalpha = value
			Rofaetion.debuffTracker:SetAlpha(value)
		end
	end)
	DebuffAlpha:SetPoint("TOPLEFT", 10, -218)
	DebuffAlpha:Show()

	local ThreatWarnBtn = Rofaetion:CreateCheckButton(L.CONFIG_THREAT_WARNING, Rofaetion.configPanel, RofaetionDB, "ThreatWarning", false)
	ThreatWarnBtn:SetPoint('TOPLEFT', 10, -238)

	local ResetBtn = Rofaetion:CreateButton(L.CONFIG_RESET_POSITIONS, Rofaetion.configPanel)
	ResetBtn:SetWidth(160)
	ResetBtn:SetHeight(22)
	ResetBtn:SetScript('OnClick', function()
		Rofaetion:ResetPosition()
	end)
	ResetBtn:SetPoint("TOPLEFT", 10, -268)
	ResetBtn:Show()

	-- Class-specific options section
	local classOptionsYOffset = -298

	if Rofaetion.activeModule and Rofaetion.activeModule.configOptions then
		local spec = Rofaetion.activeModule.specs[Rofaetion.activeSpec]
		local options = (spec and spec.configOptions) or Rofaetion.activeModule.configOptions
		if options then
			local header = Rofaetion.configPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
			header:SetText(L.CONFIG_CLASS_OPTIONS .. ": " .. Rofaetion.activeModule.className .. (spec and (" - " .. spec.name) or ""))
			header:SetPoint('TOPLEFT', 10, classOptionsYOffset)
			classOptionsYOffset = classOptionsYOffset - 20

			local cfg = Rofaetion:GetClassConfig()

			for _, opt in ipairs(options) do
				if opt.type == "checkbox" then
					if not cfg[opt.key] and cfg[opt.key] ~= false then
						cfg[opt.key] = opt.default
					end
					local btn = Rofaetion:CreateCheckButton(opt.label, Rofaetion.configPanel, cfg, opt.key, false)
					btn:SetPoint('TOPLEFT', 10, classOptionsYOffset)
					classOptionsYOffset = classOptionsYOffset - 20
				elseif opt.type == "dropdown" then
					if not cfg[opt.key] then
						cfg[opt.key] = opt.default
					end
					local items = {}
					for _, v in ipairs(opt.options) do
						table.insert(items, { text = v })
					end
					local menu = Rofaetion:CreateDropDownMenu(opt.label, Rofaetion.configPanel, cfg, opt.key, items, 200)
					menu:SetPoint('TOPLEFT', 10, classOptionsYOffset)
					classOptionsYOffset = classOptionsYOffset - 30
				end
			end
		end
	end

	Rofaetion.configPanel.okay = function()
		Rofaetion:ApplySettings()
	end
	Rofaetion.configPanel.cancel = function()
		Rofaetion:ReStoreUIValues()
		Rofaetion:ApplySettings()
	end
	Rofaetion.configPanel.default = function()
		RofaetionDB.scale = 1
		RofaetionDB.debuffscale = 1
		RofaetionDB.locked = false
		RofaetionDB.enabled = true
		RofaetionDB.debuffdisabled = false
		RofaetionDB.alpha = 0.8
		RofaetionDB.debuffalpha = 1
		RofaetionDB.ThreatWarning = true
		RofaetionDB.x = -200
		RofaetionDB.y = -200
		RofaetionDB.relativePoint = "CENTER"
		RofaetionDB.debuffx = -200
		RofaetionDB.debuffy = -100
		RofaetionDB.debuffrelativePoint = "CENTER"
	end

	Rofaetion.configPanel:SetScript('OnShow', function(self)
		self.onShow = true
		Rofaetion:DecideSpells()
		self.onShow = nil
	end)
	Rofaetion.configPanel:SetScript('OnHide', function(self)
		self.onHide = true
		Rofaetion:DecideSpells()
		self.onHide = nil
	end)

	InterfaceOptions_AddCategory(Rofaetion.configPanel)
end

function Rofaetion.Options()
	InterfaceOptionsFrame_OpenToCategory(getglobal("RofaetionConfigPanel"))
end
