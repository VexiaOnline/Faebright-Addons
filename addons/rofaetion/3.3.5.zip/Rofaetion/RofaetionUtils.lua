-------------------------------------------------------------------------------
-- Rofaetion Utility Functions
--
-- Shared helper functions used by all class modules.
-------------------------------------------------------------------------------

Rofaetion = Rofaetion or {}
Rofaetion.Locals = Rofaetion.Locals or {}
Rofaetion.classModules = {}

function Rofaetion:RegisterClass(module)
	for specIndex, spec in pairs(module.specs) do
		if spec.spellList then
			for key, val in pairs(spec.spellList) do
				if type(val) == "number" then
					local name = GetSpellInfo(val)
					spec.spellList[key] = name or key
				end
			end
		end
	end
	Rofaetion.classModules[module.englishClass] = module
end

function Rofaetion:Debug(statictxt, msg)
	if Rofaetion.DebugMode then
		if msg then
			DEFAULT_CHAT_FRAME:AddMessage("ROFDBG: " .. statictxt .. " : " .. msg)
		else
			DEFAULT_CHAT_FRAME:AddMessage("ROFDBG: " .. statictxt .. " : <nil>")
		end
	end
end

function Rofaetion:GetSpellCooldownRemaining(spell)
	if not spell then return 0 end
	local s, d, _ = GetSpellCooldown(spell)
	if d and d > 0 then
		d = s - GetTime() + d
	end
	return d or 0
end

function Rofaetion:hasDeBuff(unit, spellName, casterUnit)
	if not spellName then return nil end
	local i = 1
	while true do
		local name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable = UnitDebuff(unit, i)
		if not name then break end
		if string.match(name, spellName) and ((unitCaster == casterUnit) or (casterUnit == nil)) then
			return name, rank, icon, count, debuffType, duration, expirationTime, unitCaster, isStealable
		end
		i = i + 1
	end
	return nil
end

function Rofaetion:hasBuff(unit, spellName, stealableOnly, getByID)
	if not spellName and not getByID then return nil end
	local i = 1
	while true do
		local name, rank, icon, count, buffType, duration, expirationTime, source, isStealable, shouldConsolidate, spellId = UnitBuff(unit, i)
		if not name then break end
		if not getByID then
			if string.match(name, spellName) then
				if (not stealableOnly) or isStealable then
					return name, rank, icon, count, buffType, duration, expirationTime, source, isStealable
				end
			end
		else
			if getByID == spellId then
				return name, rank, icon, count, buffType, duration, expirationTime, source, isStealable
			end
		end
		i = i + 1
	end
	return nil
end

function Rofaetion:hasTotem(unit, spellName)
	if not spellName then return nil end
	local i = 1
	while true do
		local name, rank, icon, count, buffType, duration, expirationTime, source, isStealable = UnitBuff(unit, i)
		if not name then break end
		if (string.match(name, spellName) or string.match(icon, spellName)) and expirationTime == 0 then
			return name, rank, icon, count, buffType, duration, expirationTime, source, isStealable
		end
		i = i + 1
	end
	return nil
end

function Rofaetion:SpellAvailable(spell)
	if not spell then return false end
	local u, m = IsUsableSpell(spell)
	if u then return true end
	return false
end

function Rofaetion:PlayerInParty()
	if GetNumRaidMembers() > 0 then
		return 2
	elseif GetNumPartyMembers() > 0 then
		return 1
	else
		return 0
	end
end

function Rofaetion:HighDMGFormat(dmg_amount)
	if dmg_amount >= 10000 then
		return format('%.1f', dmg_amount / 1000) .. "K"
	else
		return format('%.f', dmg_amount)
	end
end

function Rofaetion:PurgePersonTable()
	for i, v in pairs(Rofaetion.person["foe"]) do
		if time() - v > 2 then
			Rofaetion.person["foe"][i] = 0
			Rofaetion.person["foeCount"] = Rofaetion.person["foeCount"] - 1
		end
	end
	for i, v in pairs(Rofaetion.person["friend"]) do
		if GetTime() - v > 2 then
			Rofaetion.person["friend"][i] = 0
			Rofaetion.person["friendCount"] = Rofaetion.person["friendCount"] - 1
		end
	end
	Rofaetion.lastPersonTablePurged = GetTime()
end

function Rofaetion:CountPerson(time, event, sguid, sname, sflags, dguid, dname, dflags)
	local suffix = event:match(".+(_.-)$")
	local stype = (tonumber(sguid:sub(5, 5), 16)) % 8
	local dtype = (tonumber(dguid:sub(5, 5), 16)) % 8
	if Rofaetion.HostileFilter[suffix] then
		if (bit.band(sflags, COMBATLOG_OBJECT_AFFILIATION_MASK) < 8) and ((dtype == 0) or (dtype == 3)) then
			if (not Rofaetion.person["foe"][dguid]) or (Rofaetion.person["foe"][dguid] == 0) then
				Rofaetion.person["foeCount"] = Rofaetion.person["foeCount"] + 1
			end
			Rofaetion.person["foe"][dguid] = time
		elseif (bit.band(dflags, COMBATLOG_OBJECT_AFFILIATION_MASK) < 8) and ((stype == 0) or (stype == 3)) then
			if (not Rofaetion.person["foe"][sguid]) or (Rofaetion.person["foe"][sguid] == 0) then
				Rofaetion.person["foeCount"] = Rofaetion.person["foeCount"] + 1
			end
			Rofaetion.person["foe"][sguid] = time
		end
		if (bit.band(sflags, COMBATLOG_OBJECT_AFFILIATION_MASK) >= 8) and ((dtype == 0) or (dtype == 3)) then
			if (not Rofaetion.person["friend"][dguid]) or (Rofaetion.person["friend"][dguid] == 0) then
				Rofaetion.person["friendCount"] = Rofaetion.person["friendCount"] + 1
			end
			Rofaetion.person["friend"][dguid] = time
		elseif (bit.band(dflags, COMBATLOG_OBJECT_AFFILIATION_MASK) >= 8) and ((stype == 0) or (stype == 3)) then
			if (not Rofaetion.person["friend"][sguid]) or (Rofaetion.person["friend"][sguid] == 0) then
				Rofaetion.person["friendCount"] = Rofaetion.person["friendCount"] + 1
			end
			Rofaetion.person["friend"][sguid] = time
		end
	end
	if (Rofaetion.lastPersonTablePurged < (GetTime() - 3)) and (Rofaetion.person["foeCount"] > 0) then
		Rofaetion:PurgePersonTable()
	end
end
