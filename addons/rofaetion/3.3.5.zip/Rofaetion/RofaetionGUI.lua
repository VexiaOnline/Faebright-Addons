-------------------------------------------------------------------------------
-- Rofaetion GUI
--
-- Creates and manages all display frames: spell advisor, debuff tracker,
-- cooldown overlays, and DPS/threat text.
-------------------------------------------------------------------------------

Rofaetion = Rofaetion or {}

Rofaetion.textureList = {
	["next"]  = nil,
	["next1"] = nil,
	["next2"] = nil,
	["Misc"]  = nil,
	["int"]   = nil,
	["debuff"] = nil,
}

Rofaetion.textList = {
	["dps"]    = nil,
	["debuff"] = nil,
}

function Rofaetion:CreateGUI()
	local displayFrame = CreateFrame("Frame", "RofaetionDisplayFrame", UIParent)
	displayFrame:SetFrameStrata("BACKGROUND")
	displayFrame:SetWidth(150)
	displayFrame:SetHeight(120)
	displayFrame:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", tile = true, tileSize = 32,
	})
	displayFrame:SetBackdropColor(0, 0, 0, 0)

	if not RofaetionDB.locked then
		displayFrame:SetBackdropColor(0, 0, 0, 0.3)
		displayFrame:EnableMouse(true)
		displayFrame:SetMovable(true)
		displayFrame:SetClampedToScreen(true)
		displayFrame:SetScript("OnMouseDown", function(self) self:StartMoving(); self:SetBackdropColor(0, 0, 0, 0.6) end)
		displayFrame:SetScript("OnMouseUp", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.x = x
			RofaetionDB.y = y
			RofaetionDB.relativePoint = rp
		end)
		displayFrame:SetScript("OnDragStop", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.x = x
			RofaetionDB.y = y
			RofaetionDB.relativePoint = rp
		end)
	end
	displayFrame:SetPoint(RofaetionDB.relativePoint, RofaetionDB.x, RofaetionDB.y)

	-- Sub-frames for spell icons
	local displayFrame_next  = CreateFrame("Frame", "$parent_next", RofaetionDisplayFrame)
	local displayFrame_next1 = CreateFrame("Frame", "$parent_next1", RofaetionDisplayFrame)
	local displayFrame_next2 = CreateFrame("Frame", "$parent_next2", RofaetionDisplayFrame)
	local displayFrame_misc  = CreateFrame("Frame", "$parent_misc", RofaetionDisplayFrame)
	local displayFrame_int   = CreateFrame("Frame", "$parent_int", RofaetionDisplayFrame)
	local displayFrame_dps   = CreateFrame("Frame", "$parent_dps", RofaetionDisplayFrame)

	displayFrame_next:SetWidth(60)
	displayFrame_next1:SetWidth(40)
	displayFrame_next2:SetWidth(20)
	displayFrame_misc:SetWidth(40)
	displayFrame_int:SetWidth(40)
	displayFrame_dps:SetWidth(60)

	displayFrame_next:SetFrameLevel(10)
	displayFrame_next1:SetFrameLevel(5)
	displayFrame_next2:SetFrameLevel(0)

	displayFrame_next:SetHeight(60)
	displayFrame_next1:SetHeight(40)
	displayFrame_next2:SetHeight(20)
	displayFrame_misc:SetHeight(40)
	displayFrame_int:SetHeight(40)
	displayFrame_dps:SetHeight(30)

	displayFrame_next:SetPoint("TOPLEFT", 45, -30)
	displayFrame_next1:SetPoint("TOPLEFT", 55, -10)
	displayFrame_next2:SetPoint("TOPLEFT", 65, 0)
	displayFrame_misc:SetPoint("TOPLEFT", 0, -80)
	displayFrame_int:SetPoint("TOPLEFT", 110, -80)
	displayFrame_dps:SetPoint("TOPLEFT", 45, -90)

	-- Textures
	local t

	t = displayFrame_next:CreateTexture(nil, "BACKGROUND")
	t:SetTexture(nil)
	t:SetAllPoints(displayFrame_next)
	t:SetAlpha(1)
	displayFrame_next.texture = t
	Rofaetion.textureList["next"] = t

	t = displayFrame_next1:CreateTexture(nil, "BACKGROUND")
	t:SetTexture(nil)
	t:SetAllPoints(displayFrame_next1)
	t:SetAlpha(0.7)
	displayFrame_next1.texture = t
	Rofaetion.textureList["next1"] = t

	t = displayFrame_next2:CreateTexture(nil, "BACKGROUND")
	t:SetTexture(nil)
	t:SetAllPoints(displayFrame_next2)
	t:SetAlpha(0.5)
	displayFrame_next2.texture = t
	Rofaetion.textureList["next2"] = t

	t = displayFrame_misc:CreateTexture(nil, "BACKGROUND")
	t:SetTexture(nil)
	t:SetAllPoints(displayFrame_misc)
	t:SetAlpha(1)
	displayFrame_misc.texture = t
	Rofaetion.textureList["Misc"] = t

	t = displayFrame_int:CreateTexture(nil, "BACKGROUND")
	t:SetTexture(nil)
	t:SetAllPoints(displayFrame_int)
	t:SetAlpha(1)
	displayFrame_int.texture = t
	Rofaetion.textureList["int"] = t

	t = displayFrame_dps:CreateFontString("$parentText", "ARTWORK", "GameFontNormal")
	t:SetAllPoints(displayFrame_dps)
	t:SetAlpha(1)
	t:SetText("")
	Rofaetion.textList["dps"] = t

	-- OnUpdate script
	displayFrame:SetScript("OnUpdate", function(this, elapsed)
		Rofaetion:OnUpdate(elapsed)
	end)

	-- Cooldown overlay on main spell
	local cooldownFrame = CreateFrame("Cooldown", "$parent_cooldown", RofaetionDisplayFrame, "CooldownFrameTemplate")
	cooldownFrame:SetHeight(60)
	cooldownFrame:SetWidth(60)
	cooldownFrame:ClearAllPoints()
	cooldownFrame:SetPoint("CENTER", displayFrame_next, "CENTER", 0, 0)

	displayFrame:SetAlpha(RofaetionDB.alpha)

	Rofaetion.displayFrame = displayFrame
	Rofaetion.displayFrame_next = displayFrame_next
	Rofaetion.displayFrame_next1 = displayFrame_next1
	Rofaetion.displayFrame_next2 = displayFrame_next2
	Rofaetion.displayFrame_misc = displayFrame_misc
	Rofaetion.displayFrame_int = displayFrame_int
	Rofaetion.displayFrame_dps = displayFrame_dps
	Rofaetion.cooldownFrame = cooldownFrame

	-- Debuff tracker frame
	local debuffTracker = CreateFrame("Frame", "RofaetionDebuffTrackerFrame", UIParent)
	debuffTracker:SetFrameStrata("BACKGROUND")
	debuffTracker:SetWidth(50)
	debuffTracker:SetHeight(50)
	debuffTracker:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", tile = true, tileSize = 32,
	})
	debuffTracker:SetBackdropColor(0, 0, 0, 0)
	if not RofaetionDB.locked then
		debuffTracker:SetBackdropColor(0, 0, 0, 0.3)
		debuffTracker:EnableMouse(true)
		debuffTracker:SetMovable(true)
		debuffTracker:SetClampedToScreen(true)
		debuffTracker:SetScript("OnMouseDown", function(self) self:StartMoving(); self:SetBackdropColor(0, 0, 0, 0.6) end)
		debuffTracker:SetScript("OnMouseUp", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.debuffx = x
			RofaetionDB.debuffy = y
			RofaetionDB.debuffrelativePoint = rp
		end)
		debuffTracker:SetScript("OnDragStop", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.debuffx = x
			RofaetionDB.debuffy = y
			RofaetionDB.debuffrelativePoint = rp
		end)
	end
	debuffTracker:SetPoint(RofaetionDB.debuffrelativePoint, RofaetionDB.debuffx, RofaetionDB.debuffy)

	t = debuffTracker:CreateFontString("$parentDebuffText", "OVERLAY", "GameFontNormalLarge")
	t:SetAllPoints(debuffTracker)
	t:SetAlpha(1)
	t:SetText("")
	Rofaetion.textList["debuff"] = t

	local debuffTracker_cd = CreateFrame("Frame", "$parent_debuff", RofaetionDebuffTrackerFrame)
	debuffTracker_cd:SetWidth(50)
	debuffTracker_cd:SetHeight(50)
	debuffTracker_cd:SetPoint("CENTER", 0, 0)
	t = debuffTracker_cd:CreateTexture(nil, "BACKGROUND")
	t:SetTexture(nil)
	t:SetAllPoints(debuffTracker_cd)
	t:SetAlpha(1)
	debuffTracker_cd.texture = t
	Rofaetion.textureList["debuff"] = t

	local debuffCooldownFrame = CreateFrame("Cooldown", "$parent_debuffcooldown", RofaetionDebuffTrackerFrame, "CooldownFrameTemplate")
	debuffCooldownFrame:SetHeight(50)
	debuffCooldownFrame:SetWidth(50)
	debuffCooldownFrame:ClearAllPoints()
	debuffCooldownFrame:SetPoint("CENTER", debuffTracker, "CENTER", 0, 0)

	debuffTracker:SetAlpha(RofaetionDB.debuffalpha)

	Rofaetion.debuffTracker = debuffTracker
	Rofaetion.debuffCooldownFrame = debuffCooldownFrame

	DEFAULT_CHAT_FRAME:AddMessage("Rofaetion " .. Rofaetion.versionNumber .. " loaded")
end

function Rofaetion:UpdateDebuffTracker()
	if not Rofaetion.activeModule then return end
	local spec = Rofaetion.activeModule.specs[Rofaetion.activeSpec]
	if not spec or not spec.debuffTrackerSpell then
		Rofaetion.textureList["debuff"]:SetTexture(nil)
		Rofaetion.textList["debuff"]:SetText("")
		Rofaetion.debuffCooldownFrame:SetCooldown(0, 0)
		return
	end

	local spellName
	if type(spec.debuffTrackerSpell) == "function" then
		spellName = spec.debuffTrackerSpell()
	else
		spellName = spec.spellList and spec.spellList[spec.debuffTrackerSpell]
		if not spellName then spellName = spec.debuffTrackerSpell end
	end

	if not spellName then
		Rofaetion.textureList["debuff"]:SetTexture(nil)
		Rofaetion.textList["debuff"]:SetText("")
		Rofaetion.debuffCooldownFrame:SetCooldown(0, 0)
		return
	end

	local name, _, icon, _, _, d, e = Rofaetion:hasDeBuff("target", spellName, "player")
	Rofaetion.debuffTrackerUpdate = GetTime()

	if name then
		Rofaetion.textureList["debuff"]:SetTexture(icon)
		if not Rofaetion.OmniCC then
			Rofaetion.textList["debuff"]:SetText(format('%.1f', (e - GetTime())))
		end
		Rofaetion.debuffCooldownFrame:SetCooldown(e - d, d)
	else
		Rofaetion.textureList["debuff"]:SetTexture(nil)
		Rofaetion.textList["debuff"]:SetText("")
		Rofaetion.debuffCooldownFrame:SetCooldown(0, 0)
	end
end

function Rofaetion:SetSpellOutOfRange(texture, isOutOfRange, baseAlpha)
	if isOutOfRange then
		texture:SetDesaturated(true)
		texture:SetVertexColor(1, 0.2, 0.2)
		texture:SetAlpha(baseAlpha * 0.6)
	else
		texture:SetDesaturated(false)
		texture:SetVertexColor(1, 1, 1)
		texture:SetAlpha(baseAlpha)
	end
end

function Rofaetion:DecideSpells()
	Rofaetion.timeSinceLastUpdate = 0
	local currentTime = GetTime()

	local guid = UnitGUID("target")
	if UnitName("target") == nil or UnitIsFriend("player", "target") ~= nil or UnitHealth("target") == 0 then
		guid = nil
	end

	-- Hide everything if in vehicle or no valid target
	if UnitInVehicle("player") or not guid or UnitHealth("target") == 0 then
		Rofaetion.textureList["next"]:SetTexture(nil)
		Rofaetion.textureList["next1"]:SetTexture(nil)
		Rofaetion.textureList["next2"]:SetTexture(nil)
		Rofaetion.textureList["Misc"]:SetTexture(nil)
		Rofaetion.textureList["int"]:SetTexture(nil)
		return
	end

	if not Rofaetion.activeModule or not Rofaetion.activeSpec then
		Rofaetion.textureList["next"]:SetTexture(nil)
		Rofaetion.textureList["next1"]:SetTexture(nil)
		Rofaetion.textureList["next2"]:SetTexture(nil)
		Rofaetion.textureList["Misc"]:SetTexture(nil)
		Rofaetion.textureList["int"]:SetTexture(nil)
		return
	end

	local spec = Rofaetion.activeModule.specs[Rofaetion.activeSpec]
	if not spec then return end

	-- Eclipse state cleanup (once per frame, not inside nextSpell)
	if Rofaetion.eclipseProc and Rofaetion.eclipseProc.expiry <= currentTime then
		Rofaetion.lastEclipseType = Rofaetion.eclipseProc.type
		Rofaetion.eclipseProc = nil
	end

	-- Main spell
	local spell, oor = spec:nextSpell()
	if not spell then spell = "" end
	local d = Rofaetion:GetSpellCooldownRemaining(spell)
	if d and d > 0 then
		local cdStart = currentTime - Rofaetion.lastBaseGCD + d
		if cdStart and Rofaetion.lastBaseGCD then
			Rofaetion.cooldownFrame:SetCooldown(cdStart, Rofaetion.lastBaseGCD)
		end
	end
	Rofaetion.textureList["next"]:SetTexture(GetSpellTexture(spell))
	Rofaetion:SetSpellOutOfRange(Rofaetion.textureList["next"], oor, 1)

	-- Next spell prediction (2-deep)
	local _, _, _, _, _, _, ct1 = GetSpellInfo(spell)
	if not ct1 then ct1 = 0 else ct1 = ct1 / 1000 end
	local spell1, oor1 = spec:nextSpell(ct1, spell)
	if not spell1 then spell1 = "" end
	Rofaetion.textureList["next1"]:SetTexture(GetSpellTexture(spell1))
	Rofaetion:SetSpellOutOfRange(Rofaetion.textureList["next1"], oor1, 0.7)

	local _, _, _, _, _, _, ct2 = GetSpellInfo(spell1)
	if not ct2 then ct2 = 0 else ct2 = ct2 / 1000 end
	if not ct2 or ct2 < Rofaetion.lastBaseGCD then
		ct2 = Rofaetion.lastBaseGCD
	end
	local spell2, oor2 = spec:nextSpell(ct1 + ct2, spell, spell1)
	if not spell2 then spell2 = "" end
	Rofaetion.textureList["next2"]:SetTexture(GetSpellTexture(spell2))
	Rofaetion:SetSpellOutOfRange(Rofaetion.textureList["next2"], oor2, 0.5)

	-- Misc spell (buffs/utility)
	local miscSpell, miscIcon = spec:miscSpell()
	if miscIcon then
		Rofaetion.textureList["Misc"]:SetTexture(miscIcon)
	elseif miscSpell then
		Rofaetion.textureList["Misc"]:SetTexture(GetSpellTexture(miscSpell))
	else
		Rofaetion.textureList["Misc"]:SetTexture(nil)
	end

	-- Interrupt spell
	local intSpell = spec:intSpell() or ""
	Rofaetion.textureList["int"]:SetTexture(GetSpellTexture(intSpell))
end

function Rofaetion:OnUpdate(elapsed)
	if Rofaetion:isEnabled() then
		Rofaetion.timeSinceLastUpdate = Rofaetion.timeSinceLastUpdate + elapsed

		if Rofaetion.timeSinceLastUpdate > (1.5 - (1.5 * Rofaetion.spellHaste * 0.01)) * 0.3 then
			Rofaetion:DecideSpells()
		end
		if not RofaetionDB.debuffdisabled then
			Rofaetion.debuffTrackerUpdate = Rofaetion.debuffTrackerUpdate + elapsed
			if Rofaetion.debuffTrackerUpdate >= 1 then
				Rofaetion:UpdateDebuffTracker()
			end
		end
	end
end

function Rofaetion:ResetPosition()
	RofaetionDB.x = -200
	RofaetionDB.y = -200
	RofaetionDB.relativePoint = "CENTER"
	RofaetionDB.debuffx = -200
	RofaetionDB.debuffy = -100
	RofaetionDB.debuffrelativePoint = "CENTER"
	Rofaetion.displayFrame:ClearAllPoints()
	Rofaetion.displayFrame:SetPoint(RofaetionDB.relativePoint, RofaetionDB.x, RofaetionDB.y)
	Rofaetion.debuffTracker:ClearAllPoints()
	Rofaetion.debuffTracker:SetPoint(RofaetionDB.debuffrelativePoint, RofaetionDB.debuffx, RofaetionDB.debuffy)
end
