-------------------------------------------------------------------------------
-- Warlock Class Module for Rofaetion
--
-- DPS specs: Affliction (tab 1), Demonology (tab 2), Destruction (tab 3)
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "WARLOCK",
	className = "Warlock",

	configOptions = {
		{ key = "lifeTapThreshold", type = "dropdown", label = "Life Tap mana threshold",
		  options = { "30%", "40%", "50%" }, default = 1 },
		{ key = "useMetaOnCD", type = "checkbox", label = "Metamorphosis on cooldown (Demo)", default = true },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Affliction DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Affliction",
			isDPS = true,
			debuffTrackerSpell = "Unstable Affliction",

			spellList = {
				["Unstable Affliction"] = 47843,
				["Haunt"]               = 59163,
				["Corruption"]          = 47813,
				["Curse of Agony"]      = 47864,
				["Curse of Doom"]       = 47867,
				["Shadow Bolt"]         = 47809,
				["Drain Soul"]          = 47855,
				["Drain Life"]          = 47857,
				["Drain Mana"]          = 27222,
				["Life Tap"]            = 57946,
				["Fel Armor"]           = 47893,
				["Healthstone"]         = 36895,
				["Spell Lock"]          = 19647,
				["Howl of Terror"]      = 5484,
				["Death Coil"]          = 47860,
				["Shadowfury"]          = 47847,
				["Demonic Sacrifice"]   = 18788,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Unstable Affliction (maintain)
				if (exclude1 ~= sl["Unstable Affliction"]) and (exclude2 ~= sl["Unstable Affliction"]) then
					if IsSpellInRange(sl["Unstable Affliction"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Unstable Affliction"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Unstable Affliction"])
							if (d - timeshift) <= 0 then
								return sl["Unstable Affliction"]
							end
						end
					end
				end

				-- 2. Haunt (maintain)
				if (exclude1 ~= sl["Haunt"]) and (exclude2 ~= sl["Haunt"]) then
					if IsSpellInRange(sl["Haunt"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Haunt"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Haunt"])
							if (d - timeshift) <= 0 then
								return sl["Haunt"]
							end
						end
					end
				end

				-- 3. Corruption (maintain)
				if (exclude1 ~= sl["Corruption"]) and (exclude2 ~= sl["Corruption"]) then
					if IsSpellInRange(sl["Corruption"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Corruption"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							return sl["Corruption"]
						end
					end
				end

				-- 4. Curse of Agony / Curse of Doom
				if (exclude1 ~= sl["Curse of Agony"]) and (exclude2 ~= sl["Curse of Agony"]) then
					if IsSpellInRange(sl["Curse of Agony"], "target") == 1 then
						local name = Rofaetion:hasDeBuff("target", "Curse of", "player")
						if not name then
							-- Use Curse of Doom on long fights, Agony otherwise
							local targetHealth = UnitHealth("target")
							if targetHealth > 100000 then
								return sl["Curse of Doom"]
							else
								return sl["Curse of Agony"]
							end
						end
					end
				end

				-- 5. Drain Soul (execute, target < 25% health)
				if (exclude1 ~= sl["Drain Soul"]) and (exclude2 ~= sl["Drain Soul"]) then
					if (UnitHealth("target") / UnitHealthMax("target")) < 0.25 then
						if IsSpellInRange(sl["Drain Soul"], "target") == 1 then
							return sl["Drain Soul"]
						end
					end
				end

				-- 6. Shadow Bolt (filler)
				if (exclude1 ~= sl["Shadow Bolt"]) and (exclude2 ~= sl["Shadow Bolt"]) then
					if IsSpellInRange(sl["Shadow Bolt"], "target") == 1 then
						if sl["Shadow Bolt"] ~= spellInCast then
							return sl["Shadow Bolt"]
						end
					end
				end

				-- Fallback
				if IsSpellInRange(sl["Shadow Bolt"], "target") == 1 then
					return sl["Shadow Bolt"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Fel Armor
				if Rofaetion:SpellAvailable(sl["Fel Armor"]) then
					local name = Rofaetion:hasBuff("player", sl["Fel Armor"])
					if not name then
						return sl["Fel Armor"]
					end
				end

				-- Life Tap (mana < 40%)
				if Rofaetion:SpellAvailable(sl["Life Tap"]) then
					if (UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.4 then
						return sl["Life Tap"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Spell Lock (pet ability)
				if Rofaetion:SpellAvailable(sl["Spell Lock"]) then
					if IsSpellInRange(sl["Spell Lock"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Spell Lock"])
							if d and d < 0.5 then
								return sl["Spell Lock"]
							end
						end
					end
				end

				-- Death Coil (offensive)
				if Rofaetion:SpellAvailable(sl["Death Coil"]) then
					if IsSpellInRange(sl["Death Coil"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Death Coil"])
						if d <= 0.5 then
							return sl["Death Coil"]
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Demonology DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Demonology",
			isDPS = true,
			debuffTrackerSpell = "Immolation",

			spellList = {
				["Metamorphosis"]    = 47241,
				["Immolation"]       = 47811,
				["Corruption"]       = 47813,
				["Shadow Bolt"]      = 47809,
				["Incinerate"]       = 47838,
				["Soul Fire"]        = 47825,
				["Life Tap"]         = 57946,
				["Fel Armor"]        = 47893,
				["Demonic Empowerment"] = 47193,
				
				["Shadow Cleave"]    = 50581,
				["Immolation Aura"]  = 50589,
				["Healthstone"]      = 36895,
				["Spell Lock"]       = 19647,
				["Howl of Terror"]   = 5484,
				["Death Coil"]       = 47860,
				["Shadowfury"]       = 47847,
				["Decimation"]       = 63156,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- Check if in Metamorphosis form
				local inMeta = Rofaetion:hasBuff("player", sl["Metamorphosis"])

				if inMeta then
					-- Metamorphosis rotation
					-- 1. Immolation Aura
					if (exclude1 ~= sl["Immolation Aura"]) and (exclude2 ~= sl["Immolation Aura"]) then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Immolation Aura"])
						if (d - timeshift) <= 0 then
							return sl["Immolation Aura"]
						end
					end

					-- 2. Shadow Cleave (in melee range)
					if (exclude1 ~= sl["Shadow Cleave"]) and (exclude2 ~= sl["Shadow Cleave"]) then
						if IsSpellInRange(sl["Shadow Cleave"], "target") == 1 then
							return sl["Shadow Cleave"]
						end
					end

					-- 3. Immolation (DoT in meta)
					if (exclude1 ~= sl["Immolation"]) and (exclude2 ~= sl["Immolation"]) then
						if IsSpellInRange(sl["Immolation"], "target") == 1 then
							local name = Rofaetion:hasDeBuff("target", sl["Immolation"], "player")
							if not name then
								return sl["Immolation"]
							end
						end
					end
				else
					-- Normal rotation
					-- 1. Metamorphosis (on cooldown)
					local cfg = Rofaetion:GetClassConfig()
					if cfg.useMetaOnCD then
						if (exclude1 ~= sl["Metamorphosis"]) and (exclude2 ~= sl["Metamorphosis"]) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Metamorphosis"])
							if (d - timeshift) <= 0 then
								return sl["Metamorphosis"]
							end
						end
					end

					-- 2. Corruption (maintain)
					if (exclude1 ~= sl["Corruption"]) and (exclude2 ~= sl["Corruption"]) then
						if IsSpellInRange(sl["Corruption"], "target") == 1 then
							local name = Rofaetion:hasDeBuff("target", sl["Corruption"], "player")
							if not name then
								return sl["Corruption"]
							end
						end
					end

					-- 3. Immolation (maintain)
					if (exclude1 ~= sl["Immolation"]) and (exclude2 ~= sl["Immolation"]) then
						if IsSpellInRange(sl["Immolation"], "target") == 1 then
							local name = Rofaetion:hasDeBuff("target", sl["Immolation"], "player")
							if not name then
								if sl["Immolation"] ~= spellInCast then
									return sl["Immolation"]
								end
							end
						end
					end

					-- 4. Soul Fire (Decimation proc)
					if (exclude1 ~= sl["Soul Fire"]) and (exclude2 ~= sl["Soul Fire"]) then
						local name = Rofaetion:hasBuff("player", "Decimation")
						if name then
							if sl["Soul Fire"] ~= spellInCast then
								return sl["Soul Fire"]
							end
						end
					end

					-- 5. Incinerate / Shadow Bolt (filler)
					if (exclude1 ~= sl["Incinerate"]) and (exclude2 ~= sl["Incinerate"]) then
						if IsSpellInRange(sl["Incinerate"], "target") == 1 then
							if sl["Incinerate"] ~= spellInCast then
								return sl["Incinerate"]
							end
						end
					end

					if (exclude1 ~= sl["Shadow Bolt"]) and (exclude2 ~= sl["Shadow Bolt"]) then
						if IsSpellInRange(sl["Shadow Bolt"], "target") == 1 then
							if sl["Shadow Bolt"] ~= spellInCast then
								return sl["Shadow Bolt"]
							end
						end
					end
				end

				-- Fallback
				if IsSpellInRange(sl["Shadow Bolt"], "target") == 1 then
					return sl["Shadow Bolt"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Fel Armor
				if Rofaetion:SpellAvailable(sl["Fel Armor"]) then
					local name = Rofaetion:hasBuff("player", sl["Fel Armor"])
					if not name then
						return sl["Fel Armor"]
					end
				end

				-- Demonic Empowerment (on cooldown)
				if Rofaetion:SpellAvailable(sl["Demonic Empowerment"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Demonic Empowerment"])
					if d <= 0.5 then
						return sl["Demonic Empowerment"]
					end
				end

				-- Life Tap (mana < 40%)
				if Rofaetion:SpellAvailable(sl["Life Tap"]) then
					if (UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.4 then
						return sl["Life Tap"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				if Rofaetion:SpellAvailable(sl["Spell Lock"]) then
					if IsSpellInRange(sl["Spell Lock"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Spell Lock"])
							if d and d < 0.5 then
								return sl["Spell Lock"]
							end
						end
					end
				end

				if Rofaetion:SpellAvailable(sl["Death Coil"]) then
					if IsSpellInRange(sl["Death Coil"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Death Coil"])
						if d <= 0.5 then
							return sl["Death Coil"]
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Destruction DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Destruction",
			isDPS = true,
			debuffTrackerSpell = "Immolate",

			spellList = {
				["Immolate"]         = 47811,
				["Conflagrate"]      = 47897,
				["Chaos Bolt"]       = 59172,
				["Incinerate"]       = 47838,
				["Shadowburn"]       = 47835,
				["Shadow Bolt"]      = 47809,
				["Corruption"]       = 47813,
				["Life Tap"]         = 57946,
				["Fel Armor"]        = 47893,
				["Backdraft"]        = 54274,
				["Healthstone"]      = 36895,
				["Spell Lock"]       = 19647,
				["Howl of Terror"]   = 5484,
				["Death Coil"]       = 47860,
				["Shadowfury"]       = 47847,
				["Searing Pain"]     = 47823,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Immolate (maintain)
				if (exclude1 ~= sl["Immolate"]) and (exclude2 ~= sl["Immolate"]) then
					if IsSpellInRange(sl["Immolate"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Immolate"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Immolate"])
							if (d - timeshift) <= 0 then
								if sl["Immolate"] ~= spellInCast then
									return sl["Immolate"]
								end
							end
						end
					end
				end

				-- 2. Conflagrate (on cooldown, consume Immolate/Shadowflame)
				if (exclude1 ~= sl["Conflagrate"]) and (exclude2 ~= sl["Conflagrate"]) then
					if IsSpellInRange(sl["Conflagrate"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Conflagrate"])
						if (d - timeshift) <= 0 then
							return sl["Conflagrate"]
						end
					end
				end

				-- 3. Chaos Bolt (on cooldown)
				if (exclude1 ~= sl["Chaos Bolt"]) and (exclude2 ~= sl["Chaos Bolt"]) then
					if IsSpellInRange(sl["Chaos Bolt"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Chaos Bolt"])
						if (d - timeshift) <= 0 then
							if sl["Chaos Bolt"] ~= spellInCast then
								return sl["Chaos Bolt"]
							end
						end
					end
				end

				-- 4. Shadowburn (execute, target < 25%)
				if (exclude1 ~= sl["Shadowburn"]) and (exclude2 ~= sl["Shadowburn"]) then
					if (UnitHealth("target") / UnitHealthMax("target")) < 0.25 then
						if IsSpellInRange(sl["Shadowburn"], "target") == 1 then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Shadowburn"])
							if (d - timeshift) <= 0 then
								return sl["Shadowburn"]
							end
						end
					end
				end

				-- 5. Corruption (maintain)
				if (exclude1 ~= sl["Corruption"]) and (exclude2 ~= sl["Corruption"]) then
					if IsSpellInRange(sl["Corruption"], "target") == 1 then
						local name = Rofaetion:hasDeBuff("target", sl["Corruption"], "player")
						if not name then
							return sl["Corruption"]
						end
					end
				end

				-- 6. Incinerate (filler)
				if (exclude1 ~= sl["Incinerate"]) and (exclude2 ~= sl["Incinerate"]) then
					if IsSpellInRange(sl["Incinerate"], "target") == 1 then
						if sl["Incinerate"] ~= spellInCast then
							return sl["Incinerate"]
						end
					end
				end

				-- Fallback
				if IsSpellInRange(sl["Incinerate"], "target") == 1 then
					return sl["Incinerate"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Fel Armor
				if Rofaetion:SpellAvailable(sl["Fel Armor"]) then
					local name = Rofaetion:hasBuff("player", sl["Fel Armor"])
					if not name then
						return sl["Fel Armor"]
					end
				end

				-- Life Tap (mana < 40%)
				if Rofaetion:SpellAvailable(sl["Life Tap"]) then
					if (UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.4 then
						return sl["Life Tap"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				if Rofaetion:SpellAvailable(sl["Spell Lock"]) then
					if IsSpellInRange(sl["Spell Lock"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Spell Lock"])
							if d and d < 0.5 then
								return sl["Spell Lock"]
							end
						end
					end
				end

				if Rofaetion:SpellAvailable(sl["Death Coil"]) then
					if IsSpellInRange(sl["Death Coil"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Death Coil"])
						if d <= 0.5 then
							return sl["Death Coil"]
						end
					end
				end

				return ""
			end,
		},
	},
})
