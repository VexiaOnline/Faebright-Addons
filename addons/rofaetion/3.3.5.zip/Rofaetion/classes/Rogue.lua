-------------------------------------------------------------------------------
-- Rogue Class Module for Rofaetion
--
-- DPS specs: Assassination (tab 1), Combat (tab 2), Subtlety (tab 3)
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "ROGUE",
	className = "Rogue",

		configOptions = {
		{ key = "useTricksOfTheTrade", type = "checkbox", label = "Tricks of the Trade on cooldown", default = true },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Assassination DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Assassination",
			isDPS = true,
			debuffTrackerSpell = "Slice and Dice",

			spellList = {
				["Mutilate"]          = 1329,
				["Envenom"]           = 32645,
				["Slice and Dice"]    = 6774,
				["Rupture"]           = 48672,
				["Hunger for Blood"]  = 51662,
				["Fan of Knives"]     = 51723,
				["Deadly Poison"]     = 2818,
				["Instant Poison"]    = 8679,
				["Kidney Shot"]       = 408,
				["Cheap Shot"]        = 1833,
				["Ambush"]            = 48691,
				["Garrote"]           = 48676,
				["Tricks of the Trade"] = 57934,
				["Shadowstep"]        = 36554,
				["Vanish"]            = 1856,
				["Evasion"]           = 5277,
				["Cloak of Shadows"]  = 31224,
				["Kick"]              = 1766,
				["Blind"]             = 2094,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local comboPoints = GetComboPoints("player", "target")

				-- Check if target has any bleed effect (required for Hunger for Blood)
				local bleedNames = { "Rupture", "Garrote", "Rip", "Rake", "Lacerate", "Deep Wounds", "Pounce Bleed" }
				local targetHasBleed = false
				for _, bname in ipairs(bleedNames) do
					if Rofaetion:hasDeBuff("target", bname, nil) then
						targetHasBleed = true
						break
					end
				end

				-- 1. Fan of Knives (AoE, 5+ targets)
				if (exclude1 ~= sl["Fan of Knives"]) and (exclude2 ~= sl["Fan of Knives"]) then
					if Rofaetion.person["foeCount"] >= 5 then
						return sl["Fan of Knives"], IsSpellInRange(sl["Fan of Knives"], "target") ~= 1
					end
				end

				-- 2. Slice and Dice (maintain, refresh at <3s remaining)
				if (exclude1 ~= sl["Slice and Dice"]) and (exclude2 ~= sl["Slice and Dice"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasBuff("player", sl["Slice and Dice"])
					if not name or (expiration and (expiration - GetTime() - timeshift) < 3) then
						if comboPoints >= 1 then
							return sl["Slice and Dice"]
						end
					end
				end

				-- 3. Hunger for Blood (maintain, only if target has a bleed)
				if (exclude1 ~= sl["Hunger for Blood"]) and (exclude2 ~= sl["Hunger for Blood"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasBuff("player", sl["Hunger for Blood"])
					local hfbExpiring = not name or (expiration and (expiration - GetTime() - timeshift) < 3)
					if hfbExpiring then
						if Rofaetion:SpellAvailable(sl["Hunger for Blood"]) and targetHasBleed then
							return sl["Hunger for Blood"]
						end
					end
				end

				-- 4. Rupture (establish/refresh bleed for Hunger for Blood)
				if (exclude1 ~= sl["Rupture"]) and (exclude2 ~= sl["Rupture"]) then
					local hfbName, _, _, _, _, _, hfbExpiration = Rofaetion:hasBuff("player", sl["Hunger for Blood"])
					local hfbExpiring = not hfbName or (hfbExpiration and (hfbExpiration - GetTime() - timeshift) < 3)
					if hfbExpiring and not targetHasBleed then
						if comboPoints >= 1 then
							return sl["Rupture"]
						end
					end
				end

				-- 5. Envenom (at 4-5 CP, when Envenom buff fading or at 5 CP)
				if (exclude1 ~= sl["Envenom"]) and (exclude2 ~= sl["Envenom"]) then
					if comboPoints >= 4 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasBuff("player", "Envenom")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 1.5) or comboPoints == 5 then
							return sl["Envenom"]
						end
					end
				end

				-- 6. Mutilate (CP builder / filler)
				if (exclude1 ~= sl["Mutilate"]) and (exclude2 ~= sl["Mutilate"]) then
					if comboPoints < 5 then
						return sl["Mutilate"], IsSpellInRange(sl["Mutilate"], "target") ~= 1
					end
				end

				-- Fallback
				return sl["Mutilate"], IsSpellInRange(sl["Mutilate"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Deadly Poison (if not active on target)
				if Rofaetion:SpellAvailable(sl["Deadly Poison"]) then
					local name = Rofaetion:hasDeBuff("target", "Deadly Poison", "player")
					if not name then
						return sl["Deadly Poison"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Kick
				if Rofaetion:SpellAvailable(sl["Kick"]) then
					if IsSpellInRange(sl["Kick"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Kick"])
							if d and d < 0.5 then
								return sl["Kick"]
							end
						end
					end
				end

				-- Kidney Shot (stun, use as interrupt if Kick on CD)
				if Rofaetion:SpellAvailable(sl["Kidney Shot"]) then
					if IsSpellInRange(sl["Kidney Shot"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if (name or channel) then
							local kickCD = Rofaetion:GetSpellCooldownRemaining(sl["Kick"])
							if kickCD > 0 then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Kidney Shot"])
								if d and d < 0.5 then
									return sl["Kidney Shot"]
								end
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Combat DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Combat",
			isDPS = true,
			debuffTrackerSpell = "Slice and Dice",

			spellList = {
				["Sinister Strike"]   = 48638,
				["Eviscerate"]        = 48668,
				["Slice and Dice"]    = 6774,
				["Killing Spree"]     = 51690,
				["Blade Flurry"]      = 13877,
				["Adrenaline Rush"]   = 13750,
				["Off-Hand Attack"]   = 0,
				["Gouge"]             = 1776,
				["Riposte"]           = 14251,
				["Evasion"]           = 5277,
				["Cloak of Shadows"]  = 31224,
				["Kick"]              = 1766,
				["Blind"]             = 2094,
				["Tricks of the Trade"] = 57934,
				["Feint"]             = 1966,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local comboPoints = GetComboPoints("player", "target")

				-- 1. Slice and Dice (maintain, refresh at <3s)
				if (exclude1 ~= sl["Slice and Dice"]) and (exclude2 ~= sl["Slice and Dice"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasBuff("player", sl["Slice and Dice"])
					if not name or (expiration and (expiration - GetTime() - timeshift) < 3) then
						if comboPoints >= 1 then
							return sl["Slice and Dice"]
						end
					end
				end

				-- 2. Eviscerate (at 5 CP, when SnD is up)
				if (exclude1 ~= sl["Eviscerate"]) and (exclude2 ~= sl["Eviscerate"]) then
					if comboPoints >= 5 then
						local sndActive = Rofaetion:hasBuff("player", sl["Slice and Dice"])
						if sndActive then
							return sl["Eviscerate"]
						end
					end
				end

				-- 3. Sinister Strike (CP builder)
				if (exclude1 ~= sl["Sinister Strike"]) and (exclude2 ~= sl["Sinister Strike"]) then
					if comboPoints < 5 then
						return sl["Sinister Strike"], IsSpellInRange(sl["Sinister Strike"], "target") ~= 1
					end
				end

				-- Fallback
				return sl["Sinister Strike"], IsSpellInRange(sl["Sinister Strike"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Killing Spree (on cooldown)
				if Rofaetion:SpellAvailable(sl["Killing Spree"]) then
					if IsSpellInRange(sl["Sinister Strike"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Killing Spree"])
						if d <= 0.5 then
							return sl["Killing Spree"]
						end
					end
				end

				-- Blade Flurry (on cooldown, 2+ targets)
				if Rofaetion:SpellAvailable(sl["Blade Flurry"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Blade Flurry"])
					if d <= 0.5 then
						return sl["Blade Flurry"]
					end
				end

				-- Adrenaline Rush (on cooldown)
				if Rofaetion:SpellAvailable(sl["Adrenaline Rush"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Adrenaline Rush"])
					if d <= 0.5 then
						return sl["Adrenaline Rush"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Kick
				if Rofaetion:SpellAvailable(sl["Kick"]) then
					if IsSpellInRange(sl["Kick"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Kick"])
							if d and d < 0.5 then
								return sl["Kick"]
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Subtlety DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Subtlety",
			isDPS = true,
			debuffTrackerSpell = "Slice and Dice",

			spellList = {
				["Hemorrhage"]        = 48660,
				["Eviscerate"]        = 48668,
				["Slice and Dice"]    = 6774,
				["Rupture"]           = 48672,
				["Premeditation"]     = 14183,
				["Ambush"]            = 48691,
				["Backstab"]          = 48657,
				["Shadowstep"]        = 36554,
				["Vanish"]            = 1856,
				["Shadow Dance"]      = 51713,
				["Evasion"]           = 5277,
				["Cloak of Shadows"]  = 31224,
				["Kick"]              = 1766,
				["Kidney Shot"]       = 408,
				["Cheap Shot"]        = 1833,
				["Garrote"]           = 48676,
				["Tricks of the Trade"] = 57934,
				["Preparation"]       = 14185,
				["Dismantle"]         = 51722,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local comboPoints = GetComboPoints("player", "target")

				-- 1. Slice and Dice (maintain, refresh at <3s)
				if (exclude1 ~= sl["Slice and Dice"]) and (exclude2 ~= sl["Slice and Dice"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasBuff("player", sl["Slice and Dice"])
					if not name or (expiration and (expiration - GetTime() - timeshift) < 3) then
						if comboPoints >= 1 then
							return sl["Slice and Dice"]
						end
					end
				end

				-- 2. Rupture (maintain at 5 CP)
				if (exclude1 ~= sl["Rupture"]) and (exclude2 ~= sl["Rupture"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Rupture"], "player")
					if not name or (expiration and (expiration - GetTime() - timeshift) < 3) then
						if comboPoints >= 5 then
							return sl["Rupture"]
						end
					end
				end

				-- 3. Hemorrhage (maintain debuff on target)
				if (exclude1 ~= sl["Hemorrhage"]) and (exclude2 ~= sl["Hemorrhage"]) then
					local name = Rofaetion:hasDeBuff("target", "Hemorrhage", "player")
					if not name then
						return sl["Hemorrhage"], IsSpellInRange(sl["Hemorrhage"], "target") ~= 1
					end
				end

				-- 4. Eviscerate (at 5 CP, both buffs active)
				if (exclude1 ~= sl["Eviscerate"]) and (exclude2 ~= sl["Eviscerate"]) then
					if comboPoints >= 5 then
						return sl["Eviscerate"]
					end
				end

				-- 5. Backstab (filler / CP builder when behind target)
				if (exclude1 ~= sl["Backstab"]) and (exclude2 ~= sl["Backstab"]) then
					if comboPoints < 5 then
						return sl["Backstab"], IsSpellInRange(sl["Backstab"], "target") ~= 1
					end
				end

				-- 6. Hemorrhage (filler if no Backstab available)
				if (exclude1 ~= sl["Hemorrhage"]) and (exclude2 ~= sl["Hemorrhage"]) then
					if comboPoints < 5 then
						return sl["Hemorrhage"], IsSpellInRange(sl["Hemorrhage"], "target") ~= 1
					end
				end

				-- Fallback
				return sl["Hemorrhage"], IsSpellInRange(sl["Hemorrhage"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Shadow Dance (on cooldown)
				if Rofaetion:SpellAvailable(sl["Shadow Dance"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Shadow Dance"])
					if d <= 0.5 then
						return sl["Shadow Dance"]
					end
				end

				-- Premeditation (before opener)
				if Rofaetion:SpellAvailable(sl["Premeditation"]) then
					if not UnitAffectingCombat("player") then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Premeditation"])
						if d <= 0.5 then
							return sl["Premeditation"]
						end
					end
				end

				-- Preparation (reset cooldowns)
				if Rofaetion:SpellAvailable(sl["Preparation"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Preparation"])
					if d <= 0.5 then
						return sl["Preparation"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Kick
				if Rofaetion:SpellAvailable(sl["Kick"]) then
					if IsSpellInRange(sl["Kick"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Kick"])
							if d and d < 0.5 then
								return sl["Kick"]
							end
						end
					end
				end

				return ""
			end,
		},
	},
})
