-------------------------------------------------------------------------------
-- Mage Class Module for Rofaetion
--
-- DPS specs: Arcane (tab 1), Fire (tab 2), Frost (tab 3)
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "MAGE",
	className = "Mage",

	configOptions = {
		{ key = "arcaneBlastStacks", type = "dropdown", label = "Arcane Blast max stacks",
		  options = { "3 stacks", "4 stacks", "6 stacks" }, default = 2 },
		{ key = "livingBombSpread", type = "checkbox", label = "Spread Living Bomb (Fire)", default = true },
		{ key = "frostCooldowns", type = "checkbox", label = "Use cooldowns (Frost)", default = true },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Arcane DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Arcane",
			isDPS = true,
			debuffTrackerSpell = "Arcane Blast",

			spellList = {
				["Arcane Blast"]      = 42897,
				["Arcane Missiles"]   = 42846,
				["Arcane Barrage"]    = 44781,
				["Arcane Intellect"]  = 43002,
				["Mana Shield"]       = 43020,
				["Remove Curse"]      = 475,
				["Counterspell"]      = 2139,
				["Polymorph"]         = 12826,
				["Icy Veins"]         = 12472,
				["Mirror Image"]      = 55342,
				["Evocation"]         = 12051,
				["Conjure Mana Gem"]  = 42985,
				["Blink"]             = 1953,
				["Arcane Explosion"]  = 1449,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Evocation (if mana < 20%)
				if Rofaetion:SpellAvailable(sl["Evocation"]) then
					if (UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.2 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Evocation"])
						if (d - timeshift) <= 0 then
							return sl["Evocation"]
						end
					end
				end

				-- 2. Arcane Missiles (Missile Barrage proc - check buff)
				if (exclude1 ~= sl["Arcane Missiles"]) and (exclude2 ~= sl["Arcane Missiles"]) then
					local name = Rofaetion:hasBuff("player", "Missile Barrage")
					if name then
						if IsSpellInRange(sl["Arcane Missiles"], "target") == 1 then
							return sl["Arcane Missiles"]
						end
					end
				end

				-- 3. Arcane Barrage (on cooldown, saves mana)
				if (exclude1 ~= sl["Arcane Barrage"]) and (exclude2 ~= sl["Arcane Barrage"]) then
					if IsSpellInRange(sl["Arcane Barrage"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Arcane Barrage"])
						if (d - timeshift) <= 0 then
							return sl["Arcane Barrage"]
						end
					end
				end

				-- 4. Arcane Blast (filler, up to stacks)
				if (exclude1 ~= sl["Arcane Blast"]) and (exclude2 ~= sl["Arcane Blast"]) then
					if IsSpellInRange(sl["Arcane Blast"], "target") == 1 then
						if sl["Arcane Blast"] ~= spellInCast then
							return sl["Arcane Blast"]
						end
					end
				end

				-- Fallback
				if IsSpellInRange(sl["Arcane Blast"], "target") == 1 then
					return sl["Arcane Blast"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Arcane Intellect
				if Rofaetion:SpellAvailable(sl["Arcane Intellect"]) then
					local name = Rofaetion:hasBuff("player", sl["Arcane Intellect"])
					if not name then
						return sl["Arcane Intellect"]
					end
				end

				-- Mana Shield (if health < 70%)
				if Rofaetion:SpellAvailable(sl["Mana Shield"]) then
					if (UnitHealth("player") / UnitHealthMax("player")) < 0.7 then
						local name = Rofaetion:hasBuff("player", sl["Mana Shield"])
						if not name then
							return sl["Mana Shield"]
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				if Rofaetion:SpellAvailable(sl["Counterspell"]) then
					if IsSpellInRange(sl["Counterspell"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Counterspell"])
							if d and d < 0.5 then
								return sl["Counterspell"]
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Fire DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Fire",
			isDPS = true,
			debuffTrackerSpell = "Living Bomb",

			spellList = {
				["Fireball"]          = 42833,
				["Pyroblast"]         = 42845,
				["Fire Blast"]        = 42873,
				["Living Bomb"]       = 44457,
				["Ignite"]            = 12848,
				["Molten Armor"]      = 43046,
				["Counterspell"]      = 2139,
				["Combustion"]        = 28682,
				["Mirror Image"]      = 55342,
				["Icy Veins"]         = 12472,
				["Blink"]             = 1953,
				["Flamestrike"]       = 42891,
				["Fire Nova"]         = 61657,
				["Remove Curse"]      = 475,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Living Bomb (maintain on target)
				if (exclude1 ~= sl["Living Bomb"]) and (exclude2 ~= sl["Living Bomb"]) then
					if IsSpellInRange(sl["Living Bomb"], "target") == 1 then
						local name, _, _, _, _, duration, expiration = Rofaetion:hasDeBuff("target", sl["Living Bomb"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Living Bomb"])
							if (d - timeshift) <= 0 then
								return sl["Living Bomb"]
							end
						end
					end
				end

				-- 2. Pyroblast (Hot Streak proc)
				if (exclude1 ~= sl["Pyroblast"]) and (exclude2 ~= sl["Pyroblast"]) then
					local name = Rofaetion:hasBuff("player", "Hot Streak")
					if name then
						if IsSpellInRange(sl["Pyroblast"], "target") == 1 then
							if sl["Pyroblast"] ~= spellInCast then
								return sl["Pyroblast"]
							end
						end
					end
				end

				-- 3. Fire Blast (with Impact proc or on cooldown for Living Bomb spread)
				if (exclude1 ~= sl["Fire Blast"]) and (exclude2 ~= sl["Fire Blast"]) then
					if IsSpellInRange(sl["Fire Blast"], "target") == 1 then
						local name = Rofaetion:hasBuff("player", "Impact")
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Fire Blast"])
						if (name and (d - timeshift) <= 0) or ((d - timeshift) <= 0) then
							return sl["Fire Blast"]
						end
					end
				end

				-- 4. Fireball (filler)
				if (exclude1 ~= sl["Fireball"]) and (exclude2 ~= sl["Fireball"]) then
					if IsSpellInRange(sl["Fireball"], "target") == 1 then
						if sl["Fireball"] ~= spellInCast then
							return sl["Fireball"]
						end
					end
				end

				if IsSpellInRange(sl["Fireball"], "target") == 1 then
					return sl["Fireball"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Molten Armor
				if Rofaetion:SpellAvailable(sl["Molten Armor"]) then
					local name = Rofaetion:hasBuff("player", sl["Molten Armor"])
					if not name then
						return sl["Molten Armor"]
					end
				end

				-- Combustion (use when Ignite is rolling)
				if Rofaetion:SpellAvailable(sl["Combustion"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Combustion"])
					if d <= 0.5 then
						return sl["Combustion"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				if Rofaetion:SpellAvailable(sl["Counterspell"]) then
					if IsSpellInRange(sl["Counterspell"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Counterspell"])
							if d and d < 0.5 then
								return sl["Counterspell"]
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Frost DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Frost",
			isDPS = true,
			debuffTrackerSpell = "Frostbolt",

			spellList = {
				["Frostbolt"]         = 42841,
				["Ice Lance"]         = 42913,
				["Deep Freeze"]       = 44572,
				["Frostfire Bolt"]    = 47610,
				["Fireball"]          = 42833,
				["Blizzard"]          = 42938,
				["Frost Armor"]       = 7302,
				["Ice Barrier"]       = 43038,
				["Counterspell"]      = 2139,
				["Icy Veins"]         = 12472,
				["Cold Snap"]         = 11958,
				["Mirror Image"]      = 55342,
				["Blink"]             = 1953,
				["Cone of Cold"]      = 42930,
				["Remove Curse"]      = 475,
				["Water Elemental"]   = 31687,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- Check procs
				local fofName, _, _, fofCount = Rofaetion:hasBuff("player", "Fingers of Frost")
				local brainFreeze = Rofaetion:hasBuff("player", "Brain Freeze")

				-- Brain Freeze spell: Frostfire Bolt if known, else Fireball
				local bfSpell = sl["Frostfire Bolt"]
				if not Rofaetion:SpellAvailable(bfSpell) then
					bfSpell = sl["Fireball"]
				end

				-- 1. Blizzard (AoE, 3+ targets)
				if (exclude1 ~= sl["Blizzard"]) and (exclude2 ~= sl["Blizzard"]) then
					if Rofaetion.person["foeCount"] >= 3 then
						if sl["Blizzard"] ~= spellInCast then
							return sl["Blizzard"]
						end
					end
				end

				-- 2. Brain Freeze (instant Frostfire Bolt / Fireball)
				if brainFreeze then
					if (exclude1 ~= bfSpell) and (exclude2 ~= bfSpell) then
						if IsSpellInRange(bfSpell, "target") == 1 then
							return bfSpell
						end
					end
				end

				-- 3. Fingers of Frost: Frostbolt (1st), then Deep Freeze (2nd)
				if fofName then
					-- Deep Freeze (only after Frostbolt was already suggested)
					if (exclude1 ~= sl["Deep Freeze"]) and (exclude2 ~= sl["Deep Freeze"]) then
						if (exclude1 == sl["Frostbolt"] or exclude2 == sl["Frostbolt"]
							or exclude1 == bfSpell or exclude2 == bfSpell) then
							if IsSpellInRange(sl["Deep Freeze"], "target") == 1 then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Deep Freeze"])
								if (d - timeshift) <= 0 then
									return sl["Deep Freeze"]
								end
							end
						end
					end

					-- Frostbolt (consume FoF charge)
					if (exclude1 ~= sl["Frostbolt"]) and (exclude2 ~= sl["Frostbolt"]) then
						if IsSpellInRange(sl["Frostbolt"], "target") == 1 then
							if sl["Frostbolt"] ~= spellInCast then
								return sl["Frostbolt"]
							end
						end
					end
				end

				-- 4. Frostbolt (filler)
				if (exclude1 ~= sl["Frostbolt"]) and (exclude2 ~= sl["Frostbolt"]) then
					if IsSpellInRange(sl["Frostbolt"], "target") == 1 then
						if sl["Frostbolt"] ~= spellInCast then
							return sl["Frostbolt"]
						end
					end
				end

				-- Fallback
				if IsSpellInRange(sl["Frostbolt"], "target") == 1 then
					return sl["Frostbolt"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()

				-- Ice Barrier
				if Rofaetion:SpellAvailable(sl["Ice Barrier"]) then
					if (UnitHealth("player") / UnitHealthMax("player")) < 0.85 then
						local name = Rofaetion:hasBuff("player", sl["Ice Barrier"])
						if not name then
							return sl["Ice Barrier"]
						end
					end
				end

				-- Water Elemental (only if no pet active - talents/glyphs make it permanent)
				if cfg.frostCooldowns then
					if Rofaetion:SpellAvailable(sl["Water Elemental"]) then
						if not UnitExists("pet") then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Water Elemental"])
							if d <= 0.5 then
								return sl["Water Elemental"]
							end
						end
					end
				end

				-- Icy Veins (cooldown)
				if cfg.frostCooldowns then
					if Rofaetion:SpellAvailable(sl["Icy Veins"]) then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Icy Veins"])
						if d <= 0.5 then
							return sl["Icy Veins"]
						end
					end
				end

				-- Cold Snap (reset Icy Veins if it's on cooldown and not currently active)
				if cfg.frostCooldowns then
					if Rofaetion:SpellAvailable(sl["Cold Snap"]) then
						local ivActive = Rofaetion:hasBuff("player", sl["Icy Veins"])
						if not ivActive then
							local ivCD = Rofaetion:GetSpellCooldownRemaining(sl["Icy Veins"])
							if ivCD and ivCD > 0 then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Cold Snap"])
								if d <= 0.5 then
									return sl["Cold Snap"]
								end
							end
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				if Rofaetion:SpellAvailable(sl["Counterspell"]) then
					if IsSpellInRange(sl["Counterspell"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Counterspell"])
							if d and d < 0.5 then
								return sl["Counterspell"]
							end
						end
					end
				end

				return ""
			end,
		},
	},
})
