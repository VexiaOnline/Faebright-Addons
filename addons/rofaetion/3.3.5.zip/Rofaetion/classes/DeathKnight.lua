-------------------------------------------------------------------------------
-- Death Knight Class Module for Rofaetion
--
-- DPS specs: Frost (tab 2), Unholy (tab 3)
-- Tab 1 (Blood) is a tank spec in 3.3.5a
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "DEATHKNIGHT",
	className = "Death Knight",

	configOptions = {
		{ key = "useGhoul", type = "checkbox", label = "Summon Ghoul (Unholy)", default = true },
		{ key = "useArmy", type = "checkbox", label = "Army of the Dead (Unholy)", default = false },
	},

	specs = {
		-- Tab 1: Blood (Tank in 3.3.5a)
		[1] = { name = "Blood", isDPS = false },

		-----------------------------------------------------------------------
		-- Frost DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Frost",
			isDPS = true,
			debuffTrackerSpell = "Frost Fever",

			spellList = {
				["Icy Touch"]         = 49895,
				["Plague Strike"]     = 49924,
				["Frost Strike"]      = 49143,
				["Obliterate"]        = 51425,
				["Howling Blast"]     = 51411,
				["Blood Strike"]      = 49930,
				["Death Strike"]      = 49999,
				["Frost Fever"]       = 55095,
				["Blood Plague"]      = 55078,
				["Horn of Frost"]     = 57652,
				["Unbreakable Armor"] = 51271,
				["Empower Rune Weapon"] = 47568,
				["Raise Dead"]        = 46584,
				["Mind Freeze"]       = 47528,
				["Strangulate"]       = 47476,
				["Anti-Magic Shell"]  = 48707,
				["Icebound Fortitude"] = 48792,
				["Death Grip"]        = 49576,
				["Chains of Ice"]     = 45524,
				["Blood Tap"]         = 45529,
				["Rune Tap"]          = 48982,
				["Deathchill"]        = 49796,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Apply diseases: Icy Touch then Plague Strike
			if (exclude1 ~= sl["Icy Touch"]) and (exclude2 ~= sl["Icy Touch"]) then
				local name = Rofaetion:hasDeBuff("target", sl["Frost Fever"], "player")
				if not name then
					return sl["Icy Touch"], IsSpellInRange(sl["Icy Touch"], "target") ~= 1
				end
			end

			if (exclude1 ~= sl["Plague Strike"]) and (exclude2 ~= sl["Plague Strike"]) then
				local name = Rofaetion:hasDeBuff("target", sl["Blood Plague"], "player")
				if not name then
					return sl["Plague Strike"], IsSpellInRange(sl["Plague Strike"], "target") ~= 1
				end
			end

			-- 2. Frost Strike (on cooldown, Runic Power dump)
			if (exclude1 ~= sl["Frost Strike"]) and (exclude2 ~= sl["Frost Strike"]) then
				if UnitPower("player", 6) >= 40 then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Frost Strike"])
					if (d - timeshift) <= 0 then
						return sl["Frost Strike"], IsSpellInRange(sl["Frost Strike"], "target") ~= 1
					end
				end
			end

			-- 3. Obliterate (on cooldown, uses Frost/Unholy runes)
			if (exclude1 ~= sl["Obliterate"]) and (exclude2 ~= sl["Obliterate"]) then
				if sl["Obliterate"] ~= spellInCast then
					return sl["Obliterate"], IsSpellInRange(sl["Obliterate"], "target") ~= 1
				end
			end

			-- 4. Howling Blast (with Rime/Freezing Fog proc)
			if (exclude1 ~= sl["Howling Blast"]) and (exclude2 ~= sl["Howling Blast"]) then
				local name = Rofaetion:hasBuff("player", "Freezing Fog")
				if name then
					return sl["Howling Blast"], IsSpellInRange(sl["Howling Blast"], "target") ~= 1
				end
			end

				-- 5. Blood Strike (on cooldown, uses Blood rune)
			if (exclude1 ~= sl["Blood Strike"]) and (exclude2 ~= sl["Blood Strike"]) then
				if sl["Blood Strike"] ~= spellInCast then
					return sl["Blood Strike"], IsSpellInRange(sl["Blood Strike"], "target") ~= 1
				end
			end

			-- 6. Death Strike (if nothing else available)
			if (exclude1 ~= sl["Death Strike"]) and (exclude2 ~= sl["Death Strike"]) then
				if sl["Death Strike"] ~= spellInCast then
					return sl["Death Strike"], IsSpellInRange(sl["Death Strike"], "target") ~= 1
				end
			end

			-- Fallback
			return sl["Frost Strike"], IsSpellInRange(sl["Frost Strike"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Horn of Frost (maintain)
				if Rofaetion:SpellAvailable(sl["Horn of Frost"]) then
					local name = Rofaetion:hasBuff("player", sl["Horn of Frost"])
					if not name then
						return sl["Horn of Frost"]
					end
				end

				-- Unbreakable Armor
				if Rofaetion:SpellAvailable(sl["Unbreakable Armor"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Unbreakable Armor"])
					if d <= 0.5 then
						return sl["Unbreakable Armor"]
					end
				end

				-- Raise Dead
				if Rofaetion:SpellAvailable(sl["Raise Dead"]) then
					if not UnitExists("pet") then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Raise Dead"])
						if d <= 0.5 then
							return sl["Raise Dead"]
						end
					end
				end

				-- Empower Rune Weapon (on cooldown, when low runes)
				if Rofaetion:SpellAvailable(sl["Empower Rune Weapon"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Empower Rune Weapon"])
					if d <= 0.5 then
						return sl["Empower Rune Weapon"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Mind Freeze (interrupt)
				if Rofaetion:SpellAvailable(sl["Mind Freeze"]) then
					if IsSpellInRange(sl["Mind Freeze"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Mind Freeze"])
							if d and d < 0.5 then
								return sl["Mind Freeze"]
							end
						end
					end
				end

				-- Strangulate (ranged interrupt)
				if Rofaetion:SpellAvailable(sl["Strangulate"]) then
					if IsSpellInRange(sl["Strangulate"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Mind Freeze"])
							if d and d > 0 then
								local d2 = Rofaetion:GetSpellCooldownRemaining(sl["Strangulate"])
								if d2 < 0.5 then
									return sl["Strangulate"]
								end
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Unholy DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Unholy",
			isDPS = true,
			debuffTrackerSpell = "Frost Fever",

			spellList = {
				["Icy Touch"]         = 49895,
				["Plague Strike"]     = 49924,
				["Scourge Strike"]    = 55271,
				["Death Coil"]        = 47541,
				["Blood Strike"]      = 49930,
				["Pestilence"]        = 50842,
				["Blood Boil"]        = 49941,
				["Frost Fever"]       = 55095,
				["Blood Plague"]      = 55078,
				["Horn of Frost"]     = 57652,
				["Summon Gargoyle"]   = 49206,
				["Summon Ghoul"]      = 46584,
				["Army of the Dead"]  = 42650,
				["Bone Shield"]       = 49222,
				["Unholy Frenzy"]     = 49016,
				["Mind Freeze"]       = 47528,
				["Strangulate"]       = 47476,
				["Anti-Magic Shell"]  = 48707,
				["Icebound Fortitude"] = 48792,
				["Death Grip"]        = 49576,
				["Chains of Ice"]     = 45524,
				["Desolation"]        = 63560,
				["Blood Tap"]         = 45529,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Apply diseases: Icy Touch then Plague Strike
			if (exclude1 ~= sl["Icy Touch"]) and (exclude2 ~= sl["Icy Touch"]) then
				local name = Rofaetion:hasDeBuff("target", sl["Frost Fever"], "player")
				if not name then
					return sl["Icy Touch"], IsSpellInRange(sl["Icy Touch"], "target") ~= 1
				end
			end

			if (exclude1 ~= sl["Plague Strike"]) and (exclude2 ~= sl["Plague Strike"]) then
				local name = Rofaetion:hasDeBuff("target", sl["Blood Plague"], "player")
				if not name then
					return sl["Plague Strike"], IsSpellInRange(sl["Plague Strike"], "target") ~= 1
				end
			end

			-- 2. Blood Boil (refresh diseases on multiple targets)
			if (exclude1 ~= sl["Pestilence"]) and (exclude2 ~= sl["Pestilence"]) then
				if Rofaetion.person["foeCount"] > 1 then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Pestilence"])
					if (d - timeshift) <= 0 then
						return sl["Pestilence"], IsSpellInRange(sl["Pestilence"], "target") ~= 1
					end
				end
			end

			-- 3. Scourge Strike (on cooldown, main DP generator)
			if (exclude1 ~= sl["Scourge Strike"]) and (exclude2 ~= sl["Scourge Strike"]) then
				if sl["Scourge Strike"] ~= spellInCast then
					return sl["Scourge Strike"], IsSpellInRange(sl["Scourge Strike"], "target") ~= 1
				end
			end

			-- 4. Death Coil (Runic Power dump)
			if (exclude1 ~= sl["Death Coil"]) and (exclude2 ~= sl["Death Coil"]) then
				if UnitPower("player", 6) >= 40 then
					return sl["Death Coil"], IsSpellInRange(sl["Death Coil"], "target") ~= 1
				end
			end

				-- 5. Blood Strike (on cooldown, uses Blood rune)
			if (exclude1 ~= sl["Blood Strike"]) and (exclude2 ~= sl["Blood Strike"]) then
				if sl["Blood Strike"] ~= spellInCast then
					return sl["Blood Strike"], IsSpellInRange(sl["Blood Strike"], "target") ~= 1
				end
			end

			-- Fallback
			return sl["Scourge Strike"], IsSpellInRange(sl["Scourge Strike"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()

				-- Horn of Frost
				if Rofaetion:SpellAvailable(sl["Horn of Frost"]) then
					local name = Rofaetion:hasBuff("player", sl["Horn of Frost"])
					if not name then
						return sl["Horn of Frost"]
					end
				end

				-- Bone Shield
				if Rofaetion:SpellAvailable(sl["Bone Shield"]) then
					local name = Rofaetion:hasBuff("player", sl["Bone Shield"])
					if not name then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Bone Shield"])
						if d <= 0.5 then
							return sl["Bone Shield"]
						end
					end
				end

				-- Summon Gargoyle (on cooldown)
				if Rofaetion:SpellAvailable(sl["Summon Gargoyle"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Summon Gargoyle"])
					if d <= 0.5 then
						return sl["Summon Gargoyle"]
					end
				end

				-- Unholy Frenzy (on cooldown)
				if Rofaetion:SpellAvailable(sl["Unholy Frenzy"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Unholy Frenzy"])
					if d <= 0.5 then
						return sl["Unholy Frenzy"]
					end
				end

				-- Raise Dead / Summon Ghoul
				if cfg.useGhoul then
					if Rofaetion:SpellAvailable(sl["Summon Ghoul"]) then
						if not UnitExists("pet") then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Summon Ghoul"])
							if d <= 0.5 then
								return sl["Summon Ghoul"]
							end
						end
					end
				end

				-- Army of the Dead (out of combat only)
				if cfg.useArmy then
					if Rofaetion:SpellAvailable(sl["Army of the Dead"]) then
						if not UnitAffectingCombat("player") then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Army of the Dead"])
							if d <= 0.5 then
								return sl["Army of the Dead"]
							end
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Mind Freeze
				if Rofaetion:SpellAvailable(sl["Mind Freeze"]) then
					if IsSpellInRange(sl["Mind Freeze"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Mind Freeze"])
							if d and d < 0.5 then
								return sl["Mind Freeze"]
							end
						end
					end
				end

				-- Strangulate
				if Rofaetion:SpellAvailable(sl["Strangulate"]) then
					if IsSpellInRange(sl["Strangulate"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Mind Freeze"])
							if d and d > 0 then
								local d2 = Rofaetion:GetSpellCooldownRemaining(sl["Strangulate"])
								if d2 < 0.5 then
									return sl["Strangulate"]
								end
							end
						end
					end
				end

				return ""
			end,
		},
	},
})
