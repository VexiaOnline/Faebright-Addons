-------------------------------------------------------------------------------
-- Warrior Class Module for Rofaetion
--
-- DPS specs: Arms (tab 1), Fury (tab 2)
-- Tab 3 (Protection) is a tank spec
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "WARRIOR",
	className = "Warrior",

	configOptions = {
		{ key = "cleaveOnAoE", type = "checkbox", label = "Cleave/Whirlwind on 2+ targets", default = true },
		{ key = "useShatteringThrow", type = "checkbox", label = "Shattering Throw (debuff boss armor)", default = false },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Arms DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Arms",
			isDPS = true,
			debuffTrackerSpell = "Rend",

			spellList = {
				["Mortal Strike"]     = 47486,
				["Overpower"]         = 7384,
				["Execute"]           = 47467,
				["Slam"]              = 47475,
				["Rend"]              = 47465,
				["Thunder Clap"]      = 47502,
				["Sweeping Strikes"]  = 12328,
				["Bladestorm"]        = 46924,
				["Heroic Strike"]     = 47450,
				["Cleave"]            = 47520,
				["Battle Stance"]     = 2457,
				["Berserker Stance"]  = 2458,
				["Defensive Stance"]  = 71,
				["Charge"]            = 100,
				["Intercept"]         = 20252,
				["Intimidating Shout"] = 5246,
				["Shattering Throw"]  = 64382,
				["Retaliation"]       = 20230,
				["Pummel"]            = 6552,
				["Disarm"]            = 676,
				["Battleshout"]       = 47436,
				["Commanding Shout"]  = 47440,
				["Victory Rush"]      = 34428,
				["Trauma"]            = 46854,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				-- 1. Rend (maintain on target)
				if (exclude1 ~= sl["Rend"]) and (exclude2 ~= sl["Rend"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Rend"], "player")
					if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Rend"])
						if (d - timeshift) <= 0 then
							return sl["Rend"], IsSpellInRange(sl["Rend"], "target") ~= 1
						end
					end
				end

				-- 2. Execute (when target < 20% health)
				if (exclude1 ~= sl["Execute"]) and (exclude2 ~= sl["Execute"]) then
					if (UnitHealth("target") / UnitHealthMax("target")) < 0.2 then
						return sl["Execute"], IsSpellInRange(sl["Execute"], "target") ~= 1
					end
				end

				-- 3. Overpower (when proc is available)
				if (exclude1 ~= sl["Overpower"]) and (exclude2 ~= sl["Overpower"]) then
					local name = Rofaetion:hasBuff("player", "Overpower")
					if name then
						return sl["Overpower"], IsSpellInRange(sl["Overpower"], "target") ~= 1
					end
				end

				-- 4. Mortal Strike (on cooldown)
				if (exclude1 ~= sl["Mortal Strike"]) and (exclude2 ~= sl["Mortal Strike"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Mortal Strike"])
					if (d - timeshift) <= 0 then
						return sl["Mortal Strike"], IsSpellInRange(sl["Mortal Strike"], "target") ~= 1
					end
				end

				-- 5. Slam (Bloodsurge proc or filler)
				if (exclude1 ~= sl["Slam"]) and (exclude2 ~= sl["Slam"]) then
					if sl["Slam"] ~= (UnitCastingInfo("player")) then
						return sl["Slam"], IsSpellInRange(sl["Slam"], "target") ~= 1
					end
				end

				-- Fallback
				return sl["Mortal Strike"], IsSpellInRange(sl["Mortal Strike"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Battle Shout
				if Rofaetion:SpellAvailable(sl["Battleshout"]) then
					local name = Rofaetion:hasBuff("player", sl["Battleshout"])
					if not name then
						return sl["Battleshout"]
					end
				end

				-- Sweeping Strikes (on cooldown, when 2+ targets)
				if Rofaetion:SpellAvailable(sl["Sweeping Strikes"]) then
					if Rofaetion.person["foeCount"] >= 2 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Sweeping Strikes"])
						if d <= 0.5 then
							return sl["Sweeping Strikes"]
						end
					end
				end

				-- Bladestorm (on cooldown, AoE)
				if Rofaetion:SpellAvailable(sl["Bladestorm"]) then
					if Rofaetion.person["foeCount"] >= 3 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Bladestorm"])
						if d <= 0.5 then
							return sl["Bladestorm"]
						end
					end
				end

				-- Shattering Throw
				if Rofaetion:GetClassConfig().useShatteringThrow then
					if Rofaetion:SpellAvailable(sl["Shattering Throw"]) then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Shattering Throw"])
						if d <= 0.5 then
							return sl["Shattering Throw"]
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Pummel
				if Rofaetion:SpellAvailable(sl["Pummel"]) then
					if IsSpellInRange(sl["Pummel"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Pummel"])
							if d and d < 0.5 then
								return sl["Pummel"]
							end
						end
					end
				end

				-- Disarm
				if Rofaetion:SpellAvailable(sl["Disarm"]) then
					if IsSpellInRange(sl["Disarm"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Disarm"])
						if d <= 0.5 then
							return sl["Disarm"]
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Fury DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Fury",
			isDPS = true,
			debuffTrackerSpell = nil,

			spellList = {
				["Bloodthirst"]       = 23881,
				["Heroic Strike"]     = 47450,
				["Cleave"]            = 47520,
				["Execute"]           = 47467,
				["Whirlwind"]         = 49020,
				["Slam"]              = 47475,
				["Berserker Rage"]    = 18499,
				["Death Wish"]        = 12292,
				["Recklessness"]      = 1719,
				["Pummel"]            = 6552,
				["Disarm"]            = 676,
				["Battleshout"]       = 47436,
				["Commanding Shout"]  = 47440,
				["Intercept"]         = 20252,
				["Charge"]            = 100,
				["Victory Rush"]      = 34428,
				["Enraged Regeneration"] = 55694,
				["Intimidating Shout"] = 5246,
				["Battle Stance"]     = 2457,
				["Berserker Stance"]  = 2458,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				-- 1. Execute (when target < 20%)
				if (exclude1 ~= sl["Execute"]) and (exclude2 ~= sl["Execute"]) then
					if (UnitHealth("target") / UnitHealthMax("target")) < 0.2 then
						return sl["Execute"], IsSpellInRange(sl["Execute"], "target") ~= 1
					end
				end

				-- 2. Bloodthirst (on cooldown)
				if (exclude1 ~= sl["Bloodthirst"]) and (exclude2 ~= sl["Bloodthirst"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Bloodthirst"])
					if (d - timeshift) <= 0 then
						return sl["Bloodthirst"], IsSpellInRange(sl["Bloodthirst"], "target") ~= 1
					end
				end

				-- 3. Whirlwind (on cooldown, especially with 2+ targets)
				if (exclude1 ~= sl["Whirlwind"]) and (exclude2 ~= sl["Whirlwind"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Whirlwind"])
					if (d - timeshift) <= 0 then
						return sl["Whirlwind"], IsSpellInRange(sl["Whirlwind"], "target") ~= 1
					end
				end

				-- 4. Slam (Bloodsurge proc)
				if (exclude1 ~= sl["Slam"]) and (exclude2 ~= sl["Slam"]) then
					local name = Rofaetion:hasBuff("player", "Bloodsurge")
					if name then
						return sl["Slam"], IsSpellInRange(sl["Slam"], "target") ~= 1
					end
				end

				-- 5. Heroic Strike (Rage dump, 50+ rage)
				if (exclude1 ~= sl["Heroic Strike"]) and (exclude2 ~= sl["Heroic Strike"]) then
					if UnitPower("player", 1) >= 50 then
						return sl["Heroic Strike"], IsSpellInRange(sl["Heroic Strike"], "target") ~= 1
					end
				end

				-- Fallback: Bloodthirst
				return sl["Bloodthirst"], IsSpellInRange(sl["Bloodthirst"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Battle Shout
				if Rofaetion:SpellAvailable(sl["Battleshout"]) then
					local name = Rofaetion:hasBuff("player", sl["Battleshout"])
					if not name then
						return sl["Battleshout"]
					end
				end

				-- Death Wish (on cooldown)
				if Rofaetion:SpellAvailable(sl["Death Wish"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Death Wish"])
					if d <= 0.5 then
						return sl["Death Wish"]
					end
				end

				-- Recklessness (on cooldown)
				if Rofaetion:SpellAvailable(sl["Recklessness"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Recklessness"])
					if d <= 0.5 then
						return sl["Recklessness"]
					end
				end

				-- Berserker Rage (on cooldown, generates rage)
				if Rofaetion:SpellAvailable(sl["Berserker Rage"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Berserker Rage"])
					if d <= 0.5 then
						return sl["Berserker Rage"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Pummel
				if Rofaetion:SpellAvailable(sl["Pummel"]) then
					if IsSpellInRange(sl["Pummel"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Pummel"])
							if d and d < 0.5 then
								return sl["Pummel"]
							end
						end
					end
				end

				return ""
			end,
		},

		-- Tab 3: Protection (Tank)
		[3] = { name = "Protection", isDPS = false },
	},
})
