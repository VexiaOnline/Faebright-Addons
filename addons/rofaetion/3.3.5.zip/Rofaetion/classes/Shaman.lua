-------------------------------------------------------------------------------
-- Shaman Class Module for Rofaetion
--
-- DPS specs: Elemental (tab 1), Enhancement (tab 2)
-- Ports the original Elementarist rotation for Elemental.
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "SHAMAN",
	className = "Shaman",

	configOptions = {
		{ key = "fsBehaviour", type = "dropdown", label = "Flame Shock behaviour",
		  options = { "Keep Flame Shock up", "Flame Shock before Lava" }, default = 1 },
		{ key = "fireNova", type = "checkbox", label = "Enable Fire Nova in rotation", default = true },
		{ key = "clBehaviour", type = "dropdown", label = "Chain Lightning single target",
		  options = { "None", "Chain Lightning after Lava", "Chain Lightning on Cooldown" }, default = 1 },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Elemental DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Elemental",
			isDPS = true,
			debuffTrackerSpell = "Flame Shock",

			spellList = {
				["Flame Shock"]       = 49233,
				["Lightning Bolt"]    = 49238,
				["Lava Burst"]        = 60043,
				["Chain Lightning"]   = 49271,
				["Thunderstorm"]      = 59159,
				["Purge"]             = 8012,
				["Wind Shear"]        = 57994,
				["Water Shield"]      = 57960,
				["Flametongue Weapon"] = 58790,
				["Totem of Wrath Totem"] = 57722,
				["Wrath of Air Totem"]   = 3738,
				["Mana Spring Totem"]    = 58777,
				["Totem of Wrath"]       = 63283,
				["Elemental Mastery"]    = 16166,
				["Fire Nova"]            = 61657,
				["Berserking"]           = 26297,
				["Blood Fury"]           = 33697,
				["Totem of Wrath Debuff"] = 30708,
				["Heart of the Crusader"] = 54499,
				["Demonic Pact"]         = 48090,
				["Flask of the North Spell"] = 67016,
				["Flask of the Frost Wyrm"] = 53755,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()
				local fsBehaviour = cfg.fsBehaviour or 1
				local clBehaviour = cfg.clBehaviour or 1

				local currentTime = GetTime()
				local lastSpell = exclude2 or exclude1 or Rofaetion.lastSpell

				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				local flameshockavail = false
				local LvBct = 2 - (2 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end

				if not timeshift then timeshift = 0 end

				-- Calculate timeshift from current cast
				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					if sl["Flametongue Weapon"] then
						local ftcd = Rofaetion:GetSpellCooldownRemaining(sl["Flametongue Weapon"])
						if ftcd then
							timeshift = timeshift + ftcd
						else
							timeshift = timeshift + Rofaetion.lastBaseGCD
						end
					else
						timeshift = timeshift + Rofaetion.lastBaseGCD
					end
				end

				-- 1. Flame Shock
				if (exclude1 ~= sl["Flame Shock"]) and (exclude2 ~= sl["Flame Shock"]) then
					if IsSpellInRange(sl["Flame Shock"], "target") == 1 then
						local name, rank, icon, count, debuffType, duration, fsExpiration, unitCaster = Rofaetion:hasDeBuff("target", sl["Flame Shock"], "player")
						if not fsExpiration then fsExpiration = 0 end
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Flame Shock"])
						if (d - timeshift) <= 0 then
							flameshockavail = true
							local doFS = false
							if unitCaster ~= "player" then
								name = false
								fsExpiration = 0
							end
							if not name then
								fsExpiration = 0
							end
							if fsBehaviour == 1 then
								doFS = true
							else
								d = Rofaetion:GetSpellCooldownRemaining(sl["Lava Burst"])
								if d <= (timeshift + Rofaetion.lastBaseGCD) then
									doFS = true
								end
							end
							if doFS and ((fsExpiration - GetTime() - timeshift) < 0) then
								return sl["Flame Shock"]
							end
						end
					end
				end

				-- 2. Lava Burst
				if not fsExpiration then fsExpiration = 0 end
				if (exclude1 ~= sl["Lava Burst"]) and (exclude2 ~= sl["Lava Burst"]) then
					if (IsSpellInRange(sl["Lava Burst"], "target") == 1) and
						(
							((fsExpiration ~= 0) and ((fsExpiration - GetTime() - timeshift) > LvBct)) or
							(exclude1 == sl["Flame Shock"]) or
							(exclude2 == sl["Flame Shock"])
						) then
						if sl["Lava Burst"] ~= spellInCast then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Lava Burst"])
							if (d - timeshift) <= 0 then
								return sl["Lava Burst"]
							end
						end
					end
				end

				-- 3. Fire Nova (3+ targets)
				if (exclude1 ~= sl["Fire Nova"]) and (exclude2 ~= sl["Fire Nova"]) then
					if cfg.fireNova and (Rofaetion.person["foeCount"] >= 3) then
						local haveFireTotem, fireTotemName, _, _ = GetTotemInfo(1)
						if haveFireTotem and fireTotemName ~= "" then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Fire Nova"])
							if (d - timeshift) <= 0 then
								return sl["Fire Nova"]
							end
						end
					end
				end

				-- 4. Chain Lightning
				if (exclude1 ~= sl["Chain Lightning"]) and (exclude2 ~= sl["Chain Lightning"]) then
					if (clBehaviour == 3) or
						((clBehaviour == 2) and (lastSpell == sl["Lava Burst"])) or
						(Rofaetion.person["foeCount"] > 1) then
						if IsSpellInRange(sl["Chain Lightning"], "target") == 1 then
							if sl["Chain Lightning"] ~= spellInCast then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Chain Lightning"])
								if (d - timeshift) <= 0 then
									return sl["Chain Lightning"]
								end
							end
						end
					end
				end

				-- 5. Lightning Bolt (filler)
				if IsSpellInRange(sl["Lightning Bolt"], "target") == 1 then
					return sl["Lightning Bolt"]
				end

				-- Fallback: Flame Shock
				if flameshockavail then
					return sl["Flame Shock"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Flask check
				local flaskSpellID = sl["Flask of the North Spell"]
				if flaskSpellID and GetItemCount(47499) ~= 0 then
					local name = Rofaetion:hasBuff("player", sl["Flask of the Frost Wyrm"])
					if not name then
						name = Rofaetion:hasBuff("player", nil, false, flaskSpellID)
						if not name then
							return nil, GetItemIcon(47499)
						end
					end
				end

				-- Flametongue Weapon
				if Rofaetion:SpellAvailable(sl["Flametongue Weapon"]) then
					local hasMainHandEnchant, mainHandExpiration = GetWeaponEnchantInfo()
					if not hasMainHandEnchant or ((mainHandExpiration / 60000) < 1) then
						return sl["Flametongue Weapon"]
					end
				end

				-- Water Shield
				if Rofaetion:SpellAvailable(sl["Water Shield"]) then
					local name = Rofaetion:hasBuff("player", sl["Water Shield"])
					if not name then
						return sl["Water Shield"]
					end
				end

				-- Totem of Wrath
				if Rofaetion:SpellAvailable(sl["Totem of Wrath Totem"]) then
					local name = Rofaetion:hasBuff("player", sl["Demonic Pact"])
					if not name then
						local totemName, _, _, _, duration = Rofaetion:hasTotem("player", sl["Totem of Wrath Totem"])
						if not totemName or duration > 0 then
							return sl["Totem of Wrath Totem"]
						end
					end
					name = Rofaetion:hasDeBuff("target", sl["Heart of the Crusader"], nil)
					if not name then
						name = Rofaetion:hasDeBuff("target", sl["Totem of Wrath Debuff"], "player")
						if not name then
							return sl["Totem of Wrath Totem"]
						end
					end
				end

				-- Wrath of Air Totem
				if Rofaetion:SpellAvailable(sl["Wrath of Air Totem"]) then
					local name = Rofaetion:hasTotem("player", sl["Wrath of Air Totem"])
					if not name then
						return sl["Wrath of Air Totem"]
					end
				end

				-- Elemental Mastery
				if Rofaetion:SpellAvailable(sl["Elemental Mastery"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Elemental Mastery"])
					if d <= 0.5 then
						return sl["Elemental Mastery"]
					end
				end

				-- Berserking (Troll racial)
				if Rofaetion:SpellAvailable(sl["Berserking"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Berserking"])
					if d <= 0.5 then
						return sl["Berserking"]
					end
				end

				-- Blood Fury (Orc racial)
				if Rofaetion:SpellAvailable(sl["Blood Fury"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Blood Fury"])
					if d <= 0.5 then
						return sl["Blood Fury"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Wind Shear (interrupt)
				if Rofaetion:SpellAvailable(sl["Wind Shear"]) then
					if IsSpellInRange(sl["Wind Shear"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						local _, status, threatpct = UnitDetailedThreatSituation("player", "target")
						if ((name) or (channel)) or ((status) and (threatpct > 80) and (Rofaetion.person["friendCount"] > 1) and (Rofaetion.inParty > 0)) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Wind Shear"])
							if d and d < 0.5 then
								return sl["Wind Shear"]
							end
						end

						local name2, _, _, _, _, _, _, _, interruptable = UnitChannelInfo("target")
						if name2 then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Wind Shear"])
							if d < 0.5 and interruptable then
								return sl["Wind Shear"]
							end
						end
					end
				end

				-- Thunderstorm (mana regen)
				if Rofaetion:SpellAvailable(sl["Thunderstorm"]) then
					local d = GetSpellCooldown(sl["Thunderstorm"])
					if d and ((UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.7) and (d < 0.5) then
						return sl["Thunderstorm"]
					end
				end

				-- Purge
				if Rofaetion:SpellAvailable(sl["Purge"]) then
					if IsSpellInRange(sl["Purge"], "target") == 1 then
						local name = Rofaetion:hasBuff("target", ".", 1)
						if name then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Purge"])
							if d < 0.5 then
								return sl["Purge"]
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Enhancement DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Enhancement",
			isDPS = true,
			debuffTrackerSpell = "Stormstrike",

			spellList = {
				["Stormstrike"]         = 17364,
				["Lava Lash"]           = 60103,
				["Earth Shock"]         = 49231,
				["Frost Shock"]         = 49236,
				["Fire Nova"]           = 61657,
				["Lightning Bolt"]      = 49238,
				["Flame Shock"]         = 49233,
				["Magma Totem"]         = 58734,
				["Strength of Earth Totem"] = 58643,
				["Windfury Weapon"]     = 58804,
				["Flametongue Weapon"]  = 58790,
				["Lightning Shield"]    = 49281,
				["Windfury Totem"]      = 2895,
				["Wrath of Air Totem"]  = 3738,
				["Shamanistic Rage"]    = 30823,
				["Purge"]               = 8012,
				["Wind Shear"]          = 57994,
				["Berserking"]          = 26297,
				["Blood Fury"]          = 33697,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Stormstrike
				if (exclude1 ~= sl["Stormstrike"]) and (exclude2 ~= sl["Stormstrike"]) then
					if sl["Stormstrike"] ~= spellInCast then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Stormstrike"])
						if (d - timeshift) <= 0 then
							return sl["Stormstrike"], IsSpellInRange(sl["Stormstrike"], "target") ~= 1
						end
					end
				end

				-- 2. Lava Lash
				if (exclude1 ~= sl["Lava Lash"]) and (exclude2 ~= sl["Lava Lash"]) then
					if sl["Lava Lash"] ~= spellInCast then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Lava Lash"])
						if (d - timeshift) <= 0 then
							return sl["Lava Lash"], IsSpellInRange(sl["Lava Lash"], "target") ~= 1
						end
					end
				end

				-- 3. Earth Shock (with 5 Maelstrom Weapon or on cooldown)
				if (exclude1 ~= sl["Earth Shock"]) and (exclude2 ~= sl["Earth Shock"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Earth Shock"])
					if (d - timeshift) <= 0 then
						return sl["Earth Shock"], IsSpellInRange(sl["Earth Shock"], "target") ~= 1
					end
				end

				-- 4. Fire Nova (AoE)
				if (exclude1 ~= sl["Fire Nova"]) and (exclude2 ~= sl["Fire Nova"]) then
					if Rofaetion.person["foeCount"] >= 3 then
						local haveFireTotem, fireTotemName = GetTotemInfo(1)
						if haveFireTotem and fireTotemName ~= "" then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Fire Nova"])
							if (d - timeshift) <= 0 then
								return sl["Fire Nova"]
							end
						end
					end
				end

				-- 5. Lightning Bolt (filler / at 5 stacks Maelstrom Weapon)
				return sl["Lightning Bolt"], IsSpellInRange(sl["Lightning Bolt"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Windfury Weapon
				if Rofaetion:SpellAvailable(sl["Windfury Weapon"]) then
					local hasMainHandEnchant = GetWeaponEnchantInfo()
					if not hasMainHandEnchant then
						return sl["Windfury Weapon"]
					end
				end

				-- Flametongue Weapon (off-hand)
				-- Enhancement keeps both weapon enchants up

				-- Lightning Shield
				if Rofaetion:SpellAvailable(sl["Lightning Shield"]) then
					local name = Rofaetion:hasBuff("player", sl["Lightning Shield"])
					if not name then
						return sl["Lightning Shield"]
					end
				end

				-- Magma Totem
				if Rofaetion:SpellAvailable(sl["Magma Totem"]) then
					local totemName = Rofaetion:hasTotem("player", sl["Magma Totem"])
					if not totemName then
						return sl["Magma Totem"]
					end
				end

				-- Strength of Earth Totem
				if Rofaetion:SpellAvailable(sl["Strength of Earth Totem"]) then
					local totemName = Rofaetion:hasTotem("player", sl["Strength of Earth Totem"])
					if not totemName then
						return sl["Strength of Earth Totem"]
					end
				end

				-- Windfury Totem
				if Rofaetion:SpellAvailable(sl["Windfury Totem"]) then
					local totemName = Rofaetion:hasTotem("player", sl["Windfury Totem"])
					if not totemName then
						return sl["Windfury Totem"]
					end
				end

				-- Wrath of Air Totem
				if Rofaetion:SpellAvailable(sl["Wrath of Air Totem"]) then
					local totemName = Rofaetion:hasTotem("player", sl["Wrath of Air Totem"])
					if not totemName then
						return sl["Wrath of Air Totem"]
					end
				end

				-- Shamanistic Rage
				if Rofaetion:SpellAvailable(sl["Shamanistic Rage"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Shamanistic Rage"])
					if d <= 0.5 then
						return sl["Shamanistic Rage"]
					end
				end

				-- Berserking (Troll racial)
				if Rofaetion:SpellAvailable(sl["Berserking"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Berserking"])
					if d <= 0.5 then return sl["Berserking"] end
				end

				-- Blood Fury (Orc racial)
				if Rofaetion:SpellAvailable(sl["Blood Fury"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Blood Fury"])
					if d <= 0.5 then return sl["Blood Fury"] end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Wind Shear
				if Rofaetion:SpellAvailable(sl["Wind Shear"]) then
					if IsSpellInRange(sl["Wind Shear"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Wind Shear"])
							if d and d < 0.5 then
								return sl["Wind Shear"]
							end
						end
					end
				end

				-- Purge
				if Rofaetion:SpellAvailable(sl["Purge"]) then
					if IsSpellInRange(sl["Purge"], "target") == 1 then
						local name = Rofaetion:hasBuff("target", ".", 1)
						if name then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Purge"])
							if d < 0.5 then
								return sl["Purge"]
							end
						end
					end
				end

				return ""
			end,
		},

		-- Tab 3: Restoration (Healer, not supported)
		[3] = {
			name = "Restoration",
			isDPS = false,
		},
	},
})
