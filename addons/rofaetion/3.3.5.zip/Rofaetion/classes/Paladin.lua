-------------------------------------------------------------------------------
-- Paladin Class Module for Rofaetion
--
-- DPS spec: Retribution (tab 3)
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "PALADIN",
	className = "Paladin",

	configOptions = {
		{ key = "consecrationOnCD", type = "checkbox", label = "Consecration on cooldown", default = true },
		{ key = "useExorcism", type = "checkbox", label = "Exorcism (Art of War proc)", default = true },
	},

	specs = {
		-- Tab 1: Holy (Healer)
		[1] = { name = "Holy", isDPS = false },
		-- Tab 2: Protection (Tank)
		[2] = { name = "Protection", isDPS = false },

		-----------------------------------------------------------------------
		-- Retribution DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Retribution",
			isDPS = true,
			debuffTrackerSpell = "Judgement of Light",

			spellList = {
				["Crusader Strike"]     = 35395,
				["Divine Storm"]        = 53385,
				["Judgement"]           = 53408,
				["Judgement of Light"]  = 20271,
				["Exorcism"]            = 48801,
				["Consecration"]        = 48819,
				["Holy Wrath"]          = 48817,
				["Hammer of Wrath"]     = 48806,
				["Seal of Command"]     = 20375,
				["Seal of Corruption"]  = 53736,
				["Seal of Righteousness"] = 20154,
				["Blessing of Might"]   = 48932,
				["Blessing of Kings"]   = 20217,
				["Righteous Fury"]      = 25780,
				["Hammer of Justice"]   = 10308,
				["Cleanse"]             = 4987,
				["Divine Plea"]         = 54428,
				["Avenging Wrath"]      = 31884,
				["Repentance"]          = 20066,
				["Forbearance"]         = 25771,
				["Sacred Shield"]       = 53601,
				["Hand of Reckoning"]   = 62124,
				["Turn Evil"]           = 2878,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Judgment (on cooldown, primary rotation starter)
				if (exclude1 ~= sl["Judgement"]) and (exclude2 ~= sl["Judgement"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Judgement"])
					if (d - timeshift) <= 0 then
						return sl["Judgement"], IsSpellInRange(sl["Judgement"], "target") ~= 1
					end
				end

				-- 2. Divine Storm (on cooldown)
				if (exclude1 ~= sl["Divine Storm"]) and (exclude2 ~= sl["Divine Storm"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Divine Storm"])
					if (d - timeshift) <= 0 then
						return sl["Divine Storm"], IsSpellInRange(sl["Divine Storm"], "target") ~= 1
					end
				end

				-- 3. Crusader Strike (on cooldown)
				if (exclude1 ~= sl["Crusader Strike"]) and (exclude2 ~= sl["Crusader Strike"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Crusader Strike"])
					if (d - timeshift) <= 0 then
						return sl["Crusader Strike"], IsSpellInRange(sl["Crusader Strike"], "target") ~= 1
					end
				end

				-- 4. Exorcism (Art of War proc)
				if cfg.useExorcism then
					if (exclude1 ~= sl["Exorcism"]) and (exclude2 ~= sl["Exorcism"]) then
						local name = Rofaetion:hasBuff("player", "Art of War")
						if name then
							if sl["Exorcism"] ~= spellInCast then
								return sl["Exorcism"], IsSpellInRange(sl["Exorcism"], "target") ~= 1
							end
						end
					end
				end

				-- 5. Hammer of Wrath (on cooldown, requires Avenging Wrath or <20% HP)
				if (exclude1 ~= sl["Hammer of Wrath"]) and (exclude2 ~= sl["Hammer of Wrath"]) then
					if (UnitHealth("target") / UnitHealthMax("target")) < 0.2 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Hammer of Wrath"])
						if (d - timeshift) <= 0 then
							return sl["Hammer of Wrath"], IsSpellInRange(sl["Hammer of Wrath"], "target") ~= 1
						end
					end
				end

				-- 6. Consecration (on cooldown if enabled)
				if cfg.consecrationOnCD then
					if (exclude1 ~= sl["Consecration"]) and (exclude2 ~= sl["Consecration"]) then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Consecration"])
						if (d - timeshift) <= 0 then
							return sl["Consecration"]
						end
					end
				end

				-- 7. Holy Wrath (if no other abilities available)
				if (exclude1 ~= sl["Holy Wrath"]) and (exclude2 ~= sl["Holy Wrath"]) then
					if Rofaetion.person["foeCount"] > 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Holy Wrath"])
						if (d - timeshift) <= 0 then
							return sl["Holy Wrath"]
						end
					end
				end

				-- Fallback
				return sl["Crusader Strike"], IsSpellInRange(sl["Crusader Strike"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Seal of Corruption / Seal of Command
				if Rofaetion:SpellAvailable(sl["Seal of Corruption"]) then
					local name = Rofaetion:hasBuff("player", "Seal of")
					if not name then
						return sl["Seal of Corruption"]
					end
				elseif Rofaetion:SpellAvailable(sl["Seal of Command"]) then
					local name = Rofaetion:hasBuff("player", "Seal of")
					if not name then
						return sl["Seal of Command"]
					end
				end

				-- Blessing of Might
				if Rofaetion:SpellAvailable(sl["Blessing of Might"]) then
					local name = Rofaetion:hasBuff("player", sl["Blessing of Might"])
					if not name then
						return sl["Blessing of Might"]
					end
				end

				-- Avenging Wrath (on cooldown)
				if Rofaetion:SpellAvailable(sl["Avenging Wrath"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Avenging Wrath"])
					if d <= 0.5 then
						return sl["Avenging Wrath"]
					end
				end

				-- Divine Plea (mana < 50%)
				if Rofaetion:SpellAvailable(sl["Divine Plea"]) then
					if (UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.5 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Divine Plea"])
						if d <= 0.5 then
							return sl["Divine Plea"]
						end
					end
				end

				-- Sacred Shield (maintain)
				if Rofaetion:SpellAvailable(sl["Sacred Shield"]) then
					local name = Rofaetion:hasBuff("player", sl["Sacred Shield"])
					if not name then
						return sl["Sacred Shield"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Hammer of Justice (interrupt/stun)
				if Rofaetion:SpellAvailable(sl["Hammer of Justice"]) then
					if IsSpellInRange(sl["Hammer of Justice"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Hammer of Justice"])
							if d and d < 0.5 then
								return sl["Hammer of Justice"]
							end
						end
					end
				end

				return ""
			end,
		},
	},
})
