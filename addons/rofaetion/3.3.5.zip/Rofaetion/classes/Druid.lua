-------------------------------------------------------------------------------
-- Druid Class Module for Rofaetion
--
-- DPS specs: Balance (tab 1), Feral Combat Cat (tab 2)
-- Tab 2 (Feral) can also be Bear (Tank), detected by form
-- Tab 3 (Restoration) is a Healer
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "DRUID",
	className = "Druid",

	configOptions = {
		{ key = "useFaerieFire", type = "checkbox", label = "Faerie Fire as cooldown (Balance)", default = true },
		{ key = "useForceOfNature", type = "checkbox", label = "Force of Nature on cooldown (Balance)", default = true },
		{ key = "useStarfall", type = "checkbox", label = "Starfall on 3+ targets (Balance)", default = true },
		{ key = "useSwipe", type = "checkbox", label = "Swipe on 3+ targets (Feral Cat)", default = true },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Balance DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Balance",
			isDPS = true,
			debuffTrackerSpell = "Moonfire",

			spellList = {
				["Starfire"]          = 48465,
				["Wrath"]             = 48461,
				["Moonfire"]          = 48463,
				["Insect Swarm"]      = 48468,
				["Starfall"]          = 53201,
				["Typhoon"]           = 61384,
				["Hurricane"]         = 48467,
				["Force of Nature"]   = 33831,
				["Moonkin Form"]      = 24858,
				["Mark of the Wild"]  = 48469,
				["Thorns"]            = 53307,
				["Faerie Fire"]       = 770,
				["Innervate"]         = 29166,
				["Barkskin"]          = 22812,
				["Roots"]             = 53313,
				["Cyclone"]           = 33786,
				["Entangling Roots"]  = 26989,
				["Nature's Grasp"]    = 16689,
				["Swift Flight Form"] = 40120,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- Check Eclipse state (tracked via combat log, no timeshift - all casts consistent)
				local eclipseActive = nil
				if Rofaetion.eclipseProc and Rofaetion.eclipseProc.expiry > GetTime() then
					eclipseActive = Rofaetion.eclipseProc.type
				end

				-- Determine filler: cycles between Wrath/Starfire based on Eclipse history
				-- Solar active/expired → Wrath (fishing for Lunar from Wrath crits)
				-- Lunar active/expired → Starfire (fishing for Solar from Starfire crits)
				-- No history → Wrath
				local fillerSpell = sl["Wrath"]
				if eclipseActive == "lunar" or (not eclipseActive and Rofaetion.lastEclipseType == "lunar") then
					fillerSpell = sl["Starfire"]
				end

				-- 1. Starfall (AoE, 3+ targets, on cooldown)
				if cfg.useStarfall then
					if Rofaetion.person["foeCount"] >= 3 then
						if (exclude1 ~= sl["Starfall"]) and (exclude2 ~= sl["Starfall"]) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Starfall"])
							if (d - timeshift) <= 0 then
								return sl["Starfall"]
							end
						end
					end
				end

				-- 2. Insect Swarm (maintain)
				if (exclude1 ~= sl["Insect Swarm"]) and (exclude2 ~= sl["Insect Swarm"]) then
					if IsSpellInRange(sl["Insect Swarm"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Insect Swarm"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							return sl["Insect Swarm"]
						end
					end
				end

				-- 3. Moonfire (maintain)
				if (exclude1 ~= sl["Moonfire"]) and (exclude2 ~= sl["Moonfire"]) then
					if IsSpellInRange(sl["Moonfire"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Moonfire"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							return sl["Moonfire"]
						end
					end
				end

				-- 4. Eclipse-reactive spell swap
				if eclipseActive == "solar" then
					-- Solar Eclipse (48517): increases Wrath damage → cast Wrath
					if (exclude1 ~= sl["Wrath"]) and (exclude2 ~= sl["Wrath"]) then
						if IsSpellInRange(sl["Wrath"], "target") == 1 then
							if sl["Wrath"] ~= spellInCast then
								return sl["Wrath"]
							end
						end
					end
				elseif eclipseActive == "lunar" then
					-- Lunar Eclipse (48518): increases Starfire crit → cast Starfire
					if (exclude1 ~= sl["Starfire"]) and (exclude2 ~= sl["Starfire"]) then
						if IsSpellInRange(sl["Starfire"], "target") == 1 then
							if sl["Starfire"] ~= spellInCast then
								return sl["Starfire"]
							end
						end
					end
				end

				-- 5. Filler (cycles based on Eclipse history)
				if (exclude1 ~= fillerSpell) and (exclude2 ~= fillerSpell) then
					if IsSpellInRange(fillerSpell, "target") == 1 then
						if fillerSpell ~= spellInCast then
							return fillerSpell
						end
					end
				end

				-- Fallback (uses filler even if excluded - Eclipse requires same spell for all casts)
				if IsSpellInRange(fillerSpell, "target") == 1 then
					return fillerSpell
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()

				-- Faerie Fire (maintain on target - increases spell hit/crit)
				if cfg.useFaerieFire then
					if Rofaetion:SpellAvailable(sl["Faerie Fire"]) then
						if IsSpellInRange(sl["Faerie Fire"], "target") == 1 then
							local name = Rofaetion:hasDeBuff("target", sl["Faerie Fire"], "player")
							if not name then
								return sl["Faerie Fire"]
							end
						end
					end
				end

				-- Force of Nature (Treants - on cooldown)
				if cfg.useForceOfNature then
					if Rofaetion:SpellAvailable(sl["Force of Nature"]) then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Force of Nature"])
						if d <= 0.5 then
							return sl["Force of Nature"]
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Nature's Grasp / Entangling Roots
				if Rofaetion:SpellAvailable(sl["Cyclone"]) then
					if IsSpellInRange(sl["Cyclone"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Cyclone"])
							if d and d < 0.5 then
								return sl["Cyclone"]
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Feral Combat DPS (Tab 2) - Cat Form
		-----------------------------------------------------------------------
		[2] = {
			name = "Feral (Cat)",
			isDPS = true,
			debuffTrackerSpell = function()
				-- Track Rip or Savage Roar depending on what's active
				return "Rip"
			end,

			spellList = {
				["Mangle (Cat)"]       = 33917,
				["Shred"]              = 48572,
				["Rip"]                = 49799,
				["Ferocious Bite"]     = 48577,
				["Savage Roar"]        = 52610,
				["Rake"]               = 48574,
				["Tiger's Fury"]       = 50213,
				["Berserk"]            = 50334,
				["Swipe (Cat)"]        = 62078,
				["Cat Form"]           = 768,
				["Bear Form"]          = 5487,
				["Mark of the Wild"]   = 48469,
				["Thorns"]             = 53307,
				["Faerie Fire (Feral)"] = 16857,
				["Cower"]              = 8998,
				["Pounce"]             = 9005,
				["Ravage"]             = 6785,
				["Survival Instincts"] = 61336,
				["Feral Charge (Cat)"] = 49376,
				["Roar"]               = 77761,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()
				Rofaetion.lastBaseGCD = 1.0 - (1.0 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local comboPoints = GetComboPoints("player", "target")

				-- Check if we're in Cat Form
				local inCatForm = Rofaetion:hasBuff("player", sl["Cat Form"])
				if not inCatForm then
					return sl["Cat Form"]
				end

				-- 1. Savage Roar (maintain, refresh when low or at 5 CP)
				if (exclude1 ~= sl["Savage Roar"]) and (exclude2 ~= sl["Savage Roar"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasBuff("player", sl["Savage Roar"])
					if not name or (expiration and (expiration - GetTime() - timeshift) < 1) then
						if comboPoints >= 1 then
							return sl["Savage Roar"]
						end
					end
				end

				-- 2. Mangle (Cat) (maintain debuff on target)
				if (exclude1 ~= sl["Mangle (Cat)"]) and (exclude2 ~= sl["Mangle (Cat)"]) then
					local name = Rofaetion:hasDeBuff("target", "Mangle", "player")
					if not name then
						return sl["Mangle (Cat)"], IsSpellInRange(sl["Mangle (Cat)"], "target") ~= 1
					end
				end

				-- 3. Rip (at 5 CP, maintain)
				if (exclude1 ~= sl["Rip"]) and (exclude2 ~= sl["Rip"]) then
					if comboPoints >= 5 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Rip"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 3) then
							return sl["Rip"]
						end
					end
				end

				-- 4. Ferocious Bite (at 5 CP when Rip is up, or execute)
				if (exclude1 ~= sl["Ferocious Bite"]) and (exclude2 ~= sl["Ferocious Bite"]) then
					if comboPoints >= 5 then
						local ripActive = Rofaetion:hasDeBuff("target", sl["Rip"], "player")
						if ripActive then
							return sl["Ferocious Bite"], IsSpellInRange(sl["Ferocious Bite"], "target") ~= 1
						end
					end
				end

				-- 5. Tiger's Fury (on cooldown, when not energy capped)
				if (exclude1 ~= sl["Tiger's Fury"]) and (exclude2 ~= sl["Tiger's Fury"]) then
					if UnitPower("player", 3) < 80 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Tiger's Fury"])
						if (d - timeshift) <= 0 then
							return sl["Tiger's Fury"]
						end
					end
				end

				-- 6. Berserk (on cooldown)
				if (exclude1 ~= sl["Berserk"]) and (exclude2 ~= sl["Berserk"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Berserk"])
					if (d - timeshift) <= 0 then
						return sl["Berserk"]
					end
				end

				-- 7. Rake (maintain, if no Mangle debuff and need DoT)
				if (exclude1 ~= sl["Rake"]) and (exclude2 ~= sl["Rake"]) then
					local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Rake"], "player")
					if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
						return sl["Rake"], IsSpellInRange(sl["Rake"], "target") ~= 1
					end
				end

				-- 8. Shred (CP builder / filler)
				if (exclude1 ~= sl["Shred"]) and (exclude2 ~= sl["Shred"]) then
					if comboPoints < 5 then
						return sl["Shred"], IsSpellInRange(sl["Shred"], "target") ~= 1
					end
				end

				-- Fallback
				return sl["Shred"], IsSpellInRange(sl["Shred"], "target") ~= 1
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Cat Form (if not in cat form)
				if Rofaetion:SpellAvailable(sl["Cat Form"]) then
					local name = Rofaetion:hasBuff("player", sl["Cat Form"])
					if not name then
						return sl["Cat Form"]
					end
				end

				-- Mark of the Wild
				if Rofaetion:SpellAvailable(sl["Mark of the Wild"]) then
					local name = Rofaetion:hasBuff("player", sl["Mark of the Wild"])
					if not name then
						return sl["Mark of the Wild"]
					end
				end

				-- Thorns
				if Rofaetion:SpellAvailable(sl["Thorns"]) then
					local name = Rofaetion:hasBuff("player", sl["Thorns"])
					if not name then
						return sl["Thorns"]
					end
				end

				-- Faerie Fire (Feral)
				if Rofaetion:SpellAvailable(sl["Faerie Fire (Feral)"]) then
					if IsSpellInRange(sl["Faerie Fire (Feral)"], "target") == 1 then
						local name = Rofaetion:hasDeBuff("target", "Faerie Fire", "player")
						if not name then
							return sl["Faerie Fire (Feral)"]
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Bash (interrupt in Cat/Bear form)
				if Rofaetion:SpellAvailable(5211) then
					if IsSpellInRange(5211, "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(5211)
							if d and d < 0.5 then
								return 5211
							end
						end
					end
				end

				return ""
			end,
		},

		-- Tab 3: Restoration (Healer)
		[3] = { name = "Restoration", isDPS = false },
	},
})
