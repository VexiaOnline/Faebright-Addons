-------------------------------------------------------------------------------
-- Hunter Class Module for Rofaetion
--
-- DPS specs: Beast Mastery (tab 1), Marksmanship (tab 2), Survival (tab 3)
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "HUNTER",
	className = "Hunter",

	configOptions = {
		{ key = "useKillShot", type = "checkbox", label = "Kill Shot in rotation (<20%)", default = true },
		{ key = "multiShotAoE", type = "checkbox", label = "Multi-Shot for AoE", default = true },
	},

	specs = {
		-----------------------------------------------------------------------
		-- Beast Mastery DPS (Tab 1)
		-----------------------------------------------------------------------
		[1] = {
			name = "Beast Mastery",
			isDPS = true,
			debuffTrackerSpell = "Serpent Sting",

			spellList = {
				["Steady Shot"]       = 49050,
				["Arcane Shot"]       = 49048,
				["Kill Shot"]         = 61005,
				["Serpent Sting"]     = 49001,
				["Hunter's Mark"]     = 53338,
				["Kill Command"]      = 34026,
				["Mend Pet"]          = 48990,
				["Intimidation"]      = 19577,
				["Bestial Wrath"]     = 19574,
				["Rapid Fire"]        = 3045,
				["Multi-Shot"]        = 49045,
				["Volley"]            = 58434,
				["Disengage"]         = 781,
				["Concussive Shot"]   = 5116,
				["Trap Launcher"]     = 77769,
				["Explosive Trap"]    = 60202,
				["Freezing Trap"]     = 1499,
				["Wyvern Sting"]      = 49011,
				["Trueshot Aura"]     = 19506,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Kill Shot (execute, target < 20%)
				if Rofaetion:GetClassConfig().useKillShot then
					if (exclude1 ~= sl["Kill Shot"]) and (exclude2 ~= sl["Kill Shot"]) then
						if (UnitHealth("target") / UnitHealthMax("target")) < 0.2 then
							if IsSpellInRange(sl["Kill Shot"], "target") == 1 then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Kill Shot"])
								if (d - timeshift) <= 0 then
									return sl["Kill Shot"]
								end
							end
						end
					end
				end

				-- 2. Serpent Sting (maintain)
				if (exclude1 ~= sl["Serpent Sting"]) and (exclude2 ~= sl["Serpent Sting"]) then
					if IsSpellInRange(sl["Serpent Sting"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Serpent Sting"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							return sl["Serpent Sting"]
						end
					end
				end

				-- 3. Kill Command (on cooldown)
				if (exclude1 ~= sl["Kill Command"]) and (exclude2 ~= sl["Kill Command"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Kill Command"])
					if (d - timeshift) <= 0 then
						return sl["Kill Command"]
					end
				end

				-- 4. Arcane Shot (on cooldown)
				if (exclude1 ~= sl["Arcane Shot"]) and (exclude2 ~= sl["Arcane Shot"]) then
					if IsSpellInRange(sl["Arcane Shot"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Arcane Shot"])
						if (d - timeshift) <= 0 then
							return sl["Arcane Shot"]
						end
					end
				end

				-- 5. Steady Shot (filler)
				if (exclude1 ~= sl["Steady Shot"]) and (exclude2 ~= sl["Steady Shot"]) then
					if IsSpellInRange(sl["Steady Shot"], "target") == 1 then
						if sl["Steady Shot"] ~= spellInCast then
							return sl["Steady Shot"]
						end
					end
				end

				if IsSpellInRange(sl["Steady Shot"], "target") == 1 then
					return sl["Steady Shot"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Hunter's Mark
				if Rofaetion:SpellAvailable(sl["Hunter's Mark"]) then
					if IsSpellInRange(sl["Hunter's Mark"], "target") == 1 then
						local name = Rofaetion:hasDeBuff("target", sl["Hunter's Mark"], nil)
						if not name then
							return sl["Hunter's Mark"]
						end
					end
				end

				-- Mend Pet
				if Rofaetion:SpellAvailable(sl["Mend Pet"]) then
					if UnitExists("pet") then
						if (UnitHealth("pet") / UnitHealthMax("pet")) < 0.8 then
							local name = Rofaetion:hasBuff("pet", sl["Mend Pet"])
							if not name then
								return sl["Mend Pet"]
							end
						end
					end
				end

				-- Bestial Wrath (on cooldown)
				if Rofaetion:SpellAvailable(sl["Bestial Wrath"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Bestial Wrath"])
					if d <= 0.5 then
						return sl["Bestial Wrath"]
					end
				end

				-- Rapid Fire (on cooldown)
				if Rofaetion:SpellAvailable(sl["Rapid Fire"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Rapid Fire"])
					if d <= 0.5 then
						return sl["Rapid Fire"]
					end
				end

				-- Trueshot Aura
				if Rofaetion:SpellAvailable(sl["Trueshot Aura"]) then
					local name = Rofaetion:hasBuff("player", sl["Trueshot Aura"])
					if not name then
						return sl["Trueshot Aura"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Concussive Shot (slow)
				if Rofaetion:SpellAvailable(sl["Concussive Shot"]) then
					if IsSpellInRange(sl["Concussive Shot"], "target") == 1 then
						return sl["Concussive Shot"]
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Marksmanship DPS (Tab 2)
		-----------------------------------------------------------------------
		[2] = {
			name = "Marksmanship",
			isDPS = true,
			debuffTrackerSpell = "Serpent Sting",

			spellList = {
				["Chimera Shot"]      = 53209,
				["Steady Shot"]       = 49050,
				["Arcane Shot"]       = 49048,
				["Aimed Shot"]        = 49049,
				["Kill Shot"]         = 61005,
				["Serpent Sting"]     = 49001,
				["Hunter's Mark"]     = 53338,
				["Multi-Shot"]        = 49045,
				["Volley"]            = 58434,
				["Silencing Shot"]    = 34490,
				["Rapid Fire"]        = 3045,
				["Readiness"]         = 23989,
				["Trueshot Aura"]     = 19506,
				["Disengage"]         = 781,
				["Concussive Shot"]   = 5116,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Kill Shot (execute)
				if Rofaetion:GetClassConfig().useKillShot then
					if (exclude1 ~= sl["Kill Shot"]) and (exclude2 ~= sl["Kill Shot"]) then
						if (UnitHealth("target") / UnitHealthMax("target")) < 0.2 then
							if IsSpellInRange(sl["Kill Shot"], "target") == 1 then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Kill Shot"])
								if (d - timeshift) <= 0 then
									return sl["Kill Shot"]
								end
							end
						end
					end
				end

				-- 2. Serpent Sting (maintain)
				if (exclude1 ~= sl["Serpent Sting"]) and (exclude2 ~= sl["Serpent Sting"]) then
					if IsSpellInRange(sl["Serpent Sting"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Serpent Sting"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							return sl["Serpent Sting"]
						end
					end
				end

				-- 3. Chimera Shot (on cooldown, refreshes Serpent Sting)
				if (exclude1 ~= sl["Chimera Shot"]) and (exclude2 ~= sl["Chimera Shot"]) then
					if IsSpellInRange(sl["Chimera Shot"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Chimera Shot"])
						if (d - timeshift) <= 0 then
							return sl["Chimera Shot"]
						end
					end
				end

				-- 4. Aimed Shot (on cooldown or auto-cast in rapid fire)
				if (exclude1 ~= sl["Aimed Shot"]) and (exclude2 ~= sl["Aimed Shot"]) then
					if IsSpellInRange(sl["Aimed Shot"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Aimed Shot"])
						if (d - timeshift) <= 0 then
							if sl["Aimed Shot"] ~= spellInCast then
								return sl["Aimed Shot"]
							end
						end
					end
				end

				-- 5. Arcane Shot (on cooldown)
				if (exclude1 ~= sl["Arcane Shot"]) and (exclude2 ~= sl["Arcane Shot"]) then
					if IsSpellInRange(sl["Arcane Shot"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Arcane Shot"])
						if (d - timeshift) <= 0 then
							return sl["Arcane Shot"]
						end
					end
				end

				-- 6. Steady Shot (filler)
				if (exclude1 ~= sl["Steady Shot"]) and (exclude2 ~= sl["Steady Shot"]) then
					if IsSpellInRange(sl["Steady Shot"], "target") == 1 then
						if sl["Steady Shot"] ~= spellInCast then
							return sl["Steady Shot"]
						end
					end
				end

				if IsSpellInRange(sl["Steady Shot"], "target") == 1 then
					return sl["Steady Shot"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Hunter's Mark
				if Rofaetion:SpellAvailable(sl["Hunter's Mark"]) then
					if IsSpellInRange(sl["Hunter's Mark"], "target") == 1 then
						local name = Rofaetion:hasDeBuff("target", sl["Hunter's Mark"], nil)
						if not name then
							return sl["Hunter's Mark"]
						end
					end
				end

				-- Rapid Fire
				if Rofaetion:SpellAvailable(sl["Rapid Fire"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Rapid Fire"])
					if d <= 0.5 then
						return sl["Rapid Fire"]
					end
				end

				-- Readiness (reset all cooldowns)
				if Rofaetion:SpellAvailable(sl["Readiness"]) then
					local d = Rofaetion:GetSpellCooldownRemaining(sl["Readiness"])
					if d <= 0.5 then
						return sl["Readiness"]
					end
				end

				-- Trueshot Aura
				if Rofaetion:SpellAvailable(sl["Trueshot Aura"]) then
					local name = Rofaetion:hasBuff("player", sl["Trueshot Aura"])
					if not name then
						return sl["Trueshot Aura"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Silencing Shot
				if Rofaetion:SpellAvailable(sl["Silencing Shot"]) then
					if IsSpellInRange(sl["Silencing Shot"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Silencing Shot"])
							if d and d < 0.5 then
								return sl["Silencing Shot"]
							end
						end
					end
				end

				return ""
			end,
		},

		-----------------------------------------------------------------------
		-- Survival DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Survival",
			isDPS = true,
			debuffTrackerSpell = "Serpent Sting",

			spellList = {
				["Explosive Shot"]    = 60053,
				["Black Arrow"]       = 63672,
				["Serpent Sting"]     = 49001,
				["Arcane Shot"]       = 49048,
				["Kill Shot"]         = 61005,
				["Steady Shot"]       = 49050,
				["Hunter's Mark"]     = 53338,
				["Multi-Shot"]        = 49045,
				["Volley"]            = 58434,
				["Silencing Shot"]    = 34490,
				["Explosive Trap"]    = 60202,
				["Disengage"]         = 781,
				["Concussive Shot"]   = 5116,
				["Trap Launcher"]     = 77769,
				["Wyvern Sting"]      = 49011,
				["Trueshot Aura"]     = 19506,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Kill Shot (execute)
				if Rofaetion:GetClassConfig().useKillShot then
					if (exclude1 ~= sl["Kill Shot"]) and (exclude2 ~= sl["Kill Shot"]) then
						if (UnitHealth("target") / UnitHealthMax("target")) < 0.2 then
							if IsSpellInRange(sl["Kill Shot"], "target") == 1 then
								local d = Rofaetion:GetSpellCooldownRemaining(sl["Kill Shot"])
								if (d - timeshift) <= 0 then
									return sl["Kill Shot"]
								end
							end
						end
					end
				end

				-- 2. Explosive Shot (on cooldown, maintain)
				if (exclude1 ~= sl["Explosive Shot"]) and (exclude2 ~= sl["Explosive Shot"]) then
					if IsSpellInRange(sl["Explosive Shot"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Explosive Shot"])
						if (d - timeshift) <= 0 then
							return sl["Explosive Shot"]
						end
					end
				end

				-- 3. Serpent Sting (maintain)
				if (exclude1 ~= sl["Serpent Sting"]) and (exclude2 ~= sl["Serpent Sting"]) then
					if IsSpellInRange(sl["Serpent Sting"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Serpent Sting"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < 0) then
							return sl["Serpent Sting"]
						end
					end
				end

				-- 4. Black Arrow (on cooldown)
				if (exclude1 ~= sl["Black Arrow"]) and (exclude2 ~= sl["Black Arrow"]) then
					if IsSpellInRange(sl["Black Arrow"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Black Arrow"])
						if (d - timeshift) <= 0 then
							return sl["Black Arrow"]
						end
					end
				end

				-- 5. Arcane Shot (on cooldown)
				if (exclude1 ~= sl["Arcane Shot"]) and (exclude2 ~= sl["Arcane Shot"]) then
					if IsSpellInRange(sl["Arcane Shot"], "target") == 1 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Arcane Shot"])
						if (d - timeshift) <= 0 then
							return sl["Arcane Shot"]
						end
					end
				end

				-- 6. Steady Shot (filler)
				if (exclude1 ~= sl["Steady Shot"]) and (exclude2 ~= sl["Steady Shot"]) then
					if IsSpellInRange(sl["Steady Shot"], "target") == 1 then
						if sl["Steady Shot"] ~= spellInCast then
							return sl["Steady Shot"]
						end
					end
				end

				if IsSpellInRange(sl["Steady Shot"], "target") == 1 then
					return sl["Steady Shot"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Hunter's Mark
				if Rofaetion:SpellAvailable(sl["Hunter's Mark"]) then
					if IsSpellInRange(sl["Hunter's Mark"], "target") == 1 then
						local name = Rofaetion:hasDeBuff("target", sl["Hunter's Mark"], nil)
						if not name then
							return sl["Hunter's Mark"]
						end
					end
				end

				-- Trueshot Aura
				if Rofaetion:SpellAvailable(sl["Trueshot Aura"]) then
					local name = Rofaetion:hasBuff("player", sl["Trueshot Aura"])
					if not name then
						return sl["Trueshot Aura"]
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Silencing Shot
				if Rofaetion:SpellAvailable(sl["Silencing Shot"]) then
					if IsSpellInRange(sl["Silencing Shot"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Silencing Shot"])
							if d and d < 0.5 then
								return sl["Silencing Shot"]
							end
						end
					end
				end

				return ""
			end,
		},
	},
})
