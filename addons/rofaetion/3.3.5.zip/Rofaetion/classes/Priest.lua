-------------------------------------------------------------------------------
-- Priest Class Module for Rofaetion
--
-- DPS spec: Shadow (tab 3)
-------------------------------------------------------------------------------

Rofaetion:RegisterClass({
	englishClass = "PRIEST",
	className = "Priest",

	configOptions = {
		{ key = "shadowWordDeathExecute", type = "checkbox", label = "Shadow Word: Death execute (<25%)", default = true },
		{ key = "dispelMagic", type = "checkbox", label = "Dispel Magic (steal buffs)", default = false },
	},

	specs = {
		-- Tab 1: Discipline (Healer)
		[1] = { name = "Discipline", isDPS = false },
		-- Tab 2: Holy (Healer)
		[2] = { name = "Holy", isDPS = false },

		-----------------------------------------------------------------------
		-- Shadow DPS (Tab 3)
		-----------------------------------------------------------------------
		[3] = {
			name = "Shadow",
			isDPS = true,
			debuffTrackerSpell = "Shadow Word: Pain",

			spellList = {
				["Vampiric Touch"]    = 48160,
				["Devouring Plague"]  = 48300,
				["Shadow Word: Pain"] = 48125,
				["Mind Blast"]        = 48127,
				["Mind Flay"]         = 48156,
				["Shadow Word: Death"] = 48158,
				["Shadowform"]        = 15473,
				["Vampiric Embrace"]  = 15286,
				["Shadowfiend"]       = 34433,
				["Silence"]           = 15487,
				["Psychic Scream"]    = 8122,
				["Dispel Magic"]      = 988,
				["Fade"]              = 6346,
				["Inner Fire"]        = 48168,
				["Mind Soothe"]       = 453,
			},

			nextSpell = function(self, timeshift, exclude1, exclude2)
				local sl = self.spellList
				local cfg = Rofaetion:GetClassConfig()
				Rofaetion.lastBaseGCD = 1.5 - (1.5 * Rofaetion.spellHaste * 0.01)

				if UnitHealth("target") <= 0 then return "" end
				if not timeshift then timeshift = 0 end

				local spellInCast, _, _, _, sICstartTime, sICendTime = UnitCastingInfo("player")
				if spellInCast then
					if ((sICendTime - sICstartTime) / 1000) < Rofaetion.lastBaseGCD then
						sICendTime = sICstartTime + (Rofaetion.lastBaseGCD * 1000)
					end
					timeshift = timeshift + (sICendTime / 1000) - GetTime()
				else
					timeshift = timeshift + Rofaetion.lastBaseGCD
				end

				-- 1. Vampiric Touch (maintain, 30s duration)
				if (exclude1 ~= sl["Vampiric Touch"]) and (exclude2 ~= sl["Vampiric Touch"]) then
					if IsSpellInRange(sl["Vampiric Touch"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Vampiric Touch"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < Rofaetion.lastBaseGCD) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Vampiric Touch"])
							if (d - timeshift) <= 0 then
								if sl["Vampiric Touch"] ~= spellInCast then
									return sl["Vampiric Touch"]
								end
							end
						end
					end
				end

				-- 2. Devouring Plague (maintain, 24s)
				if (exclude1 ~= sl["Devouring Plague"]) and (exclude2 ~= sl["Devouring Plague"]) then
					if IsSpellInRange(sl["Devouring Plague"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Devouring Plague"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < Rofaetion.lastBaseGCD) then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Devouring Plague"])
							if (d - timeshift) <= 0 then
								return sl["Devouring Plague"]
							end
						end
					end
				end

				-- 3. Shadow Word: Pain (maintain, 18s)
				if (exclude1 ~= sl["Shadow Word: Pain"]) and (exclude2 ~= sl["Shadow Word: Pain"]) then
					if IsSpellInRange(sl["Shadow Word: Pain"], "target") == 1 then
						local name, _, _, _, _, _, expiration = Rofaetion:hasDeBuff("target", sl["Shadow Word: Pain"], "player")
						if not name or (expiration and (expiration - GetTime() - timeshift) < Rofaetion.lastBaseGCD) then
							return sl["Shadow Word: Pain"]
						end
					end
				end

				-- 4. Mind Blast (on cooldown, consume Shadow Weaving if 3+ stacks)
				if (exclude1 ~= sl["Mind Blast"]) and (exclude2 ~= sl["Mind Blast"]) then
					if IsSpellInRange(sl["Mind Blast"], "target") == 1 then
						if sl["Mind Blast"] ~= spellInCast then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Mind Blast"])
							if (d - timeshift) <= 0 then
								return sl["Mind Blast"]
							end
						end
					end
				end

				-- 5. Shadow Word: Death (execute, target < 25%)
				if cfg.shadowWordDeathExecute then
					if (exclude1 ~= sl["Shadow Word: Death"]) and (exclude2 ~= sl["Shadow Word: Death"]) then
						if (UnitHealth("target") / UnitHealthMax("target")) < 0.25 then
							if IsSpellInRange(sl["Shadow Word: Death"], "target") == 1 then
								return sl["Shadow Word: Death"]
							end
						end
					end
				end

				-- 6. Mind Flay (filler)
				if (exclude1 ~= sl["Mind Flay"]) and (exclude2 ~= sl["Mind Flay"]) then
					if IsSpellInRange(sl["Mind Flay"], "target") == 1 then
						if sl["Mind Flay"] ~= spellInCast then
							return sl["Mind Flay"]
						end
					end
				end

				-- Fallback
				if IsSpellInRange(sl["Mind Flay"], "target") == 1 then
					return sl["Mind Flay"]
				end

				return ""
			end,

			miscSpell = function(self)
				local sl = self.spellList

				-- Shadowform
				if Rofaetion:SpellAvailable(sl["Shadowform"]) then
					local name = Rofaetion:hasBuff("player", sl["Shadowform"])
					if not name then
						return sl["Shadowform"]
					end
				end

				-- Vampiric Embrace
				if Rofaetion:SpellAvailable(sl["Vampiric Embrace"]) then
					local name = Rofaetion:hasBuff("player", sl["Vampiric Embrace"])
					if not name then
						return sl["Vampiric Embrace"]
					end
				end

				-- Inner Fire
				if Rofaetion:SpellAvailable(sl["Inner Fire"]) then
					local name = Rofaetion:hasBuff("player", sl["Inner Fire"])
					if not name then
						return sl["Inner Fire"]
					end
				end

				-- Shadowfiend (mana < 50%)
				if Rofaetion:SpellAvailable(sl["Shadowfiend"]) then
					if (UnitPower("player", 0) / UnitPowerMax("player", 0)) < 0.5 then
						local d = Rofaetion:GetSpellCooldownRemaining(sl["Shadowfiend"])
						if d <= 0.5 then
							return sl["Shadowfiend"]
						end
					end
				end

				return ""
			end,

			intSpell = function(self)
				local sl = self.spellList

				-- Silence
				if Rofaetion:SpellAvailable(sl["Silence"]) then
					if IsSpellInRange(sl["Silence"], "target") == 1 then
						local name = UnitCastingInfo("target")
						local channel = UnitChannelInfo("target")
						if name or channel then
							local d = Rofaetion:GetSpellCooldownRemaining(sl["Silence"])
							if d and d < 0.5 then
								return sl["Silence"]
							end
						end
					end
				end

				return ""
			end,
		},
	},
})
