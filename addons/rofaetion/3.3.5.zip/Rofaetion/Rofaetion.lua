-------------------------------------------------------------------------------
-- Rofaetion 2.0
--
-- A rotation helper for all DPS classes and specs in WotLK 3.3.5a.
-- Detects the player's class and spec, loads the appropriate module,
-- and displays the advised spell for optimal DPS output.
-------------------------------------------------------------------------------

Rofaetion = Rofaetion or {}
Rofaetion.Locals = Rofaetion.Locals or {}
Rofaetion.versionNumber = '2.0'
Rofaetion.DebugMode = false

-- Player state
Rofaetion.playerName = UnitName("player")
Rofaetion.playerGUID = UnitGUID("player")
Rofaetion.targetGUID = nil
Rofaetion.spellHaste = GetCombatRatingBonus(20)
Rofaetion.timeSinceLastUpdate = 0
Rofaetion.debuffTrackerUpdate = 0
Rofaetion.spellPower = GetSpellBonusDamage(4)
Rofaetion.lastBaseGCD = 1.5
Rofaetion.lastSpell = nil
Rofaetion.inParty = 0
Rofaetion.OmniCC = _G['OmniCC']
Rofaetion.configPanel = nil
Rofaetion.prevDB = {}
Rofaetion.DPSTable = {}
Rofaetion.activeModule = nil
Rofaetion.activeSpec = nil
Rofaetion.eclipseProc = nil
Rofaetion.lastEclipseType = nil

Rofaetion.person = {
	["foeCount"]    = 0,
	["friendCount"] = 0,
	["friend"] = {},
	["foe"]    = {},
}
Rofaetion.lastPersonTablePurged = 0.0

Rofaetion.HostileFilter = {
	["_DAMAGE"]    = true,
	["_LEECH"]     = true,
	["_DRAIN"]     = true,
	["_STOLEN"]    = true,
	["_INSTAKILL"] = true,
	["_INTERRUPT"] = true,
	["_MISSED"]    = true,
}

-------------------------------------------------------------------------------
-- Event frame
-------------------------------------------------------------------------------
Rofaetion.eventFrame = CreateFrame("Frame")
Rofaetion.eventFrame:SetScript("OnEvent", function(this, event, ...)
	Rofaetion.events[event](...)
end)

Rofaetion.eventFrame:RegisterEvent("ADDON_LOADED")
Rofaetion.eventFrame:RegisterEvent("PLAYER_LOGIN")
Rofaetion.eventFrame:RegisterEvent("PLAYER_ALIVE")

Rofaetion.events = {}

-------------------------------------------------------------------------------
-- Talent / spec detection
-------------------------------------------------------------------------------
function Rofaetion:detectSpec()
	local _, englishClass = UnitClass("player")
	local module = Rofaetion.classModules[englishClass]
	if not module then
		Rofaetion.activeModule = nil
		Rofaetion.activeSpec = nil
		return
	end

	local maxPoints, primaryTab = 0, nil
	for i = 1, GetNumTalentTabs() do
		local _, _, pointsSpent = GetTalentTabInfo(i)
		if pointsSpent > maxPoints then
			maxPoints = pointsSpent
			primaryTab = i
		end
	end
	if not primaryTab or maxPoints == 0 then
		Rofaetion.activeModule = nil
		Rofaetion.activeSpec = nil
		return
	end

	local spec = module.specs[primaryTab]
	if spec and spec.isDPS then
		Rofaetion.activeModule = module
		Rofaetion.activeSpec = primaryTab
	else
		Rofaetion.activeModule = nil
		Rofaetion.activeSpec = nil
	end
end

function Rofaetion:isEnabled()
	if not RofaetionDB.enabled then return false end
	if not Rofaetion.activeModule or not Rofaetion.activeSpec then
		Rofaetion:detectSpec()
	end
	return Rofaetion.activeModule ~= nil and Rofaetion.activeSpec ~= nil
end

-------------------------------------------------------------------------------
-- Settings
-------------------------------------------------------------------------------
function Rofaetion:InitSettings()
	if not RofaetionDB then
		RofaetionDB = {}
	end
	if not RofaetionDB.scale then RofaetionDB.scale = 1 end
	if not RofaetionDB.debuffscale then RofaetionDB.debuffscale = 1 end
	if RofaetionDB.locked == nil then RofaetionDB.locked = false end
	if RofaetionDB.enabled == nil then RofaetionDB.enabled = true end
	if RofaetionDB.debuffdisabled == nil then RofaetionDB.debuffdisabled = false end
	if RofaetionDB.alpha == nil then RofaetionDB.alpha = 0.8 end
	if RofaetionDB.debuffalpha == nil then RofaetionDB.debuffalpha = 1 end
	if RofaetionDB.ThreatWarning == nil then RofaetionDB.ThreatWarning = true end
	if not RofaetionDB.x then RofaetionDB.x = -200 end
	if not RofaetionDB.y then RofaetionDB.y = -200 end
	if not RofaetionDB.relativePoint then RofaetionDB.relativePoint = "CENTER" end
	if not RofaetionDB.debuffx then RofaetionDB.debuffx = -200 end
	if not RofaetionDB.debuffy then RofaetionDB.debuffy = -100 end
	if not RofaetionDB.debuffrelativePoint then RofaetionDB.debuffrelativePoint = "CENTER" end
	RofaetionDB.classConfig = RofaetionDB.classConfig or {}
end

function Rofaetion:ApplySettings()
	Rofaetion:InitSettings()
	if not RofaetionDB.locked then
		Rofaetion.displayFrame:EnableMouse(true)
		Rofaetion.displayFrame:SetMovable(true)
		Rofaetion.displayFrame:SetClampedToScreen(true)
		Rofaetion.displayFrame:SetScript("OnMouseDown", function(self) self:StartMoving(); self:SetBackdropColor(0, 0, 0, 0.4) end)
		Rofaetion.displayFrame:SetScript("OnMouseUp", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.x = x
			RofaetionDB.y = y
			RofaetionDB.relativePoint = rp
		end)
		Rofaetion.displayFrame:SetScript("OnDragStop", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.x = x
			RofaetionDB.y = y
			RofaetionDB.relativePoint = rp
		end)
		Rofaetion.displayFrame:SetBackdropColor(0, 0, 0, 0.3)
		Rofaetion.debuffTracker:EnableMouse(true)
		Rofaetion.debuffTracker:SetMovable(true)
		Rofaetion.debuffTracker:SetClampedToScreen(true)
		Rofaetion.debuffTracker:SetScript("OnMouseDown", function(self) self:StartMoving(); self:SetBackdropColor(0, 0, 0, 0.4) end)
		Rofaetion.debuffTracker:SetScript("OnMouseUp", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.debuffx = x
			RofaetionDB.debuffy = y
			RofaetionDB.debuffrelativePoint = rp
		end)
		Rofaetion.debuffTracker:SetScript("OnDragStop", function(self)
			self:StopMovingOrSizing()
			if RofaetionDB.locked then
				self:SetBackdropColor(0, 0, 0, 0)
			else
				self:SetBackdropColor(0, 0, 0, 0.3)
			end
			local _, _, rp, x, y = self:GetPoint()
			RofaetionDB.debuffx = x
			RofaetionDB.debuffy = y
			RofaetionDB.debuffrelativePoint = rp
		end)
		Rofaetion.debuffTracker:SetBackdropColor(0, 0, 0, 0.3)
	else
		if Rofaetion.displayFrame then
			Rofaetion.displayFrame:EnableMouse(false)
			Rofaetion.displayFrame:SetMovable(false)
			Rofaetion.displayFrame:SetBackdropColor(0, 0, 0, 0)
			Rofaetion.debuffTracker:EnableMouse(false)
			Rofaetion.debuffTracker:SetMovable(false)
			Rofaetion.debuffTracker:SetBackdropColor(0, 0, 0, 0)
		end
	end
	if not Rofaetion:isEnabled() then
		if Rofaetion.displayFrame then
			Rofaetion.displayFrame:Hide()
			Rofaetion.debuffTracker:Hide()
		end
	else
		if Rofaetion.displayFrame then
			Rofaetion.displayFrame:Show()
			if RofaetionDB.debuffdisabled then
				Rofaetion.debuffTracker:Hide()
			else
				Rofaetion.debuffTracker:Show()
			end
		end
	end
	if Rofaetion.displayFrame then
		Rofaetion.displayFrame:SetAlpha(RofaetionDB.alpha)
		Rofaetion.displayFrame:SetScale(RofaetionDB.scale)
		Rofaetion.debuffTracker:SetAlpha(RofaetionDB.debuffalpha)
		Rofaetion.debuffTracker:SetScale(RofaetionDB.debuffscale)
	end
end

-------------------------------------------------------------------------------
-- Event Handlers
-------------------------------------------------------------------------------
function Rofaetion.events.ADDON_LOADED(addon)
	if addon == "OmniCC" then
		Rofaetion.OmniCC = _G['OmniCC']
	end
	if addon ~= "Rofaetion" then return end

	Rofaetion:InitSettings()

	SlashCmdList["Rofaetion"] = Rofaetion.Options
	SLASH_Rofaetion1 = "/rofaetion"
	SLASH_Rofaetion2 = "/rot"

	Rofaetion:detectSpec()

	if not Rofaetion.activeModule then
		local _, englishClass = UnitClass("player")
		DEFAULT_CHAT_FRAME:AddMessage("|cffff0000" .. format(Rofaetion.Locals.NO_CLASS_MODULE or "Rofaetion: No module for %s", englishClass) .. "|r")
	end

	Rofaetion.playerLevel = UnitLevel("player")

	Rofaetion:CreateGUI()
	Rofaetion.displayFrame:SetScale(RofaetionDB.scale)
	Rofaetion.OmniCC = _G['OmniCC']

	Rofaetion:CreateConfig()

	Rofaetion.eventFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	Rofaetion.eventFrame:RegisterEvent("COMBAT_RATING_UPDATE")
	Rofaetion.eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
	Rofaetion.eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
	Rofaetion.eventFrame:RegisterEvent("PLAYER_TALENT_UPDATE")
	Rofaetion.eventFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")
	Rofaetion.eventFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
end

function Rofaetion.events.PLAYER_LOGIN()
	Rofaetion.playerName = UnitName("player")
	Rofaetion.spellHaste = GetCombatRatingBonus(20)
	Rofaetion.spellPower = GetSpellBonusDamage(4)
end

function Rofaetion.events.PLAYER_ALIVE()
	Rofaetion:detectSpec()
	Rofaetion:ApplySettings()
end

function Rofaetion.events.PLAYER_ENTERING_WORLD()
	Rofaetion:detectSpec()
end

function Rofaetion.events.PLAYER_TALENT_UPDATE()
	Rofaetion:detectSpec()
	Rofaetion:ApplySettings()
end

function Rofaetion.events.ACTIVE_TALENT_GROUP_CHANGED()
	Rofaetion:detectSpec()
	Rofaetion:ApplySettings()
end

function Rofaetion.events.PARTY_MEMBERS_CHANGED()
	Rofaetion.inParty = Rofaetion:PlayerInParty()
end

function Rofaetion.events.COMBAT_RATING_UPDATE(unit)
	if unit == "player" then
		Rofaetion.spellHaste = GetCombatRatingBonus(20)
		Rofaetion.spellPower = GetSpellBonusDamage(4)
	end
end

function Rofaetion.events.PLAYER_TARGET_CHANGED(...)
	Rofaetion.targetGUID = UnitGUID("target")
	Rofaetion.inParty = Rofaetion:PlayerInParty()

	if not Rofaetion.activeModule then
		Rofaetion:detectSpec()
		if Rofaetion:isEnabled() then
			Rofaetion:ApplySettings()
		end
	end

	if not Rofaetion.targetGUID then
		local threat_txt = ""
		local _, status, threatpct, _, _ = UnitDetailedThreatSituation("player", "target")
		if status then
			if threatpct < 80 then
				threat_txt = format("%.f", threatpct) .. " %"
				Rofaetion.cooldownFrame:SetReverse(false)
			else
				threat_txt = "|cffff0000" .. format("%.f", threatpct) .. " %|r"
				Rofaetion.cooldownFrame:SetReverse((Rofaetion.person["friendCount"] > 1) and (Rofaetion.inParty > 0))
			end
		end
		Rofaetion.textList["dps"]:SetText(threat_txt)
	end
	Rofaetion:DecideSpells()
end

function Rofaetion.events.PLAYER_REGEN_ENABLED(...)
	Rofaetion.person["friend"] = {}
	Rofaetion.person["friendCount"] = 0
	Rofaetion.person["foe"] = {}
	Rofaetion.person["foeCount"] = 0
	Rofaetion.DPSTable = {}
	if Rofaetion.textList["dps"] then
		Rofaetion.textList["dps"]:SetText("")
	end
	if Rofaetion.textList["debuff"] then
		Rofaetion.textList["debuff"]:SetText("")
	end
	Rofaetion.cooldownFrame:SetReverse(false)
	Rofaetion:PurgePersonTable()
end

function Rofaetion.events.COMBAT_LOG_EVENT_UNFILTERED(timestamp, event, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, spellId, spellName, spellSchool, damage, ...)
	if not Rofaetion:isEnabled() then return end

	if srcName == Rofaetion.playerName then
		Rofaetion:DecideSpells()
		if event == "SPELL_CAST_SUCCESS" then
			Rofaetion.lastSpell = spellName
		end
		if event == "SPELL_AURA_APPLIED" then
			if spellId == 48517 then
				Rofaetion.eclipseProc = { type = "solar", expiry = GetTime() + 15 }
			elseif spellId == 48518 then
				Rofaetion.eclipseProc = { type = "lunar", expiry = GetTime() + 15 }
			end
		end
		if event == "SPELL_AURA_REMOVED" then
			if spellId == 48517 or spellId == 48518 then
				if Rofaetion.eclipseProc then
					Rofaetion.lastEclipseType = Rofaetion.eclipseProc.type
				end
				Rofaetion.eclipseProc = nil
			end
		end
		if (event == "SPELL_DAMAGE") or (event == "SPELL_PERIODIC_DAMAGE") then
			if not Rofaetion.DPSTable[dstGUID] then
				Rofaetion.DPSTable[dstGUID] = {
					["time"] = GetTime(),
					["amount"] = 0,
				}
			end
			Rofaetion.DPSTable[dstGUID]["amount"] = Rofaetion.DPSTable[dstGUID]["amount"] + damage
			local dps_txt = ""
			if (dstGUID == Rofaetion.targetGUID) and Rofaetion.DPSTable[Rofaetion.targetGUID] then
				local dps_sec = GetTime() - Rofaetion.DPSTable[dstGUID]["time"]
				if dps_sec > 5 then
					dps_txt = format('%.f', (Rofaetion.DPSTable[dstGUID]["amount"] / dps_sec))
				end
				local threat_txt = ""
				local _, status, threatpct, _, _ = UnitDetailedThreatSituation("player", "target")
				if status then
					if threatpct < 80 then
						threat_txt = format("%.f", threatpct) .. " %"
						Rofaetion.cooldownFrame:SetReverse(false)
						if RofaetionDB.ThreatWarning and (Rofaetion.inParty > 0) and (threatpct > 70) then
							RaidNotice_AddMessage(RaidBossEmoteFrame, Rofaetion.Locals.THREAT_WARNING_PREFIX .. format("%.f", threatpct) .. Rofaetion.Locals.THREAT_WARNING_SUFFIX, ChatTypeInfo["RAID_WARNING"])
						end
					else
						threat_txt = "|cffff0000" .. format("%.f", threatpct) .. " %|r"
						if RofaetionDB.ThreatWarning and (Rofaetion.inParty > 0) then
							RaidNotice_AddMessage(RaidBossEmoteFrame, "|cffff0000" .. Rofaetion.Locals.THREAT_WARNING_PREFIX .. format("%.f", threatpct) .. Rofaetion.Locals.THREAT_WARNING_SUFFIX .. "|r", ChatTypeInfo["RAID_WARNING"])
						end
						Rofaetion.cooldownFrame:SetReverse((Rofaetion.person["friendCount"] > 1) and (Rofaetion.inParty > 0))
					end
				end
				dps_txt = dps_txt .. "|n" .. threat_txt
				Rofaetion.textList["dps"]:SetText(dps_txt)
			end
		end
	else
		if UnitAffectingCombat("player") then
			Rofaetion:CountPerson(timestamp, event, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags)
		end
	end
end
