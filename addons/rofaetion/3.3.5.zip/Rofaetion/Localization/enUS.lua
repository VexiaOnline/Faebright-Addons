-- enUS localization file for Rofaetion

if GetLocale() then
	local L = Rofaetion.Locals

	-- General
	L.ADDON_LOADED = "Rofaetion v%s loaded"
	L.NO_DPS_SPEC = "Rofaetion: No DPS spec detected. Addon disabled."
	L.NO_CLASS_MODULE = "Rofaetion: No module found for class: %s"
	L.THREAT_WARNING_PREFIX = ""
	L.THREAT_WARNING_SUFFIX = "% threat!"

	-- Configuration
	L.CONFIG_ENABLED = "Enabled"
	L.CONFIG_LOCK_FRAMES = "Lock frames"
	L.CONFIG_SPELL_ADV_SCALE = "Spell advisor scale"
	L.CONFIG_SPELL_ADV_ALPHA = "Spell advisor alpha"
	L.CONFIG_DISABLE_DEBUFF_TRACKER = "Disable debuff tracker"
	L.CONFIG_DEBUFF_TRACKER_SCALE = "Debuff tracker scale"
	L.CONFIG_DEBUFF_TRACKER_ALPHA = "Debuff tracker alpha"
	L.CONFIG_THREAT_WARNING = "Threat warning"
	L.CONFIG_RESET_POSITIONS = "Reset frame positions"
	L.CONFIG_CLASS_OPTIONS = "Class-specific options"

	-- Shaman specific
	L.SHAMAN_BEHAVIOUR = "Flame Shock behaviour"
	L.SHAMAN_BEHAVIOUR_KEEP_FS_UP = "Keep Flame Shock up"
	L.SHAMAN_BEHAVIOUR_FS_BEFORE_LVB = "Flame Shock before Lava"
	L.SHAMAN_ENABLE_NOVA = "Enable Fire Nova in rotation"
	L.SHAMAN_CLSTBEHAVIOUR = "Chain Lightning single target behaviour"
	L.SHAMAN_CLSTBEHAVIOUR_NONE = "None"
	L.SHAMAN_CLSTBEHAVIOUR_CL_AFTER_LVB = "Chain Lightning after Lava"
	L.SHAMAN_CLSTBEHAVIOUR_CL_ON_CD = "Chain Lightning on Cooldown"

end
