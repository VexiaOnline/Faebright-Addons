local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");
local _G = getfenv(0)

local WHITE = "|cffFFFFFF";

-- World Bosses: Azeroth + Outland world bosses (Azuregos, Doom Lord Kazzak,
-- Doomwalker, the four Dragons of Nightmare, and Highlord Kruul).
function AtlasLoot_WorldBossMenu()
	AtlasLoot_PrepMenu(nil, AL["World Bosses"])
	AtlasLootCharDB.LastBoss = "WORLDBOSSMENU"
	AtlasLootCharDB.LastBossText = AL["World Bosses"]
	local list = {
		{ AL["Azuregos"], AL["Azshara"], "AAzuregos", "INV_Misc_Head_Dragon_Blue" },
		{ AL["Doom Lord Kazzak"], AL["Hellfire Peninsula"], "DoomLordKazzak", "Spell_Shadow_SummonInfernal" },
		{ AL["Doomwalker"], AL["Shadowmoon Valley"], "DDoomwalker", "Spell_Fire_FelImmolation" },
		{ AL["Emeriss"], AL["Various Locations"], "DEmeriss", "INV_Misc_Head_Dragon_Green" },
		{ AL["Highlord Kruul"], AL["Various Locations"], "KKruul", "Warlock_summon_doomguard" },
		{ AL["Lethon"], AL["Various Locations"], "DLethon", "INV_Misc_Head_Dragon_Green" },
		{ AL["Taerar"], AL["Various Locations"], "DTaerar", "INV_Misc_Head_Dragon_Green" },
		{ AL["Ysondre"], AL["Various Locations"], "DYsondre", "INV_Misc_Head_Dragon_Green" },
	}
	for i = 1, table.getn(list) do
		_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(list[i][1])
		_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText(WHITE..list[i][2])
		_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture("Interface\\Icons\\"..list[i][4])
		_G["AtlasLootMenuItem_"..i].lootpage = list[i][3]
		_G["AtlasLootMenuItem_"..i]:Show()
	end
end
