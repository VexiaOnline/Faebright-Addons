-- Dungeons & Raids panel menu. Rebuilt to list the original (Vanilla + TBC)
-- instances; entry dataIDs resolved from the original menu's first-boss tables.
-- Ordered by WotLK level bracket (dungeons by level, raids by tier).
local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");
local _G = getfenv(0)
local buttonsPerPage = 30
local ButtonsInfo1
local ButtonsInfo2

function AtlasLoot_DungeonsMenu1()
	if not ButtonsInfo1 then
		ButtonsInfo1 = {
			{ name = "Ragefire Chasm", extra = "", lootpage = "RFCTaragaman", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Deadmines", extra = "", lootpage = "DMMarisaDuPaige", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Wailing Caverns", extra = "", lootpage = "WCKalldanFelmoon", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Shadowfang Keep", extra = "", lootpage = "BSFRethilgore", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Stockade", extra = "", lootpage = "SWStTargorr", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Blackfathom Deeps", extra = "", lootpage = "BFDGhamoora", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Gnomeregan", extra = "", lootpage = "GnTechbot", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Razorfen Kraul", extra = "", lootpage = "RFKThorncurse", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Scarlet Monastery", extra = "", lootpage = "SMVishas", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Razorfen Downs", extra = "", lootpage = "RFDTutenkash", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Uldaman", extra = "", lootpage = "UldShovelphlange", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Zul'Farrak", extra = "", lootpage = "ZFAntusul", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Maraudon", extra = "", lootpage = "MaraNoxxion", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Temple of Atal'Hakkar", extra = "", lootpage = "STSpawnOfHakkar", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Blackrock Depths", extra = "", lootpage = "BRDPyron", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Lower Blackrock Spire", extra = "", lootpage = "LBRSSpirestoneButcher", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Upper Blackrock Spire", extra = "", lootpage = "UBRSEmberseer", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Dire Maul (East)", extra = "", lootpage = "DMEPusillin", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Dire Maul (West)", extra = "", lootpage = "DMWTendrisWarpwood", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Dire Maul (North)", extra = "", lootpage = "DMNGuardMoldar", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Scholomance", extra = "", lootpage = "SCHOLOBloodStewardofKirtonos", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Stratholme", extra = "", lootpage = "STRATSkull", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Molten Core", extra = "", lootpage = "MCLucifron", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Onyxia's Lair", extra = "", lootpage = "Onyxia", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Blackwing Lair", extra = "", lootpage = "BWLRazorgore", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Zul'Gurub", extra = "", lootpage = "ZGJeklik", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Ruins of Ahn'Qiraj", extra = "", lootpage = "AQ20Kurinnaxx", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Temple of Ahn'Qiraj", extra = "", lootpage = "AQ40Skeram", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Naxxramas", extra = "", lootpage = "NAXPatchwerk", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
		}
	end
	AtlasLoot_PrepMenu(nil, AL["Dungeons & Raids"])
	AtlasLootCharDB.LastBoss = "DUNGEONSMENU1"
	AtlasLootCharDB.LastBossText = AL["Dungeons & Raids"]
	AtlasLootItemsFrame_NEXT:Show()
	for i = 1, min(buttonsPerPage, table.getn(ButtonsInfo1)) do
		if ButtonsInfo1[i].name then
			_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(ButtonsInfo1[i].name)
			_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText(ButtonsInfo1[i].extra)
			_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture(ButtonsInfo1[i].icon)
			_G["AtlasLootMenuItem_"..i].lootpage = ButtonsInfo1[i].lootpage
			_G["AtlasLootMenuItem_"..i]:Show()
		end
	end
end

function AtlasLoot_DungeonsMenu2()
	if not ButtonsInfo2 then
		ButtonsInfo2 = {
			{ name = "Hellfire Ramparts", extra = "", lootpage = "HCRampWatchkeeper", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Blood Furnace", extra = "", lootpage = "HCFurnaceMaker", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Slave Pens", extra = "", lootpage = "CFRSlaveMennu", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Underbog", extra = "", lootpage = "CFRUnderHungarfen", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Mana-Tombs", extra = "", lootpage = "AuchManaPandemonius", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Auchenai Crypts", extra = "", lootpage = "AuchCryptsShirrak", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Old Hillsbrad Foothills", extra = "", lootpage = "CoTHillsbradDrake", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Sethekk Halls", extra = "", lootpage = "AuchSethekkDarkweaver", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Mechanar", extra = "", lootpage = "TKMechGyro", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Steamvault", extra = "", lootpage = "CFRSteamThespia", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Botanica", extra = "", lootpage = "TKBotSarannis", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Shadow Labyrinth", extra = "", lootpage = "AuchShadowHellmaw", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Shattered Halls", extra = "", lootpage = "HCHallsNethekurse", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Black Morass", extra = "", lootpage = "CoTMorassDeja", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Arcatraz", extra = "", lootpage = "TKArcUnbound", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Magisters' Terrace", extra = "", lootpage = "SMTFireheart", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Karazhan", extra = "", lootpage = "KaraNamed", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Gruul's Lair", extra = "", lootpage = "GruulsLairHighKingMaulgar", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Magtheridon's Lair", extra = "", lootpage = "HCMagtheridon", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Serpentshrine Cavern", extra = "", lootpage = "CFRSerpentHydross", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "The Eye", extra = "", lootpage = "TKEyeAlar", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Hyjal Summit", extra = "", lootpage = "MountHyjalWinterchill", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Black Temple", extra = "", lootpage = "BTNajentus", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Zul'Aman", extra = "", lootpage = "ZANalorakk", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
			{ name = "Sunwell Plateau", extra = "", lootpage = "SPKalecgos", icon = "Interface/Icons/Spell_Arcane_PortalIronForge" },
		}
	end
	AtlasLoot_PrepMenu(nil, AL["Dungeons & Raids"])
	AtlasLootCharDB.LastBoss = "DUNGEONSMENU2"
	AtlasLootCharDB.LastBossText = AL["Dungeons & Raids"]
	AtlasLootItemsFrame_PREV:Show()
	for i = 1, min(buttonsPerPage, table.getn(ButtonsInfo2)) do
		if ButtonsInfo2[i].name then
			_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(ButtonsInfo2[i].name)
			_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText(ButtonsInfo2[i].extra)
			_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture(ButtonsInfo2[i].icon)
			_G["AtlasLootMenuItem_"..i].lootpage = ButtonsInfo2[i].lootpage
			_G["AtlasLootMenuItem_"..i]:Show()
		end
	end
end

-- Split panel menus: Classic Dungeons / Classic Raids / TBC Dungeons / TBC Raids.
-- Each is a standalone single-page grid (no NEXT/PREV) opened from its own category.
local DUNGEON_ICON = "Interface/Icons/Spell_Arcane_PortalIronForge"

local function AtlasLoot_RenderInstanceMenu(list, menuID, title)
	AtlasLoot_PrepMenu(nil, title)
	AtlasLootCharDB.LastBoss = menuID
	AtlasLootCharDB.LastBossText = title
	for i = 1, min(buttonsPerPage, table.getn(list)) do
		_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(list[i][1])
		_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText("")
		_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture(DUNGEON_ICON)
		_G["AtlasLootMenuItem_"..i].lootpage = list[i][2]
		_G["AtlasLootMenuItem_"..i]:Show()
	end
end

local ClassicDungeons = {
	{ "Ragefire Chasm", "RFCTaragaman" },
	{ "The Deadmines", "DMMarisaDuPaige" },
	{ "Wailing Caverns", "WCKalldanFelmoon" },
	{ "Shadowfang Keep", "BSFRethilgore" },
	{ "The Stockade", "SWStTargorr" },
	{ "Blackfathom Deeps", "BFDGhamoora" },
	{ "Gnomeregan", "GnTechbot" },
	{ "Razorfen Kraul", "RFKThorncurse" },
	{ "Scarlet Monastery", "SMVishas" },
	{ "Razorfen Downs", "RFDTutenkash" },
	{ "Uldaman", "UldShovelphlange" },
	{ "Zul'Farrak", "ZFAntusul" },
	{ "Maraudon", "MaraNoxxion" },
	{ "The Temple of Atal'Hakkar", "STSpawnOfHakkar" },
	{ "Blackrock Depths", "BRDPyron" },
	{ "Lower Blackrock Spire", "LBRSSpirestoneButcher" },
	{ "Upper Blackrock Spire", "UBRSEmberseer" },
	{ "Dire Maul (East)", "DMEPusillin" },
	{ "Dire Maul (West)", "DMWTendrisWarpwood" },
	{ "Dire Maul (North)", "DMNGuardMoldar" },
	{ "Scholomance", "SCHOLOBloodStewardofKirtonos" },
	{ "Stratholme", "STRATSkull" },
}

local ClassicRaids = {
	{ "Molten Core", "MCLucifron" },
	{ "Onyxia's Lair", "Onyxia" },
	{ "Blackwing Lair", "BWLRazorgore" },
	{ "Zul'Gurub", "ZGJeklik" },
	{ "Ruins of Ahn'Qiraj", "AQ20Kurinnaxx" },
	{ "Temple of Ahn'Qiraj", "AQ40Skeram" },
	{ "Naxxramas", "NAXPatchwerk" },
}

local TBCDungeons = {
	{ "Hellfire Ramparts", "HCRampWatchkeeper" },
	{ "The Blood Furnace", "HCFurnaceMaker" },
	{ "The Slave Pens", "CFRSlaveMennu" },
	{ "The Underbog", "CFRUnderHungarfen" },
	{ "Mana-Tombs", "AuchManaPandemonius" },
	{ "Auchenai Crypts", "AuchCryptsShirrak" },
	{ "Old Hillsbrad Foothills", "CoTHillsbradDrake" },
	{ "Sethekk Halls", "AuchSethekkDarkweaver" },
	{ "The Mechanar", "TKMechGyro" },
	{ "The Steamvault", "CFRSteamThespia" },
	{ "The Botanica", "TKBotSarannis" },
	{ "Shadow Labyrinth", "AuchShadowHellmaw" },
	{ "The Shattered Halls", "HCHallsNethekurse" },
	{ "The Black Morass", "CoTMorassDeja" },
	{ "The Arcatraz", "TKArcUnbound" },
	{ "Magisters' Terrace", "SMTFireheart" },
}

local TBCHeroics = {
	{ "Hellfire Ramparts", "HCRampWatchkeeperHEROIC" },
	{ "The Blood Furnace", "HCFurnaceMakerHEROIC" },
	{ "The Slave Pens", "CFRSlaveMennuHEROIC" },
	{ "The Underbog", "CFRUnderHungarfenHEROIC" },
	{ "Mana-Tombs", "AuchManaPandemoniusHEROIC" },
	{ "Auchenai Crypts", "AuchCryptsShirrakHEROIC" },
	{ "Old Hillsbrad Foothills", "CoTHillsbradDrakeHEROIC" },
	{ "Sethekk Halls", "AuchSethekkDarkweaverHEROIC" },
	{ "The Mechanar", "TKMechCapacitusHEROIC" },
	{ "The Steamvault", "CFRSteamThespiaHEROIC" },
	{ "The Botanica", "TKBotSarannisHEROIC" },
	{ "Shadow Labyrinth", "AuchShadowHellmawHEROIC" },
	{ "The Shattered Halls", "HCHallsNethekurseHEROIC" },
	{ "The Black Morass", "CoTMorassDejaHEROIC" },
	{ "The Arcatraz", "TKArcUnboundHEROIC" },
	{ "Magisters' Terrace", "SMTFireheartHEROIC" },
}

local TBCRaids = {
	{ "Karazhan", "KaraNamed" },
	{ "Gruul's Lair", "GruulsLairHighKingMaulgar" },
	{ "Magtheridon's Lair", "HCMagtheridon" },
	{ "Serpentshrine Cavern", "CFRSerpentHydross" },
	{ "The Eye (Tempest Keep)", "TKEyeAlar" },
	{ "Hyjal Summit", "MountHyjalWinterchill" },
	{ "Black Temple", "BTNajentus" },
	{ "Zul'Aman", "ZANalorakk" },
	{ "Sunwell Plateau", "SPKalecgos" },
}

function AtlasLoot_ClassicDungeonMenu()
	AtlasLoot_RenderInstanceMenu(ClassicDungeons, "CLASSICDUNGEONMENU", AL["Classic Dungeons"])
end

function AtlasLoot_ClassicRaidMenu()
	AtlasLoot_RenderInstanceMenu(ClassicRaids, "CLASSICRAIDMENU", AL["Classic Raids"])
end

function AtlasLoot_TBCDungeonMenu()
	AtlasLoot_RenderInstanceMenu(TBCDungeons, "TBCDUNGEONMENU", AL["TBC Dungeons"])
end

function AtlasLoot_TBCHeroicMenu()
	AtlasLoot_RenderInstanceMenu(TBCHeroics, "TBCHEROICMENU", AL["TBC Heroics"])
end

function AtlasLoot_TBCRaidMenu()
	AtlasLoot_RenderInstanceMenu(TBCRaids, "TBCRAIDMENU", AL["TBC Raids"])
end

function AtlasLoot_HomeMenu()
	AtlasLoot_PrepMenu(nil, AL["Home"])
	AtlasLootCharDB.LastBoss = "HOMEMENU"
	AtlasLootCharDB.LastBossText = AL["Home"]
	AtlasLootDefaultFrame_SelectedCategory:SetText("")
	AtlasLootDefaultFrame_SelectedTable:SetText("")
	local left = {
		{ AL["Classic Dungeons"], "CLASSICDUNGEONMENU", "Spell_Arcane_PortalIronForge" },
		{ AL["TBC Dungeons"], "TBCDUNGEONMENU", "Spell_Arcane_PortalShattrath" },
		{ AL["TBC Heroics"], "TBCHEROICMENU", "Spell_Holy_ChampionsBond" },
		{ AL["PvP Rewards"], "PVPMENU", "Ability_Warrior_Rampage" },
		{ AL["Crafting"], "CRAFTINGMENU", "Trade_BlackSmithing" },
		{ AL["Collections"], "SETMENU", "INV_Helmet_06" },
	}
	local right = {
		{ AL["Classic Raids"], "CLASSICRAIDMENU", "Spell_Shadow_SummonInfernal" },
		{ AL["TBC Raids"], "TBCRAIDMENU", "Spell_Fire_FelImmolation" },
		{ AL["World Bosses"], "WORLDBOSSMENU", "INV_Misc_Head_Dragon_Blue" },
		{ AL["Factions"], "REPMENU", "INV_Misc_Note_02" },
		{ AL["World Events"], "WORLDEVENTMENU", "INV_Misc_Gift_05" },
	}
	for i = 1, table.getn(left) do
		_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(left[i][1])
		_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText("")
		_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture("Interface/Icons/"..left[i][3])
		_G["AtlasLootMenuItem_"..i].lootpage = left[i][2]
		_G["AtlasLootMenuItem_"..i]:Show()
	end
	for i = 1, table.getn(right) do
		local slot = 15 + i
		_G["AtlasLootMenuItem_"..slot.."_Name"]:SetText(right[i][1])
		_G["AtlasLootMenuItem_"..slot.."_Extra"]:SetText("")
		_G["AtlasLootMenuItem_"..slot.."_Icon"]:SetTexture("Interface/Icons/"..right[i][3])
		_G["AtlasLootMenuItem_"..slot].lootpage = right[i][2]
		_G["AtlasLootMenuItem_"..slot]:Show()
	end
	AtlasLoot_HomeMenuSpacing = true
	local spacing = 10
	for i = 2, table.getn(left) do
		_G["AtlasLootMenuItem_"..i]:ClearAllPoints()
		_G["AtlasLootMenuItem_"..i]:SetPoint("TOPLEFT", _G["AtlasLootMenuItem_"..(i-1)], "BOTTOMLEFT", 0, -spacing)
	end
	for i = 2, table.getn(right) do
		local slot = 15 + i
		_G["AtlasLootMenuItem_"..slot]:ClearAllPoints()
		_G["AtlasLootMenuItem_"..slot]:SetPoint("TOPLEFT", _G["AtlasLootMenuItem_"..(slot-1)], "BOTTOMLEFT", 0, -spacing)
	end
end
