local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");

local ORANGE = "|cffFF8400";

function AtlasLootWorldEventMenu()
	AtlasLoot_PrepMenu(nil, AL["World Events"])
	AtlasLootCharDB.LastBoss = "WORLDEVENTMENU"
	AtlasLootCharDB.LastBossText = AL["World Events"]
	--Brewfest
	AtlasLootMenuItem_1_Name:SetText(AL["Brewfest"]);
	AtlasLootMenuItem_1_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_1_Icon:SetTexture("Interface\\Icons\\INV_Drink_05");
	AtlasLootMenuItem_1.lootpage="Brewfest1";
	AtlasLootMenuItem_1:Show();
	--Children's Week
	AtlasLootMenuItem_2_Name:SetText(AL["Children's Week"]);
	AtlasLootMenuItem_2_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\Ability_Hunter_BeastCall");
	AtlasLootMenuItem_2.lootpage="ChildrensWeek";
	AtlasLootMenuItem_2:Show();
	--Feast of Winter Veil
	AtlasLootMenuItem_3_Name:SetText(AL["Feast of Winter Veil"]);
	AtlasLootMenuItem_3_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Holiday_Christmas_Present_01");
	AtlasLootMenuItem_3.lootpage="Winterviel1";
	AtlasLootMenuItem_3:Show();
	--Hallow's End
	AtlasLootMenuItem_4_Name:SetText(AL["Hallow's End"]);
	AtlasLootMenuItem_4_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Misc_Bag_28_Halloween");
	AtlasLootMenuItem_4.lootpage="Halloween1";
	AtlasLootMenuItem_4:Show();
	--Headless Horseman
	AtlasLootMenuItem_5_Name:SetText(AL["Headless Horseman"]);
	AtlasLootMenuItem_5_Extra:SetText(ORANGE..AL["Hallow's End"]);
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\Icons\\INV_Misc_Head_Undead_01");
	AtlasLootMenuItem_5.lootpage="HeadlessHorseman";
	AtlasLootMenuItem_5:Show();
	--Harvest Festival
	AtlasLootMenuItem_6_Name:SetText(AL["Harvest Festival"]);
	AtlasLootMenuItem_6_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\INV_Misc_Food_Wheat_01");
	AtlasLootMenuItem_6.lootpage="HarvestFestival";
	AtlasLootMenuItem_6:Show();
	--Love is in the Air
	AtlasLootMenuItem_7_Name:SetText(AL["Love is in the Air"]);
	AtlasLootMenuItem_7_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\Icons\\INV_ValentinesBoxOfChocolates02");
	AtlasLootMenuItem_7.lootpage="Valentineday";
	AtlasLootMenuItem_7:Show();
	--Lunar Festival
	AtlasLootMenuItem_8_Name:SetText(AL["Lunar Festival"]);
	AtlasLootMenuItem_8_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_8_Icon:SetTexture("Interface\\Icons\\INV_Misc_ElvenCoins");
	AtlasLootMenuItem_8.lootpage="LunarFestival1";
	AtlasLootMenuItem_8:Show();
	--Midsummer Fire Festival
	AtlasLootMenuItem_9_Name:SetText(AL["Midsummer Fire Festival"]);
	AtlasLootMenuItem_9_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_9_Icon:SetTexture("Interface\\Icons\\INV_SummerFest_Symbol_Medium");
	AtlasLootMenuItem_9.lootpage="MidsummerFestival";
	AtlasLootMenuItem_9:Show();
	--Lord Ahune
	AtlasLootMenuItem_10_Name:SetText(AL["Lord Ahune"]);
	AtlasLootMenuItem_10_Extra:SetText(ORANGE..AL["Midsummer Fire Festival"]);
	AtlasLootMenuItem_10_Icon:SetTexture("Interface\\Icons\\Spell_Frost_FrozenCore");
	AtlasLootMenuItem_10.lootpage="LordAhune";
	AtlasLootMenuItem_10:Show();
	--Lord Ahune (Heroic)
	AtlasLootMenuItem_11_Name:SetText(AL["Lord Ahune"]);
	AtlasLootMenuItem_11_Extra:SetText(ORANGE..AL["Heroic"]);
	AtlasLootMenuItem_11_Icon:SetTexture("Interface\\Icons\\Spell_Frost_FrozenCore");
	AtlasLootMenuItem_11.lootpage="LordAhuneHEROIC";
	AtlasLootMenuItem_11:Show();
	--Noblegarden
	AtlasLootMenuItem_12_Name:SetText(AL["Noblegarden"]);
	AtlasLootMenuItem_12_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_12_Icon:SetTexture("Interface\\Icons\\INV_Egg_03");
	AtlasLootMenuItem_12.lootpage="Noblegarden";
	AtlasLootMenuItem_12:Show();
	--Scourge Invasion
	AtlasLootMenuItem_13_Name:SetText(AL["Scourge Invasion"]);
	AtlasLootMenuItem_13_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_13_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Talisman_13");
	AtlasLootMenuItem_13.lootpage="ScourgeInvasionEvent1";
	AtlasLootMenuItem_13:Show();

	--Skettis
	AtlasLootMenuItem_16_Name:SetText(AL["Skettis"]);
	AtlasLootMenuItem_16_Extra:SetText(ORANGE..AL["Terokkar Forest"]);
	AtlasLootMenuItem_16_Icon:SetTexture("Interface\\Icons\\Spell_Nature_NaturesWrath");
	AtlasLootMenuItem_16.lootpage="SKETTISMENU";
	AtlasLootMenuItem_16:Show();
	--Ethereum Prison
	AtlasLootMenuItem_17_Name:SetText(AL["Ethereum Prison"]);
	AtlasLootMenuItem_17_Extra:SetText(ORANGE..AL["Netherstorm"]);
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Misc_PunchCards_Prismatic");
	AtlasLootMenuItem_17.lootpage="ETHEREUMMENU";
	AtlasLootMenuItem_17:Show();
	--Abyssal Council
	AtlasLootMenuItem_18_Name:SetText(AL["Abyssal Council"]);
	AtlasLootMenuItem_18_Extra:SetText(ORANGE..AL["Silithus"]);
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\INV_Staff_13");
	AtlasLootMenuItem_18.lootpage="ABYSSALMENU";
	AtlasLootMenuItem_18:Show();
	--Bash'ir Landing Skyguard Raid
	AtlasLootMenuItem_19_Name:SetText(AL["Bash'ir Landing Skyguard Raid"]);
	AtlasLootMenuItem_19_Extra:SetText(ORANGE..AL["Blade's Edge Mountains"]);
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\Icons\\INV_Trinket_Naxxramas02");
	AtlasLootMenuItem_19.lootpage="BashirLanding";
	AtlasLootMenuItem_19:Show();
	--Shartuul
	AtlasLootMenuItem_20_Name:SetText(AL["Shartuul"]);
	AtlasLootMenuItem_20_Extra:SetText(ORANGE..AL["Blade's Edge Mountains"]);
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_04");
	AtlasLootMenuItem_20.lootpage="Shartuul";
	AtlasLootMenuItem_20:Show();
	--Elemental Invasion
	AtlasLootMenuItem_22_Name:SetText(AL["Elemental Invasion"]);
	AtlasLootMenuItem_22_Extra:SetText(ORANGE..AL["Various Locations"]);
	AtlasLootMenuItem_22_Icon:SetTexture("Interface\\Icons\\Spell_Fire_Elemental_Totem");
	AtlasLootMenuItem_22.lootpage="ElementalInvasion";
	AtlasLootMenuItem_22:Show();
	--Gurubashi Arena
	AtlasLootMenuItem_23_Name:SetText(AL["Gurubashi Arena Booty Run"]);
	AtlasLootMenuItem_23_Extra:SetText(ORANGE..AL["Stranglethorn Vale"]);
	AtlasLootMenuItem_23_Icon:SetTexture("Interface\\Icons\\INV_Misc_ArmorKit_04");
	AtlasLootMenuItem_23.lootpage="GurubashiArena";
	AtlasLootMenuItem_23:Show();
	--Stranglethorn Fishing Extravaganza
	AtlasLootMenuItem_24_Name:SetText(AL["Stranglethorn Fishing Extravaganza"]);
	AtlasLootMenuItem_24_Extra:SetText(ORANGE..AL["Stranglethorn Vale"]);
	AtlasLootMenuItem_24_Icon:SetTexture("Interface\\Icons\\INV_Fishingpole_01");
	AtlasLootMenuItem_24.lootpage="FishingExtravaganza";
	AtlasLootMenuItem_24:Show();
end

function AtlasLootSkettisMenu()
	AtlasLoot_PrepMenu("WORLDEVENTMENU", AL["Skettis"])
	--Darkscreecher Akkarai
	AtlasLootMenuItem_2_Name:SetText(AL["Darkscreecher Akkarai"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_2.lootpage="DarkscreecherAkkarai";
	AtlasLootMenuItem_2:Show();
	--Gezzarak the Huntress
	AtlasLootMenuItem_3_Name:SetText(AL["Gezzarak the Huntress"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_3.lootpage="GezzaraktheHuntress";
	AtlasLootMenuItem_3:Show();
	--Terokk
	AtlasLootMenuItem_4_Name:SetText(AL["Terokk"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_4.lootpage="Terokk";
	AtlasLootMenuItem_4:Show();
	--Talonpriest Ishaal
	AtlasLootMenuItem_6_Name:SetText("Talonpriest Ishaal");
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_6.lootpage="SkettisTalonpriestIshaal";
	AtlasLootMenuItem_6:Show();
	--Karrog
	AtlasLootMenuItem_17_Name:SetText(AL["Karrog"]);
	AtlasLootMenuItem_17_Extra:SetText("");
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_17.lootpage="Karrog";
	AtlasLootMenuItem_17:Show();
	--Vakkiz the Windrager
	AtlasLootMenuItem_18_Name:SetText(AL["Vakkiz the Windrager"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_18.lootpage="VakkiztheWindrager";
	AtlasLootMenuItem_18:Show();
	--Hazzik's Package
	AtlasLootMenuItem_20_Name:SetText("Hazzik's Package");
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\Icons\\INV_Box_01");
	AtlasLootMenuItem_20.lootpage="SkettisHazziksPackage";
	AtlasLootMenuItem_20:Show();
end

function AtlasLootEthereumMenu()
	AtlasLoot_PrepMenu("WORLDEVENTMENU", AL["Ethereum Prison"])
	--Armbreaker Huffaz
	AtlasLootMenuItem_2_Name:SetText(AL["Armbreaker Huffaz"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Ring_59");
	AtlasLootMenuItem_2.lootpage="ArmbreakerHuffaz";
	AtlasLootMenuItem_2:Show();
	--Forgosh
	AtlasLootMenuItem_3_Name:SetText(AL["Forgosh"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Boots_05");
	AtlasLootMenuItem_3.lootpage="Forgosh";
	AtlasLootMenuItem_3:Show();
	--Malevus the Mad
	AtlasLootMenuItem_4_Name:SetText(AL["Malevus the Mad"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Boots_Chain_04");
	AtlasLootMenuItem_4.lootpage="MalevustheMad";
	AtlasLootMenuItem_4:Show();
	--Wrathbringer Laz-tarash
	AtlasLootMenuItem_5_Name:SetText(AL["Wrathbringer Laz-tarash"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\Icons\\INV_Misc_Orb_01");
	AtlasLootMenuItem_5.lootpage="WrathbringerLaztarash";
	AtlasLootMenuItem_5:Show();
	--Fel Tinkerer Zortan
	AtlasLootMenuItem_17_Name:SetText(AL["Fel Tinkerer Zortan"]);
	AtlasLootMenuItem_17_Extra:SetText("");
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Boots_Chain_08");
	AtlasLootMenuItem_17.lootpage="FelTinkererZortan";
	AtlasLootMenuItem_17:Show();
	--Gul'bor
	AtlasLootMenuItem_18_Name:SetText(AL["Gul'bor"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Necklace_29Naxxramas");
	AtlasLootMenuItem_18.lootpage="Gulbor";
	AtlasLootMenuItem_18:Show();
	--Porfus the Gem Gorger
	AtlasLootMenuItem_19_Name:SetText(AL["Porfus the Gem Gorger"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\Icons\\INV_Boots_Cloth_01");
	AtlasLootMenuItem_19.lootpage="PorfustheGemGorger";
	AtlasLootMenuItem_19:Show();
	--Bash'ir Landing Stasis Chambers
	AtlasLootMenuItem_20_Name:SetText(AL["Bash'ir Landing Stasis Chambers"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\Icons\\INV_Trinket_Naxxramas02");
	AtlasLootMenuItem_20.lootpage="BashirStasisChambers";
	AtlasLootMenuItem_20:Show();
end

function AtlasLootAbyssalMenu()
	AtlasLoot_PrepMenu("WORLDEVENTMENU", AL["Abyssal Council"])
	--Templars
	AtlasLootMenuItem_2_Name:SetText(AL["Templars"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Talisman_05");
	AtlasLootMenuItem_2.lootpage="Templars";
	AtlasLootMenuItem_2:Show();
	--High Council
	AtlasLootMenuItem_3_Name:SetText(AL["High Council"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Staff_13");
	AtlasLootMenuItem_3.lootpage="HighCouncil";
	AtlasLootMenuItem_3:Show();
	--Dukes
	AtlasLootMenuItem_17_Name:SetText(AL["Dukes"]);
	AtlasLootMenuItem_17_Extra:SetText("");
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Ring_36");
	AtlasLootMenuItem_17.lootpage="Dukes";
	AtlasLootMenuItem_17:Show();
end
