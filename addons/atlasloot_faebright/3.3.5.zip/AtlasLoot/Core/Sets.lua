﻿local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");
local _G = _G or getfenv(0)

local ORANGE = "|cffFF8400";
local data = AtlasLoot_Data["AtlasLootSetItems"]

function AtlasLoot_GetDataSource(dataID)
	local source = nil
	for k in pairs(AtlasLoot_Data) do
		if source then
			break
		end
		for i in pairs(AtlasLoot_Data[k]) do
			if i == dataID then
				source = k
				break
			end
		end
	end
	return source
end

function AtlasLoot_PrepMenu(backPage, title)
	for i = 1, 30, 1 do
		_G["AtlasLootItem_" .. i]:Hide();
	end
	for i = 1, 30, 1 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button:Hide();
		button.isheader = false;
		button.container = nil
		button.dataSource = nil
		_G["AtlasLootMenuItem_" .. i .. "_Icon"]:SetTexCoord(0, 1, 0, 1)
		_G["AtlasLootMenuItem_"..i.."_IconBorder"]:SetVertexColor(1, 1, 1)
	end
	if backPage then
		AtlasLootItemsFrame_BACK:Show();
		AtlasLootItemsFrame_BACK.lootpage = backPage;
	else
		AtlasLootItemsFrame_BACK:Hide();
	end
	AtlasLootItemsFrame_NEXT:Hide();
	AtlasLootItemsFrame_PREV:Hide();
	AtlasLootItemsFrame_PREV_BOSS:Hide();
	AtlasLootItemsFrame_NEXT_BOSS:Hide();
	AtlasLootServerQueryButton:Hide();
	for i = 1, 30, 1 do
		_G["AtlasLootMenuItem_" .. i .. "_Extra"]:Show();
	end
	AtlasLoot_BossName:SetText("|cffFFFFFF" .. title);
	if AtlasLoot_HomeMenuSpacing then
		AtlasLoot_HomeMenuSpacing = nil
		_G["AtlasLootMenuItem_1"]:ClearAllPoints()
		_G["AtlasLootMenuItem_1"]:SetPoint("TOPLEFT", AtlasLootItemsFrame, "TOPLEFT", 25, -43)
		for i = 2, 15 do
			_G["AtlasLootMenuItem_"..i]:ClearAllPoints()
			_G["AtlasLootMenuItem_"..i]:SetPoint("TOPLEFT", _G["AtlasLootItem_"..(i-1)], "BOTTOMLEFT")
		end
		_G["AtlasLootMenuItem_16"]:ClearAllPoints()
		_G["AtlasLootMenuItem_16"]:SetPoint("TOPLEFT", _G["AtlasLootItem_1"], "TOPRIGHT")
		for i = 17, 30 do
			_G["AtlasLootMenuItem_"..i]:ClearAllPoints()
			_G["AtlasLootMenuItem_"..i]:SetPoint("TOPLEFT", _G["AtlasLootItem_"..(i - 1)], "BOTTOMLEFT")
		end
	end
end

function AtlasLootSetMenu()
	AtlasLoot_PrepMenu(nil, AL["Collections"])
	AtlasLootCharDB.LastBoss = "SETMENU"
	AtlasLootCharDB.LastBossText = AL["Collections"]
	--Badge of Justice Rewards
	AtlasLootMenuItem_1_Name:SetText(AL["Badge of Justice Rewards"]);
	AtlasLootMenuItem_1_Extra:SetText(ORANGE .. AL["Burning Crusade"]);
	AtlasLootMenuItem_1_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_1.lootpage = "70TOKENMENU";
	AtlasLootMenuItem_1:Show();
	--World Epics
	AtlasLootMenuItem_2_Name:SetText(AL["BoE World Epics"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Sword_76");
	AtlasLootMenuItem_2.lootpage = "WORLDEPICS";
	AtlasLootMenuItem_2:Show();
	--Legendaries
	AtlasLootMenuItem_3_Name:SetText(AL["Legendary Items"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Staff_Medivh");
	AtlasLootMenuItem_3.lootpage = "Legendaries";
	AtlasLootMenuItem_3:Show();
	--Rare Mounts
	AtlasLootMenuItem_4_Name:SetText(AL["Rare Mounts"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Misc_QirajiCrystal_05");
	AtlasLootMenuItem_4.lootpage = "RareMounts1";
	AtlasLootMenuItem_4:Show();
	--Tabards
	AtlasLootMenuItem_5_Name:SetText(AL["Tabards"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\Icons\\INV_Shirt_GuildTabard_01");
	AtlasLootMenuItem_5.lootpage = "Tabards1";
	AtlasLootMenuItem_5:Show();
	--Card Game Items
	AtlasLootMenuItem_6_Name:SetText(AL["Upper Deck Card Game Items"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\INV_Misc_Ticket_Tarot_Madness");
	AtlasLootMenuItem_6.lootpage = "CardGame1";
	AtlasLootMenuItem_6:Show();
	--Misc Sets (Classic dungeon sets)
	AtlasLootMenuItem_8_Name:SetText(AL["Sets"]);
	AtlasLootMenuItem_8_Extra:SetText(ORANGE .. AL["Classic"]);
	AtlasLootMenuItem_8_Icon:SetTexture("Interface\\Icons\\INV_Sword_43");
	AtlasLootMenuItem_8.lootpage = "PRE60SET";
	AtlasLootMenuItem_8:Show();
	--TBC Misc Sets
	AtlasLootMenuItem_9_Name:SetText(AL["Sets"]);
	AtlasLootMenuItem_9_Extra:SetText(ORANGE .. AL["Burning Crusade"]);
	AtlasLootMenuItem_9_Icon:SetTexture("Interface\\Icons\\INV_Weapon_Glave_01");
	AtlasLootMenuItem_9.lootpage = "TBCSets";
	AtlasLootMenuItem_9:Show();
	--ZG
	AtlasLootMenuItem_10_Name:SetText(AL["Zul'Gurub Sets"]);
	AtlasLootMenuItem_10_Extra:SetText("");
	AtlasLootMenuItem_10_Icon:SetTexture("Interface\\Icons\\INV_Sword_55");
	AtlasLootMenuItem_10.lootpage = "ZGSET";
	AtlasLootMenuItem_10:Show();
	--AQ20
	AtlasLootMenuItem_11_Name:SetText(AL["Ruins of Ahn'Qiraj Sets"]);
	AtlasLootMenuItem_11_Extra:SetText("");
	AtlasLootMenuItem_11_Icon:SetTexture("Interface\\Icons\\INV_Axe_15");
	AtlasLootMenuItem_11.lootpage = "AQ20SET";
	AtlasLootMenuItem_11:Show();
	--AQ40
	AtlasLootMenuItem_12_Name:SetText(AL["Temple of Ahn'Qiraj Sets"]);
	AtlasLootMenuItem_12_Extra:SetText("");
	AtlasLootMenuItem_12_Icon:SetTexture("Interface\\Icons\\INV_Shoulder_35");
	AtlasLootMenuItem_12.lootpage = "AQ40SET";
	AtlasLootMenuItem_12:Show();

	--Dungeon Set 1/2
	AtlasLootMenuItem_16_Name:SetText(AL["Dungeon 1/2 Sets"]);
	AtlasLootMenuItem_16_Extra:SetText("");
	AtlasLootMenuItem_16_Icon:SetTexture("Interface\\Icons\\INV_Chest_Chain_03");
	AtlasLootMenuItem_16.lootpage = "T0SET";
	AtlasLootMenuItem_16:Show();
	--Dungeon Set 3
	AtlasLootMenuItem_17_Name:SetText(AL["Dungeon 3 Sets"]);
	AtlasLootMenuItem_17_Extra:SetText(ORANGE .. AL["Burning Crusade"]);
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Helmet_15");
	AtlasLootMenuItem_17.lootpage = "DS3SET";
	AtlasLootMenuItem_17:Show();
	--Tier 1/2
	AtlasLootMenuItem_20_Name:SetText(AL["Tier 1/2 Sets"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\Icons\\INV_Pants_Mail_03");
	AtlasLootMenuItem_20.lootpage = "T1T2SET";
	AtlasLootMenuItem_20:Show();
	--Tier 3
	AtlasLootMenuItem_21_Name:SetText(AL["Tier 3 Sets"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\Icons\\INV_Helmet_58");
	AtlasLootMenuItem_21.lootpage = "T3SET";
	AtlasLootMenuItem_21:Show();
	--Tier 4
	AtlasLootMenuItem_22_Name:SetText(AL["Tier 4 Sets"]);
	AtlasLootMenuItem_22_Extra:SetText(ORANGE .. AL["Burning Crusade"]);
	AtlasLootMenuItem_22_Icon:SetTexture("Interface\\Icons\\INV_Gauntlets_63");
	AtlasLootMenuItem_22.lootpage = "T4SET";
	AtlasLootMenuItem_22:Show();
	--Tier 5
	AtlasLootMenuItem_23_Name:SetText(AL["Tier 5 Sets"]);
	AtlasLootMenuItem_23_Extra:SetText(ORANGE .. AL["Burning Crusade"]);
	AtlasLootMenuItem_23_Icon:SetTexture("Interface\\Icons\\INV_Gauntlets_63");
	AtlasLootMenuItem_23.lootpage = "T5SET";
	AtlasLootMenuItem_23:Show();
	--Tier 6
	AtlasLootMenuItem_24_Name:SetText(AL["Tier 6 Sets"]);
	AtlasLootMenuItem_24_Extra:SetText(ORANGE .. AL["Burning Crusade"]);
	AtlasLootMenuItem_24_Icon:SetTexture("Interface\\Icons\\INV_Gauntlets_63");
	AtlasLootMenuItem_24.lootpage = "T6SET";
	AtlasLootMenuItem_24:Show();

	for i = 1, 30 do
		if _G["AtlasLootMenuItem_"..i].container then
			_G["AtlasLootMenuItem_"..i.."_IconBorder"]:SetVertexColor(1, 0.82, 0)
		else
			_G["AtlasLootMenuItem_"..i.."_IconBorder"]:SetVertexColor(1, 1, 1)
		end
	end
end

function AtlasLootWorldEpicsMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["BoE World Epics"])
	--Lvl 30-39 BoE World Epics
	AtlasLootMenuItem_2_Name:SetText(AL["Level 30-39"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Ring_15");
	AtlasLootMenuItem_2.lootpage = "WorldEpics1";
	AtlasLootMenuItem_2:Show();
	--Lvl 40-49 BoE World Epics
	AtlasLootMenuItem_3_Name:SetText(AL["Level 40-49"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Staff_29");
	AtlasLootMenuItem_3.lootpage = "WorldEpics2";
	AtlasLootMenuItem_3:Show();
	--Lvl 50-60 BoE World Epics
	AtlasLootMenuItem_4_Name:SetText(AL["Level 50-60"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Sword_19");
	AtlasLootMenuItem_4.lootpage = "WorldEpics3";
	AtlasLootMenuItem_4:Show();
	--Lvl 70 BoE World Epics
	AtlasLootMenuItem_17_Name:SetText(AL["Level 70"]);
	AtlasLootMenuItem_17_Extra:SetText("");
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Sword_76");
	AtlasLootMenuItem_17.lootpage = "WorldEpics4";
	AtlasLootMenuItem_17:Show();
end

function AtlasLootPRE60SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Sets"])
	--The Deadmines - Defias Leather
	AtlasLootMenuItem_2_Name:SetText(AL["Defias Leather"]);
	AtlasLootMenuItem_2_Extra:SetText(ORANGE .. AL["The Deadmines"]);
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Chest_Leather_09");
	AtlasLootMenuItem_2.lootpage = "VWOWDeadmines";
	AtlasLootMenuItem_2:Show();
	--Wailing Caverns - Embrace of the Viper
	AtlasLootMenuItem_3_Name:SetText(AL["Embrace of the Viper"]);
	AtlasLootMenuItem_3_Extra:SetText(ORANGE .. AL["Wailing Caverns"]);
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Shirt_16");
	AtlasLootMenuItem_3.lootpage = "VWOWWailingC";
	AtlasLootMenuItem_3:Show();
	--Scarlet Monastery - Chain of the Scarlet Crusade
	AtlasLootMenuItem_4_Name:SetText(AL["Chain of the Scarlet Crusade"]);
	AtlasLootMenuItem_4_Extra:SetText(ORANGE .. AL["Scarlet Monastery"]);
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Gauntlets_19");
	AtlasLootMenuItem_4.lootpage = "VWOWScarletM";
	AtlasLootMenuItem_4:Show();
	--Blackrock Depths - The Gladiator
	AtlasLootMenuItem_5_Name:SetText(AL["The Gladiator"]);
	AtlasLootMenuItem_5_Extra:SetText(ORANGE .. AL["Blackrock Depths"]);
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\Icons\\INV_Helmet_01");
	AtlasLootMenuItem_5.lootpage = "VWOWBlackrockD";
	AtlasLootMenuItem_5:Show();
	--Ironweave Battlesuit
	AtlasLootMenuItem_6_Name:SetText(AL["Ironweave Battlesuit"]);
	AtlasLootMenuItem_6_Extra:SetText(ORANGE .. AL["Various Locations"]);
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\INV_Boots_Cloth_05");
	AtlasLootMenuItem_6.lootpage = "VWOWIronweave";
	AtlasLootMenuItem_6:Show();
	--Stratholme - The Postmaster
	AtlasLootMenuItem_7_Name:SetText(AL["The Postmaster"]);
	AtlasLootMenuItem_7_Extra:SetText(ORANGE .. AL["Stratholme"]);
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\Icons\\INV_Boots_02");
	AtlasLootMenuItem_7.lootpage = "VWOWStrat";
	AtlasLootMenuItem_7:Show();
	--Scholomance - Cloth - Necropile Raiment
	AtlasLootMenuItem_8_Name:SetText(AL["Necropile Raiment"]);
	AtlasLootMenuItem_8_Extra:SetText(ORANGE .. AL["Scholomance"]);
	AtlasLootMenuItem_8_Icon:SetTexture("Interface\\Icons\\INV_Shoulder_02");
	AtlasLootMenuItem_8.lootpage = "VWOWScholo";
	AtlasLootMenuItem_8:Show();
	--Scholomance - Leather - Cadaverous Garb
	AtlasLootMenuItem_9_Name:SetText(AL["Cadaverous Garb"]);
	AtlasLootMenuItem_9_Extra:SetText(ORANGE .. AL["Scholomance"]);
	AtlasLootMenuItem_9_Icon:SetTexture("Interface\\Icons\\INV_Belt_16");
	AtlasLootMenuItem_9.lootpage = "VWOWScholo";
	AtlasLootMenuItem_9:Show();
	--Scholomance - Mail - Bloodmail Regalia
	AtlasLootMenuItem_10_Name:SetText(AL["Bloodmail Regalia"]);
	AtlasLootMenuItem_10_Extra:SetText(ORANGE .. AL["Scholomance"]);
	AtlasLootMenuItem_10_Icon:SetTexture("Interface\\Icons\\INV_Gauntlets_26");
	AtlasLootMenuItem_10.lootpage = "VWOWScholo";
	AtlasLootMenuItem_10:Show();
	--Scholomance - Plate - Deathbone Guardian
	AtlasLootMenuItem_11_Name:SetText(AL["Deathbone Guardian"]);
	AtlasLootMenuItem_11_Extra:SetText(ORANGE .. AL["Scholomance"]);
	AtlasLootMenuItem_11_Icon:SetTexture("Interface\\Icons\\INV_Belt_12");
	AtlasLootMenuItem_11.lootpage = "VWOWScholo";
	AtlasLootMenuItem_11:Show();
	--Scourge Invasion
	AtlasLootMenuItem_12_Name:SetText(AL["Scourge Invasion"]);
	AtlasLootMenuItem_12_Extra:SetText(ORANGE .. AL["Various Locations"]);
	AtlasLootMenuItem_12_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Talisman_13");
	AtlasLootMenuItem_12.lootpage = "VWOWScourgeInvasion";
	AtlasLootMenuItem_12:Show();
	--Spider's Kiss
	AtlasLootMenuItem_17_Name:SetText(AL["Spider's Kiss"]);
	AtlasLootMenuItem_17_Extra:SetText(ORANGE .. AL["Lower Blackrock Spire"]);
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Weapon_ShortBlade_16");
	AtlasLootMenuItem_17.lootpage = "VWOWSpiderKiss";
	AtlasLootMenuItem_17:Show();
	--Dal'Rend's Arms
	AtlasLootMenuItem_18_Name:SetText(AL["Dal'Rend's Arms"]);
	AtlasLootMenuItem_18_Extra:SetText(ORANGE .. AL["Upper Blackrock Spire"]);
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\INV_Sword_43");
	AtlasLootMenuItem_18.lootpage = "VWOWDalRend";
	AtlasLootMenuItem_18:Show();
	--Shard of the Gods
	AtlasLootMenuItem_22_Name:SetText(AL["Shard of the Gods"]);
	AtlasLootMenuItem_22_Extra:SetText(ORANGE .. AL["Various Locations"]);
	AtlasLootMenuItem_22_Icon:SetTexture("Interface\\Icons\\INV_Misc_MonsterScales_15");
	AtlasLootMenuItem_22.lootpage = "VWOWShardOfGods";
	AtlasLootMenuItem_22:Show();
	--Spirit of Eskhandar
	AtlasLootMenuItem_23_Name:SetText(AL["Spirit of Eskhandar"]);
	AtlasLootMenuItem_23_Extra:SetText(ORANGE .. AL["Various Locations"]);
	AtlasLootMenuItem_23_Icon:SetTexture("Interface\\Icons\\INV_Misc_MonsterClaw_04");
	AtlasLootMenuItem_23.lootpage = "VWOWSpiritofEskhandar";
	AtlasLootMenuItem_23:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootZGSetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Zul'Gurub Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest")
	AtlasLootMenuItem_3.lootpage = "ZGPriest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage = "ZGMage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "ZGWarlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue")
	AtlasLootMenuItem_6.lootpage = "ZGRogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid")
	AtlasLootMenuItem_7.lootpage = "ZGDruid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter")
	AtlasLootMenuItem_18.lootpage = "ZGHunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "ZGShaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin")
	AtlasLootMenuItem_20.lootpage = "ZGPaladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior")
	AtlasLootMenuItem_21.lootpage = "ZGWarrior";
	AtlasLootMenuItem_21:Show();
	--Zul'Gurub Rings
	AtlasLootMenuItem_23_Name:SetText(AL["Zul'Gurub Rings"]);
	AtlasLootMenuItem_23_Extra:SetText("");
	AtlasLootMenuItem_23_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Ring_46");
	AtlasLootMenuItem_23.lootpage = "VWOWZulGurub";
	AtlasLootMenuItem_23:Show();
	--Primal Blessing
	AtlasLootMenuItem_24_Name:SetText(AL["Primal Blessing"]);
	AtlasLootMenuItem_24_Extra:SetText("");
	AtlasLootMenuItem_24_Icon:SetTexture("Interface\\Icons\\INV_Weapon_Hand_01");
	AtlasLootMenuItem_24.lootpage = "VWOWZulGurub";
	AtlasLootMenuItem_24:Show();
	--The Twin Blades of Hakkari
	AtlasLootMenuItem_25_Name:SetText(AL["The Twin Blades of Hakkari"]);
	AtlasLootMenuItem_25_Extra:SetText("");
	AtlasLootMenuItem_25_Icon:SetTexture("Interface\\Icons\\INV_Sword_55");
	AtlasLootMenuItem_25.lootpage = "VWOWZulGurub";
	AtlasLootMenuItem_25:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootAQ40SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Temple of Ahn'Qiraj Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest")
	AtlasLootMenuItem_3.lootpage = "AQ40Sets2";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage = "AQ40Sets1";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "AQ40Sets2";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue");
	AtlasLootMenuItem_6.lootpage = "AQ40Sets2";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid");
	AtlasLootMenuItem_7.lootpage = "AQ40Sets1";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter");
	AtlasLootMenuItem_18.lootpage = "AQ40Sets1";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "AQ40Sets2";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin");
	AtlasLootMenuItem_20.lootpage = "AQ40Sets1";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior");
	AtlasLootMenuItem_21.lootpage = "AQ40Sets3";
	AtlasLootMenuItem_21:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootAQ20SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Ruins of Ahn'Qiraj Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest");
	AtlasLootMenuItem_3.lootpage = "AQ20Sets1";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage = "AQ20Sets1";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "AQ20Sets2";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue");
	AtlasLootMenuItem_6.lootpage = "AQ20Sets1";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid");
	AtlasLootMenuItem_7.lootpage = "AQ20Sets1";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter");
	AtlasLootMenuItem_18.lootpage = "AQ20Sets1";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "AQ20Sets2";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin");
	AtlasLootMenuItem_20.lootpage = "AQ20Sets1";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior");
	AtlasLootMenuItem_21.lootpage = "AQ20Sets2";
	AtlasLootMenuItem_21:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootT0SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Dungeon 1/2 Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest");
	AtlasLootMenuItem_3.lootpage = "T0Priest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage");
	AtlasLootMenuItem_4.lootpage = "T0Mage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "T0Warlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue")
	AtlasLootMenuItem_6.lootpage = "T0Rogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid")
	AtlasLootMenuItem_7.lootpage = "T0Druid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter")
	AtlasLootMenuItem_18.lootpage = "T0Hunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "T0Shaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin")
	AtlasLootMenuItem_20.lootpage = "T0Paladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior")
	AtlasLootMenuItem_21.lootpage = "T0Warrior";
	AtlasLootMenuItem_21:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootT1SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Tier 1 Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest");
	AtlasLootMenuItem_3.lootpage = "T1T2Priest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage = "T1T2Mage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "T1T2Warlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue");
	AtlasLootMenuItem_6.lootpage = "T1T2Rogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid");
	AtlasLootMenuItem_7.lootpage = "T1T2Druid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter");
	AtlasLootMenuItem_18.lootpage = "T1T2Hunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "T1T2Shaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin");
	AtlasLootMenuItem_20.lootpage = "T1T2Paladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior");
	AtlasLootMenuItem_21.lootpage = "T1T2Warrior";
	AtlasLootMenuItem_21:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootT2SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Tier 2 Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest");
	AtlasLootMenuItem_3.lootpage = "T1T2Priest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage = "T1T2Mage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "T1T2Warlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue");
	AtlasLootMenuItem_6.lootpage = "T1T2Rogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid");
	AtlasLootMenuItem_7.lootpage = "T1T2Druid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter");
	AtlasLootMenuItem_18.lootpage = "T1T2Hunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "T1T2Shaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin");
	AtlasLootMenuItem_20.lootpage = "T1T2Paladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior");
	AtlasLootMenuItem_21.lootpage = "T1T2Warrior";
	AtlasLootMenuItem_21:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

function AtlasLootT3SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Tier 3 Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest");
	AtlasLootMenuItem_3.lootpage = "T3Priest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage = "T3Mage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage = "T3Warlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue");
	AtlasLootMenuItem_6.lootpage = "T3Rogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid");
	AtlasLootMenuItem_7.lootpage = "T3Druid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter");
	AtlasLootMenuItem_18.lootpage = "T3Hunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage = "T3Shaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin");
	AtlasLootMenuItem_20.lootpage = "T3Paladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior");
	AtlasLootMenuItem_21.lootpage = "T3Warrior";
	AtlasLootMenuItem_21:Show();
	for i = 1, 30 do
		local button = _G["AtlasLootMenuItem_" .. i]
		button.dataSource = AtlasLoot_GetDataSource(button.lootpage)
	end
end

local function TierClassMenu(backMenu, title, prefix)
	AtlasLoot_PrepMenu(backMenu, title)
	AtlasLootMenuItem_3_Name:SetText("|cffffffff" .. AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest");
	AtlasLootMenuItem_3.lootpage = prefix .. "Priest";
	AtlasLootMenuItem_3:Show();
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef" .. AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage");
	AtlasLootMenuItem_4.lootpage = prefix .. "Mage";
	AtlasLootMenuItem_4:Show();
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9" .. AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock");
	AtlasLootMenuItem_5.lootpage = prefix .. "Warlock";
	AtlasLootMenuItem_5:Show();
	AtlasLootMenuItem_6_Name:SetText("|cfffff468" .. AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue");
	AtlasLootMenuItem_6.lootpage = prefix .. "Rogue";
	AtlasLootMenuItem_6:Show();
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a" .. AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid");
	AtlasLootMenuItem_7.lootpage = prefix .. "Druid";
	AtlasLootMenuItem_7:Show();
	AtlasLootMenuItem_18_Name:SetText("|cffaad372" .. AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter");
	AtlasLootMenuItem_18.lootpage = prefix .. "Hunter";
	AtlasLootMenuItem_18:Show();
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff" .. AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman");
	AtlasLootMenuItem_19.lootpage = prefix .. "Shaman";
	AtlasLootMenuItem_19:Show();
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba" .. AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin");
	AtlasLootMenuItem_20.lootpage = prefix .. "Paladin";
	AtlasLootMenuItem_20:Show();
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d" .. AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior");
	AtlasLootMenuItem_21.lootpage = prefix .. "Warrior";
	AtlasLootMenuItem_21:Show();
end

function AtlasLootT1T2SetMenu()
	TierClassMenu("SETMENU", AL["Tier 1/2 Sets"], "T1T2")
end

function AtlasLootT4SetMenu()
	TierClassMenu("SETMENU", AL["Tier 4 Sets"], "T4")
end

function AtlasLootT5SetMenu()
	TierClassMenu("SETMENU", AL["Tier 5 Sets"], "T5")
end

function AtlasLootT6SetMenu()
	TierClassMenu("SETMENU", AL["Tier 6 Sets"], "T6")
end

function AtlasLoot70TokenMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Badge of Justice Rewards"])
	AtlasLootMenuItem_2_Name:SetText(AL["Cloth"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_2.lootpage = "HardModeCloth";
	AtlasLootMenuItem_2:Show();
	AtlasLootMenuItem_3_Name:SetText(AL["Mail"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_3.lootpage = "HardModeMail";
	AtlasLootMenuItem_3:Show();
	AtlasLootMenuItem_4_Name:SetText(AL["Fire Resistance Gear"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_4.lootpage = "HardModeResist";
	AtlasLootMenuItem_4:Show();
	AtlasLootMenuItem_6_Name:SetText(AL["Relic"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_6.lootpage = "HardModeRelic";
	AtlasLootMenuItem_6:Show();
	AtlasLootMenuItem_8_Name:SetText(AL["Weapons"]);
	AtlasLootMenuItem_8_Extra:SetText("");
	AtlasLootMenuItem_8_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_8.lootpage = "HardModeWeapons";
	AtlasLootMenuItem_8:Show();
	AtlasLootMenuItem_17_Name:SetText(AL["Leather"]);
	AtlasLootMenuItem_17_Extra:SetText("");
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_17.lootpage = "HardModeLeather";
	AtlasLootMenuItem_17:Show();
	AtlasLootMenuItem_18_Name:SetText(AL["Plate"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_18.lootpage = "HardModePlate";
	AtlasLootMenuItem_18:Show();
	AtlasLootMenuItem_19_Name:SetText(AL["Back"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_19.lootpage = "HardModeCloaks";
	AtlasLootMenuItem_19:Show();
	AtlasLootMenuItem_21_Name:SetText(AL["Accessories"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_21.lootpage = "HardModeAccessories";
	AtlasLootMenuItem_21:Show();
	AtlasLootMenuItem_23_Name:SetText(AL["Arena Reward"]);
	AtlasLootMenuItem_23_Extra:SetText("");
	AtlasLootMenuItem_23_Icon:SetTexture("Interface\\Icons\\Spell_Holy_ChampionsBond");
	AtlasLootMenuItem_23.lootpage = "HardModeArena";
	AtlasLootMenuItem_23:Show();
end

function AtlasLootDS3SetMenu()
	AtlasLoot_PrepMenu("SETMENU", AL["Dungeon 3 Sets"])
	AtlasLootMenuItem_2_Name:SetText(AL["Cloth"]);
	AtlasLootMenuItem_2_Extra:SetText("");
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\Spell_Holy_InnerFire");
	AtlasLootMenuItem_2.lootpage = "DS3Cloth";
	AtlasLootMenuItem_2:Show();
	AtlasLootMenuItem_3_Name:SetText(AL["Leather"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\Ability_Rogue_SinisterCalling");
	AtlasLootMenuItem_3.lootpage = "DS3Leather";
	AtlasLootMenuItem_3:Show();
	AtlasLootMenuItem_17_Name:SetText(AL["Mail"]);
	AtlasLootMenuItem_17_Extra:SetText("");
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\Ability_Hunter_Pet_Wolf");
	AtlasLootMenuItem_17.lootpage = "DS3Mail";
	AtlasLootMenuItem_17:Show();
	AtlasLootMenuItem_18_Name:SetText(AL["Plate"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\Spell_Fire_EnchantWeapon");
	AtlasLootMenuItem_18.lootpage = "DS3Plate";
	AtlasLootMenuItem_18:Show();
end
