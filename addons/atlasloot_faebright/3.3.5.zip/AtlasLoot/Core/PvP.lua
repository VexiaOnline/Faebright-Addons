local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");

local RED = "|cffff0000";
local ORANGE = "|cffFF8400";

function AtlasLootPvPMenu()
	AtlasLoot_PrepMenu(nil, AL["PvP Rewards"])
	AtlasLootCharDB.LastBoss = "PVPMENU"
	AtlasLootCharDB.LastBossText = AL["PvP Rewards"]
	AtlasLootDefaultFrame_SelectedCategory:SetText("")
	AtlasLootDefaultFrame_SelectedTable:SetText("")
	--PvP Accessories Level 60
	AtlasLootMenuItem_2_Name:SetText(AL["PvP Accessories"]);
	AtlasLootMenuItem_2_Extra:SetText(ORANGE..AL["Level 60"]);
	AtlasLootMenuItem_2_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Talisman_09");
	AtlasLootMenuItem_2.lootpage="PvP60Accessories1";
	AtlasLootMenuItem_2:Show();
	--PvP Armor Sets Level 60
	AtlasLootMenuItem_3_Name:SetText(AL["PvP Armor Sets"]);
	AtlasLootMenuItem_3_Extra:SetText(ORANGE..AL["Level 60"]);
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Helmet_05");
	AtlasLootMenuItem_3.lootpage="PVPSET";
	AtlasLootMenuItem_3:Show();
	--PvP Accessories Level 70
	AtlasLootMenuItem_5_Name:SetText(AL["PvP Accessories"]);
	AtlasLootMenuItem_5_Extra:SetText(ORANGE..AL["Level 70"]);
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\Icons\\inv_jewelry_ring_60");
	AtlasLootMenuItem_5.lootpage="PvP70Accessories1";
	AtlasLootMenuItem_5:Show();
	--PvP Reputation Sets Level 70
	AtlasLootMenuItem_6_Name:SetText(AL["PvP Reputation Sets"]);
	AtlasLootMenuItem_6_Extra:SetText(ORANGE..AL["Level 70"]);
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\INV_Axe_02");
	AtlasLootMenuItem_6.lootpage="PVP70REPSET";
	AtlasLootMenuItem_6:Show();
	--Arena Sets Level 70
	AtlasLootMenuItem_7_Name:SetText(AL["Arena PvP Sets"]);
	AtlasLootMenuItem_7_Extra:SetText(ORANGE..AL["Level 70"]);
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\Icons\\inv_gauntlets_29");
	AtlasLootMenuItem_7.lootpage="ARENASET";
	AtlasLootMenuItem_7:Show();
	--Battleground Rewards
	AtlasLootMenuItem_9_Name:SetText(AL["Battleground Rewards"]);
	AtlasLootMenuItem_9_Extra:SetText("");
	AtlasLootMenuItem_9_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Necklace_21");
	AtlasLootMenuItem_9.lootpage="PVPMENU2";
	AtlasLootMenuItem_9:Show();
	--PvP Weapons Level 60
	AtlasLootMenuItem_17_Name:SetText(AL["PvP Weapons"]);
	AtlasLootMenuItem_17_Extra:SetText(ORANGE..AL["Level 60"]);
	AtlasLootMenuItem_17_Icon:SetTexture("Interface\\Icons\\INV_Sword_11");
	AtlasLootMenuItem_17.lootpage="PVPWeapons1";
	AtlasLootMenuItem_17:Show();
	--PvP Non-Set Epics Level 70
	AtlasLootMenuItem_19_Name:SetText(AL["PvP Non-Set Epics"]);
	AtlasLootMenuItem_19_Extra:SetText(ORANGE..AL["Level 70"]);
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\Icons\\inv_belt_13");
	AtlasLootMenuItem_19.lootpage="PvP70NonSet1";
	AtlasLootMenuItem_19:Show();
	--Arena PvP Weapons Level 70
	AtlasLootMenuItem_20_Name:SetText(AL["Arena PvP Weapons"]);
	AtlasLootMenuItem_20_Extra:SetText(ORANGE..AL["Level 70"]);
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\Icons\\INV_Weapon_Crossbow_10");
	AtlasLootMenuItem_20.lootpage="Arena4Weapons1";
	AtlasLootMenuItem_20:Show();
end

function AtlasLootPVPSetMenu()
	AtlasLoot_PrepMenu("PVPMENU", AL["PvP Armor Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff"..AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest")
	AtlasLootMenuItem_3.lootpage="PVPPriest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef"..AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage="PVPMage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9"..AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage="PVPWarlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468"..AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue")
	AtlasLootMenuItem_6.lootpage="PVPRogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a"..AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid")
	AtlasLootMenuItem_7.lootpage="PVPDruid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372"..AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter")
	AtlasLootMenuItem_18.lootpage="PVPHunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff"..AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage="PVPShaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba"..AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin")
	AtlasLootMenuItem_20.lootpage="PVPPaladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d"..AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior")
	AtlasLootMenuItem_21.lootpage="PVPWarrior";
	AtlasLootMenuItem_21:Show();
end

function AtlasLootPVP70RepSetMenu()
	AtlasLoot_PrepMenu("PVPMENU", AL["PvP Reputation Sets"])
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff"..AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest")
	AtlasLootMenuItem_3.lootpage="PVP70RepPriest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef"..AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage="PVP70RepMage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9"..AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage="PVP70RepWarlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468"..AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue")
	AtlasLootMenuItem_6.lootpage="PVP70RepRogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a"..AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid")
	AtlasLootMenuItem_7.lootpage="PVP70RepDruid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372"..AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter")
	AtlasLootMenuItem_18.lootpage="PVP70RepHunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff"..AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage="PVP70RepShaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba"..AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin")
	AtlasLootMenuItem_20.lootpage="PVP70RepPaladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d"..AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior")
	AtlasLootMenuItem_21.lootpage="PVP70RepWarrior";
	AtlasLootMenuItem_21:Show();
end

local function ArenaClassMenu(backMenu, title, prefix)
	AtlasLoot_PrepMenu(backMenu, title)
	--Priest
	AtlasLootMenuItem_3_Name:SetText("|cffffffff"..AL["Priest"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\priest")
	AtlasLootMenuItem_3.lootpage=prefix.."Priest";
	AtlasLootMenuItem_3:Show();
	--Mage
	AtlasLootMenuItem_4_Name:SetText("|cff68ccef"..AL["Mage"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\mage")
	AtlasLootMenuItem_4.lootpage=prefix.."Mage";
	AtlasLootMenuItem_4:Show();
	--Warlock
	AtlasLootMenuItem_5_Name:SetText("|cff9382c9"..AL["Warlock"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warlock")
	AtlasLootMenuItem_5.lootpage=prefix.."Warlock";
	AtlasLootMenuItem_5:Show();
	--Rogue
	AtlasLootMenuItem_6_Name:SetText("|cfffff468"..AL["Rogue"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\rogue")
	AtlasLootMenuItem_6.lootpage=prefix.."Rogue";
	AtlasLootMenuItem_6:Show();
	--Druid
	AtlasLootMenuItem_7_Name:SetText("|cffff7c0a"..AL["Druid"]);
	AtlasLootMenuItem_7_Extra:SetText("");
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\druid")
	AtlasLootMenuItem_7.lootpage=prefix.."Druid";
	AtlasLootMenuItem_7:Show();
	--Hunter
	AtlasLootMenuItem_18_Name:SetText("|cffaad372"..AL["Hunter"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\hunter")
	AtlasLootMenuItem_18.lootpage=prefix.."Hunter";
	AtlasLootMenuItem_18:Show();
	--Shaman
	AtlasLootMenuItem_19_Name:SetText("|cff2773ff"..AL["Shaman"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\shaman")
	AtlasLootMenuItem_19.lootpage=prefix.."Shaman";
	AtlasLootMenuItem_19:Show();
	--Paladin
	AtlasLootMenuItem_20_Name:SetText("|cfff48cba"..AL["Paladin"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\paladin")
	AtlasLootMenuItem_20.lootpage=prefix.."Paladin";
	AtlasLootMenuItem_20:Show();
	--Warrior
	AtlasLootMenuItem_21_Name:SetText("|cffc69b6d"..AL["Warrior"]);
	AtlasLootMenuItem_21_Extra:SetText("");
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\AddOns\\AtlasLoot\\Images\\warrior")
	AtlasLootMenuItem_21.lootpage=prefix.."Warrior";
	AtlasLootMenuItem_21:Show();
end

function AtlasLootArenaSetMenu()
	AtlasLoot_PrepMenu("PVPMENU", AL["Arena PvP Sets"])
	--Season 1
	AtlasLootMenuItem_3_Name:SetText(AL["Season 1"]);
	AtlasLootMenuItem_3_Extra:SetText("");
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\inv_gauntlets_29");
	AtlasLootMenuItem_3.lootpage="ARENA1SET";
	AtlasLootMenuItem_3:Show();
	--Season 2
	AtlasLootMenuItem_4_Name:SetText(AL["Season 2"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\inv_gauntlets_29");
	AtlasLootMenuItem_4.lootpage="ARENA2SET";
	AtlasLootMenuItem_4:Show();
	--Season 3
	AtlasLootMenuItem_5_Name:SetText(AL["Season 3"]);
	AtlasLootMenuItem_5_Extra:SetText("");
	AtlasLootMenuItem_5_Icon:SetTexture("Interface\\Icons\\inv_gauntlets_29");
	AtlasLootMenuItem_5.lootpage="ARENA3SET";
	AtlasLootMenuItem_5:Show();
	--Season 4
	AtlasLootMenuItem_6_Name:SetText(AL["Season 4"]);
	AtlasLootMenuItem_6_Extra:SetText("");
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\inv_gauntlets_29");
	AtlasLootMenuItem_6.lootpage="ARENA4SET";
	AtlasLootMenuItem_6:Show();
	--Season 2 Weapons
	AtlasLootMenuItem_18_Name:SetText(AL["Arena Season 2 Weapons"]);
	AtlasLootMenuItem_18_Extra:SetText("");
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\INV_Weapon_Crossbow_10");
	AtlasLootMenuItem_18.lootpage="Arena2Weapons1";
	AtlasLootMenuItem_18:Show();
	--Season 3 Weapons
	AtlasLootMenuItem_19_Name:SetText(AL["Arena Season 3 Weapons"]);
	AtlasLootMenuItem_19_Extra:SetText("");
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\Icons\\INV_Weapon_Crossbow_10");
	AtlasLootMenuItem_19.lootpage="Arena3Weapons1";
	AtlasLootMenuItem_19:Show();
	--Season 4 Weapons
	AtlasLootMenuItem_20_Name:SetText(AL["Arena Season 4 Weapons"]);
	AtlasLootMenuItem_20_Extra:SetText("");
	AtlasLootMenuItem_20_Icon:SetTexture("Interface\\Icons\\INV_Weapon_Crossbow_10");
	AtlasLootMenuItem_20.lootpage="Arena4Weapons1";
	AtlasLootMenuItem_20:Show();
end

function AtlasLootArena1SetMenu()
	ArenaClassMenu("ARENASET", AL["Season 1"], "Arena")
end

function AtlasLootArena2SetMenu()
	ArenaClassMenu("ARENASET", AL["Season 2"], "Arena2")
end

function AtlasLootArena3SetMenu()
	ArenaClassMenu("ARENASET", AL["Season 3"], "Arena3")
end

function AtlasLootArena4SetMenu()
	ArenaClassMenu("ARENASET", AL["Season 4"], "Arena4")
end

function AtlasLootPvPMenu2()
	AtlasLoot_PrepMenu("PVPMENU", AL["Battleground Rewards"])
	--AB Misc
	AtlasLootMenuItem_3_Name:SetText(AL["Misc. Rewards"]);
	AtlasLootMenuItem_3_Extra:SetText(ORANGE..AL["Arathi Basin"]);
	AtlasLootMenuItem_3_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Amulet_07");
	AtlasLootMenuItem_3.lootpage="ABMisc";
	AtlasLootMenuItem_3:Show();
	--AB Sets
	AtlasLootMenuItem_4_Name:SetText(AL["Arathi Basin Sets"]);
	AtlasLootMenuItem_4_Extra:SetText("");
	AtlasLootMenuItem_4_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Amulet_07");
	AtlasLootMenuItem_4.lootpage="ABSets1";
	AtlasLootMenuItem_4:Show();
	--WSG Misc
	AtlasLootMenuItem_6_Name:SetText(AL["Misc. Rewards"]);
	AtlasLootMenuItem_6_Extra:SetText(ORANGE..AL["Warsong Gulch"]);
	AtlasLootMenuItem_6_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_6.lootpage="WSGMisc";
	AtlasLootMenuItem_6:Show();
	--WSG Level Rewards
	AtlasLootMenuItem_7_Name:SetText(AL["Level 10-19 Rewards"]);
	AtlasLootMenuItem_7_Extra:SetText(ORANGE..AL["Warsong Gulch"]);
	AtlasLootMenuItem_7_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_7.lootpage="WSG1019";
	AtlasLootMenuItem_7:Show();
	--AV Misc
	AtlasLootMenuItem_9_Name:SetText(AL["Misc. Rewards"]);
	AtlasLootMenuItem_9_Extra:SetText(ORANGE..AL["Alterac Valley"]);
	AtlasLootMenuItem_9_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Necklace_21");
	AtlasLootMenuItem_9.lootpage="AVMisc";
	AtlasLootMenuItem_9:Show();
	--AV Superior
	AtlasLootMenuItem_10_Name:SetText(AL["Superior Rewards"]);
	AtlasLootMenuItem_10_Extra:SetText(ORANGE..AL["Alterac Valley"]);
	AtlasLootMenuItem_10_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Necklace_21");
	AtlasLootMenuItem_10.lootpage="AVBlue";
	AtlasLootMenuItem_10:Show();
	--AV Epic
	AtlasLootMenuItem_11_Name:SetText(AL["Epic Rewards"]);
	AtlasLootMenuItem_11_Extra:SetText(ORANGE..AL["Alterac Valley"]);
	AtlasLootMenuItem_11_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Necklace_21");
	AtlasLootMenuItem_11.lootpage="AVPurple";
	AtlasLootMenuItem_11:Show();
	--Hellfire
	AtlasLootMenuItem_13_Name:SetText(AL["Hellfire Fortifications"]);
	AtlasLootMenuItem_13_Extra:SetText(ORANGE..AL["Hellfire Peninsula"]);
	AtlasLootMenuItem_13_Icon:SetTexture("Interface\\Icons\\INV_Misc_Token_HonorHold");
	AtlasLootMenuItem_13.lootpage="Hellfire";
	AtlasLootMenuItem_13:Show();
	--AB Level 40-49
	AtlasLootMenuItem_18_Name:SetText(AL["Level 40-49 Rewards"]);
	AtlasLootMenuItem_18_Extra:SetText(ORANGE..AL["Arathi Basin"]);
	AtlasLootMenuItem_18_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Amulet_07");
	AtlasLootMenuItem_18.lootpage="AB40491";
	AtlasLootMenuItem_18:Show();
	--AB Level 20-29
	AtlasLootMenuItem_19_Name:SetText(AL["Level 20-29 Rewards"]);
	AtlasLootMenuItem_19_Extra:SetText(ORANGE..AL["Arathi Basin"]);
	AtlasLootMenuItem_19_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_Amulet_07");
	AtlasLootMenuItem_19.lootpage="AB20291";
	AtlasLootMenuItem_19:Show();
	--WSG Level 40-49
	AtlasLootMenuItem_21_Name:SetText(AL["Level 40-49 Rewards"]);
	AtlasLootMenuItem_21_Extra:SetText(ORANGE..AL["Warsong Gulch"]);
	AtlasLootMenuItem_21_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_21.lootpage="WSG4049";
	AtlasLootMenuItem_21:Show();
	--WSG Level 20-29
	AtlasLootMenuItem_22_Name:SetText(AL["Level 20-29 Rewards"]);
	AtlasLootMenuItem_22_Extra:SetText(ORANGE..AL["Warsong Gulch"]);
	AtlasLootMenuItem_22_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_07");
	AtlasLootMenuItem_22.lootpage="WSG2029";
	AtlasLootMenuItem_22:Show();
	--Zangarmarsh
	AtlasLootMenuItem_26_Name:SetText(AL["Twin Spire Ruins"]);
	AtlasLootMenuItem_26_Extra:SetText(ORANGE..AL["Zangarmarsh"]);
	AtlasLootMenuItem_26_Icon:SetTexture("Interface\\Icons\\Spell_Nature_ElementalPrecision_1");
	AtlasLootMenuItem_26.lootpage="Zangarmarsh";
	AtlasLootMenuItem_26:Show();
	--Terokkar
	AtlasLootMenuItem_27_Name:SetText(AL["Spirit Towers"]);
	AtlasLootMenuItem_27_Extra:SetText(ORANGE..AL["Terokkar Forest"]);
	AtlasLootMenuItem_27_Icon:SetTexture("Interface\\Icons\\INV_Jewelry_FrostwolfTrinket_04");
	AtlasLootMenuItem_27.lootpage="Terokkar";
	AtlasLootMenuItem_27:Show();
	--Nagrand
	AtlasLootMenuItem_28_Name:SetText(AL["Halaa"]);
	AtlasLootMenuItem_28_Extra:SetText(ORANGE..AL["Nagrand"]);
	AtlasLootMenuItem_28_Icon:SetTexture("Interface\\Icons\\INV_Misc_Rune_09");
	AtlasLootMenuItem_28.lootpage="Nagrand1";
	AtlasLootMenuItem_28:Show();
end
