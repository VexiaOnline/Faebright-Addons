local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");
local _G = getfenv(0)

local ORANGE = "|cffFF8400";

-- Crafting menu, rebuilt for the WotLK profession set (no Gardening/Survival/Poisons;
-- Inscription added). Profession data sourced from the official AtlasLoot WotLK crafting module.
function AtlasLoot_CraftingMenu()
	AtlasLoot_PrepMenu(nil, AL["Crafting"])
	AtlasLootCharDB.LastBoss = "CRAFTINGMENU"
	AtlasLootCharDB.LastBossText = AL["Crafting"]
	local list = {
		{ "Alchemy", "ALCHEMYMENU", "Trade_Alchemy" },
		{ "Blacksmithing", "SMITHINGMENU", "Trade_BlackSmithing" },
		{ "Cooking", "COOKINGMENU", "INV_Misc_Food_15" },
		{ "Enchanting", "ENCHANTINGMENU", "Trade_Engraving" },
		{ "Engineering", "ENGINEERINGMENU", "Trade_Engineering" },
		{ "First Aid", "FirstAid1", "Spell_Holy_SealOfSacrifice" },
		{ "Inscription", "INSCRIPTIONMENU", "INV_Inscription_Tradeskill01" },
		{ "Jewelcrafting", "JEWELCRAFTMENU", "INV_Misc_Gem_01" },
		{ "Leatherworking", "LEATHERWORKINGMENU", "INV_Misc_ArmorKit_17" },
		{ "Mining", "Mining1", "Trade_Mining" },
		{ "Tailoring", "TAILORINGMENU", "Trade_Tailoring" },
		{ "Crafted Epic Weapons", "CraftedWeapons1", "INV_Hammer_Unique_Sulfuras" },
		{ "Crafted Sets", "CRAFTSET", "INV_Chest_Chain_03" },
	}
	for i = 1, table.getn(list) do
		_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(list[i][1])
		_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText("")
		_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture("Interface\\Icons\\"..list[i][3])
		_G["AtlasLootMenuItem_"..i].lootpage = list[i][2]
		_G["AtlasLootMenuItem_"..i]:Show()
	end
end

function AtlasLoot_AlchemyMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Alchemy"])
	AtlasLootCharDB.LastBoss = "ALCHEMYMENU"
	AtlasLootCharDB.LastBossText = AL["Alchemy"]
	_G["AtlasLootMenuItem_1".."_Name"]:SetText("Battle Elixir")
	_G["AtlasLootMenuItem_1".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_1".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Alchemy")
	_G["AtlasLootMenuItem_1"].lootpage = "AlchemyBattleElixir1"
	_G["AtlasLootMenuItem_1"]:Show()
	_G["AtlasLootMenuItem_2".."_Name"]:SetText("Flask")
	_G["AtlasLootMenuItem_2".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_2".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Alchemy")
	_G["AtlasLootMenuItem_2"].lootpage = "AlchemyFlask1"
	_G["AtlasLootMenuItem_2"]:Show()
	_G["AtlasLootMenuItem_3".."_Name"]:SetText("Guardian Elixir")
	_G["AtlasLootMenuItem_3".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_3".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Alchemy")
	_G["AtlasLootMenuItem_3"].lootpage = "AlchemyGuardianElixir1"
	_G["AtlasLootMenuItem_3"]:Show()
	_G["AtlasLootMenuItem_4".."_Name"]:SetText("Misc")
	_G["AtlasLootMenuItem_4".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_4".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Alchemy")
	_G["AtlasLootMenuItem_4"].lootpage = "AlchemyMisc1"
	_G["AtlasLootMenuItem_4"]:Show()
	_G["AtlasLootMenuItem_5".."_Name"]:SetText("Potion")
	_G["AtlasLootMenuItem_5".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_5".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Alchemy")
	_G["AtlasLootMenuItem_5"].lootpage = "AlchemyPotion1"
	_G["AtlasLootMenuItem_5"]:Show()
	_G["AtlasLootMenuItem_6".."_Name"]:SetText("Transmute")
	_G["AtlasLootMenuItem_6".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_6".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Alchemy")
	_G["AtlasLootMenuItem_6"].lootpage = "AlchemyTransmute1"
	_G["AtlasLootMenuItem_6"]:Show()
end

function AtlasLoot_SmithingMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Blacksmithing"])
	AtlasLootCharDB.LastBoss = "SMITHINGMENU"
	AtlasLootCharDB.LastBossText = AL["Blacksmithing"]
	_G["AtlasLootMenuItem_1".."_Name"]:SetText("Armor BC")
	_G["AtlasLootMenuItem_1".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_1".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_1"].lootpage = "SmithingArmorBC1"
	_G["AtlasLootMenuItem_1"]:Show()
	_G["AtlasLootMenuItem_2".."_Name"]:SetText("Armor Old")
	_G["AtlasLootMenuItem_2".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_2".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_2"].lootpage = "SmithingArmorOld1"
	_G["AtlasLootMenuItem_2"]:Show()
	_G["AtlasLootMenuItem_3".."_Name"]:SetText("Armor Wrath")
	_G["AtlasLootMenuItem_3".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_3".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_3"].lootpage = "SmithingArmorWrath1"
	_G["AtlasLootMenuItem_3"]:Show()
	_G["AtlasLootMenuItem_4".."_Name"]:SetText("Enhancement")
	_G["AtlasLootMenuItem_4".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_4".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_4"].lootpage = "SmithingEnhancement1"
	_G["AtlasLootMenuItem_4"]:Show()
	_G["AtlasLootMenuItem_5".."_Name"]:SetText("Misc")
	_G["AtlasLootMenuItem_5".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_5".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_5"].lootpage = "SmithingMisc1"
	_G["AtlasLootMenuItem_5"]:Show()
	_G["AtlasLootMenuItem_6".."_Name"]:SetText("Weapon BC")
	_G["AtlasLootMenuItem_6".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_6".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_6"].lootpage = "SmithingWeaponBC1"
	_G["AtlasLootMenuItem_6"]:Show()
	_G["AtlasLootMenuItem_7".."_Name"]:SetText("Weapon Old")
	_G["AtlasLootMenuItem_7".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_7".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_7"].lootpage = "SmithingWeaponOld1"
	_G["AtlasLootMenuItem_7"]:Show()
	_G["AtlasLootMenuItem_8".."_Name"]:SetText("Weapon Wrath")
	_G["AtlasLootMenuItem_8".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_8".."_Icon"]:SetTexture("Interface\\Icons\\Trade_BlackSmithing")
	_G["AtlasLootMenuItem_8"].lootpage = "SmithingWeaponWrath1"
	_G["AtlasLootMenuItem_8"]:Show()
end

function AtlasLoot_CookingMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Cooking"])
	AtlasLootCharDB.LastBoss = "COOKINGMENU"
	AtlasLootCharDB.LastBossText = AL["Cooking"]
	_G["AtlasLootMenuItem_1".."_Name"]:SetText("Cooking")
	_G["AtlasLootMenuItem_1".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_1".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Food_15")
	_G["AtlasLootMenuItem_1"].lootpage = "Cooking1"
	_G["AtlasLootMenuItem_1"]:Show()
	_G["AtlasLootMenuItem_2".."_Name"]:SetText("Daily")
	_G["AtlasLootMenuItem_2".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_2".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Food_15")
	_G["AtlasLootMenuItem_2"].lootpage = "CookingDaily1"
	_G["AtlasLootMenuItem_2"]:Show()
end

function AtlasLoot_EnchantingMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Enchanting"])
	AtlasLootCharDB.LastBoss = "ENCHANTINGMENU"
	AtlasLootCharDB.LastBossText = AL["Enchanting"]
	_G["AtlasLootMenuItem_1".."_Name"]:SetText("2HWeapon")
	_G["AtlasLootMenuItem_1".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_1".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_1"].lootpage = "Enchanting2HWeapon1"
	_G["AtlasLootMenuItem_1"]:Show()
	_G["AtlasLootMenuItem_2".."_Name"]:SetText("Boots")
	_G["AtlasLootMenuItem_2".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_2".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_2"].lootpage = "EnchantingBoots1"
	_G["AtlasLootMenuItem_2"]:Show()
	_G["AtlasLootMenuItem_3".."_Name"]:SetText("Bracer")
	_G["AtlasLootMenuItem_3".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_3".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_3"].lootpage = "EnchantingBracer1"
	_G["AtlasLootMenuItem_3"]:Show()
	_G["AtlasLootMenuItem_4".."_Name"]:SetText("Chest")
	_G["AtlasLootMenuItem_4".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_4".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_4"].lootpage = "EnchantingChest1"
	_G["AtlasLootMenuItem_4"]:Show()
	_G["AtlasLootMenuItem_5".."_Name"]:SetText("Cloak")
	_G["AtlasLootMenuItem_5".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_5".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_5"].lootpage = "EnchantingCloak1"
	_G["AtlasLootMenuItem_5"]:Show()
	_G["AtlasLootMenuItem_6".."_Name"]:SetText("Gloves")
	_G["AtlasLootMenuItem_6".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_6".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_6"].lootpage = "EnchantingGloves1"
	_G["AtlasLootMenuItem_6"]:Show()
	_G["AtlasLootMenuItem_7".."_Name"]:SetText("Misc")
	_G["AtlasLootMenuItem_7".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_7".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_7"].lootpage = "EnchantingMisc1"
	_G["AtlasLootMenuItem_7"]:Show()
	_G["AtlasLootMenuItem_8".."_Name"]:SetText("Ring")
	_G["AtlasLootMenuItem_8".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_8".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_8"].lootpage = "EnchantingRing1"
	_G["AtlasLootMenuItem_8"]:Show()
	_G["AtlasLootMenuItem_9".."_Name"]:SetText("Shield")
	_G["AtlasLootMenuItem_9".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_9".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_9"].lootpage = "EnchantingShield1"
	_G["AtlasLootMenuItem_9"]:Show()
	_G["AtlasLootMenuItem_10".."_Name"]:SetText("Staff")
	_G["AtlasLootMenuItem_10".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_10".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_10"].lootpage = "EnchantingStaff1"
	_G["AtlasLootMenuItem_10"]:Show()
	_G["AtlasLootMenuItem_11".."_Name"]:SetText("Weapon")
	_G["AtlasLootMenuItem_11".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_11".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engraving")
	_G["AtlasLootMenuItem_11"].lootpage = "EnchantingWeapon1"
	_G["AtlasLootMenuItem_11"]:Show()
end

function AtlasLoot_EngineeringMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Engineering"])
	AtlasLootCharDB.LastBoss = "ENGINEERINGMENU"
	AtlasLootCharDB.LastBossText = AL["Engineering"]
	_G["AtlasLootMenuItem_1".."_Name"]:SetText("Ammo")
	_G["AtlasLootMenuItem_1".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_1".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_1"].lootpage = "EngineeringAmmo1"
	_G["AtlasLootMenuItem_1"]:Show()
	_G["AtlasLootMenuItem_2".."_Name"]:SetText("Armor")
	_G["AtlasLootMenuItem_2".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_2".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_2"].lootpage = "EngineeringArmor1"
	_G["AtlasLootMenuItem_2"]:Show()
	_G["AtlasLootMenuItem_3".."_Name"]:SetText("Explosives")
	_G["AtlasLootMenuItem_3".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_3".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_3"].lootpage = "EngineeringExplosives1"
	_G["AtlasLootMenuItem_3"]:Show()
	_G["AtlasLootMenuItem_4".."_Name"]:SetText("Item Enhancements")
	_G["AtlasLootMenuItem_4".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_4".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_4"].lootpage = "EngineeringItemEnhancements1"
	_G["AtlasLootMenuItem_4"]:Show()
	_G["AtlasLootMenuItem_5".."_Name"]:SetText("Misc")
	_G["AtlasLootMenuItem_5".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_5".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_5"].lootpage = "EngineeringMisc1"
	_G["AtlasLootMenuItem_5"]:Show()
	_G["AtlasLootMenuItem_6".."_Name"]:SetText("Reagents")
	_G["AtlasLootMenuItem_6".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_6".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_6"].lootpage = "EngineeringReagents1"
	_G["AtlasLootMenuItem_6"]:Show()
	_G["AtlasLootMenuItem_7".."_Name"]:SetText("Weapon")
	_G["AtlasLootMenuItem_7".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_7".."_Icon"]:SetTexture("Interface\\Icons\\Trade_Engineering")
	_G["AtlasLootMenuItem_7"].lootpage = "EngineeringWeapon1"
	_G["AtlasLootMenuItem_7"]:Show()
end

-- Glyph categories, in class order.  Fields: table-key prefix, locale key, class colour,
-- icon.  Death Knight has no class image in Images/ (TBC realm, not a playable class), so
-- it falls back to the client's class icon.
local INSCRIPTION_CLASSES = {
	{ "DeathKnight", "Death Knight", "|cffc41e3a", "Interface\\Icons\\Spell_Deathknight_ClassIcon" },
	{ "Druid",       "Druid",        "|cffff7c0a", "Interface\\AddOns\\AtlasLoot\\Images\\druid" },
	{ "Hunter",      "Hunter",       "|cffaad372", "Interface\\AddOns\\AtlasLoot\\Images\\hunter" },
	{ "Mage",        "Mage",         "|cff68ccef", "Interface\\AddOns\\AtlasLoot\\Images\\mage" },
	{ "Paladin",     "Paladin",      "|cfff48cba", "Interface\\AddOns\\AtlasLoot\\Images\\paladin" },
	{ "Priest",      "Priest",       "|cffffffff", "Interface\\AddOns\\AtlasLoot\\Images\\priest" },
	{ "Rogue",       "Rogue",        "|cfffff468", "Interface\\AddOns\\AtlasLoot\\Images\\rogue" },
	{ "Shaman",      "Shaman",       "|cff2773ff", "Interface\\AddOns\\AtlasLoot\\Images\\shaman" },
	{ "Warlock",     "Warlock",      "|cff9382c9", "Interface\\AddOns\\AtlasLoot\\Images\\warlock" },
	{ "Warrior",     "Warrior",      "|cffc69b6d", "Interface\\AddOns\\AtlasLoot\\Images\\warrior" },
}

function AtlasLoot_InscriptionMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Inscription"])
	AtlasLootCharDB.LastBoss = "INSCRIPTIONMENU"
	AtlasLootCharDB.LastBossText = AL["Inscription"]
	-- Major glyphs down the left column, minor glyphs down the right, one row per class
	for i = 1, table.getn(INSCRIPTION_CLASSES) do
		local class = INSCRIPTION_CLASSES[i]
		local label = class[3] .. AL[class[2]]
		local major, minor = i, 15 + i
		_G["AtlasLootMenuItem_"..major.."_Name"]:SetText(label)
		_G["AtlasLootMenuItem_"..major.."_Extra"]:SetText(ORANGE .. AL["Major Glyph"])
		_G["AtlasLootMenuItem_"..major.."_Icon"]:SetTexture(class[4])
		_G["AtlasLootMenuItem_"..major].lootpage = "Inscription_"..class[1].."Major1"
		_G["AtlasLootMenuItem_"..major]:Show()
		_G["AtlasLootMenuItem_"..minor.."_Name"]:SetText(label)
		_G["AtlasLootMenuItem_"..minor.."_Extra"]:SetText(ORANGE .. AL["Minor Glyph"])
		_G["AtlasLootMenuItem_"..minor.."_Icon"]:SetTexture(class[4])
		_G["AtlasLootMenuItem_"..minor].lootpage = "Inscription_"..class[1].."Minor1"
		_G["AtlasLootMenuItem_"..minor]:Show()
	end
	-- Non-class categories fill the bottom of the left column, below a blank row
	local extras = {
		{ AL["Scrolls"],       "Inscription_Scrolls1" },
		{ AL["Off Hand"],      "Inscription_OffHand1" },
		{ AL["Reagents"],      "Inscription_Reagents1" },
		{ AL["Miscellaneous"], "Inscription_Misc1" },
	}
	for i = 1, table.getn(extras) do
		local slot = 11 + i
		_G["AtlasLootMenuItem_"..slot.."_Name"]:SetText(extras[i][1])
		_G["AtlasLootMenuItem_"..slot.."_Extra"]:SetText("")
		_G["AtlasLootMenuItem_"..slot.."_Icon"]:SetTexture("Interface\\Icons\\INV_Inscription_Tradeskill01")
		_G["AtlasLootMenuItem_"..slot].lootpage = extras[i][2]
		_G["AtlasLootMenuItem_"..slot]:Show()
	end
end

function AtlasLoot_JewelcraftingMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Jewelcrafting"])
	AtlasLootCharDB.LastBoss = "JEWELCRAFTMENU"
	AtlasLootCharDB.LastBossText = AL["Jewelcrafting"]
	_G["AtlasLootMenuItem_1".."_Name"]:SetText("Blue")
	_G["AtlasLootMenuItem_1".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_1".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_1"].lootpage = "JewelBlue1"
	_G["AtlasLootMenuItem_1"]:Show()
	_G["AtlasLootMenuItem_2".."_Name"]:SetText("Dragons Eye")
	_G["AtlasLootMenuItem_2".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_2".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_2"].lootpage = "JewelDragonsEye1"
	_G["AtlasLootMenuItem_2"]:Show()
	_G["AtlasLootMenuItem_3".."_Name"]:SetText("Green")
	_G["AtlasLootMenuItem_3".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_3".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_3"].lootpage = "JewelGreen1"
	_G["AtlasLootMenuItem_3"]:Show()
	_G["AtlasLootMenuItem_4".."_Name"]:SetText("Meta")
	_G["AtlasLootMenuItem_4".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_4".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_4"].lootpage = "JewelMeta1"
	_G["AtlasLootMenuItem_4"]:Show()
	_G["AtlasLootMenuItem_5".."_Name"]:SetText("Misc")
	_G["AtlasLootMenuItem_5".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_5".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_5"].lootpage = "JewelMisc1"
	_G["AtlasLootMenuItem_5"]:Show()
	_G["AtlasLootMenuItem_6".."_Name"]:SetText("Neck")
	_G["AtlasLootMenuItem_6".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_6".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_6"].lootpage = "JewelNeck1"
	_G["AtlasLootMenuItem_6"]:Show()
	_G["AtlasLootMenuItem_7".."_Name"]:SetText("Orange")
	_G["AtlasLootMenuItem_7".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_7".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_7"].lootpage = "JewelOrange1"
	_G["AtlasLootMenuItem_7"]:Show()
	_G["AtlasLootMenuItem_8".."_Name"]:SetText("Prismatic")
	_G["AtlasLootMenuItem_8".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_8".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_8"].lootpage = "JewelPrismatic1"
	_G["AtlasLootMenuItem_8"]:Show()
	_G["AtlasLootMenuItem_9".."_Name"]:SetText("Purple")
	_G["AtlasLootMenuItem_9".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_9".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_9"].lootpage = "JewelPurple1"
	_G["AtlasLootMenuItem_9"]:Show()
	_G["AtlasLootMenuItem_10".."_Name"]:SetText("Red")
	_G["AtlasLootMenuItem_10".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_10".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_10"].lootpage = "JewelRed1"
	_G["AtlasLootMenuItem_10"]:Show()
	_G["AtlasLootMenuItem_11".."_Name"]:SetText("Ring")
	_G["AtlasLootMenuItem_11".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_11".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_11"].lootpage = "JewelRing1"
	_G["AtlasLootMenuItem_11"]:Show()
	_G["AtlasLootMenuItem_12".."_Name"]:SetText("Trinket")
	_G["AtlasLootMenuItem_12".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_12".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_12"].lootpage = "JewelTrinket1"
	_G["AtlasLootMenuItem_12"]:Show()
	_G["AtlasLootMenuItem_13".."_Name"]:SetText("Yellow")
	_G["AtlasLootMenuItem_13".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_13".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_13"].lootpage = "JewelYellow1"
	_G["AtlasLootMenuItem_13"]:Show()
	_G["AtlasLootMenuItem_14".."_Name"]:SetText("crafting Daily")
	_G["AtlasLootMenuItem_14".."_Extra"]:SetText("")
	_G["AtlasLootMenuItem_14".."_Icon"]:SetTexture("Interface\\Icons\\INV_Misc_Gem_01")
	_G["AtlasLootMenuItem_14"].lootpage = "JewelcraftingDaily1"
	_G["AtlasLootMenuItem_14"]:Show()
end

-- Crafted armour sets, grouped by armour type rather than by profession -- a player looks
-- for "a leather set", not "a Leatherworking set".  These used to be dumped into the
-- profession menus, which pushed Leatherworking past the 30-button cap and hid ~10
-- categories entirely; the wotlk module lists categories only, and so do we now.
--
-- Display names are NOT stored here.  Every set table's header row is
-- `{ 0, icon, "=q6=#craftXX#", ... }` and that token already resolves to the set's proper
-- localised name via TextParsing, so we read it back at runtime -- nothing to keep in sync.
local CRAFTED_SET_GROUPS = {
	CLOTH = {
		icon = "Interface/Icons/Trade_Tailoring",
		"TailoringArcanoVest",
		"TailoringBattlecastG",
		"TailoringBloodvineG",
		"TailoringDuskweaver",
		"TailoringFrostsavageBattlegear",
		"TailoringFrostwovenPower",
		"TailoringImbuedNeather",
		"TailoringNeatherVest",
		"TailoringPrimalMoon",
		"TailoringShadowEmbrace",
		"TailoringSoulclothEm",
		"TailoringSpellfireWrath",
		"TailoringSpellstrikeInfu",
		"TailoringTheUnyielding",
		"TailoringWhitemendWis",
	},
	LEATHER = {
		icon = "Interface/Icons/INV_Misc_ArmorKit_17",
		"LeatherworkingLeatherBloodTigerH",
		"LeatherworkingLeatherBoreanEmbrace",
		"LeatherworkingLeatherDevilsaurArmor",
		"LeatherworkingLeatherEvisceratorBattlegear",
		"LeatherworkingLeatherFelSkin",
		"LeatherworkingLeatherIceborneEmbrace",
		"LeatherworkingLeatherIronfeatherArmor",
		"LeatherworkingLeatherOvercasterBattlegear",
		"LeatherworkingLeatherPrimalBatskin",
		"LeatherworkingLeatherPrimalIntent",
		"LeatherworkingLeatherSClefthoof",
		"LeatherworkingLeatherStormshroudArmor",
		"LeatherworkingLeatherThickDraenicA",
		"LeatherworkingLeatherVolcanicArmor",
		"LeatherworkingLeatherWildDraenishA",
		"LeatherworkingLeatherWindhawkArmor",
	},
	MAIL = {
		icon = "Interface/Icons/INV_Misc_ArmorKit_17",
		"LeatherworkingMailBlackDragonM",
		"LeatherworkingMailBlueDragonM",
		"LeatherworkingMailFelscaleArmor",
		"LeatherworkingMailFelstalkerArmor",
		"LeatherworkingMailFrostscaleBinding",
		"LeatherworkingMailGreenDragonM",
		"LeatherworkingMailNerubianHive",
		"LeatherworkingMailNetherFury",
		"LeatherworkingMailNetherscaleArmor",
		"LeatherworkingMailNetherstrikeArmor",
		"LeatherworkingMailScaledDraenicA",
		"LeatherworkingMailStormhideBattlegear",
		"LeatherworkingMailSwiftarrowBattlefear",
		"BlacksmithingMailBloodsoulEmbrace",
		"BlacksmithingMailFelIronChain",
	},
	PLATE = {
		icon = "Interface/Icons/Trade_BlackSmithing",
		"BlacksmithingPlateAdamantiteB",
		"BlacksmithingPlateBurningRage",
		"BlacksmithingPlateEnchantedAdaman",
		"BlacksmithingPlateFaithFelsteel",
		"BlacksmithingPlateFelIronPlate",
		"BlacksmithingPlateFlameG",
		"BlacksmithingPlateImperialPlate",
		"BlacksmithingPlateKhoriumWard",
		"BlacksmithingPlateOrnateSaroniteBattlegear",
		"BlacksmithingPlateSavageSaroniteBattlegear",
		"BlacksmithingPlateTheDarksoul",
	},
}

-- Reads a crafted set's display name out of its own data table's header row.
local function AtlasLoot_CraftedSetLabel(dataID)
	local source = AtlasLoot_Data and AtlasLoot_Data["AtlasLootCrafting"]
	local tbl = source and source[dataID]
	if ( tbl and tbl[1] and type(tbl[1][3]) == "string" and tbl[1][3] ~= "" ) then
		local label = gsub(tbl[1][3], "=q%d=", "")
		label = AtlasLoot_FixText(label)
		if ( label and label ~= "" ) then
			return label
		end
	end
	return dataID
end

-- Shared renderer for the four crafted-set pages.  Splits the list across the two columns
-- (buttons 1-15 left, 16-30 right) instead of filling the left column first.
local function AtlasLoot_RenderCraftedSets(title, group)
	AtlasLoot_PrepMenu("CRAFTSET", title)
	local count = table.getn(group)
	local half = math.ceil(count / 2)
	for i = 1, count do
		local slot = i
		if ( i > half ) then
			slot = 15 + (i - half)
		end
		if ( slot <= 30 ) then
			_G["AtlasLootMenuItem_"..slot.."_Name"]:SetText(AtlasLoot_CraftedSetLabel(group[i]))
			_G["AtlasLootMenuItem_"..slot.."_Extra"]:SetText("")
			_G["AtlasLootMenuItem_"..slot.."_Icon"]:SetTexture(group.icon)
			_G["AtlasLootMenuItem_"..slot].lootpage = group[i]
			_G["AtlasLootMenuItem_"..slot]:Show()
		end
	end
end

function AtlasLoot_LeatherworkingMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Leatherworking"])
	AtlasLootCharDB.LastBoss = "LEATHERWORKINGMENU"
	AtlasLootCharDB.LastBossText = AL["Leatherworking"]
	local LW = "Interface/Icons/INV_Misc_ArmorKit_17"
	local list = {
		{ 2,  AL["Leather"].." "..AL["Armor"], ORANGE..AL["Classic"],                "LeatherLeatherArmorOld1" },
		{ 3,  AL["Leather"].." "..AL["Armor"], ORANGE..AL["Burning Crusade"],        "LeatherLeatherArmorBC1" },
		{ 4,  AL["Leather"].." "..AL["Armor"], ORANGE..AL["Wrath of the Lich King"], "LeatherLeatherArmorWrath1" },
		{ 6,  AL["Cloaks"],                    "",                                   "LeatherCloaks1" },
		{ 7,  AL["Quivers and Ammo Pouches"],  "",                                   "LeatherQuiversPouches1" },
		{ 8,  AL["Leather"],                   "",                                   "LeatherLeather1" },
		{ 10, (GetSpellInfo(10656)),           "",                                   "Dragonscale1" },
		{ 11, (GetSpellInfo(10660)),           "",                                   "Tribal1" },
		{ 12, (GetSpellInfo(10658)),           "",                                   "Elemental1" },
		{ 17, AL["Mail"].." "..AL["Armor"],    ORANGE..AL["Classic"],                "LeatherMailArmorOld1" },
		{ 18, AL["Mail"].." "..AL["Armor"],    ORANGE..AL["Burning Crusade"],        "LeatherMailArmorBC1" },
		{ 19, AL["Mail"].." "..AL["Armor"],    ORANGE..AL["Wrath of the Lich King"], "LeatherMailArmorWrath1" },
		{ 21, AL["Item Enhancements"],         "",                                   "LeatherItemEnhancement1" },
		{ 22, AL["Drums, Bags and Misc."],     "",                                   "LeatherDrumsBagsMisc1" },
	}
	for i = 1, table.getn(list) do
		local slot = list[i][1]
		_G["AtlasLootMenuItem_"..slot.."_Name"]:SetText(list[i][2] or "")
		_G["AtlasLootMenuItem_"..slot.."_Extra"]:SetText(list[i][3])
		_G["AtlasLootMenuItem_"..slot.."_Icon"]:SetTexture(LW)
		_G["AtlasLootMenuItem_"..slot].lootpage = list[i][4]
		_G["AtlasLootMenuItem_"..slot]:Show()
	end
end

function AtlasLoot_TailoringMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Tailoring"])
	AtlasLootCharDB.LastBoss = "TAILORINGMENU"
	AtlasLootCharDB.LastBossText = AL["Tailoring"]
	local TL = "Interface/Icons/Trade_Tailoring"
	local list = {
		{ 2,  AL["Cloth"].." "..AL["Armor"], ORANGE..AL["Classic"],                "TailoringArmorOld1" },
		{ 3,  AL["Cloth"].." "..AL["Armor"], ORANGE..AL["Burning Crusade"],        "TailoringArmorBC1" },
		{ 4,  AL["Cloth"].." "..AL["Armor"], ORANGE..AL["Wrath of the Lich King"], "TailoringArmorWotLK1" },
		{ 6,  (GetSpellInfo(26798)),         "",                                   "Mooncloth1" },
		{ 7,  (GetSpellInfo(26801)),         "",                                   "Shadoweave1" },
		{ 8,  (GetSpellInfo(26797)),         "",                                   "Spellfire1" },
		{ 17, AL["Bags"],                    "",                                   "TailoringBags1" },
		{ 18, AL["Shirts"],                  "",                                   "TailoringShirts1" },
		{ 19, AL["Miscellaneous"],           "",                                   "TailoringMisc1" },
	}
	for i = 1, table.getn(list) do
		local slot = list[i][1]
		_G["AtlasLootMenuItem_"..slot.."_Name"]:SetText(list[i][2] or "")
		_G["AtlasLootMenuItem_"..slot.."_Extra"]:SetText(list[i][3])
		_G["AtlasLootMenuItem_"..slot.."_Icon"]:SetTexture(TL)
		_G["AtlasLootMenuItem_"..slot].lootpage = list[i][4]
		_G["AtlasLootMenuItem_"..slot]:Show()
	end
end

function AtlasLootCraftedSetMenu()
	AtlasLoot_PrepMenu("CRAFTINGMENU", AL["Crafted Sets"])
	AtlasLootCharDB.LastBoss = "CRAFTSET"
	AtlasLootCharDB.LastBossText = AL["Crafted Sets"]
	local list = {
		{ 2,  AL["Cloth"].." "..AL["Sets"],   "Interface/Icons/Trade_Tailoring",         "CRAFTSETCLOTH" },
		{ 3,  AL["Leather"].." "..AL["Sets"], "Interface/Icons/INV_Misc_ArmorKit_17",    "CRAFTSETLEATHER" },
		{ 17, AL["Mail"].." "..AL["Sets"],    "Interface/Icons/INV_Misc_ArmorKit_17",    "CRAFTSETMAIL" },
		{ 18, AL["Plate"].." "..AL["Sets"],   "Interface/Icons/Trade_BlackSmithing",     "CRAFTSETPLATE" },
	}
	for i = 1, table.getn(list) do
		local slot = list[i][1]
		_G["AtlasLootMenuItem_"..slot.."_Name"]:SetText(list[i][2])
		_G["AtlasLootMenuItem_"..slot.."_Extra"]:SetText("")
		_G["AtlasLootMenuItem_"..slot.."_Icon"]:SetTexture(list[i][3])
		_G["AtlasLootMenuItem_"..slot].lootpage = list[i][4]
		_G["AtlasLootMenuItem_"..slot]:Show()
	end
end

function AtlasLootCraftedClothSetMenu()
	AtlasLoot_RenderCraftedSets(AL["Cloth"].." "..AL["Sets"], CRAFTED_SET_GROUPS.CLOTH)
end

function AtlasLootCraftedLeatherSetMenu()
	AtlasLoot_RenderCraftedSets(AL["Leather"].." "..AL["Sets"], CRAFTED_SET_GROUPS.LEATHER)
end

function AtlasLootCraftedMailSetMenu()
	AtlasLoot_RenderCraftedSets(AL["Mail"].." "..AL["Sets"], CRAFTED_SET_GROUPS.MAIL)
end

function AtlasLootCraftedPlateSetMenu()
	AtlasLoot_RenderCraftedSets(AL["Plate"].." "..AL["Sets"], CRAFTED_SET_GROUPS.PLATE)
end
