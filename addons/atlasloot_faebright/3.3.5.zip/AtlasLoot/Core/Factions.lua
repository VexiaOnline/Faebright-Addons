local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");
local _G = getfenv(0)
local WHITE = "|cffFFFFFF"

-- Reputation Factions, rebuilt from the migrated reputation loot tables.
-- Page 1 = Outland (BC) factions, Page 2 = Azeroth + PvP factions.
-- Entry format: { displayName, lootpage(dataID), icon, regionLabel }

local Page1 = {
	{ "The Aldor", "Aldor1", "Spell_Holy_ChampionsBond", "Outland" },
	{ "The Scryers", "Scryer1", "Spell_Arcane_Arcane03", "Outland" },
	{ "The Sha'tar", "Shatar1", "Spell_Holy_AuraOfLight", "Outland" },
	{ "Sha'tar (Flasks)", "ShattrathFlasks1", "INV_Potion_97", "Outland" },
	{ "Lower City", "LowerCity1", "INV_Misc_Coin_01", "Outland" },
	{ "Cenarion Expedition", "CExpedition1", "Spell_Nature_HealingTouch", "Outland" },
	{ "Honor Hold", "HonorHold1", "INV_BannerPVP_02", "Outland" },
	{ "Thrallmar", "Thrallmar1", "INV_BannerPVP_01", "Outland" },
	{ "Keepers of Time", "KeepersofTime1", "INV_Misc_PocketWatch_01", "Outland" },
	{ "The Consortium", "Consortium1", "INV_Misc_Gem_Variety_01", "Outland" },
	{ "The Mag'har", "Maghar1", "INV_Misc_Head_Orc_01", "Outland" },
	{ "Kurenai", "Kurenai1", "INV_Misc_Head_Draenei_01", "Outland" },
	{ "Netherwing", "Netherwing1", "INV_Misc_Head_Dragon_Black", "Outland" },
	{ "Ogri'la", "Ogrila1", "INV_Misc_Gem_Crystal_02", "Outland" },
	{ "Sha'tari Skyguard", "Skyguard1", "Ability_Hunter_EagleEye", "Outland" },
	{ "Sporeggar", "Sporeggar1", "INV_Mushroom_11", "Outland" },
	{ "The Scale of the Sands", "ScaleSands1", "INV_Misc_Head_Dragon_Bronze", "Outland" },
	{ "Ashtongue Deathsworn", "Ashtongue1", "Spell_Shadow_ShadowWordPain", "Outland" },
	{ "The Violet Eye", "VioletEye1", "INV_Jewelry_Ring_55", "Outland" },
	{ "Shattered Sun Offensive", "SunOffensive1", "Spell_Holy_SealOfVengeance", "Outland" },
	{ "Tranquillien", "Tranquillien1", "Spell_Holy_HolyProtection", "Outland" },
}

local Page2 = {
	{ "Argent Dawn", "Argent1", "INV_Jewelry_Talisman_08", "Azeroth" },
	{ "Brood of Nozdormu", "AQBroodRings", "INV_Jewelry_Ring_40", "Azeroth" },
	{ "Cenarion Circle", "Cenarion1", "Spell_Nature_HealingTouch", "Azeroth" },
	{ "Thorium Brotherhood", "Thorium1", "INV_Ingot_Mithril", "Azeroth" },
	{ "Hydraxian Waterlords", "WaterLords1", "Spell_Frost_SummonWaterElemental_2", "Azeroth" },
	{ "Timbermaw Hold", "Timbermaw", "INV_Misc_Horn_01", "Azeroth" },
	{ "Zandalar Tribe", "Zandalar1", "INV_Misc_Coin_08", "Azeroth" },
	{ "Darkmoon Faire", "Darkmoon1", "INV_Misc_Ticket_Tarot_Maelstrom_01", "Azeroth" },
	{ "Gelkis Clan Centaur", "GelkisClan1", "INV_Misc_Head_Centaur_01", "Azeroth" },
	{ "Magram Clan Centaur", "MagramClan1", "INV_Misc_Head_Centaur_01", "Azeroth" },
	{ "Wintersaber Trainers", "Wintersaber1", "Ability_Mount_PinkTiger", "Azeroth" },
	{ "Bloodsail Buccaneers", "Bloodsail1", "INV_Helmet_66", "Azeroth" },
	{ "The Defilers", "Defilers", "INV_BannerPVP_02", "PvP" },
	{ "Frostwolf Clan", "Frostwolf1", "INV_BannerPVP_01", "PvP" },
	{ "The League of Arathor", "LeagueofArathor", "INV_BannerPVP_02", "PvP" },
	{ "Stormpike Guard", "Stormpike1", "INV_BannerPVP_01", "PvP" },
}

local function AtlasLoot_RenderRepPage(list)
	for i = 1, table.getn(list) do
		_G["AtlasLootMenuItem_"..i.."_Name"]:SetText(list[i][1])
		_G["AtlasLootMenuItem_"..i.."_Extra"]:SetText(WHITE..(list[i][4] or ""))
		_G["AtlasLootMenuItem_"..i.."_Icon"]:SetTexture("Interface\\Icons\\"..list[i][3])
		_G["AtlasLootMenuItem_"..i].lootpage = list[i][2]
		_G["AtlasLootMenuItem_"..i]:Show()
	end
end

function AtlasLootRepMenu()
	AtlasLoot_PrepMenu(nil, AL["Factions"])
	AtlasLootCharDB.LastBoss = "REPMENU"
	AtlasLootCharDB.LastBossText = AL["Factions"]
	AtlasLootItemsFrame_NEXT:Show()
	AtlasLoot_RenderRepPage(Page1)
end

function AtlasLootRepMenu2()
	AtlasLoot_PrepMenu(nil, AL["Factions"])
	AtlasLootCharDB.LastBoss = "REPMENU2"
	AtlasLootCharDB.LastBossText = AL["Factions"]
	AtlasLootItemsFrame_PREV:Show()
	AtlasLoot_RenderRepPage(Page2)
end
