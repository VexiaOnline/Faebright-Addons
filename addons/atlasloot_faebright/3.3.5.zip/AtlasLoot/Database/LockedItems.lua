-- Auto-generated (scratchpad/gen_lockedfile.php), then hand-corrected -- see INSCRIPTION note.
-- Crafted items / recipes classed as "locked" for this TBC realm: profession skill 390+
-- (from the #sr# annotation) or WotLK-only crafted items absent from the TBC crafting
-- baseline (_backup_TBC/AtlasLoot_Crafting).  AtlasLoot_IsRowLocked() consults these so
-- high-skill consumables (e.g. Flask of the North) are caught even with no level-to-use gate.
--
-- INSCRIPTION: the "absent from the TBC baseline" rule is meaningless for Inscription,
-- because the profession did not exist in TBC at all -- so the generator swept in all of
-- it (387 items + 12 spells, ~99% of the profession's rows) even though the realm has
-- Inscription enabled.  Inscription carries no #sr# annotations either, so the skill-390
-- rule contributed nothing there and every entry came from the invalid rule.  All
-- Inscription entries have been removed; genuine gating now comes from the level-71+
-- fallback in AtlasLoot_IsRowLocked().
--
-- IF YOU REGENERATE THIS FILE: exclude the Inscription_* tables from the baseline diff,
-- or this bug comes straight back.  Note a few Inscription recipes really are above 390
-- skill (Master's Inscription of the Axe/Crag/Pinnacle/Storm at 405, Greater Darkmoon
-- Card at 400, Darkmoon Card of the North at 425); the addon has no skill data for them,
-- so they are currently visible.  Re-add by hand if the realm caps Inscription below that.
-- items=985  spells=102

AtlasLoot_LockedItems = {
	[23775]=true,[34722]=true,[35349]=true,[35350]=true,[35622]=true,[35623]=true,[35624]=true,[35625]=true,[35627]=true,[36766]=true,[36767]=true,[36784]=true,
	[36860]=true,[36913]=true,[36916]=true,[36919]=true,[36922]=true,[36925]=true,[36928]=true,[36931]=true,[36934]=true,[37503]=true,[37567]=true,[37663]=true,
	[38225]=true,[38277]=true,[38278]=true,[38347]=true,[38371]=true,[38372]=true,[38373]=true,[38374]=true,[38375]=true,[38376]=true,[38399]=true,[38400]=true,
	[38401]=true,[38402]=true,[38403]=true,[38404]=true,[38405]=true,[38406]=true,[38407]=true,[38408]=true,[38409]=true,[38410]=true,[38411]=true,[38412]=true,
	[38413]=true,[38414]=true,[38415]=true,[38416]=true,[38417]=true,[38418]=true,[38419]=true,[38420]=true,[38421]=true,[38422]=true,[38424]=true,[38425]=true,
	[38433]=true,[38434]=true,[38435]=true,[38436]=true,[38437]=true,[38438]=true,[38439]=true,[38440]=true,[38441]=true,[38590]=true,[38591]=true,[38592]=true,
	[39083]=true,[39084]=true,[39085]=true,[39086]=true,[39087]=true,[39088]=true,[39520]=true,[39666]=true,[39671]=true,[39681]=true,[39682]=true,[39683]=true,
	[39688]=true,[39690]=true,[39900]=true,[39905]=true,[39906]=true,[39907]=true,[39908]=true,[39909]=true,[39910]=true,[39911]=true,[39912]=true,[39914]=true,
	[39915]=true,[39916]=true,[39917]=true,[39918]=true,[39919]=true,[39920]=true,[39927]=true,[39932]=true,[39933]=true,[39934]=true,[39935]=true,[39936]=true,
	[39937]=true,[39938]=true,[39939]=true,[39940]=true,[39941]=true,[39942]=true,[39943]=true,[39944]=true,[39945]=true,[39946]=true,[39947]=true,[39948]=true,
	[39949]=true,[39950]=true,[39951]=true,[39952]=true,[39953]=true,[39954]=true,[39955]=true,[39956]=true,[39957]=true,[39958]=true,[39959]=true,[39960]=true,
	[39961]=true,[39962]=true,[39963]=true,[39964]=true,[39965]=true,[39966]=true,[39967]=true,[39968]=true,[39974]=true,[39975]=true,[39976]=true,[39977]=true,
	[39978]=true,[39979]=true,[39980]=true,[39981]=true,[39982]=true,[39983]=true,[39984]=true,[39985]=true,[39986]=true,[39988]=true,[39989]=true,[39990]=true,
	[39991]=true,[39992]=true,[39996]=true,[39997]=true,[39998]=true,[39999]=true,[40001]=true,[40002]=true,[40003]=true,[40008]=true,[40009]=true,[40010]=true,
	[40011]=true,[40012]=true,[40013]=true,[40014]=true,[40015]=true,[40016]=true,[40017]=true,[40022]=true,[40023]=true,[40024]=true,[40025]=true,[40026]=true,
	[40027]=true,[40028]=true,[40029]=true,[40030]=true,[40031]=true,[40032]=true,[40033]=true,[40034]=true,[40037]=true,[40038]=true,[40039]=true,[40040]=true,
	[40041]=true,[40043]=true,[40044]=true,[40045]=true,[40046]=true,[40047]=true,[40048]=true,[40049]=true,[40050]=true,[40051]=true,[40052]=true,[40053]=true,
	[40054]=true,[40055]=true,[40056]=true,[40057]=true,[40058]=true,[40059]=true,[40067]=true,[40068]=true,[40070]=true,[40072]=true,[40073]=true,[40076]=true,
	[40077]=true,[40078]=true,[40079]=true,[40081]=true,[40085]=true,[40086]=true,[40087]=true,[40088]=true,[40089]=true,[40090]=true,[40091]=true,[40092]=true,
	[40093]=true,[40094]=true,[40095]=true,[40096]=true,[40097]=true,[40098]=true,[40099]=true,[40100]=true,[40101]=true,[40102]=true,[40103]=true,[40104]=true,
	[40105]=true,[40106]=true,[40109]=true,[40111]=true,[40112]=true,[40113]=true,[40114]=true,[40115]=true,[40116]=true,[40117]=true,[40118]=true,[40119]=true,
	[40120]=true,[40121]=true,[40122]=true,[40123]=true,[40124]=true,[40125]=true,[40126]=true,[40127]=true,[40128]=true,[40129]=true,[40130]=true,[40131]=true,
	[40132]=true,[40133]=true,[40134]=true,[40135]=true,[40136]=true,[40137]=true,[40138]=true,[40139]=true,[40140]=true,[40141]=true,[40142]=true,[40143]=true,
	[40144]=true,[40145]=true,[40146]=true,[40147]=true,[40148]=true,[40149]=true,[40150]=true,[40151]=true,[40152]=true,[40153]=true,[40154]=true,[40155]=true,
	[40156]=true,[40157]=true,[40158]=true,[40159]=true,[40160]=true,[40161]=true,[40162]=true,[40163]=true,[40164]=true,[40165]=true,[40166]=true,[40167]=true,
	[40168]=true,[40169]=true,[40170]=true,[40171]=true,[40172]=true,[40173]=true,[40174]=true,[40175]=true,[40176]=true,[40177]=true,[40178]=true,[40179]=true,
	[40180]=true,[40181]=true,[40182]=true,[40195]=true,[40211]=true,[40212]=true,[40213]=true,[40214]=true,[40215]=true,[40216]=true,[40217]=true,[40248]=true,
	[40536]=true,[40668]=true,[40669]=true,[40670]=true,[40671]=true,[40672]=true,[40673]=true,[40674]=true,[40675]=true,[40767]=true,[40768]=true,[40769]=true,
	[40771]=true,[40772]=true,[40865]=true,[40892]=true,[40893]=true,[40895]=true,[40942]=true,[40943]=true,[40949]=true,[40950]=true,[40951]=true,[40952]=true,
	[40953]=true,[40954]=true,[40955]=true,[40956]=true,[40957]=true,[40958]=true,[40959]=true,[41113]=true,[41114]=true,[41116]=true,[41117]=true,[41121]=true,
	[41126]=true,[41127]=true,[41128]=true,[41129]=true,[41146]=true,[41163]=true,[41164]=true,[41165]=true,[41167]=true,[41168]=true,[41181]=true,[41182]=true,
	[41183]=true,[41184]=true,[41185]=true,[41186]=true,[41187]=true,[41188]=true,[41189]=true,[41190]=true,[41238]=true,[41239]=true,[41240]=true,[41241]=true,
	[41242]=true,[41243]=true,[41245]=true,[41248]=true,[41249]=true,[41250]=true,[41251]=true,[41252]=true,[41253]=true,[41254]=true,[41255]=true,[41257]=true,
	[41266]=true,[41285]=true,[41307]=true,[41333]=true,[41334]=true,[41335]=true,[41339]=true,[41344]=true,[41345]=true,[41346]=true,[41347]=true,[41348]=true,
	[41349]=true,[41350]=true,[41351]=true,[41352]=true,[41353]=true,[41354]=true,[41355]=true,[41356]=true,[41357]=true,[41367]=true,[41375]=true,[41376]=true,
	[41377]=true,[41378]=true,[41379]=true,[41380]=true,[41381]=true,[41382]=true,[41383]=true,[41384]=true,[41385]=true,[41386]=true,[41387]=true,[41388]=true,
	[41389]=true,[41391]=true,[41392]=true,[41394]=true,[41395]=true,[41396]=true,[41397]=true,[41398]=true,[41400]=true,[41401]=true,[41508]=true,[41509]=true,
	[41510]=true,[41511]=true,[41512]=true,[41513]=true,[41515]=true,[41516]=true,[41519]=true,[41520]=true,[41521]=true,[41522]=true,[41523]=true,[41525]=true,
	[41528]=true,[41543]=true,[41544]=true,[41545]=true,[41546]=true,[41548]=true,[41549]=true,[41550]=true,[41551]=true,[41553]=true,[41554]=true,[41555]=true,
	[41576]=true,[41577]=true,[41578]=true,[41579]=true,[41580]=true,[41581]=true,[41582]=true,[41593]=true,[41594]=true,[41595]=true,[41597]=true,[41598]=true,
	[41599]=true,[41600]=true,[41601]=true,[41602]=true,[41603]=true,[41604]=true,[41607]=true,[41608]=true,[41609]=true,[41610]=true,[41611]=true,[41686]=true,
	[41687]=true,[41688]=true,[41689]=true,[41690]=true,[41692]=true,[41693]=true,[41694]=true,[41696]=true,[41697]=true,[41698]=true,[41699]=true,[41701]=true,
	[41702]=true,[41703]=true,[41704]=true,[41705]=true,[41706]=true,[41707]=true,[41708]=true,[41709]=true,[41710]=true,[41711]=true,[41745]=true,[41974]=true,
	[41975]=true,[41976]=true,[41984]=true,[41985]=true,[41986]=true,[42093]=true,[42095]=true,[42096]=true,[42100]=true,[42101]=true,[42102]=true,[42103]=true,
	[42111]=true,[42113]=true,[42138]=true,[42142]=true,[42143]=true,[42144]=true,[42145]=true,[42146]=true,[42148]=true,[42149]=true,[42150]=true,[42151]=true,
	[42152]=true,[42153]=true,[42154]=true,[42155]=true,[42156]=true,[42157]=true,[42158]=true,[42225]=true,[42298]=true,[42299]=true,[42300]=true,[42301]=true,
	[42302]=true,[42303]=true,[42304]=true,[42305]=true,[42306]=true,[42307]=true,[42308]=true,[42309]=true,[42310]=true,[42311]=true,[42312]=true,[42313]=true,
	[42314]=true,[42315]=true,[42336]=true,[42337]=true,[42338]=true,[42339]=true,[42340]=true,[42341]=true,[42395]=true,[42413]=true,[42418]=true,[42420]=true,
	[42421]=true,[42435]=true,[42443]=true,[42500]=true,[42508]=true,[42546]=true,[42549]=true,[42550]=true,[42551]=true,[42552]=true,[42553]=true,[42554]=true,
	[42555]=true,[42641]=true,[42642]=true,[42643]=true,[42644]=true,[42645]=true,[42646]=true,[42647]=true,[42648]=true,[42649]=true,[42650]=true,[42651]=true,
	[42652]=true,[42653]=true,[42701]=true,[42702]=true,[42723]=true,[42724]=true,[42725]=true,[42726]=true,[42727]=true,[42728]=true,[42729]=true,[42730]=true,
	[42731]=true,[42942]=true,[42993]=true,[42994]=true,[42995]=true,[42996]=true,[42997]=true,[42998]=true,[42999]=true,[43000]=true,[43001]=true,[43004]=true,
	[43005]=true,[43007]=true,[43015]=true,[43018]=true,[43019]=true,[43020]=true,[43021]=true,[43022]=true,[43023]=true,[43024]=true,[43025]=true,[43026]=true,
	[43027]=true,[43028]=true,[43029]=true,[43030]=true,[43031]=true,[43032]=true,[43033]=true,[43034]=true,[43035]=true,[43036]=true,[43037]=true,[43129]=true,
	[43130]=true,[43131]=true,[43132]=true,[43133]=true,[43244]=true,[43245]=true,[43246]=true,[43247]=true,[43248]=true,[43249]=true,[43250]=true,[43251]=true,
	[43252]=true,[43253]=true,[43255]=true,[43256]=true,[43257]=true,[43258]=true,[43260]=true,[43261]=true,[43262]=true,[43263]=true,[43264]=true,[43265]=true,
	[43266]=true,[43268]=true,[43271]=true,[43273]=true,[43433]=true,[43434]=true,[43435]=true,[43436]=true,[43437]=true,[43438]=true,[43439]=true,[43442]=true,
	[43443]=true,[43444]=true,[43445]=true,[43446]=true,[43447]=true,[43448]=true,[43449]=true,[43450]=true,[43451]=true,[43452]=true,[43453]=true,[43454]=true,
	[43455]=true,[43456]=true,[43457]=true,[43458]=true,[43459]=true,[43461]=true,[43469]=true,[43478]=true,[43480]=true,[43481]=true,[43482]=true,[43484]=true,
	[43488]=true,[43490]=true,[43491]=true,[43492]=true,[43495]=true,[43498]=true,[43502]=true,[43565]=true,[43566]=true,[43569]=true,[43570]=true,[43582]=true,
	[43583]=true,[43584]=true,[43585]=true,[43586]=true,[43587]=true,[43588]=true,[43590]=true,[43591]=true,[43592]=true,[43593]=true,[43594]=true,[43595]=true,
	[43853]=true,[43854]=true,[43860]=true,[43864]=true,[43865]=true,[43870]=true,[43871]=true,[43969]=true,[43970]=true,[43971]=true,[43972]=true,[43973]=true,
	[43974]=true,[43975]=true,[44063]=true,[44114]=true,[44211]=true,[44228]=true,[44322]=true,[44323]=true,[44324]=true,[44325]=true,[44327]=true,[44328]=true,
	[44329]=true,[44330]=true,[44331]=true,[44332]=true,[44413]=true,[44436]=true,[44437]=true,[44438]=true,[44440]=true,[44441]=true,[44442]=true,[44443]=true,
	[44444]=true,[44445]=true,[44446]=true,[44447]=true,[44448]=true,[44452]=true,[44504]=true,[44554]=true,[44558]=true,[44739]=true,[44742]=true,[44836]=true,
	[44837]=true,[44838]=true,[44839]=true,[44840]=true,[44930]=true,[44931]=true,[44936]=true,[44939]=true,[44943]=true,[44949]=true,[44951]=true,[44953]=true,
	[44958]=true,[44963]=true,[44983]=true,[45085]=true,[45550]=true,[45551]=true,[45552]=true,[45553]=true,[45554]=true,[45555]=true,[45556]=true,[45557]=true,
	[45558]=true,[45559]=true,[45560]=true,[45561]=true,[45562]=true,[45563]=true,[45564]=true,[45565]=true,[45566]=true,[45567]=true,[45621]=true,[45626]=true,
	[45627]=true,[45631]=true,[45773]=true,[45808]=true,[45809]=true,[45810]=true,[45811]=true,[45812]=true,[45813]=true,[45861]=true,[45862]=true,[45879]=true,
	[45880]=true,[45881]=true,[45882]=true,[45883]=true,[45932]=true,[45984]=true,[45986]=true,[45987]=true,[45991]=true,[45992]=true,[45998]=true,[46004]=true,
	[46006]=true,[46349]=true,[46376]=true,[46377]=true,[46378]=true,[46379]=true,[46691]=true,[46897]=true,[46898]=true,[46899]=true,[46900]=true,[46901]=true,
	[46902]=true,[46903]=true,[46904]=true,[46905]=true,[46906]=true,[46907]=true,[46908]=true,[46909]=true,[46910]=true,[46911]=true,[46912]=true,[46913]=true,
	[46914]=true,[46915]=true,[46916]=true,[46917]=true,[46918]=true,[46919]=true,[46920]=true,[46921]=true,[46922]=true,[46923]=true,[46924]=true,[46925]=true,
	[46926]=true,[46927]=true,[46928]=true,[46929]=true,[46930]=true,[46931]=true,[46932]=true,[46933]=true,[46934]=true,[46935]=true,[46936]=true,[46937]=true,
	[46938]=true,[46939]=true,[46940]=true,[46941]=true,[46942]=true,[46943]=true,[46944]=true,[46945]=true,[46946]=true,[46947]=true,[46948]=true,[46949]=true,
	[46950]=true,[46951]=true,[46952]=true,[46953]=true,[46956]=true,[47007]=true,[47008]=true,[47010]=true,[47011]=true,[47012]=true,[47015]=true,[47016]=true,
	[47017]=true,[47018]=true,[47019]=true,[47020]=true,[47021]=true,[47022]=true,[47023]=true,[47499]=true,[47570]=true,[47571]=true,[47572]=true,[47573]=true,
	[47574]=true,[47575]=true,[47576]=true,[47577]=true,[47579]=true,[47580]=true,[47581]=true,[47582]=true,[47583]=true,[47584]=true,[47585]=true,[47586]=true,
	[47587]=true,[47588]=true,[47589]=true,[47590]=true,[47591]=true,[47592]=true,[47593]=true,[47594]=true,[47595]=true,[47596]=true,[47597]=true,[47598]=true,
	[47599]=true,[47600]=true,[47601]=true,[47602]=true,[47603]=true,[47604]=true,[47605]=true,[47606]=true,[47828]=true,[48679]=true,[48933]=true,[49040]=true,
	[49110]=true,[49633]=true,[49634]=true,[49888]=true,[49890]=true,[49891]=true,[49892]=true,[49893]=true,[49894]=true,[49895]=true,[49896]=true,[49897]=true,
	[49898]=true,[49899]=true,[49900]=true,[49901]=true,[49902]=true,[49903]=true,[49904]=true,[49905]=true,[49906]=true,[49907]=true,[52020]=true,[52021]=true,
	[54797]=true,
}

AtlasLoot_LockedSpells = {
	["s44383"]=true,["s44483"]=true,["s44484"]=true,["s44488"]=true,["s44489"]=true,["s44492"]=true,["s44494"]=true,["s44500"]=true,["s44506"]=true,["s44508"]=true,["s44509"]=true,["s44510"]=true,
	["s44513"]=true,["s44524"]=true,["s44528"]=true,["s44529"]=true,["s44555"]=true,["s44556"]=true,["s44575"]=true,["s44576"]=true,["s44582"]=true,["s44584"]=true,["s44588"]=true,["s44589"]=true,
	["s44590"]=true,["s44591"]=true,["s44592"]=true,["s44593"]=true,["s44595"]=true,["s44596"]=true,["s44598"]=true,["s44616"]=true,["s44621"]=true,["s44623"]=true,["s44625"]=true,["s44629"]=true,
	["s44630"]=true,["s44631"]=true,["s44633"]=true,["s44635"]=true,["s44636"]=true,["s44645"]=true,["s46578"]=true,["s46594"]=true,["s47051"]=true,["s47672"]=true,["s47766"]=true,["s47898"]=true,
	["s47899"]=true,["s47900"]=true,["s47901"]=true,["s54736"]=true,["s54793"]=true,["s54998"]=true,["s54999"]=true,["s55002"]=true,["s55016"]=true,["s55628"]=true,["s55641"]=true,["s55642"]=true,
	["s55769"]=true,["s55777"]=true,["s56034"]=true,["s56039"]=true,["s57683"]=true,["s57690"]=true,["s57691"]=true,["s57692"]=true,["s57694"]=true,["s57696"]=true,["s57699"]=true,["s57701"]=true,
	["s59619"]=true,["s59621"]=true,["s59625"]=true,["s59636"]=true,["s60583"]=true,["s60584"]=true,["s60606"]=true,["s60609"]=true,["s60616"]=true,["s60621"]=true,["s60623"]=true,["s60653"]=true,
	["s60663"]=true,["s60668"]=true,["s60691"]=true,["s60692"]=true,["s60707"]=true,["s60714"]=true,["s60763"]=true,["s60767"]=true,["s62256"]=true,["s62948"]=true,["s62959"]=true,["s63746"]=true,
	["s63765"]=true,["s63770"]=true,["s64054"]=true,["s64441"]=true,["s64579"]=true,["s71692"]=true,
}
