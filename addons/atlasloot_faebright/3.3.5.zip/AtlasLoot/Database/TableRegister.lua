﻿--[[
loottables.en.lua
This file assigns a title to every loot table.  The primary use of this table
is in the search function, as when iterating through the loot tables there is no
inherant title to the loot table, given the origins of the mod as an Atlas plugin.
]]

--Invoke libraries





local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");

-- Using alchemy skill to get localized rank
local ALCHEMY, APPRENTICE = GetSpellInfo(2259);
local JOURNEYMAN = select(2, GetSpellInfo(3101));
local EXPERT = select(2, GetSpellInfo(3464));
local ARTISAN = select(2, GetSpellInfo(11611));
local MASTER = select(2, GetSpellInfo(28596));
local BLACKSMITHING = GetSpellInfo(2018);
local ARMORSMITH = GetSpellInfo(9788);
local WEAPONSMITH = GetSpellInfo(9787);
local AXESMITH = GetSpellInfo(17041);
local HAMMERSMITH = GetSpellInfo(17040);
local SWORDSMITH = GetSpellInfo(17039);
local ENCHANTING = GetSpellInfo(7411);
local ENGINEERING = GetSpellInfo(4036);
local GNOMISH = GetSpellInfo(20220);
local GOBLIN = GetSpellInfo(20221);
local JEWELCRAFTING = GetSpellInfo(25229);
local LEATHERWORKING = GetSpellInfo(2108);
local DRAGONSCALE = GetSpellInfo(10656);
local ELEMENTAL = GetSpellInfo(10658);
local TRIBAL = GetSpellInfo(10660);
local MINING = GetSpellInfo(2575);
local TAILORING = GetSpellInfo(3908);
local MOONCLOTH = GetSpellInfo(26798);
local SHADOWEAVE = GetSpellInfo(26801);
local SPELLFIRE = GetSpellInfo(26797);
local COOKING = GetSpellInfo(2550);
local FIRSTAID = GetSpellInfo(3273);

--Table of loot titles
AtlasLoot_TableNames = {};

-----------------------
--- WotLK Instances ---
-----------------------

--------------------
--- BC Instances ---
--------------------

  --Keys
	AtlasLoot_TableNames["OldKeys"] = { "Keys", "AtlasLootItems" };
  --Auch: Auchenai Crypts
	AtlasLoot_TableNames["AuchCryptsShirrak"] = { "Shirrak the Dead Watcher", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchCryptsShirrakHEROIC"] = { "Shirrak the Dead Watcher".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchCryptsExarch"] = { "Exarch Maladaar", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchCryptsExarchHEROIC"] = { "Exarch Maladaar".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchCryptsAvatar"] = { AL["Avatar of the Martyred"], "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchCryptsTrash"] = { AL["Trash Mobs"].." (".."Auchenai Crypts"..")", "AtlasLootExpansionItems" };
  --Auch: Mana-Tombs
	AtlasLoot_TableNames["AuchManaPandemonius"] = { "Pandemonius", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaPandemoniusHEROIC"] = { "Pandemonius".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaTavarok"] = { "Tavarok", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaTavarokHEROIC"] = { "Tavarok".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaNexusPrince"] = { "Nexus-Prince Shaffar", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaNexusPrinceHEROIC"] = { "Nexus-Prince Shaffar".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaYor"] = { AL["Yor"], "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchManaTrash"] = { AL["Trash Mobs"].." (".."Mana-Tombs"..")", "AtlasLootExpansionItems" };
  --Auch: Sethekk Halls
	AtlasLoot_TableNames["AuchSethekkDarkweaver"] = { "Darkweaver Syth", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchSethekkDarkweaverHEROIC"] = { "Darkweaver Syth".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchSethekkTheSagaofTerokk"] = { "The Saga of Terokk", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchSethekkRavenGod"] = { "Anzu", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchSethekkTalonKing"] = { "Talon King Ikiss", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchSethekkTalonKingHEROIC"] = { "Talon King Ikiss".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchSethekkTrash"] = { AL["Trash Mobs"].." (".."Sethekk Halls"..")", "AtlasLootExpansionItems" };
  --Auch: Shadow Labyrinth
	AtlasLoot_TableNames["AuchShadowHellmaw"] = { "Ambassador Hellmaw", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowHellmawHEROIC"] = { "Ambassador Hellmaw".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowBlackheart"] = { "Blackheart the Inciter", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowBlackheartHEROIC"] = { "Blackheart the Inciter".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowGrandmaster"] = { "Grandmaster Vorpil", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowGrandmasterHEROIC"] = { "Grandmaster Vorpil".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowMurmur"] = { "Murmur", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowMurmurHEROIC"] = { "Murmur".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowFirstFragmentGuardian"] = { "First Fragment Guardian", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["AuchShadowTrash"] = { AL["Trash Mobs"].." (".."Shadow Labyrinth"..")", "AtlasLootExpansionItems" };
  --The Black Temple
	AtlasLoot_TableNames["BTNajentus"] = { "High Warlord Naj'entus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTSupremus"] = { "Supremus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTGorefiend"] = { "Teron Gorefiend", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTBloodboil"] = { "Gurtogg Bloodboil", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTAkama"] = { "Shade of Akama", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTEssencofSouls"] = { "Essence of Souls", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTShahraz"] = { "Mother Shahraz", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTCouncil"] = { "Illidari Council", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTIllidanStormrage"] = { "Illidan Stormrage", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTTrash"] = { AL["Trash Mobs"].." (".."Black Temple"..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["BTPatterns"] = { "BT Patterns/Plans", "AtlasLootExpansionItems" };
  --CFR: Serpentshrine Cavern
	AtlasLoot_TableNames["CFRSerpentHydross"] = { "Hydross the Unstable", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSerpentKarathress"] = { "Fathom-Lord Karathress", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSerpentMorogrim"] = { "Morogrim Tidewalker", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSerpentLeotheras"] = { "Leotheras the Blind", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSerpentLurker"] = { "The Lurker Below", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSerpentVashj"] = { "Lady Vashj", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSerpentTrash"] = { AL["Trash Mobs"].." (".."Serpentshrine Cavern"..")", "AtlasLootExpansionItems" };
  --CFR: Slave Pens
	AtlasLoot_TableNames["CFRSlaveMennu"] = { "Mennu the Betrayer", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSlaveMennuHEROIC"] = { "Mennu the Betrayer".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSlaveRokmar"] = { "Rokmar the Crackler", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSlaveRokmarHEROIC"] = { "Rokmar the Crackler".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSlaveQuagmirran"] = { "Quagmirran", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSlaveQuagmirranHEROIC"] = { "Quagmirran".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
  --CFR: The Steamvault
	AtlasLoot_TableNames["CFRSteamThespia"] = { "Hydromancer Thespia", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamThespiaHEROIC"] = { "Hydromancer Thespia".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamSecondFragmentGuardian"] = { "Second Fragment Guardian", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamSteamrigger"] = { "Mekgineer Steamrigger", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamSteamriggerHEROIC"] = { "Mekgineer Steamrigger".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamWarlord"] = { "Warlord Kalithresh", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamWarlordHEROIC"] = { "Warlord Kalithresh".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRSteamTrash"] = { AL["Trash Mobs"].." (".."The Steamvault"..")", "AtlasLootExpansionItems" };
  --CFR: The Underbog
	AtlasLoot_TableNames["CFRUnderHungarfen"] = { "Hungarfen", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderHungarfenHEROIC"] = { "Hungarfen".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderGhazan"] = { "Ghaz'an", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderGhazanHEROIC"] = { "Ghaz'an".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderSwamplord"] = { "Swamplord Musel'ek", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderSwamplordHEROIC"] = { "Swamplord Musel'ek".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderStalker"] = { "The Black Stalker", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CFRUnderStalkerHEROIC"] = { "The Black Stalker".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
  --CoT: Old Hillsbrad Foothills
	AtlasLoot_TableNames["CoTHillsbradDrake"] = { "Lieutenant Drake", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradDrakeHEROIC"] = { "Lieutenant Drake".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradSkarloc"] = { "Captain Skarloc", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradSkarlocHEROIC"] = { "Captain Skarloc".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradHunter"] = { "Epoch Hunter", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradHunterHEROIC"] = { "Epoch Hunter".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradTrash"] = { AL["Trash Mobs"].." (".."Old Hillsbrad Foothills"..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradThomasYance"] = { AL["Thomas Yance"], "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradAgedDalaranWizard"] = { "Aged Dalaran Wizard", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradDonCarlos"] = { AL["Don Carlos"], "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTHillsbradDonCarlosHEROIC"] = { AL["Don Carlos"], "AtlasLootExpansionItems" };
  --CoT: Black Morass
	AtlasLoot_TableNames["CoTMorassDeja"] = { "Chrono Lord Deja", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTMorassDejaHEROIC"] = { "Chrono Lord Deja".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTMorassTemporus"] = { "Temporus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTMorassTemporusHEROIC"] = { "Temporus".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTMorassAeonus"] = { "Aeonus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTMorassAeonusHEROIC"] = { "Aeonus".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["CoTMorassTrash"] = { AL["Trash Mobs"].." (".."The Black Morass"..")", "AtlasLootExpansionItems" };
  --CoT: Hyjal Summit
	AtlasLoot_TableNames["MountHyjalWinterchill"] = { "Rage Winterchill", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["MountHyjalAnetheron"] = { "Anetheron", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["MountHyjalKazrogal"] = { "Kaz'rogal", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["MountHyjalAzgalor"] = { "Azgalor", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["MountHyjalArchimonde"] = { "Archimonde", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["MountHyjalTrash"] = { AL["Trash Mobs"].." (".."Hyjal Summit"..")", "AtlasLootExpansionItems" };
  --Gruul's Lair
	AtlasLoot_TableNames["GruulsLairHighKingMaulgar"] = { "High King Maulgar", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["GruulGruul"] = { "Gruul the Dragonkiller", "AtlasLootExpansionItems" };
  --HC: Blood Furnace
	AtlasLoot_TableNames["HCFurnaceMaker"] = { "The Maker", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCFurnaceMakerHEROIC"] = { "The Maker".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCFurnaceBroggok"] = { "Broggok", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCFurnaceBroggokHEROIC"] = { "Broggok".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCFurnaceBreaker"] = { "Keli'dan the Breaker", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCFurnaceBreakerHEROIC"] = { "Keli'dan the Breaker".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
  --HC: Magtheridon's Lair
	AtlasLoot_TableNames["HCMagtheridon"] = { "Magtheridon", "AtlasLootExpansionItems" };
  --HC: Ramparts
	AtlasLoot_TableNames["HCRampWatchkeeper"] = { "Watchkeeper Gargolmar", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampWatchkeeperHEROIC"] = { "Watchkeeper Gargolmar".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampOmor"] = { "Omor the Unscarred", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampOmorHEROIC"] = { "Omor the Unscarred".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampVazruden"] = { "Vazruden", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampNazan"] = { "Nazan", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampFelIronChest"] = { AL["Reinforced Fel Iron Chest"], "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCRampFelIronChestHEROIC"] = { AL["Reinforced Fel Iron Chest"].." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
  --HC: Shattered Halls
	AtlasLoot_TableNames["HCHallsNethekurse"] = { "Grand Warlock Nethekurse", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsNethekurseHEROIC"] = { "Grand Warlock Nethekurse".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsPorung"] = { "Blood Guard Porung".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsOmrogg"] = { "Warbringer O'mrogg", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsOmroggHEROIC"] = { "Warbringer O'mrogg".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsKargath"] = { "Warchief Kargath Bladefist", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsKargathHEROIC"] = { "Warchief Kargath Bladefist".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsExecutioner"] = { "Shattered Hand Executioner", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["HCHallsTrash"] = { AL["Trash Mobs"].." (".."The Shattered Halls"..")", "AtlasLootExpansionItems" };
  --Karazhan
	AtlasLoot_TableNames["KaraCharredBoneFragment"] = { "Charred Bone Fragment ("..AL["Quest Item"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraNamed"] = { "Servant's Quarter Animal Bosses", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraAttumen"] = { "Attumen the Huntsman", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraMoroes"] = { "Moroes", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraKeannaLog"] = { "Keanna's Log ("..AL["Quest Item"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraMaiden"] = { "Maiden of Virtue", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraOperaEvent"] = { "Opera Event", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraCurator"] = { "The Curator", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraIllhoof"] = { "Terestian Illhoof", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraAran"] = { "Shade of Aran", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraNetherspite"] = { "Netherspite", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraNightbane"] = { "Nightbane", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraChess"] = { "Chess Event", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraPrince"] = { "Prince Malchezaar", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["KaraTrash"] = { AL["Trash Mobs"].." (".."Karazhan"..")", "AtlasLootExpansionItems" };
  --Sunwell Isle: Magister's Terrace
	AtlasLoot_TableNames["SMTFireheart"] = { "Selin Fireheart", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTFireheartHEROIC"] = { "Selin Fireheart".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTVexallus"] = { "Vexallus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTVexallusHEROIC"] = { "Vexallus".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTDelrissa"] = { "Priestess Delrissa", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTDelrissaHEROIC"] = { "Priestess Delrissa".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTKaelthas"] = { "Kael'thas Sunstrider", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTKaelthasHEROIC"] = { "Kael'thas Sunstrider".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SMTTrash"] = { AL["Trash Mobs"].." (".."Magisters' Terrace"..")", "AtlasLootExpansionItems" };
  --Sunwell Plateau
	AtlasLoot_TableNames["SPKalecgos"] = { "Kalecgos", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPBrutallus"] = { "Brutallus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPFelmyst"] = { "Felmyst", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPEredarTwins"] = { "The Eredar Twins", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPMuru"] = { "M'uru", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPKiljaeden"] = { "Kil'jaeden", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPTrash"] = { AL["Trash Mobs"].." (".."Sunwell Plateau"..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["SPPatterns"] = { "SP Patterns/Plans", "AtlasLootExpansionItems" };
  --TK: The Arcatraz
	AtlasLoot_TableNames["TKArcUnbound"] = { "Zereketh the Unbound", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcUnboundHEROIC"] = { "Zereketh the Unbound".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcThirdFragmentGuardian"] = { "Third Fragment Guardian", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcDalliah"] = { "Dalliah the Doomsayer", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcDalliahHEROIC"] = { "Dalliah the Doomsayer".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcScryer"] = { "Wrath-Scryer Soccothrates", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcScryerHEROIC"] = { "Wrath-Scryer Soccothrates".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcHarbinger"] = { "Harbinger Skyriss", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcHarbingerHEROIC"] = { "Harbinger Skyriss".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKArcTrash"] = { AL["Trash Mobs"].." (".."The Arcatraz"..")", "AtlasLootExpansionItems" };
  --TK: The Botanica
	AtlasLoot_TableNames["TKBotSarannis"] = { "Commander Sarannis", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotSarannisHEROIC"] = { "Commander Sarannis".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotFreywinn"] = { "High Botanist Freywinn", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotFreywinnHEROIC"] = { "High Botanist Freywinn".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotThorngrin"] = { "Thorngrin the Tender", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotThorngrinHEROIC"] = { "Thorngrin the Tender".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotLaj"] = { "Laj", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotLajHEROIC"] = { "Laj".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotSplinter"] = { "Warp Splinter", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotSplinterHEROIC"] = { "Warp Splinter".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKBotTrash"] = { AL["Trash Mobs"].." (".."The Botanica"..")", "AtlasLootExpansionItems" };
  --TK: The Eye
	AtlasLoot_TableNames["TKEyeAlar"] = { "Al'ar", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKEyeVoidReaver"] = { "Void Reaver", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKEyeSolarian"] = { "High Astromancer Solarian", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKEyeKaelthas"] = { "Kael'thas Sunstrider", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKEyeLegendaries"] = { "Legendary Items for Kael'thas Fight", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKEyeTrash"] = { AL["Trash Mobs"].." (".."The Eye"..")", "AtlasLootExpansionItems" };
  --TK: The Mechanar
	AtlasLoot_TableNames["TKMechGyro"] = { "Gatewatcher Gyro-Kill", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechIron"] = { "Gatewatcher Iron-Hand", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechCacheoftheLegion"] = { "Cache of the Legion", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechCapacitus"] = { "Mechano-Lord Capacitus", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechCapacitusHEROIC"] = { "Mechano-Lord Capacitus".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechOverchargedManacell"] = { "Overcharged Manacell", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechSepethrea"] = { "Nethermancer Sepethrea", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechSepethreaHEROIC"] = { "Nethermancer Sepethrea".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechCalc"] = { "Pathaleon the Calculator", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechCalcHEROIC"] = { "Pathaleon the Calculator".." ("..AL["Heroic"]..")", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["TKMechTrash"] = { AL["Trash Mobs"].." (".."The Mechanar"..")", "AtlasLootExpansionItems" };
  --Zul'Aman
	AtlasLoot_TableNames["ZANalorakk"] = { "Nalorakk", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZAAkilZon"] = { "Akil'zon", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZAJanAlai"] = { "Jan'alai", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZAHalazzi"] = { "Halazzi", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZAMalacrass"] = { "Hex Lord Malacrass", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZAZuljin"] = { "Zul'jin", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZATimedChest"] = { "Timed Reward Chest", "AtlasLootExpansionItems" };
	AtlasLoot_TableNames["ZATrash"] = { AL["Trash Mobs"].." (".."Zul'Aman"..")", "AtlasLootExpansionItems" };

-------------------------
--- Classic Instances ---
-------------------------

  --Keys
	AtlasLoot_TableNames["BCKeys"] = { "Keys", "AtlasLootExpansionItems" };
  --Blackfathom Deeps
	AtlasLoot_TableNames["BFDGhamoora"] = { "Ghamoo-ra", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDLadySarevess"] = { "Lady Sarevess", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDGelihast"] = { "Gelihast", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDBaronAquanis"] = { "Baron Aquanis", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDTwilightLordKelris"] = { "Twilight Lord Kelris", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDOldSerrakis"] = { "Old Serra'kis", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDAkumai"] = { "Aku'mai", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDQuestItems"] = { AL["Quest Item"].." (".."Blackfathom Deeps"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["BFDTrash"] = { AL["Trash Mobs"].." (".."Blackfathom Deeps"..")", "AtlasLootItems" };
  --Blackrock Mountain
	AtlasLoot_TableNames["BRMScarshieldQuartermaster"] = { AL["Scarshield Quartermaster"], "AtlasLootItems" };
  --Blackrock Depths
	AtlasLoot_TableNames["BRDPyron"] = { AL["Overmaster Pyron"], "AtlasLootItems" };
	AtlasLoot_TableNames["BRDLordRoccor"] = { "Lord Roccor", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDHighInterrogatorGerstahn"] = { "High Interrogator Gerstahn", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDArena"] = { "Ring of Law", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDTheldren"] = { AL["Theldren"], "AtlasLootItems" };
	AtlasLoot_TableNames["BRDHoundmaster"] = { "Houndmaster Grebmar", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDForgewright"] = { "Monument of Franclorn Forgewright", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDPyromantLoregrain"] = { "Pyromancer Loregrain", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDTheVault"] = { AL["The Vault"], "AtlasLootItems" };
	AtlasLoot_TableNames["BRDWarderStilgiss"] = { "Warder Stilgiss", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDVerek"] = { "Verek", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDFineousDarkvire"] = { "Fineous Darkvire", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDLordIncendius"] = { "Lord Incendius", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDBaelGar"] = { "Bael'Gar", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDGeneralAngerforge"] = { "General Angerforge", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDGolemLordArgelmach"] = { "Golem Lord Argelmach", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDGuzzler"] = { "The Grim Guzzler", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDFlamelash"] = { "Ambassador Flamelash", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDPanzor"] = { "Panzor the Invincible".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDTomb"] = { "Summoner's Tomb", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDLyceum"] = { AL["Shadowforge Flame Keeper"], "AtlasLootItems" };
	AtlasLoot_TableNames["BRDMagmus"] = { "Magmus", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDPrincess"] = { "Princess Moira Bronzebeard", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDImperatorDagranThaurissan"] = { "Emperor Dagran Thaurissan", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDBSPlans"] = { "Blacksmith Plans".." (".."Blackrock Depths"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["BRDTrash"] = { AL["Trash Mobs"].." (".."Blackrock Depths"..")", "AtlasLootItems" };
  --Lower Blackrock Spire
	AtlasLoot_TableNames["LBRSQuestItems"] = { "Lower Blackrock Spire".." - "..AL["Quest Item"], "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSSpirestoneButcher"] = { "Spirestone Butcher".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSOmokk"] = { "Highlord Omokk", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSSpirestoneLord"] = { "Spirestone Battle Lord".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSLordMagus"] = { "Spirestone Lord Magus".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSVosh"] = { "Shadow Hunter Vosh'gajin", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSVoone"] = { "War Master Voone", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSGrayhoof"] = { "Mor Grayhoof".." ("..AL["Summon"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSGrimaxe"] = { "Bannok Grimaxe".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSSmolderweb"] = { "Mother Smolderweb", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSCrystalFang"] = { "Crystal Fang", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSDoomhowl"] = { "Urok Doomhowl".." ("..AL["Summon"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSZigris"] = { "Quartermaster Zigris", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSHalycon"] = { "Halycon", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSSlavener"] = { "Gizrul the Slavener", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSBashguud"] = { "Ghok Bashguud".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSWyrmthalak"] = { "Overlord Wyrmthalak", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSFelguard"] = { "Burning Felguard".." ("..AL["Rare"]..", "..AL["Random"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["LBRSTrash"] = { AL["Trash Mobs"].." (".."Lower Blackrock Spire"..")", "AtlasLootItems" };
  --Upper Blackrock Spire
	AtlasLoot_TableNames["UBRSEmberseer"] = { "Pyroguard Emberseer", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSSolakar"] = { "Solakar Flamewreath", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSFLAME"] = { AL["Father Flame"], "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSQuestItems"] = { AL["Quest Item"].." (".."Upper Blackrock Spire"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSRunewatcher"] = { "Jed Runewatcher", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSAnvilcrack"] = { "Goraluk Anvilcrack", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSRend"] = { "Warchief Rend Blackhand", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSGyth"] = { "Gyth", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSBeast"] = { "The Beast", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSValthalak"] = { "Lord Valthalak".." ("..AL["Summon"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSDrakkisath"] = { "General Drakkisath", "AtlasLootItems" };
	AtlasLoot_TableNames["UBRSTrash"] = { AL["Trash Mobs"].." (".."Upper Blackrock Spire"..")", "AtlasLootItems" };
  --Blackwing Lair
	AtlasLoot_TableNames["BWLRazorgore"] = { "Razorgore the Untamed", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLVaelastrasz"] = { "Vaelastrasz the Corrupt", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLLashlayer"] = { "Broodlord Lashlayer", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLFiremaw"] = { "Firemaw", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLDraconicForDummies"] = { "Draconic for Dummies Chapter VII", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLEbonroc"] = { "Ebonroc", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLFlamegor"] = { "Flamegor", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLChromaggus"] = { "Chromaggus", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLNefarian"] = { "Nefarian", "AtlasLootItems" };
	AtlasLoot_TableNames["BWLTrashMobs"] = { AL["Trash Mobs"].." (".."Blackwing Lair"..")", "AtlasLootItems" };
  --The Deadmines
	AtlasLoot_TableNames["DMMarisaDuPaige"] = { "Marisa du'Paige", "AtlasLootItems" };
	AtlasLoot_TableNames["DMBrainwashedNoble"] = { "Brainwashed Noble", "AtlasLootItems" };
	AtlasLoot_TableNames["DMThistlenettle"] = { "Foreman Thistlenettle", "AtlasLootItems" };
	AtlasLoot_TableNames["DMRhahkZor"] = { "Rhahk'Zor", "AtlasLootItems" };
	AtlasLoot_TableNames["DMMinerJohnson"] = { "Miner Johnson", "AtlasLootItems" };
	AtlasLoot_TableNames["DMSneedsShredder"] = { "Sneed's Shredder", "AtlasLootItems" };
	AtlasLoot_TableNames["DMSneed"] = { "Sneed", "AtlasLootItems" };
	AtlasLoot_TableNames["DMGilnid"] = { "Gilnid", "AtlasLootItems" };
	AtlasLoot_TableNames["DMCaptainGreenskin"] = { "Captain Greenskin", "AtlasLootItems" };
	AtlasLoot_TableNames["DMMrSmite"] = { "Mr. Smite", "AtlasLootItems" };
	AtlasLoot_TableNames["DMCookie"] = { "Cookie", "AtlasLootItems" };
	AtlasLoot_TableNames["DMVanCleef"] = { "Edwin VanCleef", "AtlasLootItems" };
  --Dire Maul East
	AtlasLoot_TableNames["DMEPusillin"] = { "Pusillin", "AtlasLootItems" };
	AtlasLoot_TableNames["DMEZevrimThornhoof"] = { "Zevrim Thornhoof", "AtlasLootItems" };
	AtlasLoot_TableNames["DMEHydro"] = { "Hydrospawn", "AtlasLootItems" };
	AtlasLoot_TableNames["DMELethtendris"] = { "Lethtendris", "AtlasLootItems" };
	AtlasLoot_TableNames["DMEPimgib"] = { "Pimgib", "AtlasLootItems" };
	AtlasLoot_TableNames["DMEAlzzin"] = { "Alzzin the Wildshaper", "AtlasLootItems" };
	AtlasLoot_TableNames["DMEIsalien"] = { "Isalien", "AtlasLootItems" };
	AtlasLoot_TableNames["DMETrash"] = { AL["Trash Mobs"].." (".."Dire Maul (East)"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["DMBooks"] = { "Dire Maul Books", "AtlasLootItems" };
  --Dire Maul North
	AtlasLoot_TableNames["DMNGuardMoldar"] = { "Guard Mol'dar", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNStomperKreeg"] = { "Stomper Kreeg", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNGuardFengus"] = { "Guard Fengus", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNThimblejack"] = { AL["Knot Thimblejack"], "AtlasLootItems" };
	AtlasLoot_TableNames["DMNGuardSlipkik"] = { "Guard Slip'kik", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNCaptainKromcrush"] = { "Captain Kromcrush", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNChoRush"] = { "Cho'Rush the Observer", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNKingGordok"] = { "King Gordok", "AtlasLootItems" };
	AtlasLoot_TableNames["DMNTRIBUTERUN"] = { AL["DM North Tribute Chest"], "AtlasLootItems" };
  --Dire Maul West
	AtlasLoot_TableNames["DMWTendrisWarpwood"] = { "Tendris Warpwood", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWIllyannaRavenoak"] = { "Illyanna Ravenoak", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWMagisterKalendris"] = { "Magister Kalendris", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWTsuzee"] = { "Tsu'zee", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWImmolthar"] = { "Immol'thar", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWHelnurath"] = { "Lord Hel'nurath", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWPrinceTortheldrin"] = { "Prince Tortheldrin", "AtlasLootItems" };
	AtlasLoot_TableNames["DMWShendralarProvisioner"] = { AL["Shen'dralar Provisioner"], "AtlasLootItems" };
	AtlasLoot_TableNames["DMWTrash"] = { AL["Trash Mobs"].." (".."Dire Maul (West)"..")", "AtlasLootItems" };
  --Gnomeregan
	AtlasLoot_TableNames["GnNamdoBizzfizzle"] = { AL["Namdo Bizzfizzle"], "AtlasLootItems" };
	AtlasLoot_TableNames["GnTechbot"] = { "Techbot", "AtlasLootItems" };
	AtlasLoot_TableNames["GnGrubbis"] = { "Grubbis", "AtlasLootItems" };
	AtlasLoot_TableNames["GnViscousFallout"] = { "Viscous Fallout", "AtlasLootItems" };
	AtlasLoot_TableNames["GnElectrocutioner6000"] = { "Electrocutioner 6000", "AtlasLootItems" };
	AtlasLoot_TableNames["GnCrowdPummeler960"] = { "Crowd Pummeler 9-60", "AtlasLootItems" };
	AtlasLoot_TableNames["GnDIAmbassador"] = { "Dark Iron Ambassador".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["GnMekgineerThermaplugg"] = { "Mekgineer Thermaplugg", "AtlasLootItems" };
	AtlasLoot_TableNames["GnTrash"] = { AL["Trash Mobs"].." (".."Gnomeregan"..")", "AtlasLootItems" };
  --Maraudon
	AtlasLoot_TableNames["MaraNamelesProphet"] = { AL["The Nameles Prophet"], "AtlasLootItems" };
	AtlasLoot_TableNames["MaraKhanKolk"] = { "Kolk".." (The First Khan)", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraKhanGelk"] = { "Gelk".." (The Second Khan)", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraKhanMagra"] = { "Magra".." (The Third Khan)", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraKhanVeng"] = { "Veng".." (The Fifth Khan)", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraNoxxion"] = { "Noxxion", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraRazorlash"] = { "Razorlash", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraKhanMaraudos"] = { "Maraudos".." (The Forth Khan)", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraLordVyletongue"] = { "Lord Vyletongue", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraMeshlok"] = { "Meshlok the Harvester", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraCelebras"] = { "Celebras the Cursed", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraLandslide"] = { "Landslide", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraTinkererGizlock"] = { "Tinkerer Gizlock", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraRotgrip"] = { "Rotgrip", "AtlasLootItems" };
	AtlasLoot_TableNames["MaraPrincessTheradras"] = { "Princess Theradras", "AtlasLootItems" };
  --Molten Core
	AtlasLoot_TableNames["MCLucifron"] = { "Lucifron", "AtlasLootItems" };
	AtlasLoot_TableNames["MCMagmadar"] = { "Magmadar", "AtlasLootItems" };
	AtlasLoot_TableNames["MCGehennas"] = { "Gehennas", "AtlasLootItems" };
	AtlasLoot_TableNames["MCGarr"] = { "Garr", "AtlasLootItems" };
	AtlasLoot_TableNames["MCShazzrah"] = { "Shazzrah", "AtlasLootItems" };
	AtlasLoot_TableNames["MCGeddon"] = { "Baron Geddon", "AtlasLootItems" };
	AtlasLoot_TableNames["MCGolemagg"] = { "Golemagg the Incinerator", "AtlasLootItems" };
	AtlasLoot_TableNames["MCSulfuron"] = { "Sulfuron Harbinger", "AtlasLootItems" };
	AtlasLoot_TableNames["MCMajordomo"] = { "Majordomo Executus", "AtlasLootItems" };
	AtlasLoot_TableNames["MCRagnaros"] = { "Ragnaros", "AtlasLootItems" };
	AtlasLoot_TableNames["MCRANDOMBOSSDROPPS"] = { "Random Boss Drops", "AtlasLootItems" };
	AtlasLoot_TableNames["MCTrashMobs"] = { AL["Trash Mobs"].." (".."Molten Core"..")", "AtlasLootItems" };
  --Naxxramas
	AtlasLoot_TableNames["NAXPatchwerk"] = { "Patchwerk", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXGrobbulus"] = { "Grobbulus", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXGluth"] = { "Gluth", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXThaddius"] = { "Thaddius", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXAnubRekhan"] = { "Anub'Rekhan", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXGrandWidowFaerlina"] = { "Grand Widow Faerlina", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXMaexxna"] = { "Maexxna", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXInstructorRazuvious"] = { "Instructor Razuvious", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXGothikderHarvester"] = { "Gothik the Harvester", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXTheFourHorsemen"] = { "The Four Horsemen", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXNothderPlaguebringer"] = { "Noth the Plaguebringer", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXHeiganderUnclean"] = { "Heigan the Unclean", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXLoatheb"] = { "Loatheb", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXSapphiron"] = { "Sapphiron", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXKelThuzard"] = { "Kel'Thuzad", "AtlasLootItems" };
	AtlasLoot_TableNames["NAXTrash"] = { AL["Trash Mobs"].." (".."Naxxramas"..")", "AtlasLootItems" };
  --Onyxia's Lair
	AtlasLoot_TableNames["Onyxia"] = { "Onyxia", "AtlasLootItems" };
  --Ragefire Chasm
	AtlasLoot_TableNames["RFCTaragaman"] = { "Taragaman the Hungerer", "AtlasLootItems" };
	AtlasLoot_TableNames["RFCZelemar"] = { AL["Zelemar the Wrathful"], "AtlasLootItems" };
	AtlasLoot_TableNames["RFCJergosh"] = { "Jergosh the Invoker", "AtlasLootItems" };
  --Razorfen Downs
	AtlasLoot_TableNames["RFDTutenkash"] = { "Tuten'kash", "AtlasLootItems" };
	AtlasLoot_TableNames["RFDHenryStern"] = { AL["Henry Stern"], "AtlasLootItems" };
	AtlasLoot_TableNames["RFDMordreshFireEye"] = { "Mordresh Fire Eye", "AtlasLootItems" };
	AtlasLoot_TableNames["RFDGlutton"] = { "Glutton", "AtlasLootItems" };
	AtlasLoot_TableNames["RFDRagglesnout"] = { "Ragglesnout", "AtlasLootItems" };
	AtlasLoot_TableNames["RFDAmnennar"] = { "Amnennar the Coldbringer", "AtlasLootItems" };
	AtlasLoot_TableNames["RFDPlaguemaw"] = { "Plaguemaw the Rotting", "AtlasLootItems" };
	AtlasLoot_TableNames["RFDTrash"] = { AL["Trash Mobs"].." (".."Razorfen Downs"..")", "AtlasLootItems" };
  --Razorfen Kraul
	AtlasLoot_TableNames["RFKThorncurse"] = { AL["Aggem Thorncurse"], "AtlasLootItems" };
	AtlasLoot_TableNames["RFKDeathSpeakerJargba"] = { "Death Speaker Jargba", "AtlasLootItems" };
	AtlasLoot_TableNames["RFKRazorfenSpearhide"] = { AL["Razorfen Spearhide"], "AtlasLootItems" };
	AtlasLoot_TableNames["RFKOverlordRamtusk"] = { "Overlord Ramtusk", "AtlasLootItems" };
	AtlasLoot_TableNames["RFKAgathelos"] = { "Agathelos the Raging", "AtlasLootItems" };
	AtlasLoot_TableNames["RFKBlindHunter"] = { "Blind Hunter", "AtlasLootItems" };
	AtlasLoot_TableNames["RFKCharlgaRazorflank"] = { "Charlga Razorflank", "AtlasLootItems" };
	AtlasLoot_TableNames["RFKEarthcallerHalmgar"] = { "Earthcaller Halmgar", "AtlasLootItems" };
	AtlasLoot_TableNames["RFKRoogug"] = { AL["Roogug"], "AtlasLootItems" };
	AtlasLoot_TableNames["RFKTrash"] = { AL["Trash Mobs"].." (".."Razorfen Kraul"..")", "AtlasLootItems" };
  --The Ruins of Ahn'Qiraj
	AtlasLoot_TableNames["AQ20Kurinnaxx"] = { "Kurinnaxx", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Andorov"] = { "Lieutenant General Andorov", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20CAPTIAN"] = { "Rajaxx's Captains", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Rajaxx"] = { "General Rajaxx", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Moam"] = { "Moam", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Buru"] = { "Buru the Gorger", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Ayamiss"] = { "Ayamiss the Hunter", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Ossirian"] = { "Ossirian the Unscarred", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20Trash"] = { AL["Trash Mobs"].." (AQ20)", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ20ClassBooks"] = { "AQ Class Books", "AtlasLootItems" };
	AtlasLoot_TableNames["AQEnchants"] = { "AQ Enchants", "AtlasLootItems" };
  --Scarlet Monestery - Armory
	AtlasLoot_TableNames["SMHerod"] = { "Herod", "AtlasLootItems" };
	AtlasLoot_TableNames["SMTrash"] = { AL["Trash Mobs"].." (".."Scarlet Monastery"..")", "AtlasLootItems" };
  --Scarlet Monestery - Cathedral
	AtlasLoot_TableNames["SMFairbanks"] = { "High Inquisitor Fairbanks", "AtlasLootItems" };
	AtlasLoot_TableNames["SMMograine"] = { "Scarlet Commander Mograine", "AtlasLootItems" };
	AtlasLoot_TableNames["SMWhitemane"] = { "High Inquisitor Whitemane", "AtlasLootItems" };
  --Scarlet Monestery - Graveyard
	AtlasLoot_TableNames["SMVishas"] = { "Interrogator Vishas", "AtlasLootItems" };
	AtlasLoot_TableNames["SMIronspine"] = { "Ironspine", "AtlasLootItems" };
	AtlasLoot_TableNames["SMAzshir"] = { "Azshir the Sleepless", "AtlasLootItems" };
	AtlasLoot_TableNames["SMFallenChampion"] = { "Fallen Champion", "AtlasLootItems" };
	AtlasLoot_TableNames["SMBloodmageThalnos"] = { "Bloodmage Thalnos", "AtlasLootItems" };
  --Scarlet Monestery - Library
	AtlasLoot_TableNames["SMHoundmasterLoksey"] = { "Houndmaster Loksey", "AtlasLootItems" };
	AtlasLoot_TableNames["SMDoan"] = { "Arcanist Doan", "AtlasLootItems" };
  --Scholomance
	AtlasLoot_TableNames["SCHOLOBloodStewardofKirtonos"] = { "Blood Steward of Kirtonos", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOKirtonostheHerald"] = { "Kirtonos the Herald", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOJandiceBarov"] = { "Jandice Barov", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLORattlegore"] = { "Rattlegore", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLODeathKnight"] = { "Death Knight Darkreaver", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOMarduk"] = { "Marduk Blackpool", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOVectus"] = { "Vectus", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLORasFrostwhisper"] = { "Ras Frostwhisper", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOKormok"] = { "Kormok", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOInstructorMalicia"] = { "Instructor Malicia", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLODoctorTheolenKrastinov"] = { "Doctor Theolen Krastinov", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOLorekeeperPolkelt"] = { "Lorekeeper Polkelt", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOTheRavenian"] = { "The Ravenian", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOLordAlexeiBarov"] = { "Lord Alexei Barov", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOLadyIlluciaBarov"] = { "Lady Illucia Barov", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLODarkmasterGandling"] = { "Darkmaster Gandling", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOQuestItems"] = { AL["Quest Item"].." (".."Scholomance"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["SCHOLOTrash"] = { AL["Trash Mobs"].." (".."Scholomance"..")", "AtlasLootItems" };
  --Shadowfang Keep
	AtlasLoot_TableNames["BSFRethilgore"] = { AL["Rethilgore"], "AtlasLootItems" };
	AtlasLoot_TableNames["BSFFelSteed"] = { "Felsteed", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFRazorclawtheButcher"] = { "Razorclaw the Butcher", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFSilverlaine"] = { "Baron Silverlaine", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFSpringvale"] = { "Commander Springvale", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFOdotheBlindwatcher"] = { "Odo the Blindwatcher", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFFenrustheDevourer"] = { "Fenrus the Devourer", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFArugalsVoidwalker"] = { "Arugal's Voidwalker", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFWolfMasterNandos"] = { "Wolf Master Nandos", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFArchmageArugal"] = { "Archmage Arugal", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFDeathswornCaptain"] = { "Deathsworn Captain", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFQuestItems"] = { AL["Quest Item"].." (".."Shadowfang Keep"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["BSFTrash"] = { AL["Trash Mobs"].." (".."Shadowfang Keep"..")", "AtlasLootItems" };
  --The Stockade
	AtlasLoot_TableNames["SWStTargorr"] = { "Targorr the Dread", "AtlasLootItems" };
	AtlasLoot_TableNames["SWStKamDeepfury"] = { "Kam Deepfury", "AtlasLootItems" };
	AtlasLoot_TableNames["SWStBazil"] = { "Bazil Thredd", "AtlasLootItems" };
	AtlasLoot_TableNames["SWStDextren"] = { "Dextren Ward", "AtlasLootItems" };
	AtlasLoot_TableNames["SWStBruegalIronknuckle"] = { "Bruegal Ironknuckle", "AtlasLootItems" };
	AtlasLoot_TableNames["SWStTrash"] = { AL["Trash Mobs"].." (".."The Stockade"..")", "AtlasLootItems" };
  --Stratholme
	AtlasLoot_TableNames["STRATSkull"] = { "Skul", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATStratholmeCourier"] = { "Mailbox Keys", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATFrasSiabi"] = { "Fras Siabi", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATAtiesh"] = { "Atiesh <Hand of Sargeras>", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATHearthsingerForresten"] = { "Hearthsinger Forresten", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATTheUnforgiven"] = { "The Unforgiven", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATTimmytheCruel"] = { "Timmy the Cruel", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATMalorsStrongbox"] = { AL["Malor's Strongbox"], "AtlasLootItems" };
	AtlasLoot_TableNames["STRATCrimsonHammersmith"] = { "Crimson Hammersmith".." ("..AL["Summon"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATBSPlansSerenity"] = { "Plans: Serenity", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATCannonMasterWilley"] = { "Cannon Master Willey", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATArchivistGalford"] = { "Archivist Galford", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATBalnazzar"] = { "Balnazzar", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATSothosJarien"] = { AL["Sothos and Jarien"], "AtlasLootItems" };
	AtlasLoot_TableNames["STRATStonespine"] = { "Stonespine", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATNerubenkan"] = { "Nerub'enkan", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATBaronessAnastari"] = { "Baroness Anastari", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATBlackGuardSwordsmith"] = { "Black Guard Swordsmith".." ("..AL["Summon"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATBSPlansCorruption"] = { "Plans: Corruption", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATMalekithePallid"] = { "Maleki the Pallid", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATMagistrateBarthilas"] = { "Magistrate Barthilas", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATRamsteintheGorger"] = { "Ramstein the Gorger", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATBaronRivendare"] = { "Baron Rivendare", "AtlasLootItems" };
	AtlasLoot_TableNames["STRATTrash"] = { AL["Trash Mobs"].." (".."Stratholme"..")", "AtlasLootItems" };
  --Sunken Temple
	AtlasLoot_TableNames["STSpawnOfHakkar"] = { "Spawn of Hakkar", "AtlasLootItems" };
	AtlasLoot_TableNames["STTrollMinibosses"] = { "Troll Minibosses", "AtlasLootItems" };
	AtlasLoot_TableNames["STAtalalarion"] = { "Atal'alarion", "AtlasLootItems" };
	AtlasLoot_TableNames["STDreamscythe"] = { "Dreamscythe", "AtlasLootItems" };
	AtlasLoot_TableNames["STWeaver"] = { "Weaver", "AtlasLootItems" };
	AtlasLoot_TableNames["STAvatarofHakkar"] = { "Avatar of Hakkar", "AtlasLootItems" };
	AtlasLoot_TableNames["STJammalan"] = { "Jammal'an the Prophet", "AtlasLootItems" };
	AtlasLoot_TableNames["STOgom"] = { "Ogom the Wretched", "AtlasLootItems" };
	AtlasLoot_TableNames["STMorphaz"] = { "Morphaz", "AtlasLootItems" };
	AtlasLoot_TableNames["STHazzas"] = { "Hazzas", "AtlasLootItems" };
	AtlasLoot_TableNames["STEranikus"] = { "Shade of Eranikus", "AtlasLootItems" };
	AtlasLoot_TableNames["STTrash"] = { AL["Trash Mobs"].." (".."The Temple of Atal'Hakkar"..")", "AtlasLootItems" };
  --Temple of Ahn'Qiraj
	AtlasLoot_TableNames["AQ40Skeram"] = { "The Prophet Skeram", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Vem"] = { "The Bug Family", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Sartura"] = { "Battleguard Sartura", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Fankriss"] = { "Fankriss the Unyielding", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Viscidus"] = { "Viscidus", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Huhuran"] = { "Princess Huhuran", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Emperors"] = { "The Twin Emperors", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Ouro"] = { "Ouro", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40CThun"] = { "C'Thun", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Trash1"] = { AL["Trash Mobs"].." (AQ40)", "AtlasLootItems" };
	AtlasLoot_TableNames["AQ40Trash2"] = { AL["Trash Mobs"].." (AQ40)", "AtlasLootItems" };
	AtlasLoot_TableNames["AQOpening"] = { "AQ Opening Quest Line", "AtlasLootItems" };
  --Uldaman
	AtlasLoot_TableNames["UldMagreganDeepshadow"] = { AL["Magregan Deepshadow"], "AtlasLootItems" };
	AtlasLoot_TableNames["UldTabletofRyuneh"] = { "Tablet of Ryun'eh", "AtlasLootItems" };
	AtlasLoot_TableNames["UldKromStoutarmChest"] = { AL["Krom Stoutarm's Chest"], "AtlasLootItems" };
	AtlasLoot_TableNames["UldGarrettFamilyChest"] = { AL["Garrett Family Chest"], "AtlasLootItems" };
	AtlasLoot_TableNames["UldShovelphlange"] = { "Digmaster Shovelphlange", "AtlasLootItems" };
	AtlasLoot_TableNames["UldRevelosh"] = { "Revelosh", "AtlasLootItems" };
	AtlasLoot_TableNames["UldBaelog"] = { "Baelog", "AtlasLootItems" };
	AtlasLoot_TableNames["UldIronaya"] = { "Ironaya", "AtlasLootItems" };
	AtlasLoot_TableNames["UldObsidianSentinel"] = { "Obsidian Sentinel", "AtlasLootItems" };
	AtlasLoot_TableNames["UldAncientStoneKeeper"] = { "Ancient Stone Keeper", "AtlasLootItems" };
	AtlasLoot_TableNames["UldGalgannFirehammer"] = { "Galgann Firehammer", "AtlasLootItems" };
	AtlasLoot_TableNames["UldTabletofWill"] = { "Tablet of Will", "AtlasLootItems" };
	AtlasLoot_TableNames["UldShadowforgeCache"] = { "Shadowforge Cache", "AtlasLootItems" };
	AtlasLoot_TableNames["UldGrimlok"] = { "Grimlok", "AtlasLootItems" };
	AtlasLoot_TableNames["UldArchaedas"] = { "Archaedas", "AtlasLootItems" };
	AtlasLoot_TableNames["UldTrash"] = { AL["Trash Mobs"].." (".."Uldaman"..")", "AtlasLootItems" };
  --Wailing Caverns
	AtlasLoot_TableNames["WCKalldanFelmoon"] = { AL["Kalldan Felmoon"], "AtlasLootItems" };
	AtlasLoot_TableNames["WCMadMagglish"] = { "Mad Magglish", "AtlasLootItems" };
	AtlasLoot_TableNames["WCTrigoretheLasher"] = { "Trigore the Lasher".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["WCBoahn"] = { "Boahn".." ("..AL["Rare"]..")", "AtlasLootItems" };
	AtlasLoot_TableNames["WCLordCobrahn"] = { "Lord Cobrahn", "AtlasLootItems" };
	AtlasLoot_TableNames["WCLadyAnacondra"] = { "Lady Anacondra", "AtlasLootItems" };
	AtlasLoot_TableNames["WCKresh"] = { "Kresh", "AtlasLootItems" };
	AtlasLoot_TableNames["WCLordPythas"] = { "Lord Pythas", "AtlasLootItems" };
	AtlasLoot_TableNames["WCSkum"] = { "Skum", "AtlasLootItems" };
	AtlasLoot_TableNames["WCLordSerpentis"] = { "Lord Serpentis", "AtlasLootItems" };
	AtlasLoot_TableNames["WCVerdan"] = { "Verdan the Everliving", "AtlasLootItems" };
	AtlasLoot_TableNames["WCMutanus"] = { "Mutanus the Devourer", "AtlasLootItems" };
	AtlasLoot_TableNames["WCDeviateFaerieDragon"] = { "Deviate Faerie Dragon", "AtlasLootItems" };
  --Zul'Farrak
	AtlasLoot_TableNames["ZFAntusul"] = { "Antu'sul", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFThekatheMartyr"] = { "Theka the Martyr", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFWitchDoctorZumrah"] = { "Witch Doctor Zum'rah", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFNekrumGutchewer"] = { "Nekrum Gutchewer", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFSezzziz"] = { "Shadowpriest Sezz'ziz", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFDustwraith"] = { "Dustwraith", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFSergeantBly"] = { "Sergeant Bly", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFSandfury"] = { "Sandfury Executioner", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFHydromancerVelratha"] = { "Hydromancer Velratha", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFGahzrilla"] = { "Gahz'rilla", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFChiefUkorzSandscalp"] = { "Chief Ukorz Sandscalp", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFZerillis"] = { "Zerillis", "AtlasLootItems" };
	AtlasLoot_TableNames["ZFTrash"] = { AL["Trash Mobs"].." (".."Zul'Farrak"..")", "AtlasLootItems" };
  --Zul'Gurub
	AtlasLoot_TableNames["ZGJeklik"] = { "High Priestess Jeklik", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGVenoxis"] = { "High Priest Venoxis", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGMarli"] = { "High Priestess Mar'li", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGMandokir"] = { "Bloodlord Mandokir", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGGrilek"] = { "Gri'lek", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGHazzarah"] = { "Hazza'rah", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGRenataki"] = { "Renataki", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGWushoolay"] = { "Wushoolay", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGGahzranka"] = { "Gahz'ranka", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGThekal"] = { "High Priest Thekal", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGArlokk"] = { "High Priestess Arlokk", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGJindo"] = { "Jin'do the Hexxer", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGHakkar"] = { "Hakkar", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGMuddyChurningWaters"] = { "Muddy Churning Waters", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGShared"] = { "Shared ZG Priest Drops", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGTrash1"] = { AL["Trash Mobs"].." (".."Zul'Gurub"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGTrash2"] = { AL["Trash Mobs"].." (".."Zul'Gurub"..")", "AtlasLootItems" };
	AtlasLoot_TableNames["ZGEnchants"] = { "ZG Enchants", "AtlasLootItems" };

------------
--- Sets ---
------------

  --Arena PvP Sets, Season 1
	AtlasLoot_TableNames["ArenaDruid"] = { "Druid".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaHunter"] = { "Hunter".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaMage"] = { "Mage".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaPaladin"] = { "Paladin".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaPriest"] = { "Priest".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaRogue"] = { "Rogue".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaShaman"] = { "Shaman".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaWarlock"] = { "Warlock".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["ArenaWarrior"] = { "Warrior".." - "..AL["Arena PvP Sets"], "AtlasLootGeneralPvPItems" };
  --Arena PvP Sets, Season 2
	AtlasLoot_TableNames["Arena2Druid"] = { "Druid".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Hunter"] = { "Hunter".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Mage"] = { "Mage".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Paladin"] = { "Paladin".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Priest"] = { "Priest".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Rogue"] = { "Rogue".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Shaman"] = { "Shaman".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Warlock"] = { "Warlock".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Warrior"] = { "Warrior".." - "..AL["Arena 2 PvP Sets"], "AtlasLootGeneralPvPItems" };
  --Arena PvP Sets, Season 3
	AtlasLoot_TableNames["Arena3Druid"] = { "Druid".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Hunter"] = { "Hunter".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Mage"] = { "Mage".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Paladin"] = { "Paladin".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Priest"] = { "Priest".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Rogue"] = { "Rogue".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Shaman"] = { "Shaman".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Warlock"] = { "Warlock".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Warrior"] = { "Warrior".." - "..AL["Arena 3 PvP Sets"], "AtlasLootGeneralPvPItems" };
  --Arena PvP Sets, Season 4
	AtlasLoot_TableNames["Arena4Druid"] = { "Druid".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Hunter"] = { "Hunter".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Mage"] = { "Mage".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Paladin"] = { "Paladin".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Priest"] = { "Priest".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Rogue"] = { "Rogue".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Shaman"] = { "Shaman".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Warlock"] = { "Warlock".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Warrior"] = { "Warrior".." - "..AL["Arena 4 PvP Sets"], "AtlasLootGeneralPvPItems" };
  --Level 60 PvP Sets
	AtlasLoot_TableNames["PVPDruid"] = { "Druid".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPHunter"] = { "Hunter".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPMage"] = { "Mage".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPPaladin"] = { "Paladin".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPPriest"] = { "Priest".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPRogue"] = { "Rogue".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPShaman"] = { "Shaman".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPWarlock"] = { "Warlock".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPWarrior"] = { "Warrior".." - "..AL["PvP Sets (Level 60)"], "AtlasLootGeneralPvPItems" };
  --Level 70 PvP Reputation Sets
	AtlasLoot_TableNames["PVP70RepDruid"] = { "Druid".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepHunter"] = { "Hunter".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepMage"] = { "Mage".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepPaladin"] = { "Paladin".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepPriest"] = { "Priest".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepRogue"] = { "Rogue".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepShaman"] = { "Shaman".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepWarlock"] = { "Warlock".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVP70RepWarrior"] = { "Warrior".." - "..AL["PvP Reputation Sets"], "AtlasLootGeneralPvPItems" };
  --Vanilla WoW Sets
	AtlasLoot_TableNames["VWOWDeadmines"] = { AL["Defias Leather"], "AtlasLootItems" };
	AtlasLoot_TableNames["VWOWWailingC"] = { AL["Embrace of the Viper"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWScarletM"] = { AL["Chain of the Scarlet Crusade"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWBlackrockD"] = { AL["The Gladiator"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWIronweave"] = { AL["Ironweave Battlesuit"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWScholo"] = { "Scholomance", "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWStrat"] = { AL["The Postmaster"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWScourgeInvasion"] = { AL["Scourge Invasion"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWSpiderKiss"] = { AL["Spider's Kiss"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWDalRend"] = { AL["Dal'Rend's Arms"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWZulGurub"] = { "Zul'Gurub", "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWShardOfGods"] = { AL["Shard of the Gods"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["VWOWSpiritofEskhandar"] = { AL["Spirit of Eskhandar"], "AtlasLootSetItems" };
  --The Burning Crusade Sets
	AtlasLoot_TableNames["TBCSets"] = { AL["Burning Crusade"], "AtlasLootSetItems" };
  --Crafted Sets - Blacksmithing
	AtlasLoot_TableNames["ImperialPlate"] = { AL["Imperial Plate"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TheDarksoul"] = { AL["The Darksoul"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FelIronPlate"] = { AL["Fel Iron Plate"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["AdamantiteB"] = { AL["Adamantite Battlegear"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FlameG"] = { AL["Flame Guard"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantedAdaman"] = { AL["Enchanted Adamantite Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["KhoriumWard"] = { AL["Khorium Ward"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FaithFelsteel"] = { AL["Faith in Felsteel"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BurningRage"] = { AL["Burning Rage"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BloodsoulEmbrace"] = { AL["Bloodsoul Embrace"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FelIronChain"] = { AL["Fel Iron Chain"], "AtlasLootCrafting" };
  --Crafted Sets - Tailoring
	AtlasLoot_TableNames["BloodvineG"] = { AL["Bloodvine Garb"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["NeatherVest"] = { AL["Netherweave Vestments"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["ImbuedNeather"] = { AL["Imbued Netherweave"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["ArcanoVest"] = { AL["Arcanoweave Vestments"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TheUnyielding"] = { AL["The Unyielding"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["WhitemendWis"] = { AL["Whitemend Wisdom"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["SpellstrikeInfu"] = { AL["Spellstrike Infusion"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BattlecastG"] = { AL["Battlecast Garb"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["SoulclothEm"] = { AL["Soulcloth Embrace"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["PrimalMoon"] = { AL["Primal Mooncloth"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["ShadowEmbrace"] = { AL["Shadow's Embrace"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["SpellfireWrath"] = { AL["Wrath of Spellfire"], "AtlasLootCrafting" };
  --Crafted Sets - Leatherworking
	AtlasLoot_TableNames["VolcanicArmor"] = { AL["Volcanic Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["IronfeatherArmor"] = { AL["Ironfeather Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["StormshroudArmor"] = { AL["Stormshroud Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["DevilsaurArmor"] = { AL["Devilsaur Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BloodTigerH"] = { AL["Blood Tiger Harness"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["PrimalBatskin"] = { AL["Primal Batskin"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["WildDraenishA"] = { AL["Wild Draenish Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["ThickDraenicA"] = { AL["Thick Draenic Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FelSkin"] = { AL["Fel Skin"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["SClefthoof"] = { AL["Strength of the Clefthoof"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["GreenDragonM"] = { AL["Green Dragon Mail"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlueDragonM"] = { AL["Blue Dragon Mail"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlackDragonM"] = { AL["Black Dragon Mail"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["ScaledDraenicA"] = { AL["Scaled Draenic Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FelscaleArmor"] = { AL["Felscale Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["FelstalkerArmor"] = { AL["Felstalker Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["NetherFury"] = { AL["Fury of the Nether"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["PrimalIntent"] = { AL["Primal Intent"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["WindhawkArmor"] = { AL["Windhawk Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["NetherscaleArmor"] = { AL["Netherscale Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["NetherstrikeArmor"] = { AL["Netherstrike Armor"], "AtlasLootCrafting" };
  --ZG Sets
	AtlasLoot_TableNames["ZGDruid"] = { "Druid".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGHunter"] = { "Hunter".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGMage"] = { "Mage".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGPaladin"] = { "Paladin".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGPriest"] = { "Priest".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGRogue"] = { "Rogue".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGShaman"] = { "Shaman".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGWarlock"] = { "Warlock".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["ZGWarrior"] = { "Warrior".." - "..AL["ZG Class Sets"], "AtlasLootSetItems" };
  --AQ20 Sets
	AtlasLoot_TableNames["AQ20Sets1"] = { AL["AQ20 Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["AQ20Sets2"] = { AL["AQ20 Class Sets"], "AtlasLootSetItems" };
  --AQ40 Sets
	AtlasLoot_TableNames["AQ40Sets1"] = { AL["AQ40 Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["AQ40Sets2"] = { AL["AQ40 Class Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["AQ40Sets3"] = { AL["AQ40 Class Sets"], "AtlasLootSetItems" };
  --Dungeon Set 1/2
	AtlasLoot_TableNames["T0Druid"] = { "Druid".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Hunter"] = { "Hunter".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Mage"] = { "Mage".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Paladin"] = { "Paladin".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Priest"] = { "Priest".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Rogue"] = { "Rogue".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Shaman"] = { "Shaman".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Warlock"] = { "Warlock".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T0Warrior"] = { "Warrior".." - "..AL["Dungeon 1/2 Sets"], "AtlasLootSetItems" };
  --Dungeon Set 3
	AtlasLoot_TableNames["DS3Cloth"] = { AL["Dungeon Set 3"].." - ".."Cloth", "AtlasLootSetItems" };
	AtlasLoot_TableNames["DS3Leather"] = { AL["Dungeon Set 3"].." - ".."Leather", "AtlasLootSetItems" };
	AtlasLoot_TableNames["DS3Mail"] = { AL["Dungeon Set 3"].." - ".."Mail", "AtlasLootSetItems" };
	AtlasLoot_TableNames["DS3Plate"] = { AL["Dungeon Set 3"].." - ".."Plate", "AtlasLootSetItems" };
  --T1/2Sets
	AtlasLoot_TableNames["T1T2Druid"] = { "Druid".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Hunter"] = { "Hunter".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Mage"] = { "Mage".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Paladin"] = { "Paladin".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Priest"] = { "Priest".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Rogue"] = { "Rogue".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Shaman"] = { "Shaman".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Warlock"] = { "Warlock".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T1T2Warrior"] = { "Warrior".." - "..AL["Tier 1/2 Sets"], "AtlasLootSetItems" };
  --T3 Sets
	AtlasLoot_TableNames["T3Druid"] = { "Druid".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Hunter"] = { "Hunter".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Mage"] = { "Mage".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Paladin"] = { "Paladin".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Priest"] = { "Priest".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Rogue"] = { "Rogue".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Shaman"] = { "Shaman".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Warlock"] = { "Warlock".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T3Warrior"] = { "Warrior".." - "..AL["Tier 3 Sets"], "AtlasLootSetItems" };
  --T4 Sets
	AtlasLoot_TableNames["T4Druid"] = { "Druid".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Hunter"] = { "Hunter".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Mage"] = { "Mage".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Paladin"] = { "Paladin".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Priest"] = { "Priest".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Rogue"] = { "Rogue".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Shaman"] = { "Shaman".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Warlock"] = { "Warlock".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T4Warrior"] = { "Warrior".." - "..AL["Tier 4 Sets"], "AtlasLootSetItems" };
  --T5 Sets
	AtlasLoot_TableNames["T5Druid"] = { "Druid".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Hunter"] = { "Hunter".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Mage"] = { "Mage".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Paladin"] = { "Paladin".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Priest"] = { "Priest".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Rogue"] = { "Rogue".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Shaman"] = { "Shaman".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Warlock"] = { "Warlock".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T5Warrior"] = { "Warrior".." - "..AL["Tier 5 Sets"], "AtlasLootSetItems" };
  --T6 Sets
	AtlasLoot_TableNames["T6Druid"] = { "Druid".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Druid2"] = { "Druid".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Hunter"] = { "Hunter".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Mage"] = { "Mage".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Paladin"] = { "Paladin".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Paladin2"] = { "Paladin".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Priest"] = { "Priest".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Rogue"] = { "Rogue".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Shaman"] = { "Shaman".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Shaman2"] = { "Shaman".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Warlock"] = { "Warlock".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["T6Warrior"] = { "Warrior".." - "..AL["Tier 6 Sets"], "AtlasLootSetItems" };

------------------------
--- Misc Collections ---
------------------------

	AtlasLoot_TableNames["BlizzardCollectables1"] = { "Blizzard Collectables", "AtlasLootSetItems" };
	AtlasLoot_TableNames["CraftedWeapons1"] = { AL["Crafted Epic Weapons"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["CraftedWeapons2"] = { AL["Crafted Epic Weapons"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["HardModeCloth"] = { AL["Badge of Justice Rewards"].." - ".."Cloth", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeLeather"] = { AL["Badge of Justice Rewards"].." - ".."Leather", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeLeather2"] = { AL["Badge of Justice Rewards"].." - ".."Leather", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeMail"] = { AL["Badge of Justice Rewards"].." - ".."Mail", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModePlate"] = { AL["Badge of Justice Rewards"].." - ".."Plate", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModePlate2"] = { AL["Badge of Justice Rewards"].." - ".."Plate", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeCloaks"] = { AL["Badge of Justice Rewards"].." - ".."Back", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeResist"] = { AL["Badge of Justice Rewards"].." - "..AL["Fire Resistance Gear"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeAccessories"] = { AL["Badge of Justice Rewards"].." - "..AL["Accessories"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeAccessories2"] = { AL["Badge of Justice Rewards"].." - "..AL["Accessories"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeRelic"] = { AL["Badge of Justice Rewards"].." - ".."Relic", "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeWeapons"] = { AL["Badge of Justice Rewards"].." - "..AL["Weapons"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeArena"] = { AL["Badge of Justice Rewards"].." - "..AL["Arena Reward"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["HardModeArena2"] = { AL["Badge of Justice Rewards"].." - "..AL["Arena Reward"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["Legendaries"] = { AL["Legendary Items"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["RareMounts1"] = { AL["Rare Mounts"].." - The Burning Crusade", "AtlasLootSetItems" };
	AtlasLoot_TableNames["RareMounts2"] = { AL["Rare Mounts"].." - Classic WoW", "AtlasLootSetItems" };
	AtlasLoot_TableNames["Tabards1"] = { AL["Tabards"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["Tabards2"] = { AL["Tabards"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["CardGame1"] = { AL["Upper Deck Card Game Items"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["CardGame2"] = { AL["Upper Deck Card Game Items"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["WorldEpics1"] = { AL["BoE World Epics"].." - "..AL["Level 30-39"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["WorldEpics2"] = { AL["BoE World Epics"].." - "..AL["Level 40-49"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["WorldEpics3"] = { AL["BoE World Epics"].." - "..AL["Level 50-60"], "AtlasLootSetItems" };
	AtlasLoot_TableNames["WorldEpics4"] = { AL["BoE World Epics"].." - "..AL["Level 70"], "AtlasLootSetItems" };

--------------------
--- World Bosses ---
--------------------

  --Azuregos
	AtlasLoot_TableNames["AAzuregos"] = { "Azuregos", "AtlasLootWBItems" };
  --Doom Lord Kazzak
	AtlasLoot_TableNames["DoomLordKazzak"] = { "Doom Lord Kazzak", "AtlasLootWBItems" };
  --Doomwalker
	AtlasLoot_TableNames["DDoomwalker"] = { "Doomwalker", "AtlasLootWBItems" };
  --Emrald Dragons
	AtlasLoot_TableNames["DEmeriss"] = { "Emeriss", "AtlasLootWBItems" };
	AtlasLoot_TableNames["DLethon"] = { "Lethon", "AtlasLootWBItems" };
	AtlasLoot_TableNames["DTaerar"] = { "Taerar", "AtlasLootWBItems" };
	AtlasLoot_TableNames["DYsondre"] = { "Ysondre", "AtlasLootWBItems" };
  --Highlord Kruul
	AtlasLoot_TableNames["KKruul"] = { AL["Highlord Kruul"], "AtlasLootWBItems" };

--------------
--- Events ---
--------------

  --Abyssal Council
	AtlasLoot_TableNames["Templars"] = { "Abyssal Council - Templars", "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Dukes"] = { "Abyssal Council - Dukes", "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["HighCouncil"] = { "Abyssal Council - High Council", "AtlasLootWorldEvents" };
  --Ethereum Prison
	AtlasLoot_TableNames["ArmbreakerHuffaz"] = { AL["Armbreaker Huffaz"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["FelTinkererZortan"] = { AL["Fel Tinkerer Zortan"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Forgosh"] = { AL["Forgosh"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Gulbor"] = { AL["Gul'bor"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["MalevustheMad"] = { AL["Malevus the Mad"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["PorfustheGemGorger"] = { AL["Porfus the Gem Gorger"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["WrathbringerLaztarash"] = { AL["Wrathbringer Laz-tarash"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["BashirStasisChambers"] = { AL["Bash'ir Landing Stasis Chambers"], "AtlasLootWorldEvents" };
  --Seasonal
	AtlasLoot_TableNames["Brewfest1"] = { AL["Brewfest"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Brewfest2"] = { AL["Brewfest"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["CorenDirebrew"] = { AL["Coren Direbrew"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["ChildrensWeek"] = { AL["Children's Week"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Halloween1"] = { AL["Hallow's End"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Halloween2"] = { AL["Hallow's End"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["HeadlessHorseman"] = { AL["Headless Horseman"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["HarvestFestival"] = { AL["Harvest Festival"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["LunarFestival1"] = { AL["Lunar Festival"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["LunarFestival2"] = { AL["Lunar Festival"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["MidsummerFestival"] = { AL["Midsummer Fire Festival"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["LordAhune"] = { AL["Lord Ahune"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["LordAhuneHEROIC"] = { AL["Lord Ahune"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Noblegarden"] = { AL["Noblegarden"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Valentineday"] = { AL["Love is in the Air"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Winterviel1"] = { AL["Feast of Winter Veil"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Winterviel2"] = { AL["Feast of Winter Veil"], "AtlasLootWorldEvents" };
  --Skettis
	AtlasLoot_TableNames["DarkscreecherAkkarai"] = { AL["Darkscreecher Akkarai"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Karrog"] = { AL["Karrog"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["GezzaraktheHuntress"] = { AL["Gezzarak the Huntress"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["VakkiztheWindrager"] = { AL["Vakkiz the Windrager"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Terokk"] = { AL["Terokk"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["SkettisTalonpriestIshaal"] = { "Talonpriest Ishaal", "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["SkettisHazziksPackage"] = { "Hazzik's Package", "AtlasLootWorldEvents" };
  --Other
	AtlasLoot_TableNames["BashirLanding"] = { AL["Bash'ir Landing Skyguard Raid"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["ElementalInvasion"] = { AL["Elemental Invasion"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["FishingExtravaganza"] = { AL["Stranglethorn Fishing Extravaganza"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["GurubashiArena"] = { AL["Gurubashi Arena Booty Run"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["ScourgeInvasionEvent1"] = { AL["Scourge Invasion"], "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["ScourgeInvasionEvent2"] = { "Scourge Invasion Bosses", "AtlasLootWorldEvents" };
	AtlasLoot_TableNames["Shartuul"] = { AL["Shartuul"], "AtlasLootWorldEvents" };
	
----------------------
--- WotLK Factions ---
----------------------
	
-------------------
--- BC Factions ---
-------------------

  --The Aldor
	AtlasLoot_TableNames["Aldor1"] = { "The Aldor"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Aldor2"] = { "The Aldor"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --Ashtongue Deathsworn
	AtlasLoot_TableNames["Ashtongue1"] = { "Ashtongue Deathsworn", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Ashtongue2"] = { "Ashtongue Deathsworn", "AtlasLootRepItems" };
  --Cenarion Expedition
	AtlasLoot_TableNames["CExpedition1"] = { "Cenarion Expedition"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["CExpedition2"] = { "Cenarion Expedition"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --The Consortium
	AtlasLoot_TableNames["Consortium1"] = { "The Consortium"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Consortium2"] = { "The Consortium"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --Honor Hold
	AtlasLoot_TableNames["HonorHold1"] = { "Honor Hold"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["HonorHold2"] = { "Honor Hold"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --Keepers of Time
	AtlasLoot_TableNames["KeepersofTime1"] = { "Keepers of Time", "AtlasLootRepItems" };
  --Kurenai
	AtlasLoot_TableNames["Kurenai1"] = { "Kurenai", "AtlasLootRepItems" };
  --Lower City
	AtlasLoot_TableNames["LowerCity1"] = { "Lower City", "AtlasLootRepItems" };
  --Netherwing
	AtlasLoot_TableNames["Netherwing1"] = { "Netherwing", "AtlasLootRepItems" };
  --Ogri'la
	AtlasLoot_TableNames["Ogrila1"] = { "Ogri'la", "AtlasLootRepItems" };
  --The Scale of the Sands
	AtlasLoot_TableNames["ScaleSands1"] = { "The Scale of the Sands", "AtlasLootRepItems" };
	AtlasLoot_TableNames["ScaleSands2"] = { "The Scale of the Sands", "AtlasLootRepItems" };
  --The Scryers
	AtlasLoot_TableNames["Scryer1"] = { "The Scryers"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Scryer2"] = { "The Scryers"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --The Sha'tar
	AtlasLoot_TableNames["Shatar1"] = { "The Sha'tar", "AtlasLootRepItems" };
  --Exalted with Cenarion Expedition, The Sha'tar and The Aldor/Scryers
	AtlasLoot_TableNames["ShattrathFlasks1"] = { "Shattrath Flasks", "AtlasLootRepItems" };
  --Sha'tari Skyguard
	AtlasLoot_TableNames["Skyguard1"] = { "Sha'tari Skyguard", "AtlasLootRepItems" };
  --Shattered Sun Offensive
	AtlasLoot_TableNames["SunOffensive1"] = { "Shattered Sun Offensive"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["SunOffensive2"] = { "Shattered Sun Offensive"..": ".."Revered", "AtlasLootRepItems" };
	AtlasLoot_TableNames["SunOffensive3"] = { "Shattered Sun Offensive"..": ".."Exalted", "AtlasLootRepItems" };
  --Sporeggar
	AtlasLoot_TableNames["Sporeggar1"] = { "Sporeggar", "AtlasLootRepItems" };
  --Thrallmar
	AtlasLoot_TableNames["Thrallmar1"] = { "Thrallmar"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Thrallmar2"] = { "Thrallmar"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --Tranquillien
	AtlasLoot_TableNames["Tranquillien1"] = { "Tranquillien", "AtlasLootRepItems" };
  --The Violet Eye
	AtlasLoot_TableNames["VioletEye1"] = { "The Violet Eye", "AtlasLootRepItems" };

------------------------
--- Classic Factions ---
------------------------

  --Argent Dawn
	AtlasLoot_TableNames["Argent1"] = { "Argent Dawn"..": Token Hand-ins", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Argent2"] = { "Argent Dawn", "AtlasLootRepItems" };
  --Bloodsail Buccaneers
	AtlasLoot_TableNames["Bloodsail1"] = { "Bloodsail Buccaneers", "AtlasLootRepItems" };
  --Brood of Nozdormu
	AtlasLoot_TableNames["AQBroodRings"] = { "Brood of Nozdormu", "AtlasLootRepItems" };
  --Cenarion Circle
	AtlasLoot_TableNames["Cenarion1"] = { "Cenarion Circle"..": ".."Friendly", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Cenarion2"] = { "Cenarion Circle"..": ".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Cenarion3"] = { "Cenarion Circle"..": ".."Revered", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Cenarion4"] = { "Cenarion Circle"..": ".."Exalted", "AtlasLootRepItems" };
  --The Darkmoon Faire
	AtlasLoot_TableNames["Darkmoon1"] = { "Darkmoon Faire", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Darkmoon2"] = { "Darkmoon Faire".." - ".."Trinket", "AtlasLootRepItems" };
  --The Defilers
	AtlasLoot_TableNames["Defilers"] = { "The Defilers", "AtlasLootRepItems" };
  --Frostwolf Clan
	AtlasLoot_TableNames["Frostwolf1"] = { "Frostwolf Clan", "AtlasLootRepItems" };
  --Hydraxian Waterlords
	AtlasLoot_TableNames["WaterLords1"] = { "Hydraxian Waterlords", "AtlasLootRepItems" };
  --Gelkis Clan Centaur
	AtlasLoot_TableNames["GelkisClan1"] = { "Gelkis Clan Centaur", "AtlasLootRepItems" };
  --The League of Arathor
	AtlasLoot_TableNames["LeagueofArathor"] = { "The League of Arathor", "AtlasLootRepItems" };
  --The Mag'har
	AtlasLoot_TableNames["Maghar1"] = { "The Mag'har", "AtlasLootRepItems" };
  --Magram Clan Centaur
	AtlasLoot_TableNames["MagramClan1"] = { "Magram Clan Centaur", "AtlasLootRepItems" };
  --Stormpike Guard
	AtlasLoot_TableNames["Stormpike1"] = { "Stormpike Guard", "AtlasLootRepItems" };
  --Thorium Brotherhood
	AtlasLoot_TableNames["Thorium1"] = { "Thorium Brotherhood"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Thorium2"] = { "Thorium Brotherhood"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };
  --Timbermaw Hold
	AtlasLoot_TableNames["Timbermaw"] = { "Timbermaw Hold", "AtlasLootRepItems" };
  --Wintersaber Trainers
	AtlasLoot_TableNames["Wintersaber1"] = { "Wintersaber Trainers", "AtlasLootRepItems" };
  --Zandalar Tribe
	AtlasLoot_TableNames["Zandalar1"] = { "Zandalar Tribe"..": ".."Friendly".."/".."Honored", "AtlasLootRepItems" };
	AtlasLoot_TableNames["Zandalar2"] = { "Zandalar Tribe"..": ".."Revered".."/".."Exalted", "AtlasLootRepItems" };

--------------
--- Trades ---
--------------

  --Alchemy
	AtlasLoot_TableNames["AlchemyApprentice1"] = { ALCHEMY..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyJourneyman1"] = { ALCHEMY..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyExpert1"] = { ALCHEMY..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyArtisan1"] = { ALCHEMY..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyArtisan2"] = { ALCHEMY..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyMaster1"] = { ALCHEMY..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyMaster2"] = { ALCHEMY..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyMaster3"] = { ALCHEMY..": "..MASTER, "AtlasLootCrafting" };
  --BlackSmithing
	AtlasLoot_TableNames["SmithingApprentice1"] = { BLACKSMITHING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingJourneyman1"] = { BLACKSMITHING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingExpert1"] = { BLACKSMITHING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingExpert2"] = { BLACKSMITHING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArtisan1"] = { BLACKSMITHING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArtisan2"] = { BLACKSMITHING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster1"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster2"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster3"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster4"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster5"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster6"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster7"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMaster8"] = { BLACKSMITHING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Armorsmith1"] = { ARMORSMITH, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Weaponsmith1"] = { WEAPONSMITH, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Axesmith1"] = { AXESMITH, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Hammersmith1"] = { HAMMERSMITH, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Swordsmith1"] = { SWORDSMITH, "AtlasLootCrafting" };
  --Enchanting
	AtlasLoot_TableNames["EnchantingApprentice1"] = { ENCHANTING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingJourneyman1"] = { ENCHANTING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingExpert1"] = { ENCHANTING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingExpert2"] = { ENCHANTING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingArtisan1"] = { ENCHANTING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingArtisan2"] = { ENCHANTING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingMaster1"] = { ENCHANTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingMaster2"] = { ENCHANTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingMaster3"] = { ENCHANTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingMaster4"] = { ENCHANTING..": "..MASTER, "AtlasLootCrafting" };
  --Engineering
	AtlasLoot_TableNames["EngineeringApprentice1"] = { ENGINEERING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringJourneyman1"] = { ENGINEERING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringExpert1"] = { ENGINEERING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringExpert2"] = { ENGINEERING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArtisan1"] = { ENGINEERING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArtisan2"] = { ENGINEERING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArtisan3"] = { ENGINEERING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMaster1"] = { ENGINEERING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMaster2"] = { ENGINEERING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMaster3"] = { ENGINEERING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMaster4"] = { ENGINEERING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Gnomish1"] = { GNOMISH, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Goblin1"] = { GOBLIN, "AtlasLootCrafting" };
  --Jewelcrafing
	AtlasLoot_TableNames["JewelApprentice1"] = { JEWELCRAFTING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelJourneyman1"] = { JEWELCRAFTING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelExpert1"] = { JEWELCRAFTING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelArtisan1"] = { JEWELCRAFTING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster1"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster2"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster3"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster4"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster5"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster6"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMaster7"] = { JEWELCRAFTING..": "..MASTER, "AtlasLootCrafting" };
  --Leatherworking
	AtlasLoot_TableNames["LeatherApprentice1"] = { LEATHERWORKING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherJourneyman1"] = { LEATHERWORKING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherJourneyman2"] = { LEATHERWORKING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherExpert1"] = { LEATHERWORKING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherExpert2"] = { LEATHERWORKING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherArtisan1"] = { LEATHERWORKING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherArtisan2"] = { LEATHERWORKING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster1"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster2"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster3"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster4"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster5"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster6"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster7"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMaster8"] = { LEATHERWORKING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Dragonscale1"] = { DRAGONSCALE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Elemental1"] = { ELEMENTAL, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Tribal1"] = { TRIBAL, "AtlasLootCrafting" };
  --Mining
	AtlasLoot_TableNames["Mining1"] = { MINING, "AtlasLootCrafting" };
  --Tailoring
	AtlasLoot_TableNames["TailoringApprentice1"] = { TAILORING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringJourneyman1"] = { TAILORING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringJourneyman2"] = { TAILORING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringExpert1"] = { TAILORING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringExpert2"] = { TAILORING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArtisan1"] = { TAILORING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArtisan2"] = { TAILORING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArtisan3"] = { TAILORING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMaster1"] = { TAILORING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMaster2"] = { TAILORING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMaster3"] = { TAILORING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMaster4"] = { TAILORING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMaster5"] = { TAILORING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMaster6"] = { TAILORING..": "..MASTER, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Mooncloth1"] = { MOONCLOTH, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Shadoweave1"] = { SHADOWEAVE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["Spellfire1"] = { SPELLFIRE, "AtlasLootCrafting" };
  --Cooking
	AtlasLoot_TableNames["CookingApprentice1"] = { COOKING..": "..APPRENTICE, "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingJourneyman1"] = { COOKING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingJourneyman2"] = { COOKING..": "..JOURNEYMAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingExpert1"] = { COOKING..": "..EXPERT, "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingArtisan1"] = { COOKING..": "..ARTISAN, "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingMaster1"] = { COOKING..": "..MASTER, "AtlasLootCrafting" };
  --FirstAid
	AtlasLoot_TableNames["FirstAid1"] = { FIRSTAID, "AtlasLootCrafting" };
	
-----------
--- PvP ---
-----------

  --Battlegrounds
   --Alterac Valley
	AtlasLoot_TableNames["AVMisc"] = { "Alterac Valley".." "..AL["Misc. Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AVBlue"] = { "Alterac Valley".." "..AL["Superior Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AVPurple"] = { "Alterac Valley".." "..AL["Epic Rewards"], "AtlasLootBGItems" };
   --Arathi Basin
	AtlasLoot_TableNames["ABMisc"] = { "Arathi Basin".." "..AL["Misc. Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB20291"] = { "Arathi Basin".." "..AL["Level 20-29 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB20292"] = { "Arathi Basin".." "..AL["Level 20-29 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB3039"] = { "Arathi Basin".." "..AL["Level 30-39 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB40491"] = { "Arathi Basin".." "..AL["Level 40-49 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB40492"] = { "Arathi Basin".." "..AL["Level 40-49 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB5059"] = { "Arathi Basin".." "..AL["Level 50-59 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["AB60"] = { "Arathi Basin".." "..AL["Level 60 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["ABSets1"] = { "Arathi Basin".." "..AL["PvP Armor Sets"].." (".."Cloth".."/".."Leather"..")", "AtlasLootBGItems" };
	AtlasLoot_TableNames["ABSets2"] = { "Arathi Basin".." "..AL["PvP Armor Sets"].." (".."Mail"..")", "AtlasLootBGItems" };
	AtlasLoot_TableNames["ABSets3"] = { "Arathi Basin".." "..AL["PvP Armor Sets"].." (".."Plate"..")", "AtlasLootBGItems" };
   --Warsong Gulch
	AtlasLoot_TableNames["WSGMisc"] = { "Warsong Gulch".." "..AL["Misc. Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["WSG1019"] = { "Warsong Gulch".." "..AL["Level 10-19 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["WSG2029"] = { "Warsong Gulch".." "..AL["Level 20-29 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["WSG3039"] = { "Warsong Gulch".." "..AL["Level 30-39 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["WSG4049"] = { "Warsong Gulch".." "..AL["Level 40-49 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["WSG5059"] = { "Warsong Gulch".." "..AL["Level 50-59 Rewards"], "AtlasLootBGItems" };
	AtlasLoot_TableNames["WSG60"] = { "Warsong Gulch".." "..AL["Level 60 Rewards"], "AtlasLootBGItems" };
  --World PvP
	AtlasLoot_TableNames["Hellfire"] = { "Hellfire Peninsula"..": "..AL["Hellfire Fortifications"], "AtlasLootWorldPvPItems" };
	AtlasLoot_TableNames["Nagrand1"] = { "Nagrand"..": "..AL["Halaa"], "AtlasLootWorldPvPItems" };
	AtlasLoot_TableNames["Nagrand2"] = { "Nagrand"..": "..AL["Halaa"], "AtlasLootWorldPvPItems" };
	AtlasLoot_TableNames["Terokkar"] = { "Terokkar Forest"..": "..AL["Spirit Towers"], "AtlasLootWorldPvPItems" };
	AtlasLoot_TableNames["Zangarmarsh"] = { "Zangarmarsh"..": "..AL["Twin Spire Ruins"], "AtlasLootWorldPvPItems" };
  --Misc Other PvP
	AtlasLoot_TableNames["PvP60Accessories1"] = { AL["PvP Accessories (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP60Accessories2"] = { AL["PvP Accessories - Alliance (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP60Accessories3"] = { AL["PvP Accessories - Horde (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70Accessories1"] = { AL["PvP Accessories (Level 70)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70Accessories2"] = { AL["PvP Accessories (Level 70)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70NonSet1"] = { AL["PvP Non-Set Epics"]..": "..AL["Accessories"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70NonSet2"] = { AL["PvP Non-Set Epics"]..": ".."Cloth", "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70NonSet3"] = { AL["PvP Non-Set Epics"]..": ".."Leather", "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70NonSet4"] = { AL["PvP Non-Set Epics"]..": ".."Mail", "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PvP70NonSet5"] = { AL["PvP Non-Set Epics"]..": ".."Plate", "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPWeapons1"] = { AL["PvP Weapons (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["PVPWeapons2"] = { AL["PvP Weapons (Level 60)"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Weapons1"] = { AL["Arena Season 2 Weapons"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena2Weapons2"] = { AL["Arena Season 2 Weapons"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Weapons1"] = { AL["Arena Season 3 Weapons"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena3Weapons2"] = { AL["Arena Season 3 Weapons"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Weapons1"] = { AL["Arena Season 4 Weapons"], "AtlasLootGeneralPvPItems" };
	AtlasLoot_TableNames["Arena4Weapons2"] = { AL["Arena Season 4 Weapons"], "AtlasLootGeneralPvPItems" };

-------------
--- Other ---
-------------

  --Menus, the entry does nothing, but makes the generalised loot table code less complex
	AtlasLoot_TableNames["ABMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["AQ40SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["AQ20SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ZGSET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["PRE60SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTSET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTSETCLOTH"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTSETLEATHER"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTSETMAIL"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTSETPLATE"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTSET2"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["T6SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["T5SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["T4SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["T3SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["T1T2SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["T0SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["DS3SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["PVPSET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["PVPMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["CRAFTINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["PVP70RepSET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["PVP70NONSETEPICS"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ARENASET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ARENA2SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ARENA3SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ARENA4SET"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["REPMENU_AZEROTHPREBC"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["REPMENU_AZEROTHPOSTBC"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["REPMENU_OUTLAND"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["REPMENU_SHATTRATH"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["REPMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["SETMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["SKETTISMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["70TOKENMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["WORLDEPICS"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["WORLDEVENTMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["WSGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ETHEREUMMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ABYSSALMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["HONORMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ARENAMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ALCHEMYMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["SMITHINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ENCHANTINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["ENGINEERINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["JEWELCRAFTINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["LEATHERWORKINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["MININGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["TAILORINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["COOKINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["FIRSTAIDMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["WishList"] = { AL["WishList"], "AtlasLootCharDB" };
  --If all else fails!
	AtlasLoot_TableNames["EmptyInstance"] = { "AtlasLoot", "AtlasLootFallback" };
-- Menu/dispatch IDs (Otari98 engine) registered as dummy so ShowBossLoot resolves them --
AtlasLoot_TableNames["ALCHEMYMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["AQ20SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["AQ40SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ARENASET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ARENA1SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ARENA2SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ARENA3SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ARENA4SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["CRAFTINGMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["CRAFTSET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["DUNGEONSMENU1"] = { "dummy", "dummy" };
AtlasLoot_TableNames["DUNGEONSMENU2"] = { "dummy", "dummy" };
AtlasLoot_TableNames["HOMEMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["CLASSICDUNGEONMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["CLASSICRAIDMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["TBCDUNGEONMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["TBCHEROICMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["TBCRAIDMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ENCHANTINGMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ENGINEERINGMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["FIRSTAIDMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["JEWELCRAFTMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["LEATHERWORKINGMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["PRE60SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["PVPMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["PVPSET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["PVP70REPSET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["PVPMENU2"] = { "dummy", "dummy" };
AtlasLoot_TableNames["REPMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["SETMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["SMITHINGMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["T0SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["T1SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["T2SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["T3SET"] = { "dummy", "dummy" };
AtlasLoot_TableNames["TAILORINGMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["WORLDBOSSMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["WORLDEVENTMENU"] = { "dummy", "dummy" };
AtlasLoot_TableNames["ZGSET"] = { "dummy", "dummy" };

-- WotLK crafting dataIDs
	AtlasLoot_TableNames["AlchemyBattleElixir1"] = { "Alchemy - Battle Elixir (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyBattleElixir2"] = { "Alchemy - Battle Elixir (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyFlask1"] = { "Alchemy - Flask", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyGuardianElixir1"] = { "Alchemy - Guardian Elixir", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyMisc1"] = { "Alchemy - Misc (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyMisc2"] = { "Alchemy - Misc (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyPotion1"] = { "Alchemy - Potion (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyPotion2"] = { "Alchemy - Potion (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyPotion3"] = { "Alchemy - Potion (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyTransmute1"] = { "Alchemy - Transmute (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["AlchemyTransmute2"] = { "Alchemy - Transmute (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorBC1"] = { "Blacksmithing - Armor BC (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorBC2"] = { "Blacksmithing - Armor BC (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorBC3"] = { "Blacksmithing - Armor BC (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorOld1"] = { "Blacksmithing - Armor Old (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorOld2"] = { "Blacksmithing - Armor Old (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorOld3"] = { "Blacksmithing - Armor Old (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorOld4"] = { "Blacksmithing - Armor Old (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorOld5"] = { "Blacksmithing - Armor Old (5)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorWrath1"] = { "Blacksmithing - Armor Wrath (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorWrath2"] = { "Blacksmithing - Armor Wrath (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorWrath3"] = { "Blacksmithing - Armor Wrath (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingArmorWrath4"] = { "Blacksmithing - Armor Wrath (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingEnhancement1"] = { "Blacksmithing - Enhancement (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingEnhancement2"] = { "Blacksmithing - Enhancement (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingMisc1"] = { "Blacksmithing - Misc", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingWeaponBC1"] = { "Blacksmithing - Weapon BC (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingWeaponBC2"] = { "Blacksmithing - Weapon BC (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingWeaponOld1"] = { "Blacksmithing - Weapon Old (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingWeaponOld2"] = { "Blacksmithing - Weapon Old (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingWeaponOld3"] = { "Blacksmithing - Weapon Old (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["SmithingWeaponWrath1"] = { "Blacksmithing - Weapon Wrath", "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingMailBloodsoulEmbrace"] = { AL["Bloodsoul Embrace"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingMailFelIronChain"] = { AL["Fel Iron Chain"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateAdamantiteB"] = { AL["Adamantite Battlegear"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateBurningRage"] = { AL["Burning Rage"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateEnchantedAdaman"] = { AL["Enchanted Adamantite Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateFaithFelsteel"] = { AL["Faith in Felsteel"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateFelIronPlate"] = { AL["Fel Iron Plate"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateFlameG"] = { AL["Flame Guard"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateImperialPlate"] = { AL["Imperial Plate"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateKhoriumWard"] = { AL["Khorium Ward"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateOrnateSaroniteBattlegear"] = { "Ornate Saronite Battlegear", "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateSavageSaroniteBattlegear"] = { "Savage Saronite Battlegear", "AtlasLootCrafting" };
	AtlasLoot_TableNames["BlacksmithingPlateTheDarksoul"] = { AL["The Darksoul"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Cooking1"] = { "Cooking - Cooking (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Cooking2"] = { "Cooking - Cooking (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Cooking3"] = { "Cooking - Cooking (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Cooking4"] = { "Cooking - Cooking (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Cooking5"] = { "Cooking - Cooking (5)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Cooking6"] = { "Cooking - Cooking (6)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingDaily1"] = { "Cooking - Daily (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["CookingDaily2"] = { "Cooking - Daily (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Enchanting2HWeapon1"] = { "Enchanting - 2HWeapon", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingBoots1"] = { "Enchanting - Boots", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingBracer1"] = { "Enchanting - Bracer (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingBracer2"] = { "Enchanting - Bracer (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingChest1"] = { "Enchanting - Chest (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingChest2"] = { "Enchanting - Chest (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingCloak1"] = { "Enchanting - Cloak (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingCloak2"] = { "Enchanting - Cloak (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingGloves1"] = { "Enchanting - Gloves (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingGloves2"] = { "Enchanting - Gloves (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingMisc1"] = { "Enchanting - Misc (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingMisc2"] = { "Enchanting - Misc (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingRing1"] = { "Enchanting - Ring", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingShield1"] = { "Enchanting - Shield", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingStaff1"] = { "Enchanting - Staff", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingWeapon1"] = { "Enchanting - Weapon (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EnchantingWeapon2"] = { "Enchanting - Weapon (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringAmmo1"] = { "Engineering - Ammo", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArmor1"] = { "Engineering - Armor (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArmor2"] = { "Engineering - Armor (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArmor3"] = { "Engineering - Armor (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringArmor4"] = { "Engineering - Armor (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringExplosives1"] = { "Engineering - Explosives (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringExplosives2"] = { "Engineering - Explosives (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringItemEnhancements1"] = { "Engineering - Item Enhancements", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMisc1"] = { "Engineering - Misc (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMisc2"] = { "Engineering - Misc (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringMisc3"] = { "Engineering - Misc (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringReagents1"] = { "Engineering - Reagents (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringReagents2"] = { "Engineering - Reagents (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["EngineeringWeapon1"] = { "Engineering - Weapon", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_DeathKnightMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Death Knight"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_DeathKnightMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Death Knight"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_DruidMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Druid"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_DruidMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Druid"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_HunterMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Hunter"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_HunterMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Hunter"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_MageMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Mage"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_MageMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Mage"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_Misc1"] = { AL["Inscription"]..": "..AL["Miscellaneous"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_OffHand1"] = { AL["Inscription"]..": "..AL["Off Hand"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_PaladinMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Paladin"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_PaladinMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Paladin"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_PriestMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Priest"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_PriestMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Priest"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_Reagents1"] = { AL["Inscription"]..": "..AL["Reagents"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_RogueMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Rogue"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_RogueMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Rogue"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_Scrolls1"] = { AL["Inscription"]..": "..AL["Scrolls"].." (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_Scrolls2"] = { AL["Inscription"]..": "..AL["Scrolls"].." (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_ShamanMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Shaman"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_ShamanMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Shaman"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_WarlockMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Warlock"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_WarlockMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Warlock"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_WarriorMajor1"] = { AL["Inscription"]..": "..AL["Major Glyph"].." - "..AL["Warrior"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["Inscription_WarriorMinor1"] = { AL["Inscription"]..": "..AL["Minor Glyph"].." - "..AL["Warrior"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelBlue1"] = { "Jewelcrafting - Blue", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelDragonsEye1"] = { "Jewelcrafting - Dragons Eye", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelGreen1"] = { "Jewelcrafting - Green (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelGreen2"] = { "Jewelcrafting - Green (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelGreen3"] = { "Jewelcrafting - Green (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMeta1"] = { "Jewelcrafting - Meta (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMeta2"] = { "Jewelcrafting - Meta (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelMisc1"] = { "Jewelcrafting - Misc", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelNeck1"] = { "Jewelcrafting - Neck (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelNeck2"] = { "Jewelcrafting - Neck (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelOrange1"] = { "Jewelcrafting - Orange (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelOrange2"] = { "Jewelcrafting - Orange (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelOrange3"] = { "Jewelcrafting - Orange (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelPrismatic1"] = { "Jewelcrafting - Prismatic", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelPurple1"] = { "Jewelcrafting - Purple (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelPurple2"] = { "Jewelcrafting - Purple (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelPurple3"] = { "Jewelcrafting - Purple (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelRed1"] = { "Jewelcrafting - Red (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelRed2"] = { "Jewelcrafting - Red (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelRing1"] = { "Jewelcrafting - Ring (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelRing2"] = { "Jewelcrafting - Ring (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelRing3"] = { "Jewelcrafting - Ring (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelTrinket1"] = { "Jewelcrafting - Trinket", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelYellow1"] = { "Jewelcrafting - Yellow (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelYellow2"] = { "Jewelcrafting - Yellow (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelcraftingDaily1"] = { "Jewelcrafting - crafting Daily (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelcraftingDaily2"] = { "Jewelcrafting - crafting Daily (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelcraftingDaily3"] = { "Jewelcrafting - crafting Daily (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelcraftingDaily4"] = { "Jewelcrafting - crafting Daily (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelcraftingDaily5"] = { "Jewelcrafting - crafting Daily (5)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["JewelcraftingDaily6"] = { "Jewelcrafting - crafting Daily (6)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherCloaks1"] = { "Leatherworking - Cloaks", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherDrumsBagsMisc1"] = { "Leatherworking - Drums Bags Misc", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherItemEnhancement1"] = { "Leatherworking - Item Enhancement (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherItemEnhancement2"] = { "Leatherworking - Item Enhancement (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeather1"] = { "Leatherworking - Leather", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorBC1"] = { "Leatherworking - Leather Armor BC (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorBC2"] = { "Leatherworking - Leather Armor BC (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorOld1"] = { "Leatherworking - Leather Armor Old (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorOld2"] = { "Leatherworking - Leather Armor Old (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorOld3"] = { "Leatherworking - Leather Armor Old (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorOld4"] = { "Leatherworking - Leather Armor Old (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorOld5"] = { "Leatherworking - Leather Armor Old (5)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorOld6"] = { "Leatherworking - Leather Armor Old (6)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorWrath1"] = { "Leatherworking - Leather Armor Wrath (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorWrath2"] = { "Leatherworking - Leather Armor Wrath (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherLeatherArmorWrath3"] = { "Leatherworking - Leather Armor Wrath (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorBC1"] = { "Leatherworking - Mail Armor BC (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorBC2"] = { "Leatherworking - Mail Armor BC (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorOld1"] = { "Leatherworking - Mail Armor Old (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorOld2"] = { "Leatherworking - Mail Armor Old (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorWrath1"] = { "Leatherworking - Mail Armor Wrath (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorWrath2"] = { "Leatherworking - Mail Armor Wrath (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherMailArmorWrath3"] = { "Leatherworking - Mail Armor Wrath (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherQuiversPouches1"] = { "Leatherworking - Quivers Pouches", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherBloodTigerH"] = { AL["Blood Tiger Harness"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherBoreanEmbrace"] = { "Arctic Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherDevilsaurArmor"] = { AL["Devilsaur Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherEvisceratorBattlegear"] = { "Eviscerator Battlegear", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherFelSkin"] = { AL["Fel Skin"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherIceborneEmbrace"] = { "Iceborne Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherIronfeatherArmor"] = { AL["Ironfeather Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherOvercasterBattlegear"] = { "Overcast Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherPrimalBatskin"] = { AL["Primal Batskin"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherPrimalIntent"] = { AL["Primal Intent"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherSClefthoof"] = { AL["Strength of the Clefthoof"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherStormshroudArmor"] = { AL["Stormshroud Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherThickDraenicA"] = { AL["Thick Draenic Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherVolcanicArmor"] = { AL["Volcanic Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherWildDraenishA"] = { AL["Wild Draenish Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingLeatherWindhawkArmor"] = { AL["Windhawk Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailBlackDragonM"] = { AL["Black Dragon Mail"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailBlueDragonM"] = { AL["Blue Dragon Mail"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailFelscaleArmor"] = { AL["Felscale Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailFelstalkerArmor"] = { AL["Felstalker Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailFrostscaleBinding"] = { "Frostscale Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailGreenDragonM"] = { AL["Green Dragon Mail"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailNerubianHive"] = { "Nerubian Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailNetherFury"] = { AL["Fury of the Nether"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailNetherscaleArmor"] = { AL["Netherscale Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailNetherstrikeArmor"] = { AL["Netherstrike Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailScaledDraenicA"] = { AL["Scaled Draenic Armor"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailStormhideBattlegear"] = { "Stormhide Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["LeatherworkingMailSwiftarrowBattlefear"] = { "Swiftarrow Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArcanoVest"] = { AL["Arcanoweave Vestments"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorBC1"] = { "Tailoring - Armor BC (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorBC2"] = { "Tailoring - Armor BC (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorBC3"] = { "Tailoring - Armor BC (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld1"] = { "Tailoring - Armor Old (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld2"] = { "Tailoring - Armor Old (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld3"] = { "Tailoring - Armor Old (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld4"] = { "Tailoring - Armor Old (4)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld5"] = { "Tailoring - Armor Old (5)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld6"] = { "Tailoring - Armor Old (6)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorOld7"] = { "Tailoring - Armor Old (7)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorWotLK1"] = { "Tailoring - Armor Wot LK (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorWotLK2"] = { "Tailoring - Armor Wot LK (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringArmorWotLK3"] = { "Tailoring - Armor Wot LK (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringBags1"] = { "Tailoring - Bags (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringBags2"] = { "Tailoring - Bags (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringBattlecastG"] = { AL["Battlecast Garb"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringBloodvineG"] = { AL["Bloodvine Garb"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringDuskweaver"] = { "Duskweave Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringFrostsavageBattlegear"] = { "Frostsavage Battlegear", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringFrostwovenPower"] = { "Frostwoven Set", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringImbuedNeather"] = { AL["Imbued Netherweave"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMisc1"] = { "Tailoring - Misc (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringMisc2"] = { "Tailoring - Misc (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringNeatherVest"] = { AL["Netherweave Vestments"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringPrimalMoon"] = { AL["Primal Mooncloth"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringShadowEmbrace"] = { AL["Shadow's Embrace"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringShirts1"] = { "Tailoring - Shirts", "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringSoulclothEm"] = { AL["Soulcloth Embrace"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringSpellfireWrath"] = { AL["Wrath of Spellfire"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringSpellstrikeInfu"] = { AL["Spellstrike Infusion"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringTheUnyielding"] = { AL["The Unyielding"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["TailoringWhitemendWis"] = { AL["Whitemend Wisdom"], "AtlasLootCrafting" };
	AtlasLoot_TableNames["CraftedWeapons1"] = { "Crafted Epic Weapons (1)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["CraftedWeapons2"] = { "Crafted Epic Weapons (2)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["CraftedWeapons3"] = { "Crafted Epic Weapons (3)", "AtlasLootCrafting" };
	AtlasLoot_TableNames["FirstAid1"] = { "First Aid", "AtlasLootCrafting" };
	AtlasLoot_TableNames["Mining1"] = { "Mining", "AtlasLootCrafting" };
	AtlasLoot_TableNames["FishingDaily1"] = { "Fishing Daily", "AtlasLootCrafting" };
	AtlasLoot_TableNames["FishingDaily2"] = { "Fishing Daily", "AtlasLootCrafting" };
	AtlasLoot_TableNames["COOKINGMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["INSCRIPTIONMENU"] = { "dummy", "dummy" };
	AtlasLoot_TableNames["REPMENU2"] = { "dummy", "dummy" };
