--[[
bossnames.en.lua
This file gives the localised names of bosses needed in loot descriptions,
especially on tables from many locations where we need to indicate where the
loot came from.
]]


local AL = AceLibrary("AceLocale-2.2"):new("AtlasLoot");

AtlasLootBossNames = {

  ---------------------
  -- WotLK Instances --
  ---------------------

  ------------------
  -- BC Instances --
  ------------------

	AuchManaTombs = {
		"Nexus-Prince Shaffar".." (".."Mana-Tombs"..")";
	};

	AuchAuchenaiCrypts = {
		"Maladaar".." (".."Auchenai Crypts"..")";
		"Avatar".." (".."Auchenai Crypts"..")";
	};

	AuchSethekkHalls = {
		"Talon King Ikiss".." (".."Sethekk Halls"..")";
	};

	AuchShadowLabyrinth = {
		"Blackheart".." (".."Shadow Labyrinth"..")";
		"Grandmaster Vorpil".." (".."Shadow Labyrinth"..")";
		"Murmur".." (".."Shadow Labyrinth"..")";
	};

	BlackTemple = {
		"Mother Shahraz".." (".."Black Temple"..")";
		"Illidari Council".." (".."Black Temple"..")";
		"Illidan Stormrage".." (".."Black Temple"..")";
	};

	CFRTheSlavePens = {
		"Quagmirran";
	};

	CFRTheUnderbog = {
		"The Black Stalker";
	};

	CFRTheSteamvault = {
		"Thespia".." (".."The Steamvault"..")";
		"Kalithresh".." (".."The Steamvault"..")";
	};

	CFRSerpentshrineCavern = {
		"Leotheras the Blind".." ("..AL["Serpentshrine"]..")";
		"Fathom-Lord Karathress".." ("..AL["Serpentshrine"]..")";
		"Lady Vashj".." ("..AL["Serpentshrine"]..")";
	};

	Common = {
		AL["Trash Mobs"];
	};

	CoTOldHillsbradFoothills = {
	    "Epoch Hunter".." ("..AL["CoT1"]..")";
	};

	CoTTheBlackMorass = {
		"Aeonus".." ("..AL["CoT2"]..")";
	};

	CoTMountHyjal = {
		"Azgalor".." (".."Hyjal Summit"..")";
		"Archimonde".." (".."Hyjal Summit"..")";
	};

	GruulsLair = {
		"High King Maulgar";
		"Gruul the Dragonkiller";
	};

	HCRamparts = {
		"Omor the Unscarred".." (".."Hellfire Ramparts"..")";
	};

	HCBloodFurnace = {
		"Keli'dan".." (".."The Blood Furnace"..")";
	};

	HCShatteredHalls = {
		"O'mrogg".." (".."The Shattered Halls"..")";
		"Kargath".." (".."The Shattered Halls"..")";
	};

	SunwellPlateau = {
		"Kalecgos".." (".."Sunwell Plateau"..")";
		"Brutallus".." (".."Sunwell Plateau"..")";
		"Felmyst".." (".."Sunwell Plateau"..")";
	};

	Karazhan = {
		"The Curator".." (".."Karazhan"..")";
		"Prince Malchezaar".." (".."Karazhan"..")";
	};

	MagtheridonsLair = {
		"Magtheridon";
	};

	TKMechanar = {
		"Pathaleon the Calculator".." (Mechanar)";
	};

	TKTheBotanica = {
		"Laj".." (".."The Botanica"..")";
		"Warp Splinter".." (".."The Botanica"..")";
	};

	TKTheArcatraz = {
		"Harbinger Skyriss".." (Arcatraz)";
	};

	TKTheEye = {
		"Void Reaver".." (".."The Eye"..")";
		"Kael'thas Sunstrider".." (".."The Eye"..")";
	};
	
  -----------------------
  -- Classic Instances --
  -----------------------
	
	BlackrockSpireLower = {
		"Highlord Omokk".." ("..AL["LBRS"]..")";
		"Shadow Hunter Vosh'gajin".." ("..AL["LBRS"]..")";
		"War Master Voone".." ("..AL["LBRS"]..")";
		"Mor Grayhoof".." ("..AL["LBRS"]..")";
		"Mother Smolderweb".." ("..AL["LBRS"]..")";
		"Gizrul the Slavener".." ("..AL["LBRS"]..")";
		"Overlord Wyrmthalak".." ("..AL["LBRS"]..")";
		AL["Trash Mobs"].." ("..AL["LBRS"]..")";
	};

	BlackrockSpireUpper = {
		"Pyroguard Emberseer".." ("..AL["UBRS"]..")";
		"Solakar Flamewreath".." ("..AL["UBRS"]..")";
		"Warchief Rend Blackhand".." ("..AL["UBRS"]..")";
		"Gyth".." ("..AL["UBRS"]..")";
		"The Beast".." ("..AL["UBRS"]..")";
		"General Drakkisath".." ("..AL["UBRS"]..")";
	};

	BlackwingLair = {
		"Razorgore the Untamed";
		"Vaelastrasz the Corrupt";
		"Broodlord Lashlayer";
		"Firemaw";
		"Ebonroc";
		"Flamegor";
		"Chromaggus";
		"Nefarian";
	};

	MoltenCore = {
		"Lucifron";
		"Magmadar";
		"Gehennas";
		"Garr";
		"Shazzrah";
		"Baron Geddon";
		"Golemagg the Incinerator";
		"Sulfuron Harbinger";
		"Ragnaros";
		AL["Trash Mobs"];
	};

	Naxxramas = {
		"Patchwerk";
		"Grobbulus";
		"Gluth";
		"Thaddius";
		"Anub'Rekhan";
		"Grand Widow Faerlina";
		"Maexxna";
		"Instructor Razuvious";
		"Gothik the Harvester";
		"The Four Horsemen";
		"Noth the Plaguebringer";
		"Heigan the Unclean";
		"Loatheb";
		"Sapphiron";
		"Kel'Thuzad";
	};

	OnyxiasLair = {
		"Onyxia";
	};

	Scholomance = {
		"Kirtonos the Herald".." ("..AL["Scholo"]..")";
		"Jandice Barov".." ("..AL["Scholo"]..")";
		"Rattlegore".." ("..AL["Scholo"]..")";
		"Ras Frostwhisper".." ("..AL["Scholo"]..")";
		"Instructor Malicia".." ("..AL["Scholo"]..")";
		"Doctor Theolen Krastinov".." ("..AL["Scholo"]..")";
		"Lorekeeper Polkelt".." ("..AL["Scholo"]..")";
		"The Ravenian".." ("..AL["Scholo"]..")";
		"Lord Alexei Barov".." ("..AL["Scholo"]..")";
		"Darkmaster Gandling".." ("..AL["Scholo"]..")";
		AL["Trash Mobs"].." ("..AL["Scholo"]..")";
   };
	Stratholme = {
		"Hearthsinger Forresten".." ("..AL["Strat"]..")";
		"The Unforgiven".." ("..AL["Strat"]..")";
		"Timmy the Cruel".." ("..AL["Strat"]..")";
		"Cannon Master Willey".." ("..AL["Strat"]..")";
		"Archivist Galford".." ("..AL["Strat"]..")";
		"Balnazzar".." ("..AL["Strat"]..")";
		"Baroness Anastari".." ("..AL["Strat"]..")";
		"Nerub'enkan".." ("..AL["Strat"]..")";
		"Maleki the Pallid".." ("..AL["Strat"]..")";
		"Magistrate Barthilas".." ("..AL["Strat"]..")";
		"Ramstein the Gorger".." ("..AL["Strat"]..")";
		"Baron Rivendare".." ("..AL["Strat"]..")";
		AL["Trash Mobs"].." ("..AL["Strat"]..")";
    };
};