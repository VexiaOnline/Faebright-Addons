----------------------------------------------------------------------------------
-- Total RP 3
-- This file contains the addon main loading sequence.
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- Imports
local Globals = TRP3_API.globals;
local Log = TRP3_API.utils.log;
local Config = TRP3_API.configuration;

local CONFIG_LAST_SEEN_VERSION = "tranquilrp3_last_seen_version";
local CONFIG_DEFAULTS_VERSION = "tranquilrp3_defaults_version";
local CONFIG_PROMPT_VERSION = "tranquilrp3_rp_prompt_version";
local CONFIG_CLIENT_NAME = "tranquilrp3_client_name";
local CONFIG_TOTALRP3_WARNING_SEEN = "tranquilrp3_totalrp3_warning_seen";
local TOTALRP3_LEGACY_ADDONS = {
	"TotalRP3",
	"totalRP3_Data",
	"TotalRP3_Data",
};
local enabledTotalRP3LegacyAddons = {};

Config.registerConfigKey(CONFIG_LAST_SEEN_VERSION, "");
Config.registerConfigKey(CONFIG_DEFAULTS_VERSION, "");
Config.registerConfigKey(CONFIG_PROMPT_VERSION, "");
Config.registerConfigKey(CONFIG_CLIENT_NAME, "TotalRP3");
Config.registerConfigKey(CONFIG_TOTALRP3_WARNING_SEEN, false);

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- LOADING SEQUENCE
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local MAIN_SEQUENCE_ID, MAIN_SEQUENCE_DETAIL = "", "";
local PRIDE_TITLE_GRADIENTS = {
	{ "e40303", "ff8c00", "ffed00" },
	{ "ff5e5b", "f4a261", "ffd166" },
	{ "ff218c", "ffd800", "21b1ff" },
	{ "ff76a4", "ffffff", "7fbdf0" },
	{ "078d70", "98e8c1", "7bade2" },
	{ "5bcefa", "f5a9b8", "ffffff" },
	{ "d60270", "9b4f96", "0038a8" },
};

local function lerp(a, b, t)
	return a + (b - a) * t;
end

local function hexToRGB255(hex)
	return tonumber(string.sub(hex, 1, 2), 16), tonumber(string.sub(hex, 3, 4), 16), tonumber(string.sub(hex, 5, 6), 16);
end

local function rgb255ToHex(r, g, b)
	return string.format("%02x%02x%02x", r, g, b);
end

local function buildGradientText(text, colors)
	if not text or text == "" or not colors or #colors < 2 then
		return text or "";
	end

	local output = "";
	local charCount = string.len(text);
	local segmentCount = #colors - 1;

	for i = 1, charCount do
		local ch = string.sub(text, i, i);
		if ch == " " then
			output = output .. ch;
		else
			local progress = 0;
			if charCount > 1 then
				progress = (i - 1) / (charCount - 1);
			end
			local scaled = progress * segmentCount;
			local segment = math.floor(scaled) + 1;
			if segment > segmentCount then
				segment = segmentCount;
			end
			local localT = scaled - (segment - 1);
			local r1, g1, b1 = hexToRGB255(colors[segment]);
			local r2, g2, b2 = hexToRGB255(colors[segment + 1]);
			local r = math.floor(lerp(r1, r2, localT) + 0.5);
			local g = math.floor(lerp(g1, g2, localT) + 0.5);
			local b = math.floor(lerp(b1, b2, localT) + 0.5);
			output = output .. "|cff" .. rgb255ToHex(r, g, b) .. ch;
		end
	end

	return output .. "|r";
end

local function getPrideAddonName()
	return buildGradientText("TranquilRP 3", PRIDE_TITLE_GRADIENTS[math.random(1, #PRIDE_TITLE_GRADIENTS)]);
end

local function getCurrentAddonVersion()
	local tocVersion;
	if GetAddOnMetadata then
		tocVersion = GetAddOnMetadata("TranquilRP3", "Version");
	end
	if tocVersion and tocVersion ~= "" then
		return tostring(tocVersion);
	end
	return nil;
end

local function isInRPChannel()
	local channelName = "rp";
	local channelId = GetChannelName(channelName);
	return type(channelId) == "number" and channelId > 0;
end

local function joinRPChannel()
	if not isInRPChannel() then
		JoinChannelByName("rp");
	end
end

local function updateDetectedAddonIdentity()
	local detectedVersion = getCurrentAddonVersion();
	if detectedVersion then
		Globals.version_display = detectedVersion;
		Globals.addon_name_alt = "TranquilRP3";
		Globals.client_name = "TranquilRP3";
		Config.setValue(CONFIG_CLIENT_NAME, "TranquilRP3");
	else
		Globals.client_name = "TotalRP3";
		Globals.addon_name_alt = "TotalRP3";
		Config.setValue(CONFIG_CLIENT_NAME, "TotalRP3");
	end
end

local function applyFirstLoginDefaults()
	if Config.getValue(CONFIG_DEFAULTS_VERSION) == "" then
		Config.setValue("chat_name", 3);
		Config.setValue("chat_color", false);
		Config.setValue("chat_emote_color", true);
		Config.setValue("chat_name_icon", true);
		Config.setValue("chat_name_icon_size", 16);
		Config.setValue("chat_npc_talk", true);
		Config.setValue("chat_npc_talk_p", "|");
		Config.setValue("chat_emote", true);
		Config.setValue("chat_emote_pattern", "(%*.-%*)");
		Config.setValue("chat_chat", true);
		Config.setValue("chat_ooc", true);
		Config.setValue("chat_ooc_pattern", "(%(%(.-%)%))");
		Config.setValue("chat_ooc_color", "aaaaaa");
		Config.setValue("chat_channel_replacement", true);
		Config.setValue("chat_channel_rp", "rp");
		Config.setValue("chat_use_rp", true);
		Config.setValue(CONFIG_DEFAULTS_VERSION, Globals.version_display);
	end
end

StaticPopupDialogs["TRP3_JOIN_RP_PROMPT"] = {
	text = "Would you like to join the global /rp channel to find other roleplayers?",
	button1 = "Join /rp",
	button2 = "Maybe Later",
	OnAccept = function()
		joinRPChannel();
		Config.setValue(CONFIG_PROMPT_VERSION, Globals.version_display);
		if DEFAULT_CHAT_FRAME then
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00TranquilRP3: Joined /rp. You can leave later with /leave rp.|r");
		end
	end,
	OnCancel = function()
		Config.setValue(CONFIG_PROMPT_VERSION, Globals.version_display);
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
};

local function showRPJoinPrompt()
	Config.setValue(CONFIG_PROMPT_VERSION, Globals.version_display);
end

local function scheduleRPJoinPrompt()
	Config.setValue(CONFIG_PROMPT_VERSION, Globals.version_display);
end

local registerPromptHandlers;
local maybePromptForChatterHighlightsConflict;
local maybePromptToDisableTotalRP3;

local function getChatterProfileKey()
	local playerName = UnitName("player");
	local realmName = GetRealmName();
	if playerName and realmName then
		return playerName .. " - " .. realmName;
	end
end

local function getStoredChatterProfile()
	if type(ChatterDB) ~= "table" then
		return nil;
	end

	local profileName = "Default";
	local profileKey = getChatterProfileKey();
	if profileKey and type(ChatterDB.profileKeys) == "table" and type(ChatterDB.profileKeys[profileKey]) == "string" then
		profileName = ChatterDB.profileKeys[profileKey];
	end

	if type(ChatterDB.profiles) ~= "table" then
		return nil;
	end

	local profile = ChatterDB.profiles[profileName];
	if type(profile) ~= "table" then
		profile = ChatterDB.profiles.Default;
	end
	return profile;
end

local function isChatterHighlightsEnabled()
	if type(Chatter) == "table" and Chatter.db and type(Chatter.db.profile) == "table" then
		local modules = Chatter.db.profile.modules;
		return type(modules) ~= "table" or modules["Highlights"] ~= false;
	end

	local profile = getStoredChatterProfile();
	if type(profile) ~= "table" then
		return false;
	end

	local modules = profile.modules;
	return type(modules) ~= "table" or modules["Highlights"] ~= false;
end

local function disableChatterHighlights()
	if type(ChatterDB) == "table" then
		local profile = getStoredChatterProfile();
		if type(profile) == "table" then
			profile.modules = profile.modules or {};
			profile.modules["Highlights"] = false;
		end
	end

	if type(Chatter) == "table" and Chatter.db and type(Chatter.db.profile) == "table" then
		Chatter.db.profile.modules = Chatter.db.profile.modules or {};
		Chatter.db.profile.modules["Highlights"] = false;

		if type(Chatter.DisableModule) == "function" then
			pcall(function()
				Chatter:DisableModule("Highlights");
			end);
		end
	end
end

StaticPopupDialogs["TRP3_CHATTER_HIGHLIGHTS_CONFLICT"] = {
	text = "Chatter's Highlights module conflicts with TranquilRP3 chat handling and can cause duplicate or broken chat messages.\n\nWould you like TranquilRP3 to disable Chatter Highlights for you?",
	button1 = "Disable Highlights",
	button2 = "Ignore",
	OnAccept = function()
		disableChatterHighlights();
		if DEFAULT_CHAT_FRAME then
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00TranquilRP3: Chatter Highlights has been disabled to prevent chat conflicts.|r");
		end
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
};

StaticPopupDialogs["TRP3_DISABLE_TOTALRP3_WARNING"] = {
	text = "TotalRP3 is enabled alongside TranquilRP3.\n\nTranquilRP3 has migrated your TotalRP3 profiles and register data. TotalRP3 and TotalRP3_Data should now be disabled to avoid conflicts and duplicate behavior.\n\nDisable them now and reload?",
	button1 = "Disable Legacy TRP3",
	button2 = "Keep Enabled",
	OnAccept = function()
		TRP3_MigrateRegisterData();
		if DisableAddOn then
			for _, addonName in pairs(enabledTotalRP3LegacyAddons) do
				DisableAddOn(addonName);
			end
		end
		Config.setValue(CONFIG_TOTALRP3_WARNING_SEEN, true);
		if ReloadUI then
			ReloadUI();
		else
			StaticPopup_Show("CLIENT_RESTART_ALERT");
		end
	end,
	OnCancel = function()
		Config.setValue(CONFIG_TOTALRP3_WARNING_SEEN, true);
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
	showAlert = true,
};

maybePromptForChatterHighlightsConflict = function()
	if not IsAddOnLoaded or not IsAddOnLoaded("Chatter") then
		return;
	end
	if not isChatterHighlightsEnabled() then
		return;
	end
	if StaticPopup_Visible("TRP3_CHATTER_HIGHLIGHTS_CONFLICT") then
		return;
	end

	StaticPopup_Show("TRP3_CHATTER_HIGHLIGHTS_CONFLICT");
end

local function resolveAddonName(addonName)
	if not GetNumAddOns or not GetAddOnInfo then
		return addonName;
	end

	local loweredAddonName = string.lower(addonName);
	for index = 1, GetNumAddOns() do
		local installedAddonName = GetAddOnInfo(index);
		if type(installedAddonName) == "string" and string.lower(installedAddonName) == loweredAddonName then
			return installedAddonName;
		end
	end

	return addonName;
end

local function isAddonEnabled(addonName)
	if not GetAddOnEnableState then
		return false;
	end
	local enabledState = GetAddOnEnableState(UnitName("player") or "", resolveAddonName(addonName));
	return type(enabledState) == "number" and enabledState > 0;
end

local function collectEnabledTotalRP3LegacyAddons()
	local enabledAddons = {};
	local seenAddons = {};

	for _, addonName in pairs(TOTALRP3_LEGACY_ADDONS) do
		local resolvedAddonName = resolveAddonName(addonName);
		local addonKey = string.lower(resolvedAddonName);
		if not seenAddons[addonKey] and isAddonEnabled(resolvedAddonName) then
			enabledAddons[#enabledAddons + 1] = resolvedAddonName;
			seenAddons[addonKey] = true;
		end
	end

	return enabledAddons;
end

maybePromptToDisableTotalRP3 = function()
	local enabledAddons = collectEnabledTotalRP3LegacyAddons();
	if #enabledAddons == 0 then
		return;
	end
	if StaticPopup_Visible("TRP3_DISABLE_TOTALRP3_WARNING") then
		return;
	end

	TRP3_MigrateRegisterData();
	enabledTotalRP3LegacyAddons = enabledAddons;
	StaticPopup_Show("TRP3_DISABLE_TOTALRP3_WARNING");
end

registerPromptHandlers = function()
	maybePromptToDisableTotalRP3();
	maybePromptForChatterHighlightsConflict();
end

-- Called when TRP3 is loaded.
function Globals.addon:OnInitialize()
	updateDetectedAddonIdentity();
	TRP3_MigrateRegisterData();
	TRP3_API.utils.event.registerHandler("SAVED_VARIABLES_TOO_LARGE", function(...)
		print(...);
	end);
end

local function getRegisterDataFreshness(registerData)
	if type(registerData) ~= "table" then
		return 0, 0;
	end

	local freshestStamp = 0;
	local nodeCount = 0;

	local function scanNode(node)
		if type(node) ~= "table" then
			return;
		end

		nodeCount = nodeCount + 1;

		local versionValue = node.v;
		if type(versionValue) == "number" and versionValue > freshestStamp then
			freshestStamp = versionValue;
		end

		local timeValue = node.time;
		if type(timeValue) == "number" and timeValue > freshestStamp then
			freshestStamp = timeValue;
		end

		for _, child in pairs(node) do
			if type(child) == "table" then
				scanNode(child);
			end
		end
	end

	scanNode(registerData);

	return freshestStamp, nodeCount;
end

function TRP3_MigrateRegisterData()
	local tranquilRegister = TRP3_Register_TranquilRP3;
	local legacyRegister = TRP3_Register;

	local tranquilFreshness, tranquilNodeCount = getRegisterDataFreshness(tranquilRegister);
	local legacyFreshness, legacyNodeCount = getRegisterDataFreshness(legacyRegister);

	local selectedRegister = tranquilRegister;
	if type(selectedRegister) ~= "table" then
		selectedRegister = {};
	end

	if type(legacyRegister) == "table" then
		local shouldUseLegacy = legacyFreshness > tranquilFreshness
			or (legacyFreshness == tranquilFreshness and legacyNodeCount > tranquilNodeCount);
		if shouldUseLegacy then
			selectedRegister = legacyRegister;
		end
	end

	TRP3_Register_TranquilRP3 = selectedRegister;
	TRP3_Register = selectedRegister;
end

local function loadingSequence()
	Log.log("OnEnable() START");

	-- Get info we can't have earlier
	MAIN_SEQUENCE_DETAIL = "Globals.build";
	Globals.build();

	-- Adapt saved variables structures between versions
	MAIN_SEQUENCE_DETAIL = "TRP3_API.flyway.applyPatches";
	TRP3_API.flyway.applyPatches();

	-- Inits locale
	MAIN_SEQUENCE_DETAIL = "TRP3_API.locale.init";
	TRP3_API.locale.init();

	MAIN_SEQUENCE_DETAIL = "TRP3_API.module.init";
	TRP3_API.module.init();

	-- Call the init callback on all modules
	MAIN_SEQUENCE_DETAIL = "TRP3_API.module.initModules";
	TRP3_API.module.initModules();
	
	-- Welcome \o/
	MAIN_SEQUENCE_DETAIL = "Welcome message";
	TRP3_API.utils.message.displayMessage(("Thank you for using %s (v %s)! Early access warning: this build is not yet stable and things may break unexpectedly. Have fun !"):format(getPrideAddonName(), Globals.version_display));
	
	MAIN_SEQUENCE_DETAIL = "TRP3_API.communication.init";
	TRP3_API.communication.init();
	MAIN_SEQUENCE_DETAIL = "TRP3_API.communication.broadcast.init";
	TRP3_API.communication.broadcast.init();
	MAIN_SEQUENCE_DETAIL = "TRP3_API.profile.init";
	TRP3_API.profile.init();
	MAIN_SEQUENCE_DETAIL = "TRP3_API.dashboard.init";
	TRP3_API.dashboard.init();
	MAIN_SEQUENCE_DETAIL = "TRP3_API.navigation.init";
	TRP3_API.navigation.init();
	MAIN_SEQUENCE_DETAIL = "TRP3_API.register.init";
	TRP3_API.register.init();
	MAIN_SEQUENCE_DETAIL = "TRP3_API.popup.init";
	TRP3_API.popup.init();

	MAIN_SEQUENCE_DETAIL = "TRP3_API.events.fireEvent::WORKFLOW_ON_LOAD";
	TRP3_API.events.fireEvent(TRP3_API.events.WORKFLOW_ON_LOAD);

	-- Call module callback for all modules (onStart)
	MAIN_SEQUENCE_DETAIL = "TRP3_API.module.startModules";
	TRP3_API.module.startModules();

	MAIN_SEQUENCE_DETAIL = "TranquilRP3 defaults";
	applyFirstLoginDefaults();

	-- Select first menu
	MAIN_SEQUENCE_DETAIL = "TRP3_API.navigation.menu.selectMenu";
	TRP3_API.navigation.menu.selectMenu("main_00_dashboard");

	MAIN_SEQUENCE_DETAIL = "TRP3_API.events.fireEvent::WORKFLOW_ON_LOADED";
	TRP3_API.events.fireEvent(TRP3_API.events.WORKFLOW_ON_LOADED);
	MAIN_SEQUENCE_DETAIL = "TRP3_API.events.fireEvent::WORKFLOW_ON_FINISH";
	TRP3_API.events.fireEvent(TRP3_API.events.WORKFLOW_ON_FINISH);

	MAIN_SEQUENCE_DETAIL = "TRP3_API.configuration.constructConfigPage";
	TRP3_API.configuration.constructConfigPage();

	MAIN_SEQUENCE_DETAIL = "TranquilRP3 prompt handlers";
	registerPromptHandlers();

	if Config.getValue(CONFIG_LAST_SEEN_VERSION) ~= Globals.version_display and not isInRPChannel() then
		scheduleRPJoinPrompt(30, true);
	end
	Config.setValue(CONFIG_LAST_SEEN_VERSION, Globals.version_display);

	Log.log("OnEnable() DONE");
end

-- Called upon PLAYER_LOGIN after all addons are loaded.
function Globals.addon:OnEnable()
	MAIN_SEQUENCE_ID = "Globals.addon:OnEnable";
	local ok, errorMessage = pcall(loadingSequence);
	if not ok then
		MAIN_SEQUENCE_ERROR = errorMessage;
		TRP3_ShowErrorMessage();
		error("Error during TRP3 loading sequence: " .. errorMessage);
	end
end

function TRP3_ShowErrorMessage()
	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage(("[|cffffaa00TRP3|r] |cffff0000Error during addon loading sequence:\n|cffff7700Sequence ID: |r%s\n|cffff7700Sub-sequence ID: |r%s\n|cffff7700Error message: |r%s"):format(MAIN_SEQUENCE_ID, MAIN_SEQUENCE_DETAIL, tostring(MAIN_SEQUENCE_ERROR)), 1, 1, 1);
	end
end

TRP3_API.slash.registerCommand({
	id = "rpreset",
	helpLine = " - reset the /rp join popup for this version.",
	handler = function()
		Config.setValue(CONFIG_PROMPT_VERSION, "");
		TRP3_API.utils.message.displayMessage("TranquilRP3: The /rp prompt has been reset.");
	end,
});
