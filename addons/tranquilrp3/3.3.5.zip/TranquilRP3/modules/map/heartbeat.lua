----------------------------------------------------------------------------------
-- TranquilRP 3
-- Heartbeat directory and live map markers
----------------------------------------------------------------------------------

local Globals = TRP3_API.globals;
local Utils = TRP3_API.utils;
local Events = TRP3_API.events;
local Comm = TRP3_API.communication;
local get = TRP3_API.profile.getData;
local loc = TRP3_API.locale.getText;
local showAlertPopup = TRP3_API.popup.showAlertPopup;
local addCharacter = TRP3_API.register.addCharacter;
local isUnitIDKnown = TRP3_API.register.isUnitIDKnown;
local getUnitIDCharacter = TRP3_API.register.getUnitIDCharacter;
local hasProfile = TRP3_API.register.hasProfile;
local saveClientInformation = TRP3_API.register.saveClientInformation;
local getUnitIDCurrentProfile = TRP3_API.register.getUnitIDCurrentProfile;
local isIDIgnored = TRP3_API.register.isIDIgnored;
local getConfigValue = TRP3_API.configuration.getValue;
local registerConfigHandler = TRP3_API.configuration.registerHandler;

local tonumber, tostring, pairs, time = tonumber, tostring, pairs, time;
local CreateFrame = CreateFrame;
local GetPlayerMapPosition = GetPlayerMapPosition;
local GetCurrentMapAreaID, SetMapToCurrentZone = GetCurrentMapAreaID, SetMapToCurrentZone;
local SetMapByID = SetMapByID;
local SetMapZoom = SetMapZoom;
local GetCurrentMapContinent, GetCurrentMapZone = GetCurrentMapContinent, GetCurrentMapZone;
local GetCurrentMapDungeonLevel, SetDungeonMapLevel = GetCurrentMapDungeonLevel, SetDungeonMapLevel;
local GetRealZoneText, GetZoneText = GetRealZoneText, GetZoneText;
local GetInstanceInfo = GetInstanceInfo;
local GetZoneInstanceID = GetZoneInstanceID;
local UnitFactionGroup, UnitIsPVP, UnitIsAFK = UnitFactionGroup, UnitIsPVP, UnitIsAFK;

local HEARTBEAT_COMMAND = "TRPHB";
local HEARTBEAT_INTERVAL = 30;
local HEARTBEAT_TTL = 75;
local SELF_REFRESH_INTERVAL = 5;
local MAP_VISIBLE_REFRESH_INTERVAL = 1;
local HEARTBEAT_EVENT_MIN_INTERVAL = 10;
local FACTION_WIRE_ALLIANCE = "f1";
local FACTION_WIRE_HORDE = "f2";
local FACTION_WIRE_INDEPENDENT = "f3";

local versionAlertShown = false;
local lastHeartbeatAt = 0;
local lastLocalRefreshAt = 0;
local heartbeatTicker;
local playerScanStructure;
local lastKnownZone = "";
local lastKnownX, lastKnownY = 0, 0;
local lastKnownMapID = 0;
local refreshLocalEntry;
local pendingMapRefresh = false;
local mapRefreshScheduled = false;
local HEARTBEAT_PAYLOAD_SEPARATOR = "^";
local HEARTBEAT_PROFILE_QUERY_COOLDOWN = 30;
local CONFIG_HIDE_NSFW = "tooltip_char_hide_nsfw";

local function sanitizeProfileDisplayName(unitID, profile)
	if not profile or not profile.characteristics then
		return nil;
	end
	local fullName = TRP3_API.register.getCompleteName(profile.characteristics, unitID, true);
	if TRP3_API.register.sanitizeDisplayName then
		return TRP3_API.register.sanitizeDisplayName(fullName);
	end
	return fullName;
end

function TRP3_API.map.isHeartbeatOnline(unitID)
	if not unitID or not isUnitIDKnown(unitID) then
		return false;
	end
	local character = getUnitIDCharacter(unitID);
	return type(character) == "table"
		and type(character.heartbeatAt) == "number"
		and (time() - character.heartbeatAt) <= HEARTBEAT_TTL;
end

local function encodeHeartbeatValue(value)
	value = tostring(value or "");
	value = string.gsub(value, "%%", "%%25");
	value = string.gsub(value, HEARTBEAT_PAYLOAD_SEPARATOR, "%%5E");
	return value;
end

local function decodeHeartbeatValue(value)
	value = tostring(value or "");
	value = string.gsub(value, "%%5[Ee]", HEARTBEAT_PAYLOAD_SEPARATOR);
	value = string.gsub(value, "%%25", "%%");
	return value;
end

local function buildHeartbeatPayload(displayName, versionText, icState, faction, instanceTag, colorCode, icon)
	return table.concat({
		encodeHeartbeatValue(displayName),
		encodeHeartbeatValue(versionText),
		encodeHeartbeatValue(icState),
		encodeHeartbeatValue(faction),
		encodeHeartbeatValue(instanceTag),
		encodeHeartbeatValue(colorCode),
		encodeHeartbeatValue(icon),
	}, HEARTBEAT_PAYLOAD_SEPARATOR);
end

local function parseHeartbeatPayload(payload)
	local parts = {};
	if type(payload) ~= "string" or payload == "" then
		return parts;
	end
	local startIndex = 1;
	local separatorStart, separatorEnd = string.find(payload, HEARTBEAT_PAYLOAD_SEPARATOR, startIndex, true);
	while separatorStart do
		table.insert(parts, decodeHeartbeatValue(string.sub(payload, startIndex, separatorStart - 1)));
		startIndex = separatorEnd + 1;
		separatorStart, separatorEnd = string.find(payload, HEARTBEAT_PAYLOAD_SEPARATOR, startIndex, true);
	end
	table.insert(parts, decodeHeartbeatValue(string.sub(payload, startIndex)));
	return parts;
end

local function unpackHeartbeatPayload(payload)
	local payloadParts = parseHeartbeatPayload(payload);
	local function normalizeHeartbeatField(value)
		value = tostring(value or "");
		if string.sub(value, 1, 1) == HEARTBEAT_PAYLOAD_SEPARATOR then
			value = string.sub(value, 2);
		end
		return value;
	end

	local displayName = normalizeHeartbeatField(payloadParts[1]);
	local versionText = normalizeHeartbeatField(payloadParts[2]);
	local icState = normalizeHeartbeatField(payloadParts[3]);
	local faction = normalizeHeartbeatField(payloadParts[4]);
	local instanceTag = normalizeHeartbeatField(payloadParts[5]);
	local colorCode = normalizeHeartbeatField(payloadParts[6]);
	local icon = normalizeHeartbeatField(payloadParts[7]);

	-- Backward compatibility: older heartbeat payloads did not carry icState.
	-- In that layout, the 3rd field is faction and remote clients should default to IC.
	if icState ~= "0" and icState ~= "1" then
		icon = colorCode;
		colorCode = instanceTag;
		instanceTag = faction;
		faction = icState;
		icState = "1";
	end

	return displayName, versionText, icState, faction, instanceTag, colorCode, icon;
end

local function isMapDropdownOpen()
	return DropDownList1 and DropDownList1:IsShown();
end

local function parseVersion(versionText)
	local parts = {};
	if type(versionText) ~= "string" then
		return parts;
	end
	for value in string.gmatch(versionText, "(%d+)") do
		table.insert(parts, tonumber(value) or 0);
	end
	return parts;
end

local function isBetaVersion(versionText)
	return type(versionText) == "string" and string.match(string.lower(versionText), "b%s*$") ~= nil;
end

local function isVersionNewer(versionText)
	if isBetaVersion(Globals.version_display or "") then
		return false;
	end
	local senderParts = parseVersion(versionText);
	local localParts = parseVersion(Globals.version_display or "");
	local maxParts = math.max(#senderParts, #localParts);
	for index = 1, maxParts do
		local senderValue = senderParts[index] or 0;
		local localValue = localParts[index] or 0;
		if senderValue ~= localValue then
			return senderValue > localValue;
		end
	end
	return false;
end

local function getLocalCharacterName()
	local playerData = get("player/characteristics");
	if playerData then
		return TRP3_API.register.getCompleteName(playerData, Globals.player_id, true);
	end
	return Globals.player_id;
end

local function getLocalCharacterColor()
	local playerData = get("player/characteristics");
	if playerData and playerData.CH and playerData.CH ~= "" then
		return tostring(playerData.CH);
	end
	return nil;
end

local function getLocalCharacterIcon()
	local playerData = get("player/characteristics");
	if playerData and playerData.IC and playerData.IC ~= "" then
		return tostring(playerData.IC);
	end
	return nil;
end

local function getLocalFactionCode()
	local playerData = get("player/characteristics");
	local factionCode = playerData and playerData.FC;
	if factionCode == FACTION_WIRE_ALLIANCE or factionCode == FACTION_WIRE_HORDE or factionCode == FACTION_WIRE_INDEPENDENT then
		return factionCode;
	end
	local playerFaction = UnitFactionGroup("player");
	if playerFaction == "Alliance" then
		return FACTION_WIRE_ALLIANCE;
	elseif playerFaction == "Horde" then
		return FACTION_WIRE_HORDE;
	end
	return FACTION_WIRE_INDEPENDENT;
end

local function sanitizeVersionText(versionText)
	versionText = tostring(versionText or "");
	versionText = versionText:gsub("^%^+", "");
	versionText = versionText:gsub("^%s+", "");
	return versionText;
end

local function sanitizeInstanceTag(instanceTag)
	instanceTag = tostring(instanceTag or "");
	if instanceTag == "" or not instanceTag:match("^%d+$") then
		return nil;
	end
	return instanceTag;
end

local function sanitizeColorCode(colorCode)
	colorCode = tostring(colorCode or "");
	if colorCode == "" or not colorCode:match("^[0-9A-Fa-f]+$") then
		return nil;
	end
	if #colorCode == 8 then
		colorCode = colorCode:sub(3);
	end
	if #colorCode ~= 6 then
		return nil;
	end
	return string.lower(colorCode);
end

local function sanitizeIcon(icon)
	local sanitizer = TRP3_API.register.sanitizeIconName;
	if sanitizer then
		return sanitizer(icon);
	end
	icon = tostring(icon or "");
	if icon == "" then
		return nil;
	end
	return icon;
end

local function captureInstanceTag()
	if type(GetZoneInstanceID) == "function" then
		local zoneInstanceID = tonumber(GetZoneInstanceID());
		if zoneInstanceID and zoneInstanceID > 1 then
			return tostring(zoneInstanceID);
		end
	end
	if type(GetInstanceInfo) ~= "function" then
		return nil;
	end
	local _, _, _, _, _, _, _, instanceID = GetInstanceInfo();
	instanceID = tonumber(instanceID);
	if instanceID and instanceID > 1 then
		return tostring(instanceID);
	end
	return nil;
end

local function roundCoordinate(value)
	value = tonumber(value);
	if not value then
		return nil;
	end
	return math.floor((value * 1000) + 0.5) / 1000;
end

local function captureMapState()
	return {
		mapID = GetCurrentMapAreaID(),
		continentID = GetCurrentMapContinent(),
		zoneIndex = GetCurrentMapZone(),
		dungeonLevel = GetCurrentMapDungeonLevel(),
	};
end

local function restoreMapState(mapState)
	if not mapState then
		return;
	end

	if mapState.continentID and mapState.continentID == 0 then
		SetMapZoom(0);
	elseif mapState.continentID and mapState.continentID > 0 then
		if mapState.zoneIndex and mapState.zoneIndex > 0 then
			SetMapZoom(mapState.continentID, mapState.zoneIndex);
		else
			SetMapZoom(mapState.continentID);
		end
	end

	if mapState.dungeonLevel and mapState.dungeonLevel > 0 and type(SetDungeonMapLevel) == "function" then
		SetDungeonMapLevel(mapState.dungeonLevel);
	end

	if mapState.mapID and mapState.mapID > 0 and mapState.mapID ~= GetCurrentMapAreaID() then
		SetMapByID(mapState.mapID);
		if mapState.dungeonLevel and mapState.dungeonLevel > 0 and type(SetDungeonMapLevel) == "function" then
			SetDungeonMapLevel(mapState.dungeonLevel);
		end
	end
end

local function capturePlayerLocation()
	local previousMapState = captureMapState();

	SetMapToCurrentZone();
	local currentMapID = GetCurrentMapAreaID();
	local zone;
	local continentID = GetCurrentMapContinent();
	local zoneIndex = GetCurrentMapZone();
	if continentID and continentID > 0 and zoneIndex and zoneIndex > 0 then
		local zoneList = { GetMapZones(continentID) };
		zone = zoneList[zoneIndex];
	end
	if not zone or zone == "" then
		zone = GetRealZoneText() or GetZoneText();
	end
	local x, y = GetPlayerMapPosition("player");
	restoreMapState(previousMapState);

	if zone and zone ~= "" then
		lastKnownZone = zone;
	end
	if currentMapID and currentMapID > 0 then
		lastKnownMapID = currentMapID;
	end
	if x and y and x > 0 and y > 0 then
		lastKnownX = roundCoordinate(x);
		lastKnownY = roundCoordinate(y);
	end

	return lastKnownZone, lastKnownX, lastKnownY, lastKnownMapID;
end

local function encodeFaction(faction)
	if faction == "Alliance" then
		return FACTION_WIRE_ALLIANCE;
	elseif faction == "Horde" then
		return FACTION_WIRE_HORDE;
	end
	return FACTION_WIRE_INDEPENDENT;
end

local function decodeFaction(faction)
	if faction == FACTION_WIRE_ALLIANCE or faction == "Alliance" then
		return FACTION_WIRE_ALLIANCE;
	elseif faction == FACTION_WIRE_HORDE or faction == "Horde" then
		return FACTION_WIRE_HORDE;
	elseif faction == FACTION_WIRE_INDEPENDENT or faction == "Independent" or faction == "Neutral" then
		return FACTION_WIRE_INDEPENDENT;
	end
	return FACTION_WIRE_INDEPENDENT;
end

local function getCharacterFactionValue(faction)
	if faction == FACTION_WIRE_ALLIANCE then
		return "Alliance";
	elseif faction == FACTION_WIRE_HORDE then
		return "Horde";
	end
	return "Independent";
end

local function getCharacterICValue(value)
	return tostring(value or "0") == "1" and "1" or "0";
end

local function getMarkerTexture(entry)
	if getCharacterICValue(entry and entry.ic) ~= "1" then
		return "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconOOC.blp";
	end
	if entry.faction == FACTION_WIRE_ALLIANCE or entry.faction == "Alliance" then
		return "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconAlliance.blp";
	elseif entry.faction == FACTION_WIRE_HORDE or entry.faction == "Horde" then
		return "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconHorde.blp";
	elseif entry.faction == "Scarlet" then
		return "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconScarlet.blp";
	elseif entry.faction == "Scourge" then
		return "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconScourge.blp";
	end
	return "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconTRP.blp";
end

local function shouldRequestProfile(unitID, displayName, colorCode, icon)
	if not unitID or unitID == Globals.player_id or not isUnitIDKnown(unitID) then
		return false;
	end

	local character = getUnitIDCharacter(unitID);
	local profile = hasProfile(unitID) and getUnitIDCurrentProfile(unitID) or nil;
	if profile and profile.characteristics and profile.characteristics.FN then
		local cachedDisplayName = sanitizeProfileDisplayName(unitID, profile);
		local cachedColor = profile.characteristics.CH and tostring(profile.characteristics.CH) or nil;
		local cachedIcon = profile.characteristics.IC and tostring(profile.characteristics.IC) or nil;
		local sameName = not displayName or displayName == "" or cachedDisplayName == displayName;
		local sameColor = not colorCode or colorCode == "" or cachedColor == colorCode;
		local sameIcon = not icon or icon == "" or cachedIcon == icon;

		if sameName and sameColor and sameIcon then
			return false;
		end
	end

	local now = time();
	if character.lastHeartbeatProfileQueryAt and (now - character.lastHeartbeatProfileQueryAt) < HEARTBEAT_PROFILE_QUERY_COOLDOWN then
		return false;
	end

	character.lastHeartbeatProfileQueryAt = now;
	return true;
end

local function requestProfileFromHeartbeat(unitID, displayName, colorCode, icon)
	if shouldRequestProfile(unitID, displayName, colorCode, icon) and TRP3_API.r and TRP3_API.r.sendQuery then
		TRP3_API.r.sendQuery(unitID);
	end
end

local function updateKnownCharacter(sender, zone, x, y, mapID, displayName, versionText, icState, faction, instanceTag, colorCode, icon)
	if not isUnitIDKnown(sender) then
		addCharacter(sender);
	end

	displayName = TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(displayName) or displayName;
	displayName = displayName or sender;
	versionText = sanitizeVersionText(versionText);
	instanceTag = sanitizeInstanceTag(instanceTag);
	colorCode = sanitizeColorCode(colorCode);
	icon = sanitizeIcon(icon);

	saveClientInformation(sender, "TranquilRP3", versionText or "", false);

	local character = getUnitIDCharacter(sender);
	character.zone = zone;
	character.zoneX = x;
	character.zoneY = y;
	character.mapID = mapID;
	character.heartbeatName = displayName;
	character.heartbeatIC = icState;
	character.heartbeatVersion = versionText;
	character.heartbeatFaction = faction;
	character.heartbeatInstance = instanceTag;
	character.heartbeatColor = colorCode;
	character.heartbeatIcon = icon;
	character.heartbeatAt = time();
	if faction and faction ~= "" then
		character.faction = getCharacterFactionValue(faction);
	end

	if TRP3_API.register.clearHeartbeatProfile then
		TRP3_API.register.clearHeartbeatProfile(sender);
	end

	requestProfileFromHeartbeat(sender, displayName, colorCode, icon);
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, sender, hasProfile and hasProfile(sender) or nil, "directory_lite");
end

local function refreshMapDisplay()
	if isMapDropdownOpen() then
		pendingMapRefresh = true;
		return;
	end
	if playerScanStructure and WorldMapFrame and WorldMapFrame:IsVisible() then
		refreshLocalEntry();
		TRP3_API.map.refreshScanDisplay("playerScan");
	end
end

local function scheduleMapRefresh()
	pendingMapRefresh = true;
	if mapRefreshScheduled then
		return;
	end
	mapRefreshScheduled = true;
	local function flushMapRefresh()
		if isMapDropdownOpen() then
			return;
		end
		if not pendingMapRefresh or not WorldMapFrame or not WorldMapFrame:IsVisible() then
			return;
		end
		refreshMapDisplay();
	end
	C_Timer.After(0, flushMapRefresh);
	C_Timer.After(0.10, function()
		mapRefreshScheduled = false;
		if isMapDropdownOpen() then
			return;
		end
		if pendingMapRefresh and WorldMapFrame and WorldMapFrame:IsVisible() then
			pendingMapRefresh = false;
			refreshMapDisplay();
		end
	end);
end

local function upsertHeartbeatEntry(unitID, zone, x, y, mapID, displayName, versionText, icState, faction, instanceTag, colorCode, icon)
	if not playerScanStructure then
		return;
	end
	playerScanStructure.saveStructure[unitID] = {
		x = x,
		y = y,
		zone = zone,
		mapId = mapID,
		name = displayName,
		version = versionText,
		ic = icState,
		faction = faction,
		instanceTag = instanceTag,
		colorCode = colorCode,
		icon = icon,
		source = "heartbeat",
		expiresAt = time() + HEARTBEAT_TTL,
	};
end

local function removeHeartbeatEntry(unitID)
	if not playerScanStructure or not unitID then
		return;
	end
	playerScanStructure.saveStructure[unitID] = nil;
end

refreshLocalEntry = function()
	local now = time();
	if now - lastLocalRefreshAt < SELF_REFRESH_INTERVAL then
		return;
	end
	lastLocalRefreshAt = now;

	if UnitIsAFK("player") then
		removeHeartbeatEntry(Globals.player_id);
		return;
	end

	local zone, x, y, mapID = capturePlayerLocation();
	if not zone or zone == "" or not x or not y or x <= 0 or y <= 0 then
		return;
	end

	upsertHeartbeatEntry(
		Globals.player_id,
		zone,
		x,
		y,
		mapID,
		getLocalCharacterName(),
		Globals.version_display,
		getCharacterICValue(get("player/character/RP")),
		getLocalFactionCode(),
		captureInstanceTag(),
		getLocalCharacterColor(),
		getLocalCharacterIcon()
	);
end

local function pruneEntries(saveStructure)
	local now = time();
	for unitID, entry in pairs(saveStructure) do
		if entry.expiresAt and entry.expiresAt < now then
			saveStructure[unitID] = nil;
		end
	end
	refreshLocalEntry();
end

local function shouldDisplayHeartbeatEntry(_, entry)
	if not entry then
		return false;
	end

	local currentMapID = tonumber(GetCurrentMapAreaID and GetCurrentMapAreaID()) or 0;
	local currentZoneIndex = tonumber(GetCurrentMapZone and GetCurrentMapZone()) or 0;
	local entryMapID = tonumber(entry.mapId) or 0;

	-- Never show heartbeat dots on continent-level views.
	if currentMapID <= 0 or currentZoneIndex <= 0 then
		return false;
	end
	if entryMapID <= 0 then
		return false;
	end

	return currentMapID == entryMapID;
end

local function shouldHideNSFWMapProfile(unitID)
	if not getConfigValue(CONFIG_HIDE_NSFW) or not unitID or not isUnitIDKnown(unitID) then
		return false;
	end

	local profile = getUnitIDCurrentProfile(unitID);
	return profile and profile.character and profile.character.NSFW;
end

local function sendHeartbeat(forceSend)
	if not playerScanStructure or not Comm.broadcast then
		return;
	end

	if UnitIsAFK("player") then
		removeHeartbeatEntry(Globals.player_id);
		return;
	end

	local now = time();
	local minimumInterval = forceSend and HEARTBEAT_EVENT_MIN_INTERVAL or HEARTBEAT_INTERVAL;
	if (now - lastHeartbeatAt) < minimumInterval then
		return;
	end

	local zone, x, y, mapID = capturePlayerLocation();
	if not zone or zone == "" or not x or not y or x <= 0 or y <= 0 then
		return;
	end

	lastHeartbeatAt = now;

	local displayName = getLocalCharacterName();
	local versionText = Globals.version_display or "";
	local icState = getCharacterICValue(get("player/character/RP"));
	local faction = getLocalFactionCode();
	local instanceTag = captureInstanceTag();
	local colorCode = getLocalCharacterColor();
	local icon = getLocalCharacterIcon();
	local payload = buildHeartbeatPayload(displayName, versionText, icState, faction, instanceTag, colorCode, icon);

	upsertHeartbeatEntry(Globals.player_id, zone, x, y, mapID, displayName, versionText, icState, faction, instanceTag, colorCode, icon);
	Comm.broadcast.broadcast(HEARTBEAT_COMMAND, zone, x, y, mapID, payload);
	refreshMapDisplay();
	scheduleMapRefresh();
end

local function receiveHeartbeat(sender, zone, x, y, mapID, payload)
	if sender == Globals.player_id or isIDIgnored(sender) then
		return;
	end

	x = tonumber(x);
	y = tonumber(y);
	mapID = tonumber(mapID);
	if not zone or zone == "" or not x or not y or x <= 0 or y <= 0 then
		return;
	end

	local displayName, versionText, icState, faction, instanceTag, colorCode, icon = unpackHeartbeatPayload(payload);

	displayName = TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(displayName) or displayName;
	displayName = displayName or sender;
	versionText = sanitizeVersionText(versionText);
	icState = icState or "1";
	faction = decodeFaction(faction);
	instanceTag = sanitizeInstanceTag(instanceTag);
	colorCode = sanitizeColorCode(colorCode);
	icon = sanitizeIcon(icon);
	if icon == "" then
		icon = nil;
	end

	updateKnownCharacter(sender, zone, x, y, mapID, displayName, versionText, icState, faction, instanceTag, colorCode, icon);
	upsertHeartbeatEntry(sender, zone, x, y, mapID, displayName, versionText, icState, faction, instanceTag, colorCode, icon);

	if not versionAlertShown and isVersionNewer(versionText) then
		showAlertPopup(loc("GEN_NEW_VERSION_AVAILABLE"):format(Globals.version_display, versionText));
		versionAlertShown = true;
	end

	refreshMapDisplay();
	scheduleMapRefresh();
end

local function onRelevantEvent()
	sendHeartbeat(true);
	scheduleMapRefresh();
end

TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_LOADED, function()
	playerScanStructure = TRP3_API.map.getScan and TRP3_API.map.getScan("playerScan");
	if not playerScanStructure then
		return;
	end

	playerScanStructure.prepareDisplay = pruneEntries;
	playerScanStructure.shouldDisplayEntry = function(characterID, entry)
		if shouldHideNSFWMapProfile(characterID) then
			return false;
		end
		return shouldDisplayHeartbeatEntry(characterID, entry);
	end;

	local originalDecorator = playerScanStructure.scanMarkerDecorator;
	playerScanStructure.scanMarkerDecorator = function(characterID, entry, marker)
		if originalDecorator then
			originalDecorator(characterID, entry, marker);
		end

		if entry and entry.source == "heartbeat" then
			local iconWidget = _G[marker:GetName() .. "Icon"];
			if iconWidget then
				iconWidget:SetTexture(getMarkerTexture(entry));
				iconWidget:SetTexCoord(0.1, 0.9, 0.1, 0.9);
				iconWidget:SetSize(20, 20);
			end
		end
	end

	Comm.broadcast.registerCommand(HEARTBEAT_COMMAND, receiveHeartbeat);

	if not heartbeatTicker then
		heartbeatTicker = CreateFrame("Frame", "TRP3_TranquilHeartbeatTicker");
		heartbeatTicker.elapsed = 0;
		heartbeatTicker.mapElapsed = 0;
		heartbeatTicker:Show();
		heartbeatTicker:SetScript("OnUpdate", function(self, elapsed)
			self.elapsed = self.elapsed + elapsed;
			self.mapElapsed = self.mapElapsed + elapsed;
			if self.elapsed >= HEARTBEAT_INTERVAL then
				self.elapsed = 0;
				sendHeartbeat(true);
			end
			if self.mapElapsed >= MAP_VISIBLE_REFRESH_INTERVAL then
				self.mapElapsed = 0;
				refreshMapDisplay();
			end
		end);
	end

	Utils.event.registerHandler("PLAYER_ENTERING_WORLD", function()
		sendHeartbeat(true);
		scheduleMapRefresh();
	end);
	Utils.event.registerHandler("ZONE_CHANGED_NEW_AREA", onRelevantEvent);
	Utils.event.registerHandler("ZONE_CHANGED", onRelevantEvent);
	Utils.event.registerHandler("ZONE_CHANGED_INDOORS", onRelevantEvent);
	Utils.event.registerHandler("ZONE_INSTANCE_LIST", onRelevantEvent);
	Utils.event.registerHandler("PLAYER_FLAGS_CHANGED", onRelevantEvent);
	Utils.event.registerHandler("WORLD_MAP_UPDATE", scheduleMapRefresh);
	registerConfigHandler(CONFIG_HIDE_NSFW, scheduleMapRefresh);

	sendHeartbeat(true);
	scheduleMapRefresh();
end);
