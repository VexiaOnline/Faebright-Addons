----------------------------------------------------------------------------------
-- Total RP 3
-- Map marker and coordinates system
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

TRP3_API.map = {};

local Utils, Events, Globals = TRP3_API.utils, TRP3_API.events, TRP3_API.globals;
local Comm = TRP3_API.communication;
local setupIconButton = TRP3_API.ui.frame.setupIconButton;
local displayDropDown = TRP3_API.ui.listbox.displayDropDown;
local loc = TRP3_API.locale.getText;
local tinsert, assert, tonumber, pairs, _G, wipe = tinsert, assert, tonumber, pairs, _G, wipe;
local CreateFrame = CreateFrame;

local after = C_Timer.After;
local playAnimation = TRP3_API.ui.misc.playAnimation;
local tsize = Utils.table.size;
local getConfigValue = TRP3_API.configuration.getValue;

local CONFIG_UI_ANIMATIONS = "ui_animations";
local CONFIG_MAP_MARKERS_HIGH_STRATA = "register_map_markers_high_strata";
local CONFIG_MAP_AUTO_SCAN = "register_map_auto_scan";
local CONFIG_MAP_MARKER_ICON_TYPE = "register_map_marker_icon_type";

local TRP3_ScanLoaderFramePercent, TRP3_ScanLoaderFrame = TRP3_ScanLoaderFramePercent, TRP3_ScanLoaderFrame;

local SetMapToCurrentZone = SetMapToCurrentZone;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Logic
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local SCAN_STRUCTURES = {};

local function registerScan(structure)
	assert(structure and structure.id, "Must have a structure and a structure.id!");
	SCAN_STRUCTURES[structure.id] = structure;
	if structure.scanResponder and structure.scanCommand then
		Comm.broadcast.registerCommand(structure.scanCommand, structure.scanResponder);
	end
	if structure.scanAssembler and structure.scanCommand then
		if not structure.saveStructure then
			structure.saveStructure = {};
		end
		Comm.broadcast.registerP2PCommand(structure.scanCommand, function(...)
			structure.scanAssembler(structure.saveStructure, ...);
		end)
	end

	return structure;
end
TRP3_API.map.registerScan = registerScan;

local function getScan(scanID)
	return SCAN_STRUCTURES[scanID];
end
TRP3_API.map.getScan = getScan;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Display
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local WorldMapTooltip, WorldMapPOIFrame = WorldMapTooltip, WorldMapPOIFrame;
local MARKER_NAME_PREFIX = "TRP3_WordMapMarker";

local MAX_DISTANCE_MARKER = math.sqrt(0.5 * 0.5 + 0.5 * 0.5);

local function hideAllMarkers()
	local i = 1;
	while(_G[MARKER_NAME_PREFIX .. i]) do
		_G[MARKER_NAME_PREFIX .. i]:Hide();
		i = i + 1;
	end
end

local function getVisibleOverlappingMarkers(referenceMarker, radius)
	local markers = {};
	if not referenceMarker or not referenceMarker:IsVisible() then
		return markers;
	end
	local refX, refY = referenceMarker:GetCenter();
	if not refX or not refY then
		return markers;
	end
	radius = radius or 20;
	local i = 1;
	while(_G[MARKER_NAME_PREFIX .. i]) do
		local marker = _G[MARKER_NAME_PREFIX .. i];
		if marker:IsVisible() and marker.entryKey then
			local x, y = marker:GetCenter();
			if x and y then
				local dx = x - refX;
				local dy = y - refY;
				if (dx * dx + dy * dy) <= (radius * radius) then
					tinsert(markers, marker);
				end
			end
		end
		i = i + 1;
	end
	return markers;
end

local function handleMarkerClick(marker, button, structure)
	if not marker or not structure or not structure.onMarkerClick then
		return;
	end
	local overlappingMarkers = getVisibleOverlappingMarkers(marker, 24);
	if #overlappingMarkers > 1 then
		local dropdownItems = {};
		tinsert(dropdownItems, {structure.scanTitle or UNKNOWN, nil});
		table.sort(overlappingMarkers, function(left, right)
			local leftName = (left.entry and (left.entry.name or left.scanLine)) or left.entryKey or "";
			local rightName = (right.entry and (right.entry.name or right.scanLine)) or right.entryKey or "";
			return tostring(leftName):lower() < tostring(rightName):lower();
		end);
		for _, overlappingMarker in pairs(overlappingMarkers) do
			local entry = overlappingMarker.entry or {};
			local label = entry.name or overlappingMarker.scanLine or overlappingMarker.entryKey;
			tinsert(dropdownItems, {label, overlappingMarker.entryKey});
		end
		displayDropDown(marker, dropdownItems, function(entryKey)
			if entryKey then
				structure.onMarkerClick(entryKey, structure.saveStructure[entryKey], button);
			end
		end, 0, true);
		return;
	end
	structure.onMarkerClick(marker.entryKey, marker.entry, button);
end

local function displayMarkers(structure, instantDisplay)
	if not WorldMapFrame:IsVisible() then
		return;
	end

	if structure.prepareDisplay then
		structure.prepareDisplay(structure.saveStructure);
	end

	local i = 1;
	for key, entry in pairs(structure.saveStructure) do
		if not structure.shouldDisplayEntry or structure.shouldDisplayEntry(key, entry) then
			local marker = _G[MARKER_NAME_PREFIX .. i];
			if not marker then
				marker = CreateFrame("Button", MARKER_NAME_PREFIX .. i, WorldMapButton, "TRP3_WorldMapUnit");
			
				-- map icon strata
				if getConfigValue(CONFIG_MAP_MARKERS_HIGH_STRATA) then
					marker:SetFrameStrata("HIGH");
				end

				marker.borderBackdrop = {
	edgeFile = "Interface\\AddOns\\TranquilRP3\\resources\\UI\\ui-frame-backdrop-edge",
					tile = true,
					edgeSize = 5,
					tileSize = 380,
					insets = { left = 2, right = 2, top = 2, bottom = 2 }
				};
			
				marker:SetSize(22, 22);
				marker:EnableMouse(true);
				marker:RegisterForClicks("LeftButtonUp", "RightButtonUp");
			
				marker:SetScript("OnEnter", function(self)
					WorldMapPOIFrame.allowBlobTooltip = false;
					WorldMapTooltip:Hide();
					WorldMapTooltip:SetOwner(self, "ANCHOR_RIGHT", 0, 0);
					WorldMapTooltip:AddLine(structure.scanTitle, 1, 1, 1, true);
					local j = 1;
					while(_G[MARKER_NAME_PREFIX .. j]) do
						local markerWidget = _G[MARKER_NAME_PREFIX .. j];
						if markerWidget:IsVisible() and markerWidget:IsMouseOver() then
							local scanLine = markerWidget.scanLine;
							if scanLine then
								WorldMapTooltip:AddLine(scanLine, 1, 1, 1, true);
							end
						end
						j = j + 1;
					end
					WorldMapTooltip:Show();
				end);

				marker:SetScript("OnLeave", function()
					WorldMapPOIFrame.allowBlobTooltip = true;
					WorldMapTooltip:Hide();
				end);
				marker:SetScript("OnClick", function(self, button)
					handleMarkerClick(self, button, structure);
				end);
			end

			local mapFrame = WorldMapButton or WorldMapDetailFrame;
			local x = (entry.x or 0) * mapFrame:GetWidth();
			local y = - (entry.y or 0) * mapFrame:GetHeight();
		
			if marker:GetParent() ~= mapFrame then
				marker:SetParent(mapFrame);
			end

			marker:ClearAllPoints();
			marker:SetPoint("CENTER", mapFrame, "TOPLEFT", x, y);

			local iconWidget = _G[marker:GetName() .. "Icon"];
		
			if iconWidget then
				iconWidget:ClearAllPoints();
				iconWidget:SetPoint("CENTER", marker, "CENTER", 0, 0);
				iconWidget:SetSize(17, 17);
			end
			local iconType = getConfigValue(CONFIG_MAP_MARKER_ICON_TYPE) or 1;
			local targetRace = entry.race;
			local targetGender = entry.gender;
			local targetFaction = entry.faction;
			local targetFactionCode = tostring(targetFaction or "");
			local targetFactionLower = string.lower(targetFactionCode);

			marker:SetBackdrop(nil);
		
			-- default icon
			local function setDefaultIcon()
		iconWidget:SetTexture("Interface\\AddOns\\TranquilRP3\\resources\\UI\\OBJECTICONS");
				iconWidget:SetTexCoord(0.52734375, 0.6015625, 0.09375, 0.390625);
			end
		
			if iconType == 2 and (targetFaction == "Alliance" or targetFactionLower == "alliance" or targetFactionCode == "f1") then
			iconWidget:SetTexture("Interface\\AddOns\\TranquilRP3\\resources\\UI\\UI-PVP-Alliance");
				iconWidget:SetTexCoord(0.09375, 0.5625, 0.046875, 0.578125);
			elseif iconType == 2 and (targetFaction == "Horde" or targetFactionLower == "horde" or targetFactionCode == "f2") then
			iconWidget:SetTexture("Interface\\AddOns\\TranquilRP3\\resources\\UI\\UI-PVP-Horde");
				iconWidget:SetTexCoord(0.09375, 0.53125, 0.046875, 0.5625);
			elseif iconType == 2 and (targetFaction == "Independent" or targetFaction == "Neutral" or targetFactionLower == "independent" or targetFactionLower == "neutral" or targetFactionCode == "f3") then
				iconWidget:SetTexture("Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconTRP.blp");
				iconWidget:SetTexCoord(0.1, 0.9, 0.1, 0.9);
			elseif iconType == 3 and targetRace and targetGender then
				local raceTexture = TRP3_API.ui.misc.getUnitTexture(targetRace, targetGender);
				if raceTexture then
					iconWidget:SetTexture("Interface\\Icons\\" .. raceTexture);
					iconWidget:SetTexCoord(0.1, 0.9, 0.1, 0.9); 
					marker:SetBackdrop(marker.borderBackdrop);
				else
					setDefaultIcon();
				end
			elseif iconType == 4 and entry.profileIcon and entry.profileIcon ~= "" then
				iconWidget:SetTexture("Interface\\Icons\\" .. entry.profileIcon);
				iconWidget:SetTexCoord(0.1, 0.9, 0.1, 0.9);
				marker:SetBackdrop(marker.borderBackdrop);
			else
				setDefaultIcon();
			end

			if structure.scanMarkerDecorator then
				structure.scanMarkerDecorator(key, entry, marker);
			end

			marker.entryKey = key;
			marker.entry = entry;

			if not instantDisplay and getConfigValue(CONFIG_UI_ANIMATIONS) then
				local distanceX = 0.5 - entry.x;
				local distanceY = 0.5 - entry.y;
				local distance = math.sqrt(distanceX * distanceX + distanceY * distanceY);
				local factor = distance/MAX_DISTANCE_MARKER;

				after(4 * factor, function()
					marker:Show();
					marker:SetAlpha(0);
					playAnimation(_G[marker:GetName() .. "Bounce"]);

					-- Ensure the marker becomes fully visible after animation
					after(1, function()
						marker:SetAlpha(1);
					end);
				end);

			else
				marker:Show();
				marker:SetAlpha(1);
			end
		
			i = i + 1;
		end
	end
end

local function launchScan(scanID)
	assert(SCAN_STRUCTURES[scanID], ("Unknown scan id %s"):format(scanID));
	local structure = SCAN_STRUCTURES[scanID];
	if structure.scan then
		hideAllMarkers();
		if structure.clearOnScan ~= false then
			wipe(structure.saveStructure);
		end
		structure.scan();
		if structure.scanDuration and structure.scanComplete then
			local mapID = GetCurrentMapAreaID();
			TRP3_WorldMapButton:Disable();
			setupIconButton(TRP3_WorldMapButton, "INV_MISC_ENGGIZMOS_20");
			TRP3_ScanLoaderFrame.time = structure.scanDuration;
			TRP3_ScanLoaderFrame:Show();
			TRP3_ScanLoaderAnimationRotation:SetDuration(structure.scanDuration);
			TRP3_ScanLoaderGlowRotation:SetDuration(structure.scanDuration);
			TRP3_ScanLoaderBackAnimation1Rotation:SetDuration(structure.scanDuration);
			TRP3_ScanLoaderBackAnimation2Rotation:SetDuration(structure.scanDuration);
			playAnimation(TRP3_ScanLoaderAnimation);
			playAnimation(TRP3_ScanFadeIn);
			playAnimation(TRP3_ScanLoaderGlow);
			playAnimation(TRP3_ScanLoaderBackAnimation1);
			playAnimation(TRP3_ScanLoaderBackAnimation2);
			after(structure.scanDuration, function()
				TRP3_WorldMapButton:Enable();
				setupIconButton(TRP3_WorldMapButton, "INV_MISC_ENGGIZMOS_20");
				if mapID == GetCurrentMapAreaID() then
					structure.scanComplete(structure.saveStructure);
					displayMarkers(structure);
				end
				playAnimation(TRP3_ScanLoaderBackAnimationGrow1);
				playAnimation(TRP3_ScanLoaderBackAnimationGrow2);
				playAnimation(TRP3_ScanFadeOut);
				if getConfigValue(CONFIG_UI_ANIMATIONS) then
					after(1, function()
						TRP3_ScanLoaderFrame:Hide();
						TRP3_ScanLoaderFrame:SetAlpha(1);
					end);
				else
					TRP3_ScanLoaderFrame:Hide();
				end
			end);
		end
	end
end
TRP3_API.map.launchScan = launchScan;

local function refreshScanDisplay(scanID)
	local structure = SCAN_STRUCTURES[scanID];
	if not structure then
		return;
	end
	hideAllMarkers();
	displayMarkers(structure, true);
end
TRP3_API.map.refreshScanDisplay = refreshScanDisplay;

local function onButtonClicked(self)
	if UnitAffectingCombat("player") then
		return;
	end
	
	local playerScanStructure = SCAN_STRUCTURES["playerScan"];
	if playerScanStructure and (not playerScanStructure.canScan or playerScanStructure.canScan() == true) then
		SetMapToCurrentZone();
		launchScan("playerScan");
	end
end

local currentMapID;

local function onWorldMapUpdate()
	local mapID = GetCurrentMapAreaID();
	
	if currentMapID ~= mapID and not TRP3_WorldMapButton.doNotHide then
		currentMapID = mapID;
		hideAllMarkers();
	end

	for _, structure in pairs(SCAN_STRUCTURES) do
		if structure.saveStructure and structure.clearOnScan == false then
			displayMarkers(structure, true);
		end
	end
end

TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_LOAD, function()
	setupIconButton(TRP3_WorldMapButton, "INV_MISC_ENGGIZMOS_20");
	TRP3_WorldMapButton.title = loc("MAP_BUTTON_TITLE");
	TRP3_WorldMapButton.subtitle = "|cffff9900" .. loc("MAP_BUTTON_SUBTITLE");
	TRP3_WorldMapButton:SetScript("OnClick", onButtonClicked);
	
	-- 3.3.5 compatibility: Set font before SetText to avoid "Font not set" error
	TRP3_ScanLoaderFrameScanning:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE");
	TRP3_ScanLoaderFrameScanning:SetText(loc("MAP_BUTTON_SCANNING"));
	TRP3_ScanLoaderFrameScanning:SetTextColor(1, 0.82, 0); -- Gold color

	TRP3_ScanLoaderFrame:SetScript("OnShow", function(self)
		self.refreshTimer = 0;
	end);
	TRP3_ScanLoaderFrame:SetScript("OnUpdate", function(self, elapsed)
		self.refreshTimer = self.refreshTimer + elapsed;
		local percent = math.ceil((self.refreshTimer / self.time) * 100);
		-- TRP3_ScanLoaderFramePercent:SetText(percent .. "%");
	end);

	Utils.event.registerHandler("WORLD_MAP_UPDATE", onWorldMapUpdate);
	
	-- disable scan in combat
	local function onCombatStart()
		if activeScanTimer then
			activeScanTimer = nil;
		end
		
		if TRP3_ScanLoaderFrame and TRP3_ScanLoaderFrame:IsVisible() then
			TRP3_ScanLoaderFrame:Hide();
			TRP3_WorldMapButton:Enable();
			setupIconButton(TRP3_WorldMapButton, "INV_MISC_ENGGIZMOS_20");
		end
	end
	
	Utils.event.registerHandler("PLAYER_REGEN_DISABLED", onCombatStart);
	
	-- auto-scan functionality using event-based approach instead of function override
	local activeScanTimer = nil;
	local autoScanTriggered = false; -- prevent repeated auto-scans
	
	-- use WORLD_MAP_UPDATE event instead of overriding WorldMapFrame.Show
	local function onMapOpenForAutoScan()
		if not WorldMapFrame:IsVisible() then
			if autoScanTriggered then
				autoScanTriggered = false;
			end
			return;
		end
		
		if autoScanTriggered then
			return;
		end
		
		-- attempt to auto-scan when not in combat
		local inCombat = UnitAffectingCombat("player");
		local autoScanEnabled = getConfigValue(CONFIG_MAP_AUTO_SCAN);
		
		if autoScanEnabled and not inCombat then
			local playerScanStructure = SCAN_STRUCTURES["playerScan"];
			if playerScanStructure and playerScanStructure.autoScanOnMapOpen ~= false and (not playerScanStructure.canScan or playerScanStructure.canScan() == true) then
				autoScanTriggered = true;
				
				activeScanTimer = after(0.5, function()
					activeScanTimer = nil;
					local stillInCombat = UnitAffectingCombat("player");
					if not stillInCombat and WorldMapFrame:IsVisible() then
						launchScan("playerScan");
					else
						autoScanTriggered = false;
					end
				end);
			end
		end
	end
	
	Utils.event.registerHandler("WORLD_MAP_UPDATE", onMapOpenForAutoScan);
end);
