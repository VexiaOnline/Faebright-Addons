----------------------------------------------------------------------------------
-- TranquilRP3
-- Postal Enhanced multipart letter reader compatibility
----------------------------------------------------------------------------------

local moduleStarted;

local function safeText(text)
	if text and text ~= "" then
		return text;
	end
	return "(no subject)";
end

local function parseMultipartSubject(subject)
	if not subject then
		return;
	end
	local token, part, total, cleanSubject = strmatch(subject, "^%[P([0-9A-F]+)%-(%d+)/(%d+)%]%s*(.*)$");
	if token then
		return token, tonumber(part), tonumber(total), cleanSubject;
	end
end

local function parseMultipartBody(body)
	if not body then
		return;
	end
	local token, part, total, cleanBody = strmatch(body, "^%[%[Postal:([0-9A-F]+):(%d+)/(%d+)%]%]\n?(.*)$");
	if token then
		return token, tonumber(part), tonumber(total), cleanBody or "";
	end
end

local function getCombinedInboxLetter(mailID)
	if not mailID or not GetInboxHeaderInfo or not GetInboxText or not GetInboxNumItems then
		return;
	end

	local _, _, sender, subject = GetInboxHeaderInfo(mailID);
	local body = GetInboxText(mailID) or "";
	local token, part, total, cleanBody = parseMultipartBody(body);
	local cleanSubject = subject;

	if not token then
		token, part, total, cleanSubject = parseMultipartSubject(subject);
		if token then
			cleanBody = body;
		else
			return;
		end
	end

	local parts = {};
	for index = 1, GetInboxNumItems() do
		local _, _, partSender, partSubject = GetInboxHeaderInfo(index);
		local partBody = GetInboxText(index) or "";
		local partToken, partNumber, partTotal, partCleanBody = parseMultipartBody(partBody);
		local partCleanSubject;
		if not partToken then
			partToken, partNumber, partTotal, partCleanSubject = parseMultipartSubject(partSubject);
			partCleanBody = partBody;
		end

		if partToken == token and partTotal == total and partSender == sender then
			parts[partNumber] = partCleanBody or "";
			if partCleanSubject and partCleanSubject ~= "" then
				cleanSubject = partCleanSubject;
			end
		end
	end

	for index = 1, total do
		if not parts[index] then
			return {
				subject = cleanSubject,
				body = format("This is part %d of %d. The full long letter will display here once all parts are in your mailbox.", part or 1, total),
			};
		end
	end

	return {
		subject = cleanSubject,
		body = table.concat(parts, ""),
	};
end

local function showCombinedInboxLetter(mailID)
	if IsAddOnLoaded and IsAddOnLoaded("PostalEnhanced") then
		return;
	end

	local combined = getCombinedInboxLetter(mailID);
	if not combined then
		return;
	end

	if OpenMailSubject and OpenMailSubject.SetText then
		OpenMailSubject:SetText(safeText(combined.subject));
	end
	if OpenMailBodyText and OpenMailBodyText.SetText then
		OpenMailBodyText:SetText(combined.body or "");
	end
	if OpenMailScrollFrame and OpenMailScrollFrame.UpdateScrollChildRect then
		OpenMailScrollFrame:UpdateScrollChildRect();
		if OpenMailScrollFrameScrollBar then
			OpenMailScrollFrameScrollBar:SetValue(0);
		end
	end
end

local function resolveMailID(button, index)
	local mailID = index or button;
	if type(mailID) ~= "number" and button and type(button.GetID) == "function" then
		mailID = button:GetID();
	end
	if mailID and GetInboxNumItems and mailID >= 1 and mailID <= GetInboxNumItems() then
		return mailID;
	end
end

local function queueShowCombinedInboxLetter(mailID)
	if not mailID then
		return;
	end
	if OpenMailFrame then
		OpenMailFrame.openMailID = mailID;
	end
	if InboxFrame then
		InboxFrame.openMailID = mailID;
	end

	showCombinedInboxLetter(mailID);
	if C_Timer and C_Timer.After then
		C_Timer.After(0.10, function()
			showCombinedInboxLetter(mailID);
		end);
	end
end

local function onStart()
	if moduleStarted then
		return;
	end
	moduleStarted = true;

	if hooksecurefunc and type(InboxFrame_OnClick) == "function" then
		hooksecurefunc("InboxFrame_OnClick", function(button, index)
			queueShowCombinedInboxLetter(resolveMailID(button, index));
		end);
	end
end

TRP3_API.module.registerModule({
	name = "Postal multipart reader",
	description = "Displays Postal Enhanced split letters as a single read-only mailbox letter when Postal Enhanced is not installed.",
	version = 1.000,
	id = "trp3_postal_reader",
	onStart = onStart,
	minVersion = 3,
});
