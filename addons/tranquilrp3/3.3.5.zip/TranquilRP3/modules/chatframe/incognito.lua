----------------------------------------------------------------------------------
-- TranquilRP3
-- Incognito-style chat prefixes
----------------------------------------------------------------------------------

local Config = TRP3_API.configuration;
local registerConfigKey = Config.registerConfigKey;
local getConfigValue = Config.getValue;
local setConfigValue = Config.setValue;

TRP3_API.incognito = TRP3_API.incognito or {};
local API = TRP3_API.incognito;

local CONFIG_ENABLED = "incognito_enabled";
local CONFIG_NAME = "incognito_name";
local CONFIG_BRACKET_STYLE = "incognito_bracket_style";
local CONFIG_HIDE_MATCHING = "incognito_hide_matching_character";
local CONFIG_PARTIAL_MATCH = "incognito_partial_match";
local CONFIG_GUILD = "incognito_channel_guild";
local CONFIG_PARTY = "incognito_channel_party";
local CONFIG_RAID = "incognito_channel_raid";
local CONFIG_BATTLEGROUND = "incognito_channel_battleground";
local CONFIG_ARENA = "incognito_channel_arena";
local CONFIG_GENERAL = "incognito_channel_general";
local CONFIG_TRADE = "incognito_channel_trade";
local CONFIG_WORLD = "incognito_channel_world";
local CONFIG_CUSTOM = "incognito_custom_channels";
local CONFIG_PROMPT_SEEN = "incognito_standalone_prompt_seen";

local playerName;
local activeMessage;
local promptFrame;
local filtersRegistered;
local filterFunc;

local BRACKET_STYLES = {
	{ "Round ()", "paren" },
	{ "Square []", "square" },
	{ "Curly {}", "curly" },
	{ "Angle <>", "angle" },
};

local PARTIAL_MATCH_MODES = {
	{ "Disabled", "disabled" },
	{ "Start of character name", "start" },
	{ "Anywhere in character name", "anywhere" },
	{ "End of character name", "end" },
};

local PREFIX_EVENTS = {
	"CHAT_MSG_GUILD",
	"CHAT_MSG_OFFICER",
	"CHAT_MSG_PARTY",
	"CHAT_MSG_PARTY_LEADER",
	"CHAT_MSG_RAID",
	"CHAT_MSG_RAID_LEADER",
	"CHAT_MSG_RAID_WARNING",
	"CHAT_MSG_INSTANCE_CHAT",
	"CHAT_MSG_INSTANCE_CHAT_LEADER",
	"CHAT_MSG_CHANNEL",
};

local function trim(value)
	return (tostring(value or ""):gsub("^%s+", ""):gsub("%s+$", ""));
end

local function normalizeChannelName(value)
	value = string.lower(trim(value));
	value = value:gsub("^%d+%.%s*", "");
	value = value:gsub("[%s%-%_]", "");
	return value;
end

local EXCLUDED_CUSTOM_CHANNELS = {
	general = true,
	localdefense = true,
	trade = true,
	xtensionxtooltip2 = true,
};

local function isExcludedCustomChannel(channelName)
	local normalized = normalizeChannelName(channelName);
	if EXCLUDED_CUSTOM_CHANNELS[normalized] then
		return true;
	end
	return normalized:find("^general") or normalized:find("^trade") or normalized:find("^localdefense");
end

local function startsWithCommandSymbol(message)
	if type(message) ~= "string" then
		return false;
	end
	local firstChar = message:match("^%s*(.)");
	return firstChar and string.find("/!#@?*", firstChar, 1, true);
end

local function containsRPEmoteMarker(message)
	return type(message) == "string" and message:find("%*.-%*") ~= nil;
end

local function getInstanceKind()
	if type(GetInstanceInfo) ~= "function" then
		return nil;
	end
	local _, instanceType = GetInstanceInfo();
	return instanceType;
end

local function extractPlayerGUID(...)
	for index = 1, select("#", ...) do
		local value = select(index, ...);
		if type(value) == "string" and value:match("^Player%-") then
			return value;
		end
	end
end

local function getChannelCandidates(target)
	local candidates = {};
	local function add(value)
		local normalized = normalizeChannelName(value);
		if normalized ~= "" then
			candidates[normalized] = value;
		end
	end

	add(target);
	if target and type(GetChannelName) == "function" then
		local channelID, channelName = GetChannelName(target);
		add(channelID);
		add(channelName);
	end
	return candidates;
end

local function isFixedChannelEnabled(target)
	local candidates = getChannelCandidates(target);
	for channelName in pairs(candidates) do
		if getConfigValue(CONFIG_GENERAL) and channelName:find("^general") then
			return true;
		end
		if getConfigValue(CONFIG_TRADE) and channelName:find("^trade") then
			return true;
		end
		if getConfigValue(CONFIG_WORLD) and (channelName == "world" or channelName == "worldchat") then
			return true;
		end
	end
	return false;
end

local function isCustomChannelEnabled(target)
	local customChannels = getConfigValue(CONFIG_CUSTOM);
	if not customChannels or customChannels == "" then
		return false;
	end

	local candidates = getChannelCandidates(target);
	for candidate, display in pairs(candidates) do
		if candidate ~= "" and not isExcludedCustomChannel(display) then
			for channelName in customChannels:gmatch("([^,]+)") do
				if normalizeChannelName(channelName) == candidate then
					return true;
				end
			end
		end
	end
	return false;
end

local function shouldHideForCharacterName()
	if not getConfigValue(CONFIG_HIDE_MATCHING) or not playerName then
		return false;
	end

	local configured = string.lower(trim(getConfigValue(CONFIG_NAME)));
	local current = string.lower(playerName or "");
	if configured == "" then
		return false;
	end
	if configured == current then
		return true;
	end

	local mode = getConfigValue(CONFIG_PARTIAL_MATCH);
	if mode == "start" then
		return current:sub(1, configured:len()) == configured;
	elseif mode == "anywhere" then
		return current:find(configured, 1, true) ~= nil;
	elseif mode == "end" then
		return current:sub(-configured:len()) == configured;
	end
	return false;
end

local function getNamePrefix()
	local brackets = {
		paren = { "(", ")" },
		square = { "[", "]" },
		curly = { "{", "}" },
		angle = { "<", ">" },
	};
	local pair = brackets[getConfigValue(CONFIG_BRACKET_STYLE)] or brackets.paren;
	return pair[1] .. trim(getConfigValue(CONFIG_NAME)) .. pair[2] .. ": ";
end

local function hasNamePrefix(message)
	if type(message) ~= "string" then
		return false;
	end
	local prefix = getNamePrefix();
	return message:sub(1, prefix:len()) == prefix;
end

local function shouldPrefix(chatType, target)
	if not getConfigValue(CONFIG_ENABLED) or trim(getConfigValue(CONFIG_NAME)) == "" then
		return false;
	end
	if startsWithCommandSymbol(activeMessage) or containsRPEmoteMarker(activeMessage) then
		return false;
	end
	if shouldHideForCharacterName() then
		return false;
	end

	chatType = string.upper(tostring(chatType or "SAY"));
	local instanceType = getInstanceKind();
	if getConfigValue(CONFIG_GUILD) and (chatType == "GUILD" or chatType == "OFFICER") then
		return true;
	end
	if getConfigValue(CONFIG_RAID) and (chatType == "RAID" or chatType == "RAID_LEADER" or chatType == "RAID_WARNING") then
		return true;
	end
	if chatType == "PARTY" or chatType == "PARTY_LEADER" then
		return getConfigValue(CONFIG_PARTY);
	end
	if chatType == "INSTANCE_CHAT" or chatType == "INSTANCE_CHAT_LEADER" or chatType == "BATTLEGROUND" or chatType == "BATTLEGROUND_LEADER" then
		if instanceType == "pvp" then
			return getConfigValue(CONFIG_BATTLEGROUND);
		elseif instanceType == "arena" then
			return getConfigValue(CONFIG_ARENA);
		elseif instanceType == "party" then
			return getConfigValue(CONFIG_PARTY);
		elseif instanceType == "raid" then
			return getConfigValue(CONFIG_RAID);
		end
		return getConfigValue(CONFIG_BATTLEGROUND);
	end
	if chatType == "CHANNEL" then
		return isFixedChannelEnabled(target) or isCustomChannelEnabled(target);
	end
	return false;
end

function API.processOutgoingMessage(message, chatType, target)
	activeMessage = message;
	if not hasNamePrefix(message) and shouldPrefix(chatType, target) then
		message = getNamePrefix() .. tostring(message or "");
	end
	activeMessage = nil;
	return message;
end

local function colorPrefixFilter(_, _, message, author, ...)
	if not getConfigValue(CONFIG_ENABLED) or type(message) ~= "string" then
		return false;
	end

	local pre, open, name, close, afterClose, colonSpaces, rest = message:match("^(%s*)([%(%[%{%<])([^%(%[%{%<%]%}%>]+)([%)%]%}%>])(%s*):(%s*)(.*)$");
	if not open then
		return false;
	end
	local expectedClose = { ["("] = ")", ["["] = "]", ["{"] = "}", ["<"] = ">" };
	if expectedClose[open] ~= close then
		return false;
	end

	local classFile;
	local colors = (type(CUSTOM_CLASS_COLORS) == "table" and CUSTOM_CLASS_COLORS) or RAID_CLASS_COLORS;
	local guid = extractPlayerGUID(...);
	if guid and GetPlayerInfoByGUID then
		local ok, _, class = pcall(GetPlayerInfoByGUID, guid);
		if ok then
			classFile = class;
		end
	end
	if not classFile and author and UnitClass then
		local _, class = UnitClass(author);
		classFile = class;
	end
	local color = colors and classFile and colors[classFile];
	if not color then
		return false;
	end

	local hex = ("|cff%02x%02x%02x"):format(math.floor((color.r or 1) * 255 + 0.5), math.floor((color.g or 1) * 255 + 0.5), math.floor((color.b or 1) * 255 + 0.5));
	return false, ("%s%s%s%s|r%s%s:%s%s"):format(pre or "", open, hex, name or "", close, afterClose or "", colonSpaces or "", rest or ""), author, ...;
end

local function registerFilters()
	if filtersRegistered or type(ChatFrame_AddMessageEventFilter) ~= "function" then
		return;
	end
	filterFunc = colorPrefixFilter;
	for _, eventName in ipairs(PREFIX_EVENTS) do
		ChatFrame_AddMessageEventFilter(eventName, filterFunc);
	end
	filtersRegistered = true;
end

StaticPopupDialogs["TRP3_DISABLE_INCOGNITO_EXTINGUISHED"] = {
	text = "Incognito Extinguished is enabled alongside TranquilRP3's built-in Incognito module.\n\nRunning both can duplicate prefixes or conflict with chat wrappers.\n\nDisable Incognito Extinguished now?",
	button1 = "Disable Incognito",
	button2 = "Keep Enabled",
	OnAccept = function()
		if DisableAddOn then
			DisableAddOn("IncognitoExtinguished");
		end
		setConfigValue(CONFIG_PROMPT_SEEN, true);
		if ReloadUI then
			ReloadUI();
		else
			StaticPopup_Show("CLIENT_RESTART_ALERT");
		end
	end,
	OnCancel = function()
		setConfigValue(CONFIG_PROMPT_SEEN, true);
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
	showAlert = true,
};

local function maybePromptForStandalone()
	if getConfigValue(CONFIG_PROMPT_SEEN) then
		return;
	end
	if IsAddOnLoaded and IsAddOnLoaded("IncognitoExtinguished") then
		StaticPopup_Show("TRP3_DISABLE_INCOGNITO_EXTINGUISHED");
	end
end

local function queueStandalonePrompt()
	if promptFrame then
		return;
	end
	promptFrame = CreateFrame("Frame");
	promptFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
	promptFrame:SetScript("OnEvent", function(self)
		self = self or this;
		self:UnregisterEvent("PLAYER_ENTERING_WORLD");
		self.elapsed = 0;
		self:SetScript("OnUpdate", function(frame, elapsed)
			frame = frame or this;
			frame.elapsed = (frame.elapsed or 0) + (elapsed or arg1 or 0);
			if frame.elapsed < 4 then
				return;
			end
			frame:SetScript("OnUpdate", nil);
			maybePromptForStandalone();
		end);
	end);
end

local function getStandaloneProfile()
	if type(IncognitoExtinguishedDB) ~= "table" or type(IncognitoExtinguishedDB.profiles) ~= "table" then
		return nil;
	end

	local profileName = "Default";
	if type(IncognitoExtinguishedDB.profileKeys) == "table" then
		local realmName = GetRealmName and GetRealmName() or "";
		local profileKey = (UnitName("player") or "") .. " - " .. realmName;
		profileName = IncognitoExtinguishedDB.profileKeys[profileKey] or profileName;
	end
	return IncognitoExtinguishedDB.profiles[profileName] or IncognitoExtinguishedDB.profiles.Default;
end

local function migrateStandaloneSettings()
	local profile = getStandaloneProfile();
	if type(profile) ~= "table" or trim(getConfigValue(CONFIG_NAME)) ~= "" then
		return;
	end

	if type(profile.name) == "string" then
		setConfigValue(CONFIG_NAME, profile.name);
	end
	if type(profile.enable) == "boolean" then
		setConfigValue(CONFIG_ENABLED, profile.enable);
	end
	if type(profile.bracketStyle) == "string" then
		setConfigValue(CONFIG_BRACKET_STYLE, profile.bracketStyle);
	end
	if type(profile.hideOnMatchingCharName) == "boolean" then
		setConfigValue(CONFIG_HIDE_MATCHING, profile.hideOnMatchingCharName);
	end
	if type(profile.partialMatchMode) == "string" then
		setConfigValue(CONFIG_PARTIAL_MATCH, profile.partialMatchMode);
	end
	setConfigValue(CONFIG_GUILD, profile.guild == true);
	setConfigValue(CONFIG_PARTY, profile.party == true or profile.dungeon == true);
	setConfigValue(CONFIG_RAID, profile.raid == true);
	setConfigValue(CONFIG_BATTLEGROUND, profile.battleground == true);
	setConfigValue(CONFIG_ARENA, profile.arena == true);
	setConfigValue(CONFIG_GENERAL, profile.general == true or profile.world_chat == true or (profile.globalChannelEnabled == true and profile.globalChannelPreset == "general"));
	setConfigValue(CONFIG_TRADE, profile.trade == true or profile.world_chat == true or (profile.globalChannelEnabled == true and profile.globalChannelPreset == "trade"));
	setConfigValue(CONFIG_WORLD, profile.world == true or profile.world_chat == true or (profile.globalChannelEnabled == true and (profile.globalChannelPreset == "world" or profile.globalChannelPreset == "global")));

	if type(profile.enabledCustomChannels) == "table" then
		local customChannels = {};
		for channelName, enabled in pairs(profile.enabledCustomChannels) do
			if enabled then
				tinsert(customChannels, channelName);
			end
		end
		if #customChannels > 0 then
			setConfigValue(CONFIG_CUSTOM, table.concat(customChannels, ", "));
		end
	elseif profile.globalChannelEnabled == true and profile.globalChannelPreset == "custom" and type(profile.channel) == "string" then
		setConfigValue(CONFIG_CUSTOM, profile.channel);
	end
end

local function createConfigPage()
	Config.registerConfigurationPage({
		id = "main_config_incognito",
		menuText = "Incognito settings",
		pageText = "Incognito settings",
		elements = {
			{ inherit = "TRP3_ConfigH1", title = "General" },
			{ inherit = "TRP3_ConfigCheck", title = "Enable Incognito prefixes", configKey = CONFIG_ENABLED },
			{ inherit = "TRP3_ConfigEditBox", title = "Name prefix", configKey = CONFIG_NAME },
			{ inherit = "TRP3_ConfigDropDown", title = "Bracket style", listContent = BRACKET_STYLES, configKey = CONFIG_BRACKET_STYLE, listCancel = true },
			{ inherit = "TRP3_ConfigCheck", title = "Hide when matching character name", configKey = CONFIG_HIDE_MATCHING },
			{ inherit = "TRP3_ConfigDropDown", title = "Partial name matching", listContent = PARTIAL_MATCH_MODES, configKey = CONFIG_PARTIAL_MATCH, listCancel = true },
			{ inherit = "TRP3_ConfigH1", title = "Channels" },
			{ inherit = "TRP3_ConfigCheck", title = "Guild and Officer", configKey = CONFIG_GUILD },
			{ inherit = "TRP3_ConfigCheck", title = "Party", configKey = CONFIG_PARTY },
			{ inherit = "TRP3_ConfigCheck", title = "Raid", configKey = CONFIG_RAID },
			{ inherit = "TRP3_ConfigCheck", title = "Battleground", configKey = CONFIG_BATTLEGROUND },
			{ inherit = "TRP3_ConfigCheck", title = "Arena", configKey = CONFIG_ARENA },
			{ inherit = "TRP3_ConfigCheck", title = "General channel", configKey = CONFIG_GENERAL },
			{ inherit = "TRP3_ConfigCheck", title = "Trade channel", configKey = CONFIG_TRADE },
			{ inherit = "TRP3_ConfigCheck", title = "World channel", configKey = CONFIG_WORLD },
			{ inherit = "TRP3_ConfigEditBox", title = "Custom channels", configKey = CONFIG_CUSTOM, help = "Comma-separated channel names." },
		},
	});
end

local function slashCommand(input)
	input = trim(input);
	local command, rest = input:match("^(%S+)%s*(.*)$");
	command = command and string.lower(command) or "";
	if command == "name" then
		local name = rest:match('^"(.-)"$') or rest;
		if name and name ~= "" then
			setConfigValue(CONFIG_NAME, name);
			if DEFAULT_CHAT_FRAME then
				DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00TranquilRP3 Incognito name set to:|r " .. name);
			end
		end
	elseif command == "toggle" then
		setConfigValue(CONFIG_ENABLED, not getConfigValue(CONFIG_ENABLED));
	elseif command == "help" then
		if DEFAULT_CHAT_FRAME then
			DEFAULT_CHAT_FRAME:AddMessage("/inc name <name> - Set your Incognito prefix name");
			DEFAULT_CHAT_FRAME:AddMessage("/inc toggle - Toggle TRP3 Incognito");
		end
	else
		TRP3_API.navigation.openMainFrame();
		TRP3_API.navigation.page.setPage("main_config_incognito");
	end
end

local function registerSlash()
	SLASH_TRP3_INCOGNITO1 = "/inc";
	SLASH_TRP3_INCOGNITO2 = "/incex";
	SLASH_TRP3_INCOGNITO3 = "/incognito";
	SlashCmdList.TRP3_INCOGNITO = slashCommand;
end

local function onStart()
	playerName = UnitName("player");
	registerConfigKey(CONFIG_ENABLED, true);
	registerConfigKey(CONFIG_NAME, "");
	registerConfigKey(CONFIG_BRACKET_STYLE, "paren");
	registerConfigKey(CONFIG_HIDE_MATCHING, true);
	registerConfigKey(CONFIG_PARTIAL_MATCH, "disabled");
	registerConfigKey(CONFIG_GUILD, true);
	registerConfigKey(CONFIG_PARTY, false);
	registerConfigKey(CONFIG_RAID, false);
	registerConfigKey(CONFIG_BATTLEGROUND, false);
	registerConfigKey(CONFIG_ARENA, false);
	registerConfigKey(CONFIG_GENERAL, false);
	registerConfigKey(CONFIG_TRADE, false);
	registerConfigKey(CONFIG_WORLD, false);
	registerConfigKey(CONFIG_CUSTOM, "");
	registerConfigKey(CONFIG_PROMPT_SEEN, false);
	migrateStandaloneSettings();
	createConfigPage();
	registerFilters();
	registerSlash();
	queueStandalonePrompt();
end

TRP3_API.module.registerModule({
	name = "Incognito",
	description = "Adds configurable name prefixes to selected chat channels using TranquilRP3's shared chat pipeline.",
	version = 1.000,
	id = "trp3_incognito",
	onStart = onStart,
	minVersion = 3,
});
