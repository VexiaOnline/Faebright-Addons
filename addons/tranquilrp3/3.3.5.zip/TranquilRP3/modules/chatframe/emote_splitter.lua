----------------------------------------------------------------------------------
-- TranquilRP3
-- Chat message splitter
----------------------------------------------------------------------------------

local Config = TRP3_API.configuration;
local registerConfigKey = Config.registerConfigKey;
local getConfigValue = Config.getValue;
local setConfigValue = Config.setValue;

TRP3_API.chatSplitter = TRP3_API.chatSplitter or {};
local API = TRP3_API.chatSplitter;

local CONFIG_ENABLED = "chat_splitter_enabled";
local CONFIG_ASCENDED_PROMPT_SEEN = "chat_splitter_ascended_prompt_seen";
local MAX_CHAT_BYTES = 255;
local SAFE_CHAT_BYTES = 240;
local SEND_INTERVAL = 0.35;
local FIRST_SEND_DELAY = 0.05;
local EMOTE_CONTINUATION_PREFIX = "|| ";

local queue = {};
local queueFrame;
local promptFrame;
local unlockFrame;
local nextSendDelay = 0;

local SPLITTABLE_CHAT_TYPES = {
	AFK = true,
	BATTLEGROUND = true,
	BATTLEGROUND_LEADER = true,
	BN_WHISPER = true,
	CHANNEL = true,
	DND = true,
	EMOTE = true,
	GUILD = true,
	INSTANCE_CHAT = true,
	INSTANCE_CHAT_LEADER = true,
	OFFICER = true,
	PARTY = true,
	PARTY_LEADER = true,
	RAID = true,
	RAID_LEADER = true,
	RAID_WARNING = true,
	SAY = true,
	WHISPER = true,
	YELL = true,
};

local function normalizeChatType(chatType)
	return string.upper(tostring(chatType or "SAY"));
end

local function normalizeMessage(message)
	message = tostring(message or "");
	message = message:gsub("\r\n", "\n"):gsub("\r", "\n"):gsub("\\n", "\n");
	return message;
end

local function splitLongLine(line, maxBytes)
	local chunks = {};
	line = tostring(line or "");
	while line:len() > maxBytes do
		local splitAt;
		for index = maxBytes, 1, -1 do
			local char = line:sub(index, index);
			if char == " " or char == "\t" then
				splitAt = index;
				break;
			end
		end
		if not splitAt or splitAt < 20 then
			splitAt = maxBytes;
		end

		local chunk = strtrim(line:sub(1, splitAt));
		if chunk ~= "" then
			tinsert(chunks, chunk);
		end
		line = strtrim(line:sub(splitAt + 1));
	end
	if line ~= "" then
		tinsert(chunks, line);
	end
	return chunks;
end

local function buildChunks(message, chatType)
	message = normalizeMessage(message);
	if message == "" or (message:len() <= MAX_CHAT_BYTES and not message:find("\n", 1, true)) then
		return nil;
	end

	local chunks = {};
	local continuationBytes = chatType == "EMOTE" and EMOTE_CONTINUATION_PREFIX:len() or 0;
	local firstChunk = true;
	for line in (message .. "\n"):gmatch("(.-)\n") do
		local maxBytes = firstChunk and SAFE_CHAT_BYTES or (SAFE_CHAT_BYTES - continuationBytes);
		local lineChunks = splitLongLine(line, maxBytes);
		for _, chunk in ipairs(lineChunks) do
			if not firstChunk and chatType == "EMOTE" then
				chunk = EMOTE_CONTINUATION_PREFIX .. chunk;
			end
			tinsert(chunks, chunk);
			firstChunk = false;
		end
	end

	if #chunks <= 1 then
		return nil;
	end
	return chunks;
end

local function unlockEditBox(editBox)
	if not editBox then
		return;
	end
	if editBox.SetMaxLetters then
		editBox:SetMaxLetters(0);
	end
	if editBox.SetMaxBytes then
		editBox:SetMaxBytes(0);
	end
	if editBox.SetVisibleTextByteLimit then
		editBox:SetVisibleTextByteLimit(0);
	end
	if editBox.SetMultiLine then
		editBox:SetMultiLine(false);
	end
end

local function unlockChatEditBoxes()
	for index = 1, (NUM_CHAT_WINDOWS or 10) do
		unlockEditBox(_G["ChatFrame" .. index .. "EditBox"]);
	end
	unlockEditBox(_G.ChatFrameEditBox);
end

local function hookEditBoxUnlocks()
	if unlockFrame then
		return;
	end
	unlockFrame = CreateFrame("Frame");
	unlockFrame:RegisterEvent("UPDATE_CHAT_WINDOWS");
	unlockFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
	unlockFrame:SetScript("OnEvent", unlockChatEditBoxes);

	for index = 1, (NUM_CHAT_WINDOWS or 10) do
		local editBox = _G["ChatFrame" .. index .. "EditBox"];
		if editBox and editBox.HookScript and not editBox.trp3SplitterUnlocked then
			editBox:HookScript("OnShow", unlockEditBox);
			editBox.trp3SplitterUnlocked = true;
		end
	end
	if _G.ChatFrameEditBox and _G.ChatFrameEditBox.HookScript and not _G.ChatFrameEditBox.trp3SplitterUnlocked then
		_G.ChatFrameEditBox:HookScript("OnShow", unlockEditBox);
		_G.ChatFrameEditBox.trp3SplitterUnlocked = true;
	end
end

local function processQueue(_, elapsed)
	if #queue == 0 then
		nextSendDelay = 0;
		if queueFrame then
			queueFrame:SetScript("OnUpdate", nil);
		end
		return;
	end
	nextSendDelay = nextSendDelay - (elapsed or arg1 or 0);
	if nextSendDelay > 0 then
		return;
	end
	local entry = table.remove(queue, 1);
	entry.sendFunc(entry.message, entry.chatType, entry.language, entry.target, unpack(entry.extraArgs or {}));
	nextSendDelay = SEND_INTERVAL;
end

local function ensureQueueFrame()
	if queueFrame then
		return;
	end

	queueFrame = CreateFrame("Frame");
end

local function queueChunks(sendFunc, chunks, chatType, language, target, extraArgs)
	for index = 1, #chunks do
		tinsert(queue, {
			sendFunc = sendFunc,
			message = chunks[index],
			chatType = chatType,
			language = language,
			target = target,
			extraArgs = extraArgs,
		});
	end
	ensureQueueFrame();
	if not nextSendDelay or nextSendDelay <= 0 then
		nextSendDelay = FIRST_SEND_DELAY;
	end
	queueFrame:SetScript("OnUpdate", processQueue);
end

local function isSplitterEnabled()
	if Config.isConfigKeyRegistered and not Config.isConfigKeyRegistered(CONFIG_ENABLED) then
		return true;
	end
	return getConfigValue(CONFIG_ENABLED);
end

function API.send(sendFunc, message, chatType, language, target, ...)
	if type(sendFunc) ~= "function" then
		return;
	end

	if not isSplitterEnabled() then
		return sendFunc(message, chatType, language, target, ...);
	end

	local normalizedChatType = normalizeChatType(chatType);
	if not SPLITTABLE_CHAT_TYPES[normalizedChatType] then
		return sendFunc(message, chatType, language, target, ...);
	end

	local chunks = buildChunks(message, normalizedChatType);
	if not chunks then
		return sendFunc(message, chatType, language, target, ...);
	end

	queueChunks(sendFunc, chunks, chatType, language, target, {...});
end

StaticPopupDialogs["TRP3_DISABLE_ASCENDED_EMOTES"] = {
	text = "Ascended Emotes is enabled alongside TranquilRP3's built-in emote splitter.\n\nRunning both can cause doubled messages or stale chat-box channel labels.\n\nDisable Ascended Emotes now?",
	button1 = "Disable Ascended Emotes",
	button2 = "Keep Enabled",
	OnAccept = function()
		if DisableAddOn then
			DisableAddOn("Ascended_Emotes");
		end
		setConfigValue(CONFIG_ASCENDED_PROMPT_SEEN, true);
		if ReloadUI then
			ReloadUI();
		else
			StaticPopup_Show("CLIENT_RESTART_ALERT");
		end
	end,
	OnCancel = function()
		setConfigValue(CONFIG_ASCENDED_PROMPT_SEEN, true);
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
	showAlert = true,
};

local function maybePromptForAscendedEmotes()
	if getConfigValue(CONFIG_ASCENDED_PROMPT_SEEN) then
		return;
	end
	if IsAddOnLoaded and IsAddOnLoaded("Ascended_Emotes") then
		StaticPopup_Show("TRP3_DISABLE_ASCENDED_EMOTES");
	end
end

local function queueAscendedEmotesPrompt()
	if promptFrame then
		return;
	end
	promptFrame = CreateFrame("Frame");
	promptFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
	promptFrame:SetScript("OnEvent", function(self)
		self = self or this;
		self:UnregisterEvent("PLAYER_ENTERING_WORLD");
		self.elapsed = 0;
		self:SetScript("OnUpdate", function(frame, elapsed)
			frame = frame or this;
			frame.elapsed = (frame.elapsed or 0) + (elapsed or arg1 or 0);
			if frame.elapsed < 3 then
				return;
			end
			frame:SetScript("OnUpdate", nil);
			maybePromptForAscendedEmotes();
		end);
	end);
end

local function onStart()
	registerConfigKey(CONFIG_ENABLED, true);
	registerConfigKey(CONFIG_ASCENDED_PROMPT_SEEN, false);
	setConfigValue(CONFIG_ENABLED, true);
	unlockChatEditBoxes();
	hookEditBoxUnlocks();
	queueAscendedEmotesPrompt();
end

TRP3_API.module.registerModule({
	name = "Chat splitter",
	description = "Splits long emotes and chat messages across every supported chat channel.",
	version = 1.000,
	id = "trp3_chat_splitter",
	onStart = onStart,
	minVersion = 3,
});
