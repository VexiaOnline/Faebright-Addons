----------------------------------------------------------------------------------
-- Total RP 3
-- Language switcher
--	---------------------------------------------------------------------------
--	Copyright 2014 Renaud Parize (Ellypse) (renaud@parize.me)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- Imports
local setTooltipForFrame, refreshTooltip, mainTooltip = TRP3_API.ui.tooltip.setTooltipForFrame, TRP3_API.ui.tooltip.refresh, TRP3_MainTooltip;
local icon, color = TRP3_API.utils.str.icon, TRP3_API.utils.str.color;
local displayDropDown = TRP3_API.ui.listbox.displayDropDown;
local loc = TRP3_API.locale.getText;
local get = TRP3_API.profile.getData;
local UnitFactionGroup = UnitFactionGroup;

TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_LOADED, function()
	if not TRP3_API.toolbar then return end;

	local languagesIcon = {

		-- Alliance
		[2] = "Ability_Racial_Shadowmeld", -- Darnassian
		[6] = "Inv_Drink_05", -- Dwarvish
		[7] = "Inv_Misc_Tournaments_banner_Human",-- Common
		[13] = "Ability_Tinker",-- Gnomish

		-- Horde
		[1] = "Ability_Racial_BloodFury", -- Orcish
		[33] = "Ability_Racial_Cannibalize", -- Forsaken
		[3] = "Ability_Racial_WarStomp", -- Taurahe
		[14] = "Ability_Racial_Berserking", -- Zandali

	}
	
	local function getKnownProfileLanguages()
		local profileLanguages = get("player/languages/FL") or {};
		local languages = {};
		for languageName, fluency in pairs(profileLanguages) do
			if tonumber(fluency) and tonumber(fluency) > 0 then
				tinsert(languages, languageName);
			end
		end
		table.sort(languages);
		return languages;
	end

	local function getBlizzardLanguageIndexByName(languageName)
		for i = 1, GetNumLanguages() do
			local blizzardLanguage, languageID = GetLanguageByIndex(i);
			if blizzardLanguage == languageName then
				return i, languageID;
			end
		end
	end

	local function getNativeChatLanguage()
		if UnitFactionGroup("player") == "Horde" then
			return "Orcish";
		end
		return "Common";
	end

	local function setEditBoxLanguage(languageName)
		local _, languageID = getBlizzardLanguageIndexByName(languageName);
		for i = 1, 10 do
			if _G["ChatFrame"..i.."EditBox"] then
				_G["ChatFrame"..i.."EditBox"].languageID = languageID;
				_G["ChatFrame"..i.."EditBox"].language = languageName;
			end
		end
	end

	local function getLanguageIcon(languageName, languageID)
		if languageID and languagesIcon[languageID] then
			return languagesIcon[languageID];
		elseif TRP3_API.tongues and TRP3_API.tongues.getLanguageIcon then
			return TRP3_API.tongues.getLanguageIcon(languageName);
		end
		return "spell_holy_silence";
	end

	local function languageSelected(selection)
		local selectionType, value = string.match(selection or "", "^([^:]+):(.+)$");
		if selectionType == "blizzard" then
			local languageIndex = tonumber(value);
			local language, languageID = GetLanguageByIndex(languageIndex);
			if TRP3_API.tongues and TRP3_API.tongues.setActiveLanguage then
				TRP3_API.tongues.setActiveLanguage(language);
			end
			if language == getNativeChatLanguage() then
				setEditBoxLanguage(language);
			else
				setEditBoxLanguage(getNativeChatLanguage());
			end
		elseif selectionType == "tongues" then
			if TRP3_API.tongues and TRP3_API.tongues.setActiveLanguage then
				TRP3_API.tongues.setActiveLanguage(value);
			end
			setEditBoxLanguage(getNativeChatLanguage());
		end
	end

	local function getCurrentLanguage()
		if TRP3_API.tongues and TRP3_API.tongues.getActiveLanguage then
			return TRP3_API.tongues.getActiveLanguage();
		end
		return ChatFrame1EditBox.language or UNKNOWN;
	end

	local function getPinnedFactionLanguage()
		if UnitFactionGroup("player") == "Horde" then
			return "Orcish";
		end
		return "Common";
	end

	local function sortToolbarLanguages(left, right)
		local pinnedLanguage = getPinnedFactionLanguage();
		if left.language == pinnedLanguage and right.language ~= pinnedLanguage then
			return true;
		elseif right.language == pinnedLanguage and left.language ~= pinnedLanguage then
			return false;
		end
		return string.lower(left.language or "") < string.lower(right.language or "");
	end
	
	local languagesButton = {
		id = "ww_trp3_languages",
		order = 60,
		icon = "spell_holy_silence",
		configText = loc("TB_LANGUAGE"),
		onEnter = function(Uibutton, buttonStructure)
			if DropDownList1 and DropDownList1:IsShown() then
				mainTooltip:Hide();
				return;
			end
			local currentLanguage = getCurrentLanguage();
			local _, currentLanguageID = getBlizzardLanguageIndexByName(currentLanguage);
			setTooltipForFrame(Uibutton, Uibutton, "BOTTOM", 0, 0, icon(getLanguageIcon(currentLanguage, currentLanguageID), 25) .." "..loc("TB_LANGUAGE")..": "..currentLanguage, strconcat(color("y"), loc("CM_CLICK"), ": ", color("w"), loc("TB_LANGUAGES_TT")));
			refreshTooltip(Uibutton);
		end,
		onUpdate = function(Uibutton, buttonStructure)
			if DropDownList1 and DropDownList1:IsShown() then
				mainTooltip:Hide();
				return;
			end
			local currentLanguage = getCurrentLanguage();
			local _, currentLanguageID = getBlizzardLanguageIndexByName(currentLanguage);
			local currentIcon = getLanguageIcon(currentLanguage, currentLanguageID);
			
			if currentIcon then
				Uibutton:GetNormalTexture():SetTexture("Interface\\ICONS\\"..currentIcon);
				Uibutton:GetPushedTexture():SetTexture("Interface\\ICONS\\"..currentIcon);
				Uibutton:GetPushedTexture():SetDesaturated(1);
			else
				Uibutton:GetNormalTexture():SetTexture("Interface\\ICONS\\spell_holy_silence");
				Uibutton:GetPushedTexture():SetTexture("Interface\\ICONS\\spell_holy_silence");
				Uibutton:GetPushedTexture():SetDesaturated(1);
			end
			setTooltipForFrame(Uibutton, Uibutton, "BOTTOM", 0, 0, icon(currentIcon or "spell_holy_silence", 25) .." "..loc("TB_LANGUAGE")..": "..currentLanguage, strconcat(color("y"), loc("CM_CLICK"), ": ", color("w"), loc("TB_LANGUAGES_TT")));
			if GetMouseFocus() == Uibutton then
				refreshTooltip(Uibutton);
			end
		end,
		onClick = function(Uibutton, buttonStructure, button)
			mainTooltip:Hide();
			local dropdownItems = {};
			local listedLanguages = {};
			local languageItems = {};
			local currentLanguage = getCurrentLanguage();
			tinsert(dropdownItems,{"Languages", nil}); -- TODO TRANSLATE
			for i = 1, GetNumLanguages() do
				if GetLanguageByIndex(i) then
					local language, index = GetLanguageByIndex(i);
					listedLanguages[language] = true;
					tinsert(languageItems, { language = language, icon = getLanguageIcon(language, index), value = "blizzard:" .. i });
				end
			end
			for _, language in pairs(getKnownProfileLanguages()) do
				if not listedLanguages[language] then
					local languageIcon = getLanguageIcon(language);
					tinsert(languageItems, { language = language, icon = languageIcon, value = "tongues:" .. language });
				end
			end
			table.sort(languageItems, sortToolbarLanguages);
			for _, languageItem in ipairs(languageItems) do
				if languageItem.language == currentLanguage then
					tinsert(dropdownItems,{"|Tinterface\\icons\\"..languageItem.icon..":15|t|cff00ff00 "..languageItem.language.."|r", languageItem.value});
				else
					tinsert(dropdownItems,{"|Tinterface\\icons\\"..languageItem.icon..":15|t "..languageItem.language, languageItem.value});
				end
			end
			displayDropDown(Uibutton, dropdownItems, languageSelected, 0, true);
		end,
		onLeave = function()
			mainTooltip:Hide();
		end,
	};
	TRP3_API.toolbar.toolbarAddButton(languagesButton);
	
	
end);
