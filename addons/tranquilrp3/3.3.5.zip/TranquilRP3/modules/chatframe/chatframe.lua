----------------------------------------------------------------------------------
-- Total RP 3
-- Chat management
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- imports
local Globals, Utils = TRP3_API.globals, TRP3_API.utils;
local loc = TRP3_API.locale.getText;
local unitIDToInfo, unitInfoToID = Utils.str.unitIDToInfo, Utils.str.unitInfoToID;
local get = TRP3_API.profile.getData;
local getCompleteName = TRP3_API.register.getCompleteName;
local IsUnitIDKnown = TRP3_API.register.isUnitIDKnown;
local getUnitIDCurrentProfile, isIDIgnored = TRP3_API.register.getUnitIDCurrentProfile, TRP3_API.register.isIDIgnored;
local getUnitIDDirectoryLite = TRP3_API.register.getUnitIDDirectoryLite;
local strsub, strlen, format, _G, pairs, select, tinsert, time, tonumber, tostring, strtrim, hooksecurefunc = strsub, strlen, format, _G, pairs, select, tinsert, time, tonumber, tostring, strtrim, hooksecurefunc;
local GetTime, PlaySound = GetTime, PlaySound;
local GetChannelDisplayInfo, GetChannelName, GetChatWindowChannels = GetChannelDisplayInfo, GetChannelName, GetChatWindowChannels;
local getConfigValue, registerConfigKey, registerHandler = TRP3_API.configuration.getValue, TRP3_API.configuration.registerConfigKey, TRP3_API.configuration.registerHandler;
local ChatFrame_RemoveMessageEventFilter, ChatFrame_AddMessageEventFilter = ChatFrame_RemoveMessageEventFilter, ChatFrame_AddMessageEventFilter;
local handleCharacterMessage, hooking;
local TRP3_CHAT_MENU_SHOW = "TRP3_SHOW_TRP3";
local FACTION_WIRE_ALLIANCE = "f1";
local FACTION_WIRE_HORDE = "f2";
local FACTION_WIRE_INDEPENDENT = "f3";
local WORLD_CHANNEL_NAME = "world";
local WORLD_FACTION_TEXTURES = {
	[FACTION_WIRE_ALLIANCE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_alliance.blp",
	[FACTION_WIRE_HORDE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_horde.blp",
	[FACTION_WIRE_INDEPENDENT] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_neutral.blp",
};
local WORLD_FACTION_COLORS = {
	[FACTION_WIRE_ALLIANCE] = "|cff4a8dff",
	[FACTION_WIRE_HORDE] = "|cffff4a4a",
	[FACTION_WIRE_INDEPENDENT] = "|cffd6c88f",
};
local RACE_FACTION_MAP = {
	Human = FACTION_WIRE_ALLIANCE,
	human = FACTION_WIRE_ALLIANCE,
	Dwarf = FACTION_WIRE_ALLIANCE,
	dwarf = FACTION_WIRE_ALLIANCE,
	NightElf = FACTION_WIRE_ALLIANCE,
	nightelf = FACTION_WIRE_ALLIANCE,
	Gnome = FACTION_WIRE_ALLIANCE,
	gnome = FACTION_WIRE_ALLIANCE,
	Draenei = FACTION_WIRE_ALLIANCE,
	draenei = FACTION_WIRE_ALLIANCE,
	Worgen = FACTION_WIRE_ALLIANCE,
	worgen = FACTION_WIRE_ALLIANCE,
	HighElf = FACTION_WIRE_ALLIANCE,
	highelf = FACTION_WIRE_ALLIANCE,
	Orc = FACTION_WIRE_HORDE,
	orc = FACTION_WIRE_HORDE,
	Scourge = FACTION_WIRE_HORDE,
	scourge = FACTION_WIRE_HORDE,
	Undead = FACTION_WIRE_HORDE,
	undead = FACTION_WIRE_HORDE,
	Tauren = FACTION_WIRE_HORDE,
	tauren = FACTION_WIRE_HORDE,
	Troll = FACTION_WIRE_HORDE,
	troll = FACTION_WIRE_HORDE,
	BloodElf = FACTION_WIRE_HORDE,
	bloodelf = FACTION_WIRE_HORDE,
	Goblin = FACTION_WIRE_HORDE,
	goblin = FACTION_WIRE_HORDE,
};
local TRP3_CHAT_MENU_TYPES = {
	PLAYER = true,
	FRIEND = true,
	GUILD = true,
	GUILD_OFFLINE = true,
	PARTY = true,
	RAID_PLAYER = true,
};

local function removeMenuEntry(menuTable, value)
	if not menuTable then
		return;
	end
	for index = #menuTable, 1, -1 do
		if menuTable[index] == value then
			table.remove(menuTable, index);
		end
	end
end

local function insertMenuEntryBefore(menuTable, value, beforeValue)
	if not menuTable then
		return;
	end
	for _, currentValue in pairs(menuTable) do
		if currentValue == value then
			return;
		end
	end
	for index, currentValue in pairs(menuTable) do
		if currentValue == beforeValue then
			table.insert(menuTable, index, value);
			return;
		end
	end
	table.insert(menuTable, value);
end

local function setupChatContextMenu()
	if not UnitPopupMenus or not UnitPopupButtons or not UnitPopup_ShowMenu then
		return;
	end

	UnitPopupButtons[TRP3_CHAT_MENU_SHOW] = {
		text = "Show TRP3",
		dist = 0,
	};

	local originalUnitPopup_ShowMenu = UnitPopup_ShowMenu;
	UnitPopup_ShowMenu = function(dropdownMenu, which, unit, name, userData, ...)
		local menu = UnitPopupMenus[which];
		if TRP3_CHAT_MENU_TYPES[which] and menu then
			removeMenuEntry(menu, "TARGET");
			removeMenuEntry(menu, TRP3_CHAT_MENU_SHOW);
			insertMenuEntryBefore(menu, "TARGET", "IGNORE");

			local unitID = name and unitInfoToID(name) or nil;
			dropdownMenu.trp3UnitID = unitID;
			dropdownMenu.trp3CanShow = unitID and (unitID == Globals.player_id or IsUnitIDKnown(unitID)) or false;
			if dropdownMenu.trp3CanShow then
				insertMenuEntryBefore(menu, TRP3_CHAT_MENU_SHOW, "CANCEL");
			end
		end
		return originalUnitPopup_ShowMenu(dropdownMenu, which, unit, name, userData, ...);
	end

	hooksecurefunc("UnitPopup_OnClick", function(self)
		if not self or not self.value then
			return;
		end

		local dropdownMenu = UIDROPDOWNMENU_OPEN_MENU;
		if not dropdownMenu then
			return;
		end

		if self.value == TRP3_CHAT_MENU_SHOW then
			local unitID = dropdownMenu.trp3UnitID;
			if unitID and (unitID == Globals.player_id or IsUnitIDKnown(unitID)) then
				TRP3_API.navigation.openMainFrame();
				TRP3_API.register.openPageByUnitID(unitID);
			end
		end
	end);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Config
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local POSSIBLE_CHANNELS

local CONFIG_NAME_METHOD = "chat_name";
local CONFIG_NAME_COLOR = "chat_color";
local CONFIG_NAME_EMOTE_COLOR = "chat_emote_color";
local CONFIG_NAME_ICON = "chat_name_icon";
local CONFIG_NAME_ICON_SIZE = "chat_name_icon_size";
local CONFIG_NPC_TALK = "chat_npc_talk";
local CONFIG_NPC_TALK_PREFIX = "chat_npc_talk_p";
local CONFIG_EMOTE = "chat_emote";
local CONFIG_EMOTE_PATTERN = "chat_emote_pattern";
local CONFIG_CHAT = "chat_chat";
local CONFIG_CHAT_PATTERN = "chat_chat_pattern";
local CONFIG_USAGE = "chat_use_";
local CONFIG_OOC = "chat_ooc";
local CONFIG_OOC_PATTERN = "chat_ooc_pattern";
local CONFIG_OOC_COLOR = "chat_ooc_color";
local CONFIG_YELL_NO_EMOTE = "chat_yell_no_emote";
local CONFIG_CHANNEL_PARTY = "chat_channel_party";
local CONFIG_CHANNEL_PARTY_LEADER = "chat_channel_party_leader";
local CONFIG_CHANNEL_RAID = "chat_channel_raid";
local CONFIG_CHANNEL_RAID_LEADER = "chat_channel_raid_leader";
local CONFIG_CHANNEL_GUILD = "chat_channel_guild";
local CONFIG_CHANNEL_OFFICER = "chat_channel_officer";
local CONFIG_CHANNEL_WHISPER_IN = "chat_channel_whisper_in";
local CONFIG_CHANNEL_WHISPER_OUT = "chat_channel_whisper_out";
local CONFIG_NAME_BRACKETS = "chat_name_brackets";
local CONFIG_CHANNEL_REPLACEMENT = "chat_channel_replacement";
local CONFIG_RP_CHANNEL = "chat_channel_rp";
local CONFIG_USAGE_RP = "chat_use_rp";
local CONFIG_USAGE_WORLD = "chat_use_world";

local function configNoYelledEmote()
	return getConfigValue(CONFIG_YELL_NO_EMOTE);
end

local function configNameMethod()
	return getConfigValue(CONFIG_NAME_METHOD);
end

local function configShowNameCustomColors()
	return getConfigValue(CONFIG_NAME_COLOR);
end

local function configShowNameEmoteColors()
	return getConfigValue(CONFIG_NAME_EMOTE_COLOR);
end

local function configShowNameIcons()
	local value = getConfigValue(CONFIG_NAME_ICON);
	return value;
end

local function configNameIconSize()
	return getConfigValue(CONFIG_NAME_ICON_SIZE);
end

local function configIsChannelUsed(channel)
	return getConfigValue(CONFIG_USAGE .. channel);
end

local function configDoHandleNPCTalk()
	return getConfigValue(CONFIG_NPC_TALK);
end

local function configNPCTalkPrefix()
	return getConfigValue(CONFIG_NPC_TALK_PREFIX);
end

local function configDoEmoteDetection()
	return getConfigValue(CONFIG_EMOTE);
end

local function configEmoteDetectionPattern()
	return getConfigValue(CONFIG_EMOTE_PATTERN);
end

local function configChatDetectionPattern()
	return getConfigValue(CONFIG_CHAT_PATTERN);
end

local function configDoChatDetection()
	return getConfigValue(CONFIG_CHAT);
end

local function configDoOOCDetection()
	return getConfigValue(CONFIG_OOC);
end

local function configOOCDetectionPattern()
	return getConfigValue(CONFIG_OOC_PATTERN);
end

local function configOOCDetectionColor()
	return getConfigValue(CONFIG_OOC_COLOR);
end

local function configPartyChannelName()
	return getConfigValue(CONFIG_CHANNEL_PARTY);
end

local function configPartyLeaderChannelName()
	return getConfigValue(CONFIG_CHANNEL_PARTY_LEADER);
end

local function configRaidChannelName()
	return getConfigValue(CONFIG_CHANNEL_RAID);
end

local function configRaidLeaderChannelName()
	return getConfigValue(CONFIG_CHANNEL_RAID_LEADER);
end

local function configGuildChannelName()
	return getConfigValue(CONFIG_CHANNEL_GUILD);
end

local function configOfficerChannelName()
	return getConfigValue(CONFIG_CHANNEL_OFFICER);
end

local function configWhisperInChannelName()
	return getConfigValue(CONFIG_CHANNEL_WHISPER_IN);
end

local function configWhisperOutChannelName()
	return getConfigValue(CONFIG_CHANNEL_WHISPER_OUT);
end

local function configNameBrackets()
	return getConfigValue(CONFIG_NAME_BRACKETS);
end

local function getNameBrackets()
	local bracketStyle = configNameBrackets();
	if bracketStyle == 1 then
		return "[", "]"; 
	elseif bracketStyle == 2 then
		return "(", ")";
	elseif bracketStyle == 3 then
		return "<", ">";
	else
		return "", ""; 
	end
end

local function configChannelReplacement()
	return getConfigValue(CONFIG_CHANNEL_REPLACEMENT);
end

local function configRPChannelName()
	return getConfigValue(CONFIG_RP_CHANNEL);
end

local function configUseRPChannel()
	return getConfigValue(CONFIG_USAGE_RP);
end

local function configUseWorldChannel()
	return getConfigValue(CONFIG_USAGE_WORLD);
end

local function normalizeRPChannelName(channelName)
	channelName = strtrim(string.lower(tostring(channelName or "")));
	if channelName:sub(1, 1) == "/" then
		channelName = channelName:sub(2);
	end
	channelName = channelName:gsub("^%d+%.%s*", "");
	return channelName;
end

local function getChannelBaseToken(channelName)
	channelName = normalizeRPChannelName(channelName);
	channelName = channelName:gsub("%s+%-.*$", "");
	channelName = channelName:gsub("%s+", "");
	return channelName;
end

local BLIZZARD_GLOBAL_CHANNELS = {
	general = true,
	trade = true,
	localdefense = true,
	lookingforgroup = true,
	worlddefense = true,
	guildrecruitment = true,
	services = true,
};

local function isProtectedBlizzardChannel(channelName)
	return BLIZZARD_GLOBAL_CHANNELS[getChannelBaseToken(channelName)] == true;
end

local function getRPChannelName()
	local channelName = normalizeRPChannelName(configRPChannelName());
	if channelName == "" then
		channelName = "rp";
	end
	return channelName;
end

local function getJoinedCustomChannelInfo(targetChannelName)
	targetChannelName = normalizeRPChannelName(targetChannelName);
	if targetChannelName == "" then
		return nil;
	end
	if GetChannelName then
		local channelNumber, channelName = GetChannelName(targetChannelName);
		if type(channelNumber) == "number" and channelNumber > 0 then
			return channelNumber, channelName or targetChannelName;
		end
	end
end

local function getRPChannelInfo()
	return getJoinedCustomChannelInfo(getRPChannelName());
end

local function isCustomChannelAssignedToFrame(chatFrame, targetChannelName)
	if not chatFrame or not chatFrame.GetID or not GetChatWindowChannels then
		return false;
	end

	targetChannelName = normalizeRPChannelName(targetChannelName);
	if targetChannelName == "" then
		return false;
	end

	local frameID = chatFrame:GetID();
	if not frameID or frameID <= 0 then
		return false;
	end

	for index = 1, 10 do
		local windowChannelName = select((index * 2) - 1, GetChatWindowChannels(frameID));
		if not windowChannelName or windowChannelName == "" then
			break
		end

		if normalizeRPChannelName(windowChannelName) == targetChannelName then
			return true;
		end
	end

	return false;
end

local function isRPChannelChatMessage(channelIndex, channelBaseName, channelFullName)
	local configuredChannelName = getRPChannelName();
	local rpChannelIndex, rpChannelName = getRPChannelInfo();
	local normalizedChannelBaseName = normalizeRPChannelName(channelBaseName);
	local normalizedChannelFullName = normalizeRPChannelName(channelFullName);

	if isProtectedBlizzardChannel(channelBaseName) or isProtectedBlizzardChannel(channelFullName) then
		return false;
	end

	if rpChannelIndex and tonumber(channelIndex) == tonumber(rpChannelIndex) then
		return true;
	end

	if rpChannelIndex then
		return false;
	end

	if normalizedChannelBaseName ~= "" and normalizedChannelBaseName == configuredChannelName then
		return true;
	end

	if normalizedChannelFullName ~= "" and normalizedChannelFullName == configuredChannelName then
		return true;
	end

	return false;
end

local function getRPChannelDisplayName()
	local _, channelName = getRPChannelInfo();
	channelName = normalizeRPChannelName(channelName);
	if channelName == "" then
		channelName = getRPChannelName();
	end
	return "[" .. string.upper(channelName) .. "]";
end

local function normalizeChannelName(channelName)
	channelName = strtrim(string.lower(tostring(channelName or "")));
	channelName = channelName:gsub("^%d+%.%s*", "");
	channelName = channelName:gsub("^%[", "");
	channelName = channelName:gsub("%]$", "");
	return channelName;
end

local function getWorldChannelDisplayName(channelBaseName, channelFullName)
	local displayName = strtrim(tostring(channelBaseName or ""));
	if displayName == "" then
		displayName = strtrim(tostring(channelFullName or ""));
		displayName = displayName:gsub("^%d+%.%s*", "");
	end
	if normalizeChannelName(displayName) == WORLD_CHANNEL_NAME then
		displayName = "World";
	end
	if displayName == "" then
		displayName = "World";
	end
	return "[" .. displayName .. "]";
end

local function getWorldChannelInfo()
	return getJoinedCustomChannelInfo(WORLD_CHANNEL_NAME);
end

local function isWorldChannel(channelIndex, channelBaseName, channelFullName)
	local worldChannelIndex, worldChannelName = getWorldChannelInfo();
	if not worldChannelIndex then
		return false;
	end
	if isProtectedBlizzardChannel(channelBaseName) or isProtectedBlizzardChannel(channelFullName) then
		return false;
	end
	if tonumber(channelIndex) == tonumber(worldChannelIndex) then
		return true;
	end

	local normalizedWorldChannelName = normalizeChannelName(worldChannelName);
	return normalizedWorldChannelName ~= ""
		and (
			normalizeChannelName(channelBaseName) == normalizedWorldChannelName
			or normalizeChannelName(channelFullName) == normalizedWorldChannelName
		);
end

local function createConfigPage(useWIM)
	-- Config default value
	registerConfigKey(CONFIG_NAME_METHOD, 3);
	registerConfigKey(CONFIG_NAME_COLOR, true);
	registerConfigKey(CONFIG_NAME_EMOTE_COLOR, true);
	registerConfigKey(CONFIG_NAME_ICON, true);
	registerConfigKey(CONFIG_NAME_ICON_SIZE, 16);
	registerConfigKey(CONFIG_NPC_TALK, true);
	registerConfigKey(CONFIG_NPC_TALK_PREFIX, "|");
	registerConfigKey(CONFIG_EMOTE, true);
	registerConfigKey(CONFIG_EMOTE_PATTERN, "(%*.-%*)");
	registerConfigKey(CONFIG_CHAT, true);
	registerConfigKey(CONFIG_CHAT_PATTERN, "(%\".-%\")");
	registerConfigKey(CONFIG_OOC, true);
	registerConfigKey(CONFIG_OOC_PATTERN, "(%(%(.-%)%))");
	registerConfigKey(CONFIG_OOC_COLOR, "aaaaaa");
	registerConfigKey(CONFIG_YELL_NO_EMOTE, false);
	registerConfigKey(CONFIG_CHANNEL_PARTY, "[Party]");
	registerConfigKey(CONFIG_CHANNEL_PARTY_LEADER, "[Party Leader]");
	registerConfigKey(CONFIG_CHANNEL_RAID, "[Raid]");
	registerConfigKey(CONFIG_CHANNEL_RAID_LEADER, "[Raid Leader]");
	registerConfigKey(CONFIG_CHANNEL_GUILD, "[Guild]");
	registerConfigKey(CONFIG_CHANNEL_OFFICER, "[Officer]");
	registerConfigKey(CONFIG_CHANNEL_WHISPER_IN, "whispers");
	registerConfigKey(CONFIG_CHANNEL_WHISPER_OUT, "To");
	registerConfigKey(CONFIG_NAME_BRACKETS, 1);
	registerConfigKey(CONFIG_CHANNEL_REPLACEMENT, true);
	registerConfigKey(CONFIG_RP_CHANNEL, "rp");
	registerConfigKey(CONFIG_USAGE_RP, true);
	registerConfigKey(CONFIG_USAGE_WORLD, true);
	registerHandler(CONFIG_USAGE_RP, hooking);
	registerHandler(CONFIG_USAGE_WORLD, hooking);

	local NAMING_METHOD_TAB = {
		{loc("CO_CHAT_MAIN_NAMING_1"), 1},
		{loc("CO_CHAT_MAIN_NAMING_2"), 2},
		{loc("CO_CHAT_MAIN_NAMING_3"), 3},
		{loc("CO_CHAT_MAIN_NAMING_4"), 4},
	}
	
	local EMOTE_PATTERNS = {
		{"* Emote *", "(%*.-%*)"},
		{"** Emote **", "(%*%*.-%*%*)"},
		{"< Emote >", "(%<.-%>)"},
		{"* Emote * + < Emote >", "([%*%<].-[%*%>])"},
	}
	
	local OOC_PATTERNS = {
		{"( OOC )", "(%(.-%))"},
		{"(( OOC ))", "(%(%(.-%)%))"},
	}
	
	local NAME_BRACKET_PATTERNS = {
		{"[Name]", 1},
		{"(Name)", 2},
		{"<Name>", 3},
		{"Name", 4},
	}

	-- Build configuration page
	local CONFIG_STRUCTURE = {
		id = "main_config_chatframe",
		menuText = loc("CO_CHAT"),
		pageText = loc("CO_CHAT"),
		elements = {
			{
				inherit = "TRP3_ConfigH1",
				title = loc("CO_CHAT_MAIN"),
			},
			{
				inherit = "TRP3_ConfigDropDown",
				widgetName = "TRP3_ConfigurationTooltip_Chat_NamingMethod",
				title = loc("CO_CHAT_MAIN_NAMING"),
				listContent = NAMING_METHOD_TAB,
				configKey = CONFIG_NAME_METHOD,
				listCancel = true,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_COLOR"),
				configKey = CONFIG_NAME_COLOR,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_EMOTE_COLOR"),
				configKey = CONFIG_NAME_EMOTE_COLOR,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_ICON"),
				configKey = CONFIG_NAME_ICON,
			},
			{
				inherit = "TRP3_ConfigSlider",
				title = loc("CO_CHAT_MAIN_ICON_SIZE"),
				configKey = CONFIG_NAME_ICON_SIZE,
				min = 8,
				max = 32,
				step = 2,
				integer = true,
			},
			{
				inherit = "TRP3_ConfigH1",
				title = loc("CO_CHAT_MAIN_NPC"),
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_NPC_USE"),
				configKey = CONFIG_NPC_TALK,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = loc("CO_CHAT_MAIN_NPC_PREFIX"),
				configKey = CONFIG_NPC_TALK_PREFIX,
				help = loc("CO_CHAT_MAIN_NPC_PREFIX_TT")
			},
			{
				inherit = "TRP3_ConfigH1",
				title = loc("CO_CHAT_MAIN_EMOTE"),
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_EMOTE_YELL"),
				help = loc("CO_CHAT_MAIN_EMOTE_YELL_TT"),
				configKey = CONFIG_YELL_NO_EMOTE,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_EMOTE_USE"),
				configKey = CONFIG_EMOTE,
			},
			{
				inherit = "TRP3_ConfigDropDown",
				widgetName = "TRP3_ConfigurationTooltip_Chat_EmotePattern",
				title = loc("CO_CHAT_MAIN_EMOTE_PATTERN"),
				listContent = EMOTE_PATTERNS,
				configKey = CONFIG_EMOTE_PATTERN,
				listCancel = true,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_CHAT_USE"),
				configKey = CONFIG_CHAT,
			},
			{
				inherit = "TRP3_ConfigH1",
				title = loc("CO_CHAT_MAIN_OOC"),
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_CHAT_MAIN_OOC_USE"),
				configKey = CONFIG_OOC,
			},
			{
				inherit = "TRP3_ConfigDropDown",
				widgetName = "TRP3_ConfigurationTooltip_Chat_OOCPattern",
				title = loc("CO_CHAT_MAIN_OOC_PATTERN"),
				listContent = OOC_PATTERNS,
				configKey = CONFIG_OOC_PATTERN,
				listCancel = true,
			},
			{
				inherit = "TRP3_ConfigColorPicker",
				title = loc("CO_CHAT_MAIN_OOC_COLOR"),
				configKey = CONFIG_OOC_COLOR,
			},
			-- we don't reuse POSSIBLE_CHANNELS because of unnecessary complexity
			{
				inherit = "TRP3_ConfigH1",
				title = "Channel Names",
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = "Enable Channel Name Replacement",
				help = "Enable custom channel names for party, guild, raid, whispers, etc.",
				configKey = CONFIG_CHANNEL_REPLACEMENT,
			},
			{
				inherit = "TRP3_ConfigDropDown",
				widgetName = "TRP3_ConfigurationTooltip_Chat_NameBrackets",
				title = "Name Bracket Style",
				help = "Choose the style of brackets around player names",
				listContent = NAME_BRACKET_PATTERNS,
				configKey = CONFIG_NAME_BRACKETS,
				listCancel = true,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Party Channel Name",
				configKey = CONFIG_CHANNEL_PARTY,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Party Leader Channel Name",
				configKey = CONFIG_CHANNEL_PARTY_LEADER,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Raid Channel Name",
				configKey = CONFIG_CHANNEL_RAID,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Raid Leader Channel Name",
				configKey = CONFIG_CHANNEL_RAID_LEADER,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Guild Channel Name",
				configKey = CONFIG_CHANNEL_GUILD,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Officer Channel Name",
				configKey = CONFIG_CHANNEL_OFFICER,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Incoming Whisper Name",
				configKey = CONFIG_CHANNEL_WHISPER_IN,
			},
			{
				inherit = "TRP3_ConfigEditBox",
				title = "Outgoing Whisper Name",
				configKey = CONFIG_CHANNEL_WHISPER_OUT,
			},
			{
				inherit = "TRP3_ConfigH1",
				title = loc("CO_CHAT_USE"),
			},
		}
	};
	if useWIM then
		tinsert(CONFIG_STRUCTURE.elements, {
			inherit = "TRP3_ConfigNote",
			help = loc("CO_WIM_TT"),
			title = loc("CO_WIM"),
		});
	end

	for _, channel in pairs(POSSIBLE_CHANNELS) do
		registerConfigKey(CONFIG_USAGE .. channel, true);
		registerHandler(CONFIG_USAGE .. channel, hooking);
		tinsert(CONFIG_STRUCTURE.elements, {
			inherit = "TRP3_ConfigCheck",
			title = _G[channel],
			configKey = CONFIG_USAGE .. channel,
		});
	end

	tinsert(CONFIG_STRUCTURE.elements, {
		inherit = "TRP3_ConfigCheck",
		title = "RP Channel (/rp)",
		configKey = CONFIG_USAGE_RP,
	});
	tinsert(CONFIG_STRUCTURE.elements, {
		inherit = "TRP3_ConfigCheck",
		title = "World Channel",
		configKey = CONFIG_USAGE_WORLD,
	});

	TRP3_API.configuration.registerConfigurationPage(CONFIG_STRUCTURE);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Utils
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function getCharacterInfoTab(unitID)
	if unitID == Globals.player_id then
		return get("player");
	elseif IsUnitIDKnown(unitID) then
		local info = getUnitIDCurrentProfile(unitID) or {};
		if getUnitIDDirectoryLite then
			local liteInfo = getUnitIDDirectoryLite(unitID);
			if liteInfo and (liteInfo.name or liteInfo.colorCode or liteInfo.icon) then
				info.characteristics = info.characteristics or {};
				local liteName = TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(liteInfo.name);
				if liteName then
					info.characteristics.FN = info.characteristics.FN or liteName;
				end
				if liteInfo.colorCode and liteInfo.colorCode ~= "" then
					info.characteristics.CH = info.characteristics.CH or liteInfo.colorCode;
				end
				local liteIcon = TRP3_API.register.sanitizeIconName and TRP3_API.register.sanitizeIconName(liteInfo.icon);
				if liteIcon then
					info.characteristics.IC = info.characteristics.IC or liteIcon;
				end
			end
		end
		return info;
	end
	return {};
end

local function getHeartbeatCharacter(unitID)
	if unitID ~= Globals.player_id and unitID and IsUnitIDKnown(unitID) then
		return TRP3_API.register.getUnitIDCharacter(unitID);
	end
end

local function getHeartbeatDisplayName(unitID, fallbackName)
	local character = getHeartbeatCharacter(unitID);
	local heartbeatName = character and character.heartbeatName and TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(character.heartbeatName) or nil;
	if heartbeatName and heartbeatName ~= "" then
		return heartbeatName;
	end
	return fallbackName;
end

local function getHeartbeatColor(unitID)
	local character = getHeartbeatCharacter(unitID);
	if character and character.heartbeatColor and character.heartbeatColor ~= "" then
		return tostring(character.heartbeatColor);
	end
	local liteInfo = getUnitIDDirectoryLite and unitID and IsUnitIDKnown(unitID) and getUnitIDDirectoryLite(unitID) or nil;
	if liteInfo and liteInfo.colorCode and liteInfo.colorCode ~= "" then
		return tostring(liteInfo.colorCode);
	end
end

local function getHeartbeatIcon(unitID)
	local character = getHeartbeatCharacter(unitID);
	if character and character.heartbeatIcon and character.heartbeatIcon ~= "" then
		return tostring(character.heartbeatIcon);
	end
	local liteInfo = getUnitIDDirectoryLite and unitID and IsUnitIDKnown(unitID) and getUnitIDDirectoryLite(unitID) or nil;
	if liteInfo and liteInfo.icon and liteInfo.icon ~= "" then
		local liteIcon = TRP3_API.register.sanitizeIconName and TRP3_API.register.sanitizeIconName(liteInfo.icon);
		if liteIcon then
			return tostring(liteIcon);
		end
	end
end

local function normalizeFactionCodeFromString(faction)
	faction = strtrim(tostring(faction or ""));
	if faction == FACTION_WIRE_ALLIANCE or faction == FACTION_WIRE_HORDE or faction == FACTION_WIRE_INDEPENDENT then
		return faction;
	end

	faction = string.lower(faction);
	if faction == "alliance" or faction == string.lower(loc("REG_PLAYER_FACTION_ALLIANCE") or "") then
		return FACTION_WIRE_ALLIANCE;
	elseif faction == "horde" or faction == string.lower(loc("REG_PLAYER_FACTION_HORDE") or "") then
		return FACTION_WIRE_HORDE;
	elseif faction == "independent" or faction == "neutral" or faction == string.lower(loc("REG_PLAYER_FACTION_INDEPENDENT") or "") then
		return FACTION_WIRE_INDEPENDENT;
	end
end

local function getFactionCodeFromRaceName(raceName)
	raceName = strtrim(tostring(raceName or ""));
	if raceName == "" then
		return nil;
	end
	return RACE_FACTION_MAP[raceName]
		or RACE_FACTION_MAP[raceName:gsub("%s+", "")]
		or RACE_FACTION_MAP[raceName:gsub("%s+", ""):gsub("[^%a]", "")]
		or RACE_FACTION_MAP[raceName:gsub("%s+", ""):gsub("[^%a]", ""):lower()];
end

local function isPlayerCharacterID(characterID)
	if characterID == Globals.player_id then
		return true;
	end

	local characterName = tostring(characterID or ""):match("^([^%-]+)");
	return characterName ~= "" and characterName == Globals.player;
end

local function getWorldChatFactionCode(characterID, info, GUID)
	if isPlayerCharacterID(characterID) then
		local playerData = get("player/characteristics");
		return normalizeFactionCodeFromString(playerData and playerData.FC)
			or normalizeFactionCodeFromString(Globals.player_character and Globals.player_character.faction)
			or normalizeFactionCodeFromString(UnitFactionGroup("player"));
	end

	if info and info.characteristics and info.characteristics.FC then
		return normalizeFactionCodeFromString(info.characteristics.FC);
	end

	local liteInfo = getUnitIDDirectoryLite and characterID and IsUnitIDKnown(characterID) and getUnitIDDirectoryLite(characterID) or nil;
	if liteInfo and liteInfo.faction then
		return normalizeFactionCodeFromString(liteInfo.faction);
	end

	local knownCharacter = characterID and IsUnitIDKnown(characterID) and TRP3_API.register.getUnitIDCharacter(characterID) or nil;
	if knownCharacter and knownCharacter.heartbeatFaction then
		local heartbeatFaction = normalizeFactionCodeFromString(knownCharacter.heartbeatFaction);
		if heartbeatFaction then
			return heartbeatFaction;
		end
	end

	if info and info.characteristics and info.characteristics.RA then
		local raceFaction = getFactionCodeFromRaceName(info.characteristics.RA);
		if raceFaction then
			return raceFaction;
		end
	end

	if knownCharacter then
		return getFactionCodeFromRaceName(knownCharacter.race)
			or normalizeFactionCodeFromString(knownCharacter.faction);
	end

	if GUID and type(GetPlayerInfoByGUID) == "function" then
		local _, _, _, englishRace = GetPlayerInfoByGUID(GUID);
		return getFactionCodeFromRaceName(englishRace);
	end
end

local function getWorldChatFactionIcon(chatFrame, characterID, info, GUID)
	local factionCode = getWorldChatFactionCode(characterID, info, GUID);
	if not factionCode then
		return "";
	end

	local texture = WORLD_FACTION_TEXTURES[factionCode];
	if not texture then
		return "";
	end

	local _, fontHeight = chatFrame and chatFrame.GetFont and chatFrame:GetFont();
	fontHeight = tonumber(fontHeight) or 14;
	fontHeight = math.max(10, math.floor(fontHeight + 0.5));

	return "|T" .. texture .. ":" .. fontHeight .. ":" .. fontHeight .. ":0:0|t";
end

local function getWorldChatFactionColor(characterID, info, GUID)
	local factionCode = getWorldChatFactionCode(characterID, info, GUID);
	return factionCode and WORLD_FACTION_COLORS[factionCode];
end

local function stripDecorators(text)
	text = tostring(text or "");
	text = text:gsub("|T.-|t%s*", "");
	text = text:gsub("|c%x%x%x%x%x%x%x%x", "");
	text = text:gsub("|r", "");
	return text;
end
--bratmage\\ in Nightsong Sentinels, we have bots linked to discord. This hides the bot name and makes the user who sent from there appear grey.
local function shouldHideBridgeSenderName(characterName, eventType, isRPChannelMessage)
	characterName = tostring(characterName or ""):match("^[^-]+") or "";
	characterName = string.lower(characterName);
	return (eventType == "GUILD" and characterName == "delary")
		or (isRPChannelMessage and characterName == "discord");
end

local function applyBridgeLeadTextColor(characterName, message, eventType, isRPChannelMessage)
	if not shouldHideBridgeSenderName(characterName, eventType, isRPChannelMessage) then
		return message;
	end

	message = tostring(message or "");
	local leadText, remainder = string.match(message, "^(.-:)(.*)$");
	if not leadText then
		return message;
	end

	return "|cffd0d0d0" .. leadText .. "|r" .. remainder;
end

local function getCharacterClassColor(chatInfo, event, text, characterID, language, arg4, arg5, arg6, arg7, arg8, arg9, arg10, messageID, GUID)
	local color;
	local shouldUseClassColor = false;
	
	if event == "CHAT_MSG_EMOTE" or event == "CHAT_MSG_TEXT_EMOTE" then
		shouldUseClassColor = configShowNameEmoteColors();
	elseif configDoEmoteDetection() and text and text:find(configEmoteDetectionPattern()) then
		shouldUseClassColor = configShowNameEmoteColors();
	else
		shouldUseClassColor = chatInfo and chatInfo.colorNameByClass;
	end
	
	if shouldUseClassColor then
		local localizedClass, englishClass;
		if GUID and type(GetPlayerInfoByGUID) == "function" then
			localizedClass, englishClass = GetPlayerInfoByGUID(GUID);
		end

		if not englishClass and characterID == Globals.player_id then
			_, englishClass = UnitClass("player");
		end

		if not englishClass and characterID and IsUnitIDKnown(characterID) then
			local knownCharacter = TRP3_API.register.getUnitIDCharacter(characterID);
			if knownCharacter and knownCharacter.class and knownCharacter.class ~= "" then
				englishClass = knownCharacter.class;
			end
		end

		if not englishClass and characterID then
			local profile = getCharacterInfoTab(characterID);
			if profile and profile.characteristics and profile.characteristics.CL then
				englishClass = profile.characteristics.CL;
			end
		end

		if englishClass and RAID_CLASS_COLORS[englishClass] then
			local classColorTable = RAID_CLASS_COLORS[englishClass];
			return ("|cff%.2x%.2x%.2x"):format(classColorTable.r*255, classColorTable.g*255, classColorTable.b*255);
		end
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Name replacement in emotes and chat
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function replaceNameInEmote(message, characterID, type)
	local characters = TRP3_API.register.getCharacterList();
	local replacedNames = {};
	
	-- no name replacement when in ""
	local function isInsideQuotes(text, position)
		local quoteCount = 0;
		for i = 1, position - 1 do
			if text:sub(i, i) == '"' then
				quoteCount = quoteCount + 1;
			end
		end
		return (quoteCount % 2) == 1;
	end
	
	local skipSpeakerName = nil;
	if type == "TEXT_EMOTE" and characterID and characterID ~= Globals.player_id then
		local speakerName = unitIDToInfo(characterID);
		if speakerName and message:sub(1, speakerName:len()) == speakerName then
			skipSpeakerName = speakerName;
			replacedNames[speakerName] = true;
		end
	end
	
	-- replace player target
	if UnitExists("target") then
		local targetName = UnitName("target");
		if targetName and not replacedNames[targetName] then
			local targetRPName;
			
			-- if targeting self
			if UnitIsUnit("target", "player") then
				targetRPName = TRP3_API.register.getPlayerCompleteName(true);

				local playerData = TRP3_API.profile.getData("player/characteristics");
				if configShowNameEmoteColors() and playerData and playerData.CH then
					targetRPName = "|cff" .. playerData.CH .. targetRPName .. "|r";
				end
			else
				-- target
				local targetID = Utils.str.getUnitID("target");
				if targetID then
					local targetInfo = getCharacterInfoTab(targetID);
					if targetInfo.characteristics and targetInfo.characteristics.FN then
						targetRPName = TRP3_API.register.getCompleteName(targetInfo.characteristics, targetName, true);
						if configShowNameEmoteColors() and targetInfo.characteristics.CH then
							targetRPName = "|cff" .. targetInfo.characteristics.CH .. targetRPName .. "|r";
						end
					else
						targetRPName = getHeartbeatDisplayName(targetID, targetName);
						local heartbeatColor = getHeartbeatColor(targetID);
						if configShowNameEmoteColors() and heartbeatColor then
							targetRPName = "|cff" .. heartbeatColor .. targetRPName .. "|r";
						end
					end
				end
			end
			
			if targetRPName and targetRPName ~= targetName then
				local escapedName = targetName:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1");
				local pattern = "%f[%w]" .. escapedName .. "%f[%W]";
				
				local startPos = 1;
				while true do
					local matchStart, matchEnd = message:find(pattern, startPos);
					if not matchStart then break end
					
					if not isInsideQuotes(message, matchStart) then
						message = message:sub(1, matchStart - 1) .. targetRPName .. message:sub(matchEnd + 1);
						startPos = matchStart + targetRPName:len();
						break
					else
						startPos = matchEnd + 1;
					end
				end
				replacedNames[targetName] = true;
			end
		end
	end
	
	-- other characters
	for unitID, character in pairs(characters) do
		if unitID ~= Globals.player_id then
			local characterName = unitID;
			
			if characterName and not replacedNames[characterName] and message:find(characterName, 1, true) then
				local info = getCharacterInfoTab(unitID);
				if info.characteristics and info.characteristics.FN then
					local rpName = TRP3_API.register.getCompleteName(info.characteristics, characterName, true);
					if rpName and rpName ~= characterName then
						if configShowNameEmoteColors() and info.characteristics.CH then
							rpName = "|cff" .. info.characteristics.CH .. rpName .. "|r";
						end
						local escapedName = characterName:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1");
						local pattern = "%f[%w]" .. escapedName .. "%f[%W]";
						
						local startPos = 1;
						while true do
							local matchStart, matchEnd = message:find(pattern, startPos);
							if not matchStart then break end
							
							if not isInsideQuotes(message, matchStart) then
								message = message:sub(1, matchStart - 1) .. rpName .. message:sub(matchEnd + 1);
								startPos = matchStart + rpName:len();
								break
							else
								startPos = matchEnd + 1;
							end
						end
						replacedNames[characterName] = true;
					end
				elseif character and character.heartbeatName and character.heartbeatName ~= "" then
					local rpName = TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(character.heartbeatName) or character.heartbeatName;
					if configShowNameEmoteColors() and character.heartbeatColor and character.heartbeatColor ~= "" then
						rpName = "|cff" .. character.heartbeatColor .. rpName .. "|r";
					end
					local escapedName = characterName:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1");
					local pattern = "%f[%w]" .. escapedName .. "%f[%W]";
					local startPos = 1;
					while true do
						local matchStart, matchEnd = message:find(pattern, startPos);
						if not matchStart then break end
						if not isInsideQuotes(message, matchStart) then
							message = message:sub(1, matchStart - 1) .. rpName .. message:sub(matchEnd + 1);
							startPos = matchStart + rpName:len();
							break
						else
							startPos = matchEnd + 1;
						end
					end
					replacedNames[characterName] = true;
				end
			end
		end
	end
	
	-- player
	local playerName = Globals.player;
	if playerName and not replacedNames[playerName] and message:find(playerName, 1, true) then
		local playerRPName = TRP3_API.register.getPlayerCompleteName(true);
		if playerRPName and playerRPName ~= playerName then
			local playerData = TRP3_API.profile.getData("player/characteristics");
			if configShowNameEmoteColors() and playerData and playerData.CH then
				playerRPName = "|cff" .. playerData.CH .. playerRPName .. "|r";
			end
			local escapedName = playerName:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1");
			local pattern = "%f[%w]" .. escapedName .. "%f[%W]";
			
			-- replace matches
			local startPos = 1;
			while true do
				local matchStart, matchEnd = message:find(pattern, startPos);
				if not matchStart then break end
				
				if not isInsideQuotes(message, matchStart) then
					message = message:sub(1, matchStart - 1) .. playerRPName .. message:sub(matchEnd + 1);
					break
				else
					startPos = matchEnd + 1;
				end
			end
		end
	end
	
	return message;
end


--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Emote and OOC detection
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function detectEmoteAndOOC(type, message)
	local function stripColorCodes(text)
		return text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "");
	end
	
	if configDoEmoteDetection() and message:find(configEmoteDetectionPattern()) then
		local chatInfo = ChatTypeInfo["EMOTE"];
		local color = ("|cff%.2x%.2x%.2x"):format(chatInfo.r*255, chatInfo.g*255, chatInfo.b*255);
		message = message:gsub(configEmoteDetectionPattern(), function(content)
			local cleanContent = stripColorCodes(content);
			return color .. cleanContent .. "|r";
		end);
	end
	if configDoChatDetection() and message:find(configChatDetectionPattern()) then
		message = message:gsub(configChatDetectionPattern(), function(content)
			local cleanContent = stripColorCodes(content);
			return "|cffffffff" .. cleanContent .. "|r";  -- White color
		end);
	end
	if configDoOOCDetection() and message:find(configOOCDetectionPattern()) then
		message = message:gsub(configOOCDetectionPattern(), function(content)
			local cleanContent = stripColorCodes(content);
			return "|cff" .. configOOCDetectionColor() .. cleanContent .. "|r";
		end);
	end
	return message;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- NPC talk detection
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local NPC_TALK_CHANNELS = {
	CHAT_MSG_SAY = 1, CHAT_MSG_EMOTE = 1, CHAT_MSG_PARTY = 1, CHAT_MSG_RAID = 1, CHAT_MSG_PARTY_LEADER = 1, CHAT_MSG_RAID_LEADER = 1
};
local NPC_TALK_PATTERNS;
local RP_CHANNEL_EVENT = "CHAT_MSG_CHANNEL";
local itemRefDeveloperBadgeHooked;
local chatEditHeaderHooked;

local function getPratCapturedAddMessage(chatFrame)
	local prat = _G.Prat;
	local pratAddon = prat and prat.Addon;
	local splitMessage = prat and prat.SplitMessage;
	local hooks = pratAddon and pratAddon.hooks;
	local frameHooks = hooks and hooks[chatFrame];

	if splitMessage and splitMessage.CAPTUREOUTPUT == chatFrame and frameHooks and frameHooks.AddMessage then
		return frameHooks.AddMessage;
	end
end

local function addChatMessage(chatFrame, text, r, g, b, id, ...)
	local pratAddMessage = getPratCapturedAddMessage(chatFrame);
	if pratAddMessage then
		return pratAddMessage(chatFrame, text, r, g, b, id, ...);
	end

	return chatFrame:AddMessage(text, r, g, b, id, ...);
end

local CHAT_EDIT_HEADER_FORMATS = {
	AFK = "AFK: ",
	BATTLEGROUND = "Battleground: ",
	BATTLEGROUND_LEADER = "Battleground Leader: ",
	DND = "DND: ",
	EMOTE = "Emote: ",
	GUILD = "Guild: ",
	OFFICER = "Officer: ",
	PARTY = "Party: ",
	PARTY_LEADER = "Party Leader: ",
	RAID = "Raid: ",
	RAID_LEADER = "Raid Leader: ",
	RAID_WARNING = "Raid Warning: ",
	SAY = "Say: ",
	YELL = "Yell: ",
};

local function getChatEditHeader(editBox)
	if not editBox then
		return nil;
	end
	return _G.ChatFrameEditBoxHeader or (editBox.GetName and _G[(editBox:GetName() or "") .. "Header"]);
end

local function getChatEditValue(editBox, key)
	if not editBox then
		return nil;
	end
	local value = editBox[key];
	if (value == nil or value == "") and editBox.GetAttribute then
		value = editBox:GetAttribute(key);
	end
	return value;
end

local function setChatEditHeaderText(editBox)
	local header = getChatEditHeader(editBox);
	if not header or header.trp3HeaderUpdating then
		return;
	end

	local chatType = getChatEditValue(editBox, "chatType") or "SAY";
	local headerText;
	if chatType == "CHANNEL" then
		local channelTarget = getChatEditValue(editBox, "channelTarget");
		if channelTarget and channelTarget ~= "" and GetChannelName then
			local channelID, channelName = GetChannelName(channelTarget);
			channelID = tonumber(channelID);
			channelName = channelName or getChatEditValue(editBox, "channelName");
			if channelID and channelID > 0 and channelName and channelName ~= "" then
				headerText = _G.CHAT_CHANNEL_SEND and format(_G.CHAT_CHANNEL_SEND, channelID, channelName) or ("[" .. channelID .. ". " .. channelName .. "]: ");
			end
		end
	elseif chatType == "WHISPER" or chatType == "BN_WHISPER" then
		local tellTarget = getChatEditValue(editBox, "tellTarget");
		if tellTarget and tellTarget ~= "" then
			local formatText = _G["CHAT_" .. chatType .. "_SEND"] or _G.CHAT_WHISPER_SEND or "To %s: ";
			headerText = format(formatText, tellTarget);
		end
	else
		headerText = _G["CHAT_" .. chatType .. "_SEND"] or CHAT_EDIT_HEADER_FORMATS[chatType];
		if headerText and headerText:find("%%") then
			headerText = CHAT_EDIT_HEADER_FORMATS[chatType];
		end
	end

	if headerText and headerText ~= "" and header.GetText and header:GetText() ~= headerText then
		header.trp3HeaderUpdating = true;
		header:SetText(headerText);
		header.trp3HeaderUpdating = nil;
	end

	if headerText and headerText ~= "" and editBox.SetTextInsets and header.GetStringWidth then
		editBox:SetTextInsets((header:GetStringWidth() or 0) + 12, 0, 0, 0);
	end
end

local chatEditHeaderDelayFrame;
local function queueChatEditHeaderText(editBox)
	if not editBox then
		return;
	end
	if not chatEditHeaderDelayFrame then
		chatEditHeaderDelayFrame = CreateFrame("Frame");
	end
	chatEditHeaderDelayFrame.editBox = editBox;
	chatEditHeaderDelayFrame.ticks = 0;
	chatEditHeaderDelayFrame:SetScript("OnUpdate", function(self)
		self = self or this;
		self.ticks = (self.ticks or 0) + 1;
		setChatEditHeaderText(self.editBox);
		if self.ticks >= 4 then
			self:SetScript("OnUpdate", nil);
		end
	end);
end

local function hookChatEditHeader()
	if chatEditHeaderHooked then
		return;
	end

	if hooksecurefunc and _G.ChatEdit_UpdateHeader then
		hooksecurefunc("ChatEdit_UpdateHeader", function(editBox)
			setChatEditHeaderText(editBox);
			queueChatEditHeaderText(editBox);
		end);
	end

	if hooksecurefunc and _G.ChatEdit_ParseText then
		hooksecurefunc("ChatEdit_ParseText", function(editBox)
			queueChatEditHeaderText(editBox);
		end);
	end

	for index = 1, (NUM_CHAT_WINDOWS or 10) do
		local editBox = _G["ChatFrame" .. index .. "EditBox"];
		if editBox and editBox.HookScript and not editBox.trp3HeaderHooked then
			editBox:HookScript("OnTextChanged", function(self)
				queueChatEditHeaderText(self or this);
			end);
			editBox:HookScript("OnTabPressed", function(self)
				queueChatEditHeaderText(self or this);
			end);
			editBox:HookScript("OnShow", function(self)
				queueChatEditHeaderText(self or this);
			end);
			editBox.trp3HeaderHooked = true;
		end
	end

	chatEditHeaderHooked = true;
end

local function hookDeveloperBadgeItemRef()
	if itemRefDeveloperBadgeHooked or type(SetItemRef) ~= "function" or not ItemRefTooltip then
		return;
	end

	local originalSetItemRef = SetItemRef;
	SetItemRef = function(link, text, button, chatFrame, ...)
		originalSetItemRef(link, text, button, chatFrame, ...);

		local playerName = type(link) == "string" and link:match("^player:([^:]+)");
		local getDeveloperBadgeInfo = TRP3_API.register.getDeveloperBadgeInfo;
		if not playerName or not getDeveloperBadgeInfo then
			return;
		end

		local badgeInfo = getDeveloperBadgeInfo(playerName);
		if not badgeInfo or not badgeInfo.longText then
			return;
		end

		ItemRefTooltip:AddLine(" ");
		ItemRefTooltip:AddDoubleLine(" ", badgeInfo.longText, 1, 1, 1, 1, 1, 1);
		ItemRefTooltip:Show();
	end

	itemRefDeveloperBadgeHooked = true;
end

local function handleNPCTalk(chatFrame, message, characterID, messageID)
	local playerLink = "|Hplayer:".. characterID .. ":" .. messageID .. "|h";
	for TALK_TYPE, TALK_CHANNEL in pairs(NPC_TALK_PATTERNS) do
		if message:find(TALK_TYPE) then
			local chatInfo = ChatTypeInfo[TALK_CHANNEL];
			local name = message:sub(4, message:find(TALK_TYPE) - 2); -- Isolate the name
			local content = message:sub(name:len() + 4);
			playerLink = playerLink .. name;
			addChatMessage(chatFrame, "|cffff9900" .. playerLink .. "|h|r" .. content, chatInfo.r, chatInfo.g, chatInfo.b, chatInfo.id);
			return;
		end
	end
	local chatInfo = ChatTypeInfo["MONSTER_EMOTE"];
	addChatMessage(chatFrame, playerLink .. message:sub(4) .. "|h", chatInfo.r, chatInfo.g, chatInfo.b, chatInfo.id);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Chatframe management
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

-- Ideas:
-- Ignored to another chatframe (config)
-- Limit name length (config)

local isRenderingTonguesTranslation;

function handleCharacterMessage(chatFrame, event, ...)
	local characterName, characterColor;
	local message, characterID, language, arg4, arg5, arg6, arg7, arg8, arg9, arg10, messageID, arg12, arg13, arg14, arg15, arg16 = ...;
	local languageHeader = "";
	local character = unitIDToInfo(characterID);
	-- if not realm then -- Thanks Blizzard to not always send a full character ID
	-- 	realm = nil;
	-- 	characterID = unitInfoToID(character, realm);
	-- end
	local info = getCharacterInfoTab(characterID);
	
	if not character or character == "" then
		character = characterID or "Unknown";
	end
	
	-- Get chat type and configuration
	local type = strsub(event, 10);
	local chatInfo = ChatTypeInfo[type];
	local isRPChannelMessage = false;
	local isWorldChannelMessage = false;

	if event == RP_CHANNEL_EVENT then
		local matchesRPChannel = configUseRPChannel() and isRPChannelChatMessage(arg8, arg9, arg4);
		local matchesWorldChannel = configUseWorldChannel() and isWorldChannel(arg8, arg9, arg4);
		if not matchesRPChannel and not matchesWorldChannel then
			return false;
		end

		if matchesRPChannel then
			local _, rpChannelName = getRPChannelInfo();
			if not isCustomChannelAssignedToFrame(chatFrame, rpChannelName or getRPChannelName()) then
				return false;
			end
		elseif matchesWorldChannel then
			local _, worldChannelName = getWorldChannelInfo();
			if not isCustomChannelAssignedToFrame(chatFrame, worldChannelName or WORLD_CHANNEL_NAME) then
				return false;
			end
		end

		if matchesRPChannel then
			isRPChannelMessage = true;
		elseif matchesWorldChannel then
			isWorldChannelMessage = true;
		else
			return true;
		end

		type = "CHANNEL";
		chatInfo = (arg8 and ChatTypeInfo["CHANNEL" .. tostring(arg8)]) or ChatTypeInfo[type];
	end
	
	-- Detect NPC talk pattern on authorized channels
	local npcPrefix = configNPCTalkPrefix() or "";
	if strlen(npcPrefix) > 0 and message:sub(1, strlen(npcPrefix)) == npcPrefix and configDoHandleNPCTalk() and NPC_TALK_CHANNELS[event] then
		handleNPCTalk(chatFrame, message, characterID, messageID);
		return true;
	end

	-- WHISPER and WHISPER_INFORM have the same chat info
	if ( strsub(type, 1, 7) == "WHISPER" ) then
		chatInfo = ChatTypeInfo["WHISPER"];
	end

	-- WHISPER respond
	if type == "WHISPER" then
		ChatEdit_SetLastTellTarget(characterID, type);
		if ( chatFrame.tellTimer and (GetTime() > chatFrame.tellTimer) ) then
			PlaySound("TellMessage");
		end
		chatFrame.tellTimer = GetTime() + CHAT_TELL_ALERT_TIME;
	end

	-- Character name
	characterName = character;

	local nameMethod = configNameMethod();
	if nameMethod == 2 or nameMethod == 3 or nameMethod == 4 then -- TRP3 names
		if info.characteristics and info.characteristics.FN then
			characterName = info.characteristics.FN;
		end
		if nameMethod == 3 and info.characteristics and info.characteristics.LN then -- With last name
			characterName = characterName .. " " .. info.characteristics.LN;
		end
		if nameMethod == 4 then -- With title + first name + last name
			characterName = getCompleteName(info.characteristics);
		end
		if (not info.characteristics or not info.characteristics.FN) and characterID ~= Globals.player_id then
			characterName = getHeartbeatDisplayName(characterID, characterName);
		end
	end

	-- Ensure characterName is never nil, then keep a plain undecorated copy.
	characterName = stripDecorators(characterName or character or "Unknown");

	local characterIcon = "";
	if configShowNameIcons() and info.characteristics and info.characteristics.IC and info.characteristics.IC ~= "" then
		characterIcon = Utils.str.icon(info.characteristics.IC, configNameIconSize()) .. " ";
	end

	if isWorldChannelMessage then
		characterColor = getWorldChatFactionColor(characterID, info, arg12);
	elseif configShowNameCustomColors() and info.characteristics and info.characteristics.CH and info.characteristics.CH ~= "" then
		characterColor = "|cff" .. info.characteristics.CH;
	end
	if not characterColor then
		characterColor = getCharacterClassColor(chatInfo, event, message, characterID, language, arg4, arg5, arg6, arg7, arg8, arg9, arg10, messageID, arg12);
	end
	local linkedCharacterName = characterName;
	if characterColor then
		linkedCharacterName = characterColor .. linkedCharacterName .. "|r";
	end

	-- Language
	if ( (strlen(language) > 0) and (language ~= chatFrame.defaultLanguage) ) then
		languageHeader = "[" .. language .. "] ";
	end

	-- Show
	message = RemoveExtraSpaces(message);
	local tonguesDisplayLanguage;
	if not isRenderingTonguesTranslation and TRP3_API.tongues and TRP3_API.tongues.resolveDisplayMessage then
		local renderTonguesTranslation = function(translatedMessage, translatedLanguage)
			isRenderingTonguesTranslation = true;
			handleCharacterMessage(chatFrame, event, translatedMessage, characterID, translatedLanguage or language, arg4, arg5, arg6, arg7, arg8, arg9, arg10, messageID, arg12, arg13, arg14, arg15, arg16);
			isRenderingTonguesTranslation = false;
		end
		message, tonguesDisplayLanguage = TRP3_API.tongues.resolveDisplayMessage(message, characterID, chatFrame, language, renderTonguesTranslation, event);
		if tonguesDisplayLanguage and strlen(tonguesDisplayLanguage) > 0 and tonguesDisplayLanguage ~= chatFrame.defaultLanguage then
			languageHeader = "[" .. tonguesDisplayLanguage .. "] ";
		end
	end
	message = applyBridgeLeadTextColor(characterName, message, type, isRPChannelMessage);
	
	-- No yelled emote ?
	if event == "CHAT_MSG_YELL" and configNoYelledEmote() then
		message = message:gsub("%*.-%*", "");
		message = message:gsub("%<.-%>", "");
	end
	
	-- Colorize emote and OOC
	message = detectEmoteAndOOC(type, message);
	
	-- replace character name with trp3 names (only for emotes and messages containing emote patterns)
	if type == "EMOTE" or type == "TEXT_EMOTE" or (configDoEmoteDetection() and message:find(configEmoteDetectionPattern())) then
		message = replaceNameInEmote(message, characterID, type);
		if TRP3_API.tongues and TRP3_API.tongues.colorRelationshipNamesForDisplay then
			message = TRP3_API.tongues.colorRelationshipNamesForDisplay(message, nil, tonguesDisplayLanguage or language);
		end
		message = detectEmoteAndOOC(type, message);
	end
	
	-- Is there still something to show ?
	if strtrim(message):len() == 0 then
		return true;
	end
	
	local playerLink = "|Hplayer:".. characterID .. ":" .. messageID .. "|h";
	local body;
	if type == "EMOTE" then
		body = characterIcon .. format(_G["CHAT_"..type.."_GET"], playerLink .. linkedCharacterName .. "|h") .. message;
	elseif type == "TEXT_EMOTE" then
		body = message;
		if characterID ~= Globals.player_id and body:sub(1, character:len()) == character then
			body = body:gsub("^([^%s]+)", characterIcon .. playerLink .. linkedCharacterName .. "|h");
		end
	else
		local nameWithoutIcon = characterName or "Unknown";
		local linkedNameWithoutIcon = linkedCharacterName or nameWithoutIcon;
		local hideSenderName = shouldHideBridgeSenderName(characterName, type, isRPChannelMessage);
		
		local leftBracket, rightBracket;
		if configChannelReplacement() then
			leftBracket, rightBracket = getNameBrackets();
		else
			leftBracket, rightBracket = "[", "]";
		end
		
		-- custom channel names (only if channel replacement is enabled)
		if configChannelReplacement() then
			if type == "PARTY" then
				body = characterIcon .. configPartyChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif type == "PARTY_LEADER" then
				body = characterIcon .. configPartyLeaderChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif type == "RAID" then
				body = characterIcon .. configRaidChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif type == "RAID_LEADER" then
				body = characterIcon .. configRaidLeaderChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif type == "GUILD" and hideSenderName then
				body = characterIcon .. configGuildChannelName() .. ": " .. languageHeader .. message;
			elseif type == "GUILD" then
				body = characterIcon .. configGuildChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif type == "OFFICER" then
				body = characterIcon .. configOfficerChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif type == "WHISPER" then
				body = characterIcon .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h " .. configWhisperInChannelName() .. ": " .. languageHeader .. message;
			elseif type == "WHISPER_INFORM" then
				body = characterIcon .. configWhisperOutChannelName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif isRPChannelMessage and hideSenderName then
				body = characterIcon .. getRPChannelDisplayName() .. ": " .. languageHeader .. message;
			elseif isRPChannelMessage then
				body = characterIcon .. getRPChannelDisplayName() .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			elseif isWorldChannelMessage then
				local factionIcon = getWorldChatFactionIcon(chatFrame, characterID, info, arg12);
				local worldLabel = getWorldChannelDisplayName(arg9, arg4);
				local factionSegment = factionIcon ~= "" and (" [" .. factionIcon .. "]") or "";
				body = worldLabel .. factionSegment .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			else
				if hideSenderName then
					body = characterIcon .. languageHeader .. message;
				else
					body = characterIcon .. format(_G["CHAT_"..type.."_GET"], playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h") .. languageHeader .. message;
				end
			end
		else
			if isRPChannelMessage and hideSenderName then
				body = characterIcon .. getRPChannelDisplayName() .. ": " .. languageHeader .. message;
			elseif isWorldChannelMessage then
				local factionIcon = getWorldChatFactionIcon(chatFrame, characterID, info, arg12);
				local worldLabel = getWorldChannelDisplayName(arg9, arg4);
				local factionSegment = factionIcon ~= "" and (" [" .. factionIcon .. "]") or "";
				body = worldLabel .. factionSegment .. " " .. playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h: " .. languageHeader .. message;
			else
				if hideSenderName then
					body = characterIcon .. languageHeader .. message;
				else
					body = characterIcon .. format(_G["CHAT_"..type.."_GET"], playerLink .. leftBracket .. linkedNameWithoutIcon .. rightBracket .. "|h") .. languageHeader .. message;
				end
			end
		end
	end

	--Add Timestamps
	if ( CHAT_TIMESTAMP_FORMAT ) then
		body = BetterDate(CHAT_TIMESTAMP_FORMAT, time()) .. body;
	end

	addChatMessage(chatFrame, body, chatInfo.r, chatInfo.g, chatInfo.b, chatInfo.id, false);

	return true;
end

function hooking()
	for _, channel in pairs(POSSIBLE_CHANNELS) do
		ChatFrame_RemoveMessageEventFilter(channel, handleCharacterMessage);
		if configIsChannelUsed(channel) then
			ChatFrame_AddMessageEventFilter(channel, handleCharacterMessage);
		end
	end
	ChatFrame_RemoveMessageEventFilter(RP_CHANNEL_EVENT, handleCharacterMessage);
	ChatFrame_AddMessageEventFilter(RP_CHANNEL_EVENT, handleCharacterMessage);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Init
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function onStart()
	local useWIM = WIM ~= nil;

	if useWIM then
		POSSIBLE_CHANNELS = {
			"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE",
			"CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
			"CHAT_MSG_GUILD", "CHAT_MSG_OFFICER"
		};
	else
		POSSIBLE_CHANNELS = {
			"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE",
			"CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
			"CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM"
		};
	end
	NPC_TALK_PATTERNS = {
		[loc("NPC_TALK_SAY_PATTERN")] = "MONSTER_SAY",
		[loc("NPC_TALK_YELL_PATTERN")] = "MONSTER_YELL",
		[loc("NPC_TALK_WHISPER_PATTERN")] = "MONSTER_WHISPER",
	};
	createConfigPage(useWIM);
	hooking();
	setupChatContextMenu();
	hookChatEditHeader();
	hookDeveloperBadgeItemRef();
end

local MODULE_STRUCTURE = {
	["name"] = "Chat frames",
	["description"] = "Global enhancement for chat frames. Use roleplay information, detect emotes and OOC sentences and use colors.",
	["version"] = 1.000,
	["id"] = "trp3_chatframes",
	["onStart"] = onStart,
	["minVersion"] = 3,
};

TRP3_API.module.registerModule(MODULE_STRUCTURE);
