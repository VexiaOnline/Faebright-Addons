local RavenspeechDifficulty = Tongues.Language["Ravenspeech"] and Tongues.Language["Ravenspeech"].Difficulty;

Tongues.Language["Ravenspeech"] = {
	[1] = { "u", "a", "e", "ek" },
	[2] = { "ka", "as", "ko", "ek", "ki", "da", "so" },
	[3] = { "fai", "kah", "kar", "kel", "lek", "lak", "kri", "lan", "ark", "hak", "kh-k", "hek", "lai", "tal", "sul", "sho", "tul", "a-ak", "rak" },
	[4] = { "hark", "kaah", "laks", "ekos", "kraa", "peth", "peku", "shak", "krek", "kerh", "staa", "teyk", "kwer", "teks", "hrew", "shai", "ra-ak", "skek", "slek", "asul", "shul", "aika", "saro", "sesh", "aark", "sy-ak", "la-rk", "khai", "lan-e", "kah-e", "hak-e", "sho-e" },
	[5] = { "raark", "khrek", "khaal", "krunu", "kesti", "istis", "berek", "enzu", "teyek", "sklew", "hewis", "karaa", "sekre-e", "mokre-e", "hrsek", "hrewk", "ainos", "garim", "shaio", "mesta", "ostis" },  
	[6] = { "haz-kin", "ski-gra", "hekwos", "hek-wos", "koneta", "unzuhl", "heknos", "tokarr", "ra-kaw", "khondu", "ssakar", "mardek", "ethekk", "kekmek", "rislui", "kestes", "hestek", "sekrek", "sek-rek", "takak", "lotkoa" },
	[7] = { "shiraak", "falaisa", "teksa-ek", "uil-skek", "hakalik", "sethell", "ekksemi", "skimasi", "ekmekse", "heklaik", "stakros", "wilkwos" },
	[8] = { "skraital", "kaimaral", "akkekksek", "staalush", "pekupeth", "shoa-koak", "sekk-mekk", "tekk-lekk", "hekk-kekk", "karrkarr" },
	[9] = { "tiktaalik", "halak-tunir", "ssarokkar", "sept-halik", "dekokiani", "kahkarmak", "hetulkeks", "teyk-meyk", "kelonkosk", "taalik-tik", "kake-garim", "sesh", "ark", "taitaltak", "kh-k", "sulmak" },
	[10] = { "kondoskekk", "hekrum-tanir", "aital-aikal", "raark-khrek", "koneta-hark", "slek-mardek", "asul-ssakar", "hrsek-khaal", "beyek-kraam", "lak-shul-fai", "lek-teks-kaah", "sklewkhondu-e", "lotkotakma", "skekslekmo" },
	[11] = { "sekrek-takak", "takak-sekrek", "thuhesh-krek", "ek-ki-ssakarr", "hrewmaskeka", "krostak-raark", "khan-shaimak"},
	[12] = { "harksikomakk", "ka-as-ko-lan-ark-shai", "khondu-tokarr", "ashulsosek", "sarkulmosekla", "thulweimaskek", "gartulskekkhai", "teksa-ek-teksa", "hewlaksewendis", "hark", "kaah", "lak", "shak", "krek", "kerh", "staa", "teyk", "kwer", "teks", "hrew", "shai", "ra-ak", "skek", "slek" },
};

Tongues.Language["Ravenspeech"]["ignore"] = {
	"skeksis", "Anzu", "Arakkoa", "Terokkar", "Shattrath", "Sethekk", "Ikiss", "Syth", "Isfar", "Lakka", "Grizzik", "Terokk", "Erekem", "Kirrawk", "Kirrik", "Parshah", "Rilak", "Ssarbik", "Sketh'lon"
};


Tongues.Language["Ravenspeech"]["substitute"] = {
	["ravenspeech"] = "Arakkoakes",
	["language"] = "kes",
	["tongue"] = "kes",
	["trial"] = "hak",
	["by"] = "shki",
	["stone"] = "gar",
	["emperor"] = "shai-sho-ka",
	["kneel"] = "khaai",
	["bow"] = "khaai",
	["the crystal"] = "tul-thakarr",
	["crystal"] = "thakarr",
	["crystals"] = "thakarr",
	["calls"] = "akul",
	["minion"] = "garthim",
	["minions"] = "garthim",
	["elf"] = "gelf",
	["elf-child"] = "gelflin",
	["Quel'dorei"] = "sik gelflin-kor-kai",
	["Sin'dorei"] = "hesh-gelflin",
	["Kal'dorei"] = "lik gelflin-kor-kai",
	["heir"] = "koa",
	["heirs"] = "koa",
	["human"] = "khmo",
	["humans"] = "khmo",
	["guest"] = "kostis",
	["guests"] = "kostis",
	["now"] = "nuk",
	["worship"] = "hy-ak",
	["sacrifice"] = "hy-ak",
	["pray"] = "hy-ak",
	["promise"] = "hwek",
	["holy"] = "kwen",
	["grow"] = "kreh",
	["i"] = "ekk",
	["me"] = "hme",
	["be"] = "kuh",
	["is"] = "heski",
	["are"] = "heski",
	["am"] = "heski",
	["body"] = "krep",
	["tear"] = "hekru",
	["blood"] = "hesh",
	["you"] = "thu",
	["we"] = "wei",
	["that"] = "so",
	["he"] = "ke",
	["she"] = "kis",
	["it"] = "kos",
	["his"] = "ke-e",
	["hers"] = "kis-e",
	["its"] = "kos-e",
	["their"] = "shaik",
	["theirs"] = "shaik-e",
	["self"] = "swe",
	["him"] = "kel",
	["her"] = "kisel",
	["them"] = "shaikel",
	["himself"] = "kelswe",
	["herself"] = "kiselswe",
	["itself"] = "kos-swe",
	["themselves"] = "shaik-swe", 
	["what"] = "kod",
	["who"] = "koy",
	["not"] = "ne",
	["one"] = "oinos",
	["two"] = "kwo",
	["three"] = "tisres",
	["four"] = "ketesres",
	["five"] = "kenke",
	["six"] = "sweks",
	["seven"] = "sekten",
	["eight"] = "hokto",
	["nine"] = "newen",
	["ten"] = "dekmet",
	["same"] = "sem",
	["hundred"] = "kmtom",
	["warcraft"] = "skekkraft",
	["world"] = "lewk",
	["horse"] = "ekwos",
	["through"] = "per",
	["across"] = "per",
	["beyond"] = "per",
	["over"] = "uker",
	["OOC"] = "sekk-ok-arakter",
	["IC"] = "ik-arakter",
	["Faebright"] = "skraeskright",
	["turtle"] = "turkel",
};

Tongues.Language["Ravenspeech"].Difficulty = RavenspeechDifficulty or {
	["default"] = 1000;

	["Alliance"] = 0;
	["Horde"] = 0;

	["Human"] = 0;
	["Dwarf"] = 0;
	["Gnome"] = 0;
	["Night Elf"] = 0;
	["Draenei"] = 0;

	["Orcish"] = 0;
	["Troll"] = 0;
	["Undead"] = 0;
	["Tauren"] = 0;
	["Blood Elf"] = 0;

	["Warrior"] = 0;
	["Rogue"] = 0;
	["Druid"] = 0;
	["Mage"] = 0;
	["Warlock"] = 0;
	["Paladin"] = 0;
	["Priest"] = 0;
	["Shaman"] = 0;
	["Hunter"] = 0;
	["Death Knight"] = 0;
};
