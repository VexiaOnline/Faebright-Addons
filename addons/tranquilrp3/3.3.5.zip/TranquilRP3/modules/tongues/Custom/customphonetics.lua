Tongues.Custom.Phonetic = {
};