----------------------------------------------------------------------------------
-- TranquilRP3
-- Tongues integration
----------------------------------------------------------------------------------

local Config = TRP3_API.configuration;
local Events = TRP3_API.events;
local Globals = TRP3_API.globals;
local Utils = TRP3_API.utils;
local get = TRP3_API.profile.getData;
local registerConfigKey = Config.registerConfigKey;
local rawGetConfigValue = Config.getValue;
local setConfigValue = Config.setValue;
local registerHandler = Config.registerHandler;
local displayDropDown = TRP3_API.ui.listbox.displayDropDown;
local tinsert, pairs, type, tostring, tonumber, strtrim = tinsert, pairs, type, tostring, tonumber, strtrim;
local SendAddonMessage = SendAddonMessage;

TRP3_API.tongues = TRP3_API.tongues or {};
local API = TRP3_API.tongues;

local ADDON_PREFIX = "TRP3TONGUES";
local MESSAGE_SEP = "\031";
local lastOriginalMessage;
local originalMessageHistory = {};
local pendingOriginalRequests = {};
local pendingOriginalResponseChunks = {};
local originalBroadcastCache = {};
local originalSendChatMessage = TRP3_TonguesOriginalSendChatMessage or SendChatMessage;
local sendingFinalChatMessage;
local trp3SendChatMessageWrapper;

local CONFIG_ENABLED = "tongues_enabled";
local CONFIG_LANGUAGE = "tongues_language";
local CONFIG_DIALECT = "tongues_dialect";
local CONFIG_AFFECT = "tongues_affect";
local CONFIG_AFFECT_FREQUENCY = "tongues_affect_frequency";
local CONFIG_FILTER = "tongues_filter";
local CONFIG_SHAPESHIFT_LANGUAGE = "tongues_shapeshift_language";
local CONFIG_DIALECT_DRIFT = "tongues_dialect_drift";
local CONFIG_LORE_COMPATIBILITY = "tongues_lore_compatibility";
local CONFIG_TRANSLATE_SELF = "tongues_translate_self";
local CONFIG_TRANSLATE_TARGETTED = "tongues_translate_targetted";
local CONFIG_TRANSLATE_PARTY = "tongues_translate_party";
local CONFIG_TRANSLATE_GUILD = "tongues_translate_guild";
local CONFIG_TRANSLATE_OFFICER = "tongues_translate_officer";
local CONFIG_TRANSLATE_RAID = "tongues_translate_raid";
local CONFIG_TRANSLATE_RAID_ALERT = "tongues_translate_raid_alert";
local CONFIG_TRANSLATE_BATTLEGROUND = "tongues_translate_battleground";
local CONFIG_SCREEN_SELF = "tongues_screen_self";
local CONFIG_SCREEN_TARGETTED = "tongues_screen_targetted";
local CONFIG_SCREEN_PARTY = "tongues_screen_party";
local CONFIG_SCREEN_GUILD = "tongues_screen_guild";
local CONFIG_SCREEN_OFFICER = "tongues_screen_officer";
local CONFIG_SCREEN_RAID = "tongues_screen_raid";
local CONFIG_SCREEN_RAID_ALERT = "tongues_screen_raid_alert";
local CONFIG_SCREEN_BATTLEGROUND = "tongues_screen_battleground";
local CONFIG_DISABLE_SAY = "tongues_disable_say";
local CONFIG_DISABLE_YELL = "tongues_disable_yell";
local CONFIG_DISABLE_WHISPER = "tongues_disable_whisper";
local CONFIG_DISABLE_PARTY = "tongues_disable_party";
local CONFIG_DISABLE_GUILD = "tongues_disable_guild";
local CONFIG_DISABLE_OFFICER = "tongues_disable_officer";
local CONFIG_DISABLE_RAID = "tongues_disable_raid";
local CONFIG_DISABLE_RAID_WARNING = "tongues_disable_raid_warning";
local CONFIG_DISABLE_BATTLEGROUND = "tongues_disable_battleground";
local CONFIG_DISABLE_CHANNEL = "tongues_disable_channel";
local CONFIG_DISABLE_DEFAULTS_APPLIED = "tongues_disable_defaults_applied";
local CONFIG_DISABLE_IN_BATTLEGROUNDS = "tongues_disable_in_battlegrounds";
local CONFIG_EAVESDROP_MODE = "tongues_eavesdrop_mode";
local CONFIG_EAVESDROP_DEFAULT_APPLIED = "tongues_eavesdrop_default_applied";
local CONFIG_YELL_DEFAULT_ENABLED_APPLIED = "tongues_yell_default_enabled_applied";
local CONFIG_RELATIONSHIP_NAMES = "tongues_relationship_names";
local CONFIG_DEBUGGING = "tongues_debugging";
local CONFIG_TRANSLATORS = "tongues_translators";

local function getDefaultNativeLanguage()
	if UnitFactionGroup and UnitFactionGroup("player") == "Horde" then
		return "Orcish";
	end
	return "Common";
end

local CONFIG_DEFAULTS = {
	[CONFIG_ENABLED] = true,
	[CONFIG_LANGUAGE] = getDefaultNativeLanguage(),
	[CONFIG_DIALECT] = "<None>",
	[CONFIG_AFFECT] = "<None>",
	[CONFIG_AFFECT_FREQUENCY] = 100,
	[CONFIG_FILTER] = "<None>",
	[CONFIG_SHAPESHIFT_LANGUAGE] = true,
	[CONFIG_DIALECT_DRIFT] = false,
	[CONFIG_LORE_COMPATIBILITY] = true,
	[CONFIG_TRANSLATE_SELF] = false,
	[CONFIG_TRANSLATE_TARGETTED] = false,
	[CONFIG_TRANSLATE_PARTY] = false,
	[CONFIG_TRANSLATE_GUILD] = false,
	[CONFIG_TRANSLATE_OFFICER] = false,
	[CONFIG_TRANSLATE_RAID] = false,
	[CONFIG_TRANSLATE_RAID_ALERT] = false,
	[CONFIG_TRANSLATE_BATTLEGROUND] = false,
	[CONFIG_SCREEN_SELF] = false,
	[CONFIG_SCREEN_TARGETTED] = false,
	[CONFIG_SCREEN_PARTY] = true,
	[CONFIG_SCREEN_GUILD] = true,
	[CONFIG_SCREEN_OFFICER] = true,
	[CONFIG_SCREEN_RAID] = true,
	[CONFIG_SCREEN_RAID_ALERT] = true,
	[CONFIG_SCREEN_BATTLEGROUND] = true,
	[CONFIG_DISABLE_SAY] = false,
	[CONFIG_DISABLE_YELL] = false,
	[CONFIG_DISABLE_WHISPER] = false,
	[CONFIG_DISABLE_PARTY] = false,
	[CONFIG_DISABLE_GUILD] = false,
	[CONFIG_DISABLE_OFFICER] = false,
	[CONFIG_DISABLE_RAID] = false,
	[CONFIG_DISABLE_RAID_WARNING] = false,
	[CONFIG_DISABLE_BATTLEGROUND] = false,
	[CONFIG_DISABLE_CHANNEL] = false,
	[CONFIG_DISABLE_DEFAULTS_APPLIED] = false,
	[CONFIG_DISABLE_IN_BATTLEGROUNDS] = true,
	[CONFIG_EAVESDROP_MODE] = true,
	[CONFIG_EAVESDROP_DEFAULT_APPLIED] = false,
	[CONFIG_YELL_DEFAULT_ENABLED_APPLIED] = false,
	[CONFIG_RELATIONSHIP_NAMES] = true,
	[CONFIG_DEBUGGING] = false,
	[CONFIG_TRANSLATORS] = "",
};
local syncSuspended;
local syncHandlersRegistered;
local lastStandaloneSignature;
local lastProfileFluencySignature;
local refreshTonguesSettings;
local requestOriginal;
local getActiveLanguage;
local isKnownBlizzardLanguage;
local partiallyTranslateText;
local ensureLanguageData;
local lastActiveLanguageChangeAt;
local activeLanguageOverride;
local selectedBlizzardLanguage;

local function copyTable(source)
	if type(source) ~= "table" then
		return source;
	end
	local target = {};
	for key, value in pairs(source) do
		target[key] = copyTable(value);
	end
	return target;
end

local LANGUAGE_ICONS = {
	Common = "Inv_Misc_Tournaments_banner_Human",
	Orcish = "RACIAL_ORC_BERSERKERSTRENGTH",
	Darnassian = "Ability_Racial_Shadowmeld",
	Dwarvish = "Inv_Drink_05",
	Gnomish = "INV_Gizmo_01",
	Draenei = "INV_Misc_Gem_Pearl_05",
	Thalassian = "Spell_Holy_ArcaneIntellect",
	Taurahe = "Ability_WarStomp",
	Troll = "RACIAL_TROLL_BERSERK",
	Zandali = "Ability_Hunter_Pet_Raptor",
	Gutterspeak = "Ability_Racial_Cannibalize",
	Wolf = "Ability_Hunter_Pet_Wolf",
	Hyena = "Ability_Hunter_Pet_Hyena",
	["Core Hound"] = "Ability_Hunter_Pet_CoreHound",
	Bear = "Ability_Hunter_Pet_Bear",
	Bat = "Ability_Hunter_Pet_Bat",
	Sporebat = "Ability_Hunter_Pet_Sporebat",
	Boar = "Ability_Hunter_Pet_Boar",
	Serpent = "Ability_Hunter_Pet_WindSerpent",
	Nether = "Spell_Shadow_SummonVoidWalker",
	["Nether Ray"] = "Ability_Hunter_Pet_NetherRay",
	Chimaera = "Ability_Hunter_Pet_Chimera",
	Crocolisk = "Ability_Hunter_Pet_Crocolisk",
	Devilsaur = "Ability_Hunter_Pet_Devilsaur",
	Raptor = "Ability_Hunter_Pet_Raptor",
	Ursine = "Ability_Hunter_Pet_Bear",
	Kodo = "Ability_Mount_Kodo_01",
	Rhino = "Ability_Hunter_Pet_Rhino",
	Cat = "Ability_Hunter_Pet_Cat",
	Wyvern = "Ability_Hunter_Pet_WindSerpent",
	Seal = "Ability_Hunter_Pet_Turtle",
	Bird = "Ability_Hunter_Pet_Owl",
	Tallstrider = "Ability_Hunter_Pet_TallStrider",
	Ravenspeech = "Ability_Hunter_Pet_Owl",
	Equine = "Ability_Mount_RidingHorse",
	Binary = "INV_Gizmo_02",
	Moonkin = "Spell_Nature_ForceOfNature",
	Trentish = "Ability_Druid_ForceOfNature",
	Turtle = "Ability_Hunter_Pet_Turtle",
	["Dark Iron"] = "Spell_Fire_SelfDestruct",
	Elemental = "Spell_Nature_ElementalPrecision_1",
	Demonic = "Spell_Shadow_SummonFelHunter",
	Eredun = "Spell_Shadow_SummonFelGuard",
	Titan = "INV_Misc_Rune_10",
	Draconic = "INV_Misc_Head_Dragon_01",
	Kalimag = "Spell_Nature_Earthquake",
	Nerubian = "INV_Misc_MonsterSpiderCarapace_01",
	Qiraji = "INV_QirajIdol_Obsidian",
	Silithid = "Ability_Hunter_Pet_Silithid",
	Wasp = "Ability_Hunter_Pet_Wasp",
	Ravager = "Ability_Hunter_Pet_Ravager",
	Scorpid = "Ability_Hunter_Pet_Scorpid",
	Spider = "Ability_Hunter_Pet_Spider",
	Nerglish = "INV_Misc_Fish_21",
	Crab = "Ability_Hunter_Pet_Crab",
	Nazja = "INV_Misc_Shell_01",
	Undead = "Spell_Shadow_AnimateDead",
	Unknown = "INV_Misc_QuestionMark",
};
API.LANGUAGE_ICONS = LANGUAGE_ICONS;

local function registerKey(key, defaultValue)
	if not Config.isConfigKeyRegistered(key) then
		registerConfigKey(key, defaultValue);
	end
end

local function registerTonguesConfigKeys()
	for key, defaultValue in pairs(CONFIG_DEFAULTS) do
		registerKey(key, defaultValue);
	end
end

registerTonguesConfigKeys();

local function getConfigValue(key)
	if Config.isConfigKeyRegistered and not Config.isConfigKeyRegistered(key) then
		return CONFIG_DEFAULTS[key];
	end
	return rawGetConfigValue(key);
end

local function getRegisteredConfigValue(key, fallback)
	if Config.isConfigKeyRegistered and not Config.isConfigKeyRegistered(key) then
		if fallback ~= nil then
			return fallback;
		end
		return CONFIG_DEFAULTS[key];
	end
	return getConfigValue(key);
end

local CONFIG_TO_TONGUES_FIELD = {
	[CONFIG_LANGUAGE] = "Language",
	[CONFIG_DIALECT] = "Dialect",
	[CONFIG_AFFECT] = "Affect",
	[CONFIG_AFFECT_FREQUENCY] = "AffectFrequency",
	[CONFIG_FILTER] = "Filter",
	[CONFIG_SHAPESHIFT_LANGUAGE] = "ShapeshiftLanguage",
	[CONFIG_DIALECT_DRIFT] = "DialectDrift",
	[CONFIG_LORE_COMPATIBILITY] = "LoreCompatibility",
	[CONFIG_DEBUGGING] = "Debugging",
};

local TRANSLATION_CONFIG_TO_FIELD = {
	[CONFIG_TRANSLATE_SELF] = "Self",
	[CONFIG_TRANSLATE_TARGETTED] = "Targetted",
	[CONFIG_TRANSLATE_PARTY] = "Party",
	[CONFIG_TRANSLATE_GUILD] = "Guild",
	[CONFIG_TRANSLATE_OFFICER] = "Officer",
	[CONFIG_TRANSLATE_RAID] = "Raid",
	[CONFIG_TRANSLATE_RAID_ALERT] = "RaidAlert",
	[CONFIG_TRANSLATE_BATTLEGROUND] = "Battleground",
};

local SCREEN_CONFIG_TO_FIELD = {
	[CONFIG_SCREEN_SELF] = "Self",
	[CONFIG_SCREEN_TARGETTED] = "Targetted",
	[CONFIG_SCREEN_PARTY] = "Party",
	[CONFIG_SCREEN_GUILD] = "Guild",
	[CONFIG_SCREEN_OFFICER] = "Officer",
	[CONFIG_SCREEN_RAID] = "Raid",
	[CONFIG_SCREEN_RAID_ALERT] = "RaidAlert",
	[CONFIG_SCREEN_BATTLEGROUND] = "Battleground",
};

local function getStandaloneCharacterSettings()
	if type(Tongues_Character) == "table" then
		Tongues_Character.Fluency = Tongues_Character.Fluency or {};
		Tongues_Character.Understanding = Tongues_Character.Understanding or {};
		Tongues_Character.Translations = Tongues_Character.Translations or {};
		Tongues_Character.Screen = Tongues_Character.Screen or {};
		Tongues_Character.Translators = Tongues_Character.Translators or {};
		return Tongues_Character;
	end
end

local function translatorsToText(translators)
	if type(translators) ~= "table" then
		return "";
	end
	local values = {};
	for _, translator in pairs(translators) do
		if translator and translator ~= "" then
			tinsert(values, translator);
		end
	end
	table.sort(values);
	return table.concat(values, ", ");
end

local function textToTranslators(text)
	local translators = {};
	for translator in string.gmatch(tostring(text or ""), "([^,]+)") do
		translator = string.gsub(translator, "^%s+", "");
		translator = string.gsub(translator, "%s+$", "");
		if translator ~= "" then
			tinsert(translators, translator);
		end
	end
	return translators;
end

local function getStandaloneSignature()
	local settings = getStandaloneCharacterSettings();
	if not settings then
		return nil;
	end
	local parts = {};
	for configKey, fieldName in pairs(CONFIG_TO_TONGUES_FIELD) do
		tinsert(parts, fieldName .. "=" .. tostring(settings[fieldName]));
	end
	for configKey, fieldName in pairs(TRANSLATION_CONFIG_TO_FIELD) do
		tinsert(parts, "T" .. fieldName .. "=" .. tostring(settings.Translations[fieldName]));
	end
	for configKey, fieldName in pairs(SCREEN_CONFIG_TO_FIELD) do
		tinsert(parts, "S" .. fieldName .. "=" .. tostring(settings.Screen[fieldName]));
	end
	for languageName, fluency in pairs(settings.Fluency or {}) do
		tinsert(parts, "F" .. tostring(languageName) .. "=" .. tostring(fluency));
	end
	for languageName, fluency in pairs(settings.Understanding or {}) do
		tinsert(parts, "U" .. tostring(languageName) .. "=" .. tostring(fluency));
	end
	tinsert(parts, "Translators=" .. translatorsToText(settings.Translators));
	table.sort(parts);
	return table.concat(parts, "|");
end

local function getFluencySignature(fluencies)
	local parts = {};
	for languageName, fluency in pairs(fluencies or {}) do
		tinsert(parts, tostring(languageName) .. "=" .. tostring(fluency));
	end
	table.sort(parts);
	return table.concat(parts, "|");
end

local function resolveLanguageTable(languageName)
	if not Tongues.Language or not languageName then
		return nil;
	end
	local language = Tongues.Language[languageName];
	local checkedAliases = {};
	while type(language) == "table" and language.alias and not checkedAliases[language.alias] do
		checkedAliases[language.alias] = true;
		language = Tongues.Language[language.alias];
	end
	return language;
end

local function resolveLanguageName(languageName)
	if not Tongues.Language or not languageName then
		return languageName;
	end
	local language = Tongues.Language[languageName];
	local checkedAliases = {};
	while type(language) == "table" and language.alias and not checkedAliases[language.alias] do
		checkedAliases[language.alias] = true;
		languageName = language.alias;
		language = Tongues.Language[languageName];
	end
	return languageName;
end

local function hasUsableWordBuckets(language)
	if type(language) ~= "table" then
		return false;
	end
	for index = 1, #language do
		if type(language[index]) == "table" and #language[index] > 0 then
			return true;
		end
	end
	return false;
end

local function getUsableLanguageTable(languageName)
	local language = resolveLanguageTable(languageName);
	if hasUsableWordBuckets(language) then
		return language;
	end
	language = resolveLanguageTable("Unknown");
	if hasUsableWordBuckets(language) then
		return language;
	end
	language = resolveLanguageTable("Common");
	if hasUsableWordBuckets(language) then
		return language;
	end
	return nil;
end

local function getTranslationOptionIndex(seed, optionCount)
	if optionCount <= 1 then
		return 1;
	end
	local hash = 0;
	seed = tostring(seed or "");
	for index = 1, string.len(seed) do
		hash = ((hash * 33) + string.byte(seed, index)) % optionCount;
	end
	return hash + 1;
end

local function getProfileCharacteristics(profile)
	if profile and profile.characteristics then
		return profile.characteristics;
	end
	if profile and profile.player and profile.player.characteristics then
		return profile.player.characteristics;
	end
	return nil;
end

local function getProfileColor(profile)
	local characteristics = getProfileCharacteristics(profile);
	if characteristics and characteristics.CH and characteristics.CH ~= "" then
		return characteristics.CH;
	end
	return nil;
end

local RELATIONSHIP_NAME_STOPWORDS = {
	a = true,
	an = true,
	the = true,
	of = true,
	["and"] = true,
	["or"] = true,
	da = true,
	de = true,
	del = true,
	der = true,
	di = true,
	du = true,
	el = true,
	la = true,
	le = true,
	van = true,
	von = true,
};

local RELATIONSHIP_NAME_TITLE_WORDS = {
	archdruid = true,
	baron = true,
	baroness = true,
	captain = true,
	chief = true,
	commander = true,
	count = true,
	countess = true,
	doctor = true,
	dr = true,
	duchess = true,
	duke = true,
	elder = true,
	general = true,
	high = true,
	king = true,
	knight = true,
	lady = true,
	lord = true,
	madam = true,
	master = true,
	miss = true,
	mister = true,
	mr = true,
	mrs = true,
	ms = true,
	priest = true,
	priestess = true,
	prince = true,
	princess = true,
	professor = true,
	queen = true,
	ranger = true,
	saint = true,
	ser = true,
	sir = true,
};

local function sanitizeRelationshipName(name)
	name = strtrim(tostring(name or ""));
	if name == "" then
		return nil;
	end
	name = string.gsub(name, "%b()", " ");
	name = string.gsub(name, "%b[]", " ");
	name = string.gsub(name, "%b{}", " ");
	name = string.gsub(name, "%b<>", " ");
	name = string.gsub(name, "^%s*[%[%(%{<]+%s*", "");
	name = string.gsub(name, "%s*[%]%)}>,:;%.!%?]+%s*$", "");
	name = string.gsub(name, "%s+", " ");

	local words = {};
	for word in string.gmatch(name, "%S+") do
		tinsert(words, word);
	end
	local keptWords = {};
	for index, word in ipairs(words) do
		local cleanWord = string.lower(string.gsub(word, "[^%a']", ""));
		if index > 1 and (RELATIONSHIP_NAME_STOPWORDS[cleanWord] or RELATIONSHIP_NAME_TITLE_WORDS[cleanWord]) then
			break
		end
		tinsert(keptWords, word);
	end
	name = table.concat(keptWords, " ");
	name = strtrim(name);
	if name == "" then
		return nil;
	end
	local lowerName = string.lower(name);
	if RELATIONSHIP_NAME_STOPWORDS[lowerName] or RELATIONSHIP_NAME_TITLE_WORDS[lowerName] then
		return nil;
	end
	if not string.find(name, "%s") and string.len(name) < 3 then
		return nil;
	end
	return name;
end

local function addRelationshipName(names, seenNames, name)
	name = sanitizeRelationshipName(name);
	if not name then
		return;
	end
	local key = string.lower(name);
	if not seenNames[key] then
		seenNames[key] = true;
		tinsert(names, name);
	end
end

local function getProfileNames(profile)
	local names = {};
	local seenNames = {};
	local characteristics = getProfileCharacteristics(profile);
	if not characteristics then
		return names;
	end
	local firstName = strtrim(tostring(characteristics.FN or ""));
	local lastName = strtrim(tostring(characteristics.LN or ""));
	local fullName = strtrim(firstName .. " " .. lastName);
	if fullName ~= "" and fullName ~= firstName then
		addRelationshipName(names, seenNames, fullName);
	end
	if firstName ~= "" then
		addRelationshipName(names, seenNames, firstName);
	end
	if lastName ~= "" then
		addRelationshipName(names, seenNames, lastName);
	end
	return names;
end

local function escapePatternCharacter(character)
	if string.match(character, "[%^%$%(%)%%%.%[%]%*%+%-%?]") then
		return "%" .. character;
	end
	return character;
end

local function getNameMatchPattern(name)
	local pieces = {};
	for index = 1, string.len(name or "") do
		local character = string.sub(name, index, index);
		if string.match(character, "%a") then
			local lowerCharacter = string.lower(character);
			local upperCharacter = string.upper(character);
			if lowerCharacter ~= upperCharacter then
				tinsert(pieces, "[" .. escapePatternCharacter(lowerCharacter) .. escapePatternCharacter(upperCharacter) .. "]");
			else
				tinsert(pieces, escapePatternCharacter(character));
			end
		else
			tinsert(pieces, escapePatternCharacter(character));
		end
	end
	return "%f[%w]" .. table.concat(pieces, "") .. "%f[%W]";
end

local function getRelationshipNameEntries(languageName)
	local entries = {};
	local seenEntries = {};
	local function addEntry(name, color, isLanguage)
		name = sanitizeRelationshipName(name);
		if not name then
			return;
		end
		local key = string.lower(name);
		if not seenEntries[key] then
			seenEntries[key] = true;
			tinsert(entries, { name = name, color = color or "ffffff", isLanguage = isLanguage });
		end
	end
	if languageName and languageName ~= "" then
		addEntry(languageName, "ffffff", true);
	end
	if getConfigValue(CONFIG_RELATIONSHIP_NAMES) then
		local playerProfile = TRP3_API.profile and TRP3_API.profile.getPlayerCurrentProfile and TRP3_API.profile.getPlayerCurrentProfile();
		if playerProfile then
			local color = getProfileColor(playerProfile) or "ffffff";
			for _, name in pairs(getProfileNames(playerProfile)) do
				addEntry(name, color);
			end
		end
		addEntry(Globals.player, getProfileColor(playerProfile) or "ffffff");
		if TRP3_API.register and TRP3_API.register.relation then
			local relationNone = TRP3_API.register.relation.NONE or "NONE";
			local relationData = get("relation") or {};
			for profileID, relation in pairs(relationData) do
				if relation and relation ~= relationNone and TRP3_API.register.getProfile then
					local ok, profile = pcall(TRP3_API.register.getProfile, profileID);
					if ok and profile then
						local color = getProfileColor(profile) or "ffffff";
						for _, name in pairs(getProfileNames(profile)) do
							addEntry(name, color);
						end
					end
				end
			end
		end
	end
	table.sort(entries, function(left, right)
		return string.len(left.name or "") > string.len(right.name or "");
	end);
	return entries;
end

local function colorPatternOutsideSquareBrackets(text, pattern, color, resumeColor)
	local coloredText = tostring(text or "");
	local pieces = {};
	local position = 1;
	while position <= string.len(coloredText) do
		local bracketStart, bracketEnd = string.find(coloredText, "%b[]", position);
		local plainEnd = bracketStart and (bracketStart - 1) or string.len(coloredText);
		local plainText = string.sub(coloredText, position, plainEnd);
		plainText = string.gsub(plainText, pattern, function(match)
			return "|cff" .. color .. match .. "|r" .. (resumeColor or "");
		end);
		tinsert(pieces, plainText);
		if not bracketStart then
			break
		end
		tinsert(pieces, string.sub(coloredText, bracketStart, bracketEnd));
		position = bracketEnd + 1;
	end
	return table.concat(pieces, "");
end

local function protectRelationshipNames(text)
	local replacements = {};
	local protectedText = tostring(text or "");
	for _, entry in pairs(getRelationshipNameEntries()) do
		local name = entry.name;
		if name and name ~= "" then
			local pattern = getNameMatchPattern(name);
			protectedText = string.gsub(protectedText, pattern, function(match)
				local token = "\030" .. tostring(#replacements + 1) .. "\030";
				tinsert(replacements, { text = match, color = entry.color });
				return token;
			end);
		end
	end
	return protectedText, replacements;
end

local function restoreRelationshipNames(text, replacements, colorize)
	local restored = tostring(text or "");
	for index, replacement in pairs(replacements or {}) do
		local replacementText = replacement.text or "";
		if colorize and replacement.color and replacement.color ~= "" then
			replacementText = "|cff" .. replacement.color .. replacementText .. "|r";
		end
		restored = string.gsub(restored, "\030" .. tostring(index) .. "\030", replacementText);
	end
	return restored;
end

local function colorRelationshipNamesForDisplay(text, resumeColor, languageName)
	local coloredText = tostring(text or "");
	languageName = languageName or string.match(coloredText, "^%[([^%]]+)%]%s+");
	for _, entry in pairs(getRelationshipNameEntries(languageName)) do
		local name = entry.name;
		if name and name ~= "" and entry.color and entry.color ~= "" then
			local pattern = getNameMatchPattern(name);
			if entry.isLanguage then
				coloredText = colorPatternOutsideSquareBrackets(coloredText, pattern, entry.color, resumeColor);
			else
				coloredText = string.gsub(coloredText, pattern, function(match)
					return "|cff" .. entry.color .. match .. "|r" .. (resumeColor or "");
				end);
			end
		end
	end
	return coloredText;
end
API.colorRelationshipNamesForDisplay = colorRelationshipNamesForDisplay;

local function findNextRelationshipName(text, startPosition, entries)
	local nextStart, nextEnd, nextMatch;
	for _, entry in pairs(entries or {}) do
		local name = entry.name;
		if name and name ~= "" then
			local pattern = getNameMatchPattern(name);
			local matchStart, matchEnd = string.find(text, pattern, startPosition);
			if matchStart and (not nextStart or matchStart < nextStart or (matchStart == nextStart and matchEnd > nextEnd)) then
				nextStart = matchStart;
				nextEnd = matchEnd;
				nextMatch = string.sub(text, matchStart, matchEnd);
			end
		end
	end
	return nextStart, nextEnd, nextMatch;
end

local function translateTextChunk(text, languageName, fluency)
	if text == "" then
		return text;
	end
	if fluency < 100 then
		return partiallyTranslateText(text, languageName, fluency);
	end
	return Tongues:TranslateWord(text, languageName);
end

local function translateTextPreservingRelationshipNames(text, languageName, fluency)
	text = tostring(text or "");
	local entries = getRelationshipNameEntries(languageName);
	if #entries == 0 then
		return translateTextChunk(text, languageName, fluency);
	end

	local pieces = {};
	local position = 1;
	while position <= string.len(text) do
		local matchStart, matchEnd, matchText = findNextRelationshipName(text, position, entries);
		if not matchStart then
			local translatedChunk = translateTextChunk(string.sub(text, position), languageName, fluency);
			tinsert(pieces, translatedChunk);
			break
		end
		if matchStart > position then
			local translatedChunk = translateTextChunk(string.sub(text, position, matchStart - 1), languageName, fluency);
			tinsert(pieces, translatedChunk);
		end
		tinsert(pieces, matchText);
		position = matchEnd + 1;
	end
	return table.concat(pieces, "");
end

function Tongues:TranslateWord(text, languageName)
	if type(text) ~= "string" or not languageName or not self.Language or not self.Language[languageName] then
		return text;
	end

	local language = getUsableLanguageTable(languageName);
	if not language then
		return text;
	end

	local wordIndex = 0;
	local messageSeed = string.lower(text);
	return string.gsub(text, "[%a%!']+", function(word)
		wordIndex = wordIndex + 1;
		if string.sub(word, 1, 1) == "!" then
			return string.sub(word, 2);
		end

		if resolveLanguageName(languageName) == "Orcish" and string.lower(word) == "lol" then
			if string.upper(word) == word then
				return "KEK";
			elseif string.upper(string.sub(word, 1, 1)) == string.sub(word, 1, 1) then
				return "Kek";
			end
			return "kek";
		end

		if language.ignore then
			for _, ignoredWord in pairs(language.ignore) do
				if string.lower(ignoredWord) == string.lower(word) then
					return word;
				end
			end
		end

		if language.substitute then
			for source, replacement in pairs(language.substitute) do
				if string.lower(source) == string.lower(word) then
					return replacement;
				end
			end
		end

		local wordLength = string.len(word);
		if wordLength <= 0 then
			return word;
		end
		if wordLength > #language then
			wordLength = #language;
		end
		if not language[wordLength] or #language[wordLength] == 0 then
			return word;
		end

		local optionIndex = getTranslationOptionIndex(string.lower(word) .. "\031" .. tostring(languageName or "") .. "\031" .. messageSeed .. "\031" .. tostring(wordIndex), #language[wordLength]);
		local translated = language[wordLength][optionIndex] or word;
		local result = "";
		for index = 1, string.len(translated) do
			if string.match(string.sub(word, index, index), "%u") then
				result = result .. string.upper(string.sub(translated, index, index));
			else
				result = result .. string.sub(translated, index, index);
			end
		end
		return result;
	end);
end

partiallyTranslateText = function(text, languageName, understanding)
	understanding = math.max(0, math.min(100, math.floor(tonumber(understanding) or 0)));
	if understanding >= 100 then
		return text;
	end

	local translateChance = math.min(35, math.max(1, math.floor((100 - understanding) * 0.3)));
	return string.gsub(tostring(text or ""), "[%a%!']+", function(word)
		if (Tongues.Hash(string.lower(word)) % 100) < translateChance then
			return Tongues:TranslateWord(word, languageName);
		end
		return word;
	end);
end

local function isAliasLanguage(languageName)
	return type(Tongues.Language[languageName]) == "table" and Tongues.Language[languageName].alias ~= nil;
end

local function getLanguageList(includeAliases)
	local playerLanguageData = get("player/languages");
	if playerLanguageData and playerLanguageData.CL then
		Tongues.Custom.Language = Tongues.Custom.Language or {};
		for languageName, languageData in pairs(playerLanguageData.CL) do
			if type(languageData) == "table" then
				Tongues.Custom.Language[languageName] = languageData;
				Tongues.Language[languageName] = languageData;
			end
		end
	end
	local languages = {};
	for languageName, languageData in pairs(Tongues.Language or {}) do
		if type(languageData) == "table" and (includeAliases or not isAliasLanguage(languageName)) then
			tinsert(languages, languageName);
		end
	end
	table.sort(languages);
	return languages;
end
API.getLanguageList = getLanguageList;

local function getDropdownFromKeys(source, includeAliases)
	local values = {};
	for _, key in pairs(source) do
		tinsert(values, { key, key });
	end
	return values;
end

local function safeDropdownFromKeys(source, includeAliases)
	local ok, values = pcall(getDropdownFromKeys, source, includeAliases);
	if ok and type(values) == "table" then
		return values;
	end
	return {};
end

local function getKnownLanguageList()
	local data = ensureLanguageData();
	local languages = {};
	for languageName, fluency in pairs(data.FL or {}) do
		if (tonumber(fluency) or 0) >= 1 and Tongues.Language[languageName] and not isAliasLanguage(languageName) then
			tinsert(languages, languageName);
		end
	end
	table.sort(languages);
	return languages;
end

local function refreshKnownLanguageDropdown(values)
	for key in pairs(values) do
		values[key] = nil;
	end
	for _, languageName in pairs(getKnownLanguageList()) do
		tinsert(values, { languageName, languageName });
	end
end

local function ensureActiveLanguageIsKnown()
	local data = ensureLanguageData();
	local activeLanguage = getConfigValue(CONFIG_LANGUAGE);
	if (tonumber(data.FL[activeLanguage]) or 0) >= 1 then
		return;
	end
	local knownLanguages = getKnownLanguageList();
	if knownLanguages[1] then
		setConfigValue(CONFIG_LANGUAGE, knownLanguages[1]);
	end
end

local function mergeCustomTables()
	if API.customTablesMerged then
		return;
	end
	if Tongues.Custom then
		Tongues.Filter = merge({ Tongues.Filter or {}, Tongues.Custom.Filter or {} });
		Tongues.Affect = merge({ Tongues.Affect or {}, Tongues.Custom.Affect or {} });
		Tongues.Language = merge({ Tongues.Language or {}, Tongues.Custom.Language or {} });
		Tongues.Dialect = merge({ Tongues.Dialect or {}, Tongues.Custom.Dialect or {} });
	end
	API.customTablesMerged = true;
end

ensureLanguageData = function(profile)
	profile = profile or get("player");
	local data = profile and profile.languages;
	if not data then
		data = { v = 1, FL = {} };
		if profile then
			profile.languages = data;
		end
	end
	data.v = data.v or 1;
	data.FL = data.FL or {};
	data.UN = data.UN or {};
	for languageName, fluency in pairs(data.FL) do
		if data.UN[languageName] == nil then
			data.UN[languageName] = fluency;
		end
	end
	data.CL = data.CL or {};
	data.OR = data.OR or {};
	Tongues.Custom.Language = Tongues.Custom.Language or {};
	for languageName, languageData in pairs(data.CL) do
		if type(languageData) == "table" then
			Tongues.Custom.Language[languageName] = languageData;
			Tongues.Language[languageName] = languageData;
		end
	end
	return data;
end
API.ensureLanguageData = ensureLanguageData;

local function isNativeLanguage(languageName)
	return languageName == getDefaultNativeLanguage();
end
API.isNativeLanguage = isNativeLanguage;

local function createCustomLanguage(languageName, profile)
	languageName = strtrim(tostring(languageName or ""));
	if languageName == "" then
		return nil;
	end
	local data = ensureLanguageData(profile);
	local languageData = data.CL[languageName] or Tongues.Language[languageName];
	if type(languageData) ~= "table" then
		languageData = copyTable(Tongues.Language.Unknown or Tongues.Language.Common or {});
		languageData.Difficulty = languageData.Difficulty or { ["default"] = 1000 };
		data.CL[languageName] = languageData;
		Tongues.Custom.Language[languageName] = languageData;
		Tongues.Language[languageName] = languageData;
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
	end
	return languageName;
end
API.createCustomLanguage = createCustomLanguage;

local function getFluency(languageName, profile)
	if not profile and isNativeLanguage(languageName) then
		return 100;
	end
	local data = ensureLanguageData(profile);
	local fluency = data.FL[languageName];
	if fluency == nil then
		fluency = data.FL[resolveLanguageName(languageName)];
	end
	return tonumber(fluency) or 0;
end
API.getFluency = getFluency;

local function getUnderstanding(languageName, profile)
	if not profile and isNativeLanguage(languageName) then
		return 100;
	end
	local data = ensureLanguageData(profile);
	local resolvedLanguageName = resolveLanguageName(languageName);
	if data.UN[languageName] == nil and data.UN[resolvedLanguageName] == nil then
		data.UN[languageName] = data.FL[languageName];
	end
	local understanding = data.UN[languageName];
	if understanding == nil then
		understanding = data.UN[resolvedLanguageName] or data.FL[languageName] or data.FL[resolvedLanguageName];
	end
	return tonumber(understanding) or 0;
end
API.getUnderstanding = getUnderstanding;

local function copyTRPSettingsToStandalone()
	local settings = getStandaloneCharacterSettings();
	if not settings then
		return;
	end

	settings.Language = getActiveLanguage();
	settings.Dialect = getConfigValue(CONFIG_DIALECT);
	settings.Affect = getConfigValue(CONFIG_AFFECT);
	settings.AffectFrequency = getConfigValue(CONFIG_AFFECT_FREQUENCY);
	settings.Filter = getConfigValue(CONFIG_FILTER);
	settings.LanguageLearning = true;
	settings.ShapeshiftLanguage = getConfigValue(CONFIG_SHAPESHIFT_LANGUAGE);
	settings.DialectDrift = getConfigValue(CONFIG_DIALECT_DRIFT);
	settings.LoreCompatibility = getConfigValue(CONFIG_LORE_COMPATIBILITY);
	settings.Debugging = getConfigValue(CONFIG_DEBUGGING);
	settings.Faction = UnitFactionGroup("player");
	settings.Race = UnitRace("player");
	settings.Class = UnitClass("player");
	local languageData = ensureLanguageData();
	settings.Fluency = languageData.FL;
	settings.Understanding = languageData.UN;
	lastProfileFluencySignature = getFluencySignature(settings.Fluency) .. "#" .. getFluencySignature(settings.Understanding);
	settings.Translators = textToTranslators(getConfigValue(CONFIG_TRANSLATORS));

	for configKey, fieldName in pairs(TRANSLATION_CONFIG_TO_FIELD) do
		settings.Translations[fieldName] = getConfigValue(configKey);
	end
	for configKey, fieldName in pairs(SCREEN_CONFIG_TO_FIELD) do
		settings.Screen[fieldName] = getConfigValue(configKey);
	end

	lastStandaloneSignature = getStandaloneSignature();
end

local function onConfigChanged()
	if syncSuspended then
		return;
	end
	copyTRPSettingsToStandalone();
	if refreshTonguesSettings then
		refreshTonguesSettings();
	end
end

local function importStandaloneSettings(removeMissingFluencies)
	local settings = getStandaloneCharacterSettings();
	if not settings then
		return false;
	end

	local changedLanguages;
	local data = ensureLanguageData();

	syncSuspended = true;
	if settings.Language and Tongues.Language and Tongues.Language[settings.Language] then
		setConfigValue(CONFIG_LANGUAGE, settings.Language);
	end
	for configKey, fieldName in pairs(CONFIG_TO_TONGUES_FIELD) do
		if configKey ~= CONFIG_LANGUAGE and settings[fieldName] ~= nil then
			setConfigValue(configKey, settings[fieldName]);
		end
	end
	for configKey, fieldName in pairs(TRANSLATION_CONFIG_TO_FIELD) do
		if settings.Translations and settings.Translations[fieldName] ~= nil then
			setConfigValue(configKey, settings.Translations[fieldName]);
		end
	end
	for configKey, fieldName in pairs(SCREEN_CONFIG_TO_FIELD) do
		if settings.Screen and settings.Screen[fieldName] ~= nil then
			setConfigValue(configKey, settings.Screen[fieldName]);
		end
	end
	if settings.Translators then
		setConfigValue(CONFIG_TRANSLATORS, translatorsToText(settings.Translators));
	end
	syncSuspended = nil;

	for languageName, fluency in pairs(settings.Fluency or {}) do
		fluency = math.max(0, math.min(100, math.floor(tonumber(fluency) or 0)));
		if data.FL[languageName] ~= fluency then
			data.FL[languageName] = fluency;
			changedLanguages = true;
		end
		if data.UN[languageName] == nil then
			data.UN[languageName] = fluency;
			changedLanguages = true;
		end
	end
	for languageName, fluency in pairs(settings.Understanding or {}) do
		fluency = math.max(0, math.min(100, math.floor(tonumber(fluency) or 0)));
		if data.UN[languageName] ~= fluency then
			data.UN[languageName] = fluency;
			changedLanguages = true;
		end
	end
	if removeMissingFluencies then
		for languageName in pairs(data.FL) do
			if (settings.Fluency or {})[languageName] == nil then
				data.FL[languageName] = nil;
				data.UN[languageName] = nil;
				changedLanguages = true;
			end
		end
	end
	if changedLanguages then
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, TRP3_API.profile.getPlayerCurrentProfileID(), "languages");
	end
	local profileFluencySignature = getFluencySignature(data.FL) .. "#" .. getFluencySignature(data.UN);
	if removeMissingFluencies and profileFluencySignature ~= lastProfileFluencySignature and not changedLanguages then
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, TRP3_API.profile.getPlayerCurrentProfileID(), "languages");
	end
	lastProfileFluencySignature = profileFluencySignature;

	refreshTonguesSettings();
	lastStandaloneSignature = getStandaloneSignature();
	return changedLanguages;
end
API.importStandaloneSettings = importStandaloneSettings;

local function setFluency(languageName, value)
	local data = ensureLanguageData();
	value = math.max(0, math.min(100, math.floor(tonumber(value) or 0)));
	if data.FL[languageName] ~= value then
		data.FL[languageName] = value;
		copyTRPSettingsToStandalone();
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, TRP3_API.profile.getPlayerCurrentProfileID(), "languages");
	end
end
API.setFluency = setFluency;

local function setUnderstanding(languageName, value)
	local data = ensureLanguageData();
	value = math.max(0, math.min(100, math.floor(tonumber(value) or 0)));
	if data.UN[languageName] ~= value then
		data.UN[languageName] = value;
		copyTRPSettingsToStandalone();
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, TRP3_API.profile.getPlayerCurrentProfileID(), "languages");
	end
end
API.setUnderstanding = setUnderstanding;

local function syncKnownGameLanguages()
	local data = ensureLanguageData();
	local changed;
	for i = 1, GetNumLanguages() do
		local languageName = GetLanguageByIndex(i);
		if languageName and languageName ~= "" then
			if data.FL[languageName] == nil or (not isNativeLanguage(languageName) and data.FL[languageName] < 100) then
				data.FL[languageName] = 100;
				changed = true;
			end
			if data.UN[languageName] == nil or (not isNativeLanguage(languageName) and data.UN[languageName] < 100) then
				data.UN[languageName] = 100;
				changed = true;
			end
		end
	end
	if UnitFactionGroup("player") == "Alliance" then
		if data.FL.Common == nil then
			data.FL.Common = 100;
			changed = true;
		end
		if data.UN.Common == nil then
			data.UN.Common = 100;
			changed = true;
		end
	elseif UnitFactionGroup("player") == "Horde" then
		if data.FL.Orcish == nil then
			data.FL.Orcish = 100;
			changed = true;
		end
		if data.UN.Orcish == nil then
			data.UN.Orcish = 100;
			changed = true;
		end
	end
	if changed then
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
		copyTRPSettingsToStandalone();
	end
end
API.syncKnownGameLanguages = syncKnownGameLanguages;

local function chooseDefaultLanguage()
	return getDefaultNativeLanguage();
end

getActiveLanguage = function()
	local languageName = activeLanguageOverride or getConfigValue(CONFIG_LANGUAGE);
	if not Tongues.Language[languageName] and not isKnownBlizzardLanguage(languageName) then
		languageName = chooseDefaultLanguage();
	end
	return languageName;
end
API.getActiveLanguage = getActiveLanguage;

function API.setActiveLanguage(languageName)
	if languageName and (Tongues.Language[languageName] or isKnownBlizzardLanguage(languageName)) then
		activeLanguageOverride = languageName;
		if isKnownBlizzardLanguage(languageName) then
			selectedBlizzardLanguage = languageName;
		else
			selectedBlizzardLanguage = nil;
		end
		lastActiveLanguageChangeAt = GetTime and GetTime() or time();
		setConfigValue(CONFIG_LANGUAGE, languageName);
		copyTRPSettingsToStandalone();
		refreshTonguesSettings();
	end
end

local function getCurrentTonguesSettings()
	local translators = {};
	for translator in string.gmatch(tostring(getConfigValue(CONFIG_TRANSLATORS) or ""), "([^,]+)") do
		translator = string.gsub(translator, "^%s+", "");
		translator = string.gsub(translator, "%s+$", "");
		if translator ~= "" then
			tinsert(translators, translator);
		end
	end

	return {
		Language = getActiveLanguage(),
		Fluency = ensureLanguageData().FL,
		Understanding = ensureLanguageData().UN,
		Dialect = getConfigValue(CONFIG_DIALECT),
		Affect = getConfigValue(CONFIG_AFFECT),
		AffectFrequency = getConfigValue(CONFIG_AFFECT_FREQUENCY),
		Filter = getConfigValue(CONFIG_FILTER),
		Faction = UnitFactionGroup("player"),
		Race = UnitRace("player"),
		Class = UnitClass("player"),
		Debugging = getConfigValue(CONFIG_DEBUGGING),
		DialectDrift = getConfigValue(CONFIG_DIALECT_DRIFT),
		LanguageLearning = true,
		ShapeshiftLanguage = getConfigValue(CONFIG_SHAPESHIFT_LANGUAGE),
		LoreCompatibility = getConfigValue(CONFIG_LORE_COMPATIBILITY),
		Translations = {
			Self = getConfigValue(CONFIG_TRANSLATE_SELF),
			Targetted = getConfigValue(CONFIG_TRANSLATE_TARGETTED),
			Party = getConfigValue(CONFIG_TRANSLATE_PARTY),
			Guild = getConfigValue(CONFIG_TRANSLATE_GUILD),
			Officer = getConfigValue(CONFIG_TRANSLATE_OFFICER),
			Raid = getConfigValue(CONFIG_TRANSLATE_RAID),
			RaidAlert = getConfigValue(CONFIG_TRANSLATE_RAID_ALERT),
			Battleground = getConfigValue(CONFIG_TRANSLATE_BATTLEGROUND),
		},
		Screen = {
			Self = getConfigValue(CONFIG_SCREEN_SELF),
			Targetted = getConfigValue(CONFIG_SCREEN_TARGETTED),
			Party = getConfigValue(CONFIG_SCREEN_PARTY),
			Guild = getConfigValue(CONFIG_SCREEN_GUILD),
			Officer = getConfigValue(CONFIG_SCREEN_OFFICER),
			Raid = getConfigValue(CONFIG_SCREEN_RAID),
			RaidAlert = getConfigValue(CONFIG_SCREEN_RAID_ALERT),
			Battleground = getConfigValue(CONFIG_SCREEN_BATTLEGROUND),
		},
		Translators = translators,
	};
end

refreshTonguesSettings = function()
	Tongues.Settings = Tongues.Settings or {};
	local standaloneSettings = getStandaloneCharacterSettings();
	if standaloneSettings then
		copyTRPSettingsToStandalone();
		Tongues.Settings.Character = standaloneSettings;
	else
		Tongues.Settings.Character = getCurrentTonguesSettings();
	end
	Tongues.Settings.Character.Fluency = copyTable(Tongues.Settings.Character.Fluency or {});
	Tongues.Settings.Character.Understanding = copyTable(Tongues.Settings.Character.Understanding or {});
	Tongues.Settings.Character.Fluency[getDefaultNativeLanguage()] = 100;
	Tongues.Settings.Character.Understanding[getDefaultNativeLanguage()] = 100;
end
API.refreshSettings = refreshTonguesSettings;

local function translateOutgoingMessage(message, languageName)
	refreshTonguesSettings();
	local fluency = getFluency(languageName);
	if not languageName or not Tongues.Language[languageName] or fluency <= 0 then
		return message, nil;
	end
	if isKnownBlizzardLanguage(languageName) and languageName == chooseDefaultLanguage() then
		return message, nil;
	end
	local translated = translateTextPreservingRelationshipNames(message, languageName, fluency);
	return "[" .. languageName .. "] " .. translated, languageName;
end

local function isPlayerSender(sender)
	sender = tostring(sender or "");
	return sender == Globals.player or sender == Globals.player_id or sender:match("^[^-]+") == Globals.player;
end

local function getTimestamp()
	if GetTime then
		return GetTime();
	end
	return time();
end

local function getRequestKey(sender, languageName)
	local senderName = tostring(sender or ""):match("^[^-]+") or tostring(sender or "");
	return senderName .. "\031" .. tostring(languageName or "");
end

local function getMessageHash(message)
	return tostring(Tongues.Hash(tostring(message or "")));
end

local function getMessageRequestKey(sender, languageName, displayedMessageOrHash)
	return getRequestKey(sender, languageName) .. "\031" .. getMessageHash(displayedMessageOrHash);
end

local function getMessageRequestHashKey(sender, languageName, displayedMessageHash)
	return getRequestKey(sender, languageName) .. "\031" .. tostring(displayedMessageHash or "");
end

local function getOriginalMessageKey(languageName, translatedMessage)
	return tostring(languageName or "") .. "\031" .. getMessageHash(translatedMessage);
end

local function rememberOriginalMessage(languageName, originalText, translatedMessage, fluency)
	local entry = { language = languageName, text = originalText, translated = translatedMessage, fluency = fluency, time = getTimestamp() };
	lastOriginalMessage = entry;
	originalMessageHistory[getOriginalMessageKey(languageName, translatedMessage)] = entry;
	tinsert(originalMessageHistory, entry);
	while #originalMessageHistory > 25 do
		local removed = table.remove(originalMessageHistory, 1);
		if removed then
			originalMessageHistory[getOriginalMessageKey(removed.language, removed.translated)] = nil;
		end
	end
	return entry;
end

local function findOriginalMessage(languageName, translatedMessage)
	if translatedMessage and translatedMessage ~= "" then
		return originalMessageHistory[getOriginalMessageKey(languageName, translatedMessage)];
	end
	return lastOriginalMessage;
end

local function findOriginalMessageByHash(languageName, translatedMessageHash)
	local hash = tostring(translatedMessageHash or "");
	return originalMessageHistory[tostring(languageName or "") .. "\031" .. hash]
		or originalMessageHistory[tostring(resolveLanguageName(languageName) or "") .. "\031" .. hash];
end

local function rememberOriginalBroadcast(sender, languageName, translatedMessageHash, text, speakerFluency)
	local key = getMessageRequestHashKey(sender, languageName, translatedMessageHash);
	originalBroadcastCache[key] = {
		language = languageName,
		text = text,
		fluency = speakerFluency,
		hash = translatedMessageHash,
		time = getTimestamp(),
	};
	tinsert(originalBroadcastCache, key);
	while #originalBroadcastCache > 50 do
		local removedKey = table.remove(originalBroadcastCache, 1);
		if removedKey then
			originalBroadcastCache[removedKey] = nil;
		end
	end
	return key;
end

local function takeOriginalBroadcast(sender, languageName, translatedMessageHash)
	local key = getMessageRequestHashKey(sender, languageName, translatedMessageHash);
	local entry = originalBroadcastCache[key];
	if entry then
		originalBroadcastCache[key] = nil;
	end
	return entry;
end

local function addPendingFrame(request, chatFrame)
	chatFrame = chatFrame or DEFAULT_CHAT_FRAME;
	if not request.frames then
		request.frames = {};
	end
	for _, frame in pairs(request.frames) do
		if frame == chatFrame then
			return;
		end
	end
	tinsert(request.frames, chatFrame);
end

local function getSenderFirstName(sender)
	local unitID = tostring(sender or ""):match("^[^-]+") or tostring(sender or "");
	if unitID == "" then
		return tostring(sender or UNKNOWN);
	end

	local profile;
	if unitID == Globals.player_id then
		profile = TRP3_API.profile and TRP3_API.profile.getPlayerCurrentProfile and TRP3_API.profile.getPlayerCurrentProfile();
	elseif TRP3_API.register and TRP3_API.register.isUnitIDKnown and TRP3_API.register.isUnitIDKnown(unitID) then
		profile = TRP3_API.register.getUnitIDCurrentProfile and TRP3_API.register.getUnitIDCurrentProfile(unitID);
	end

	local firstName = profile and profile.characteristics and profile.characteristics.FN;
	if firstName and firstName ~= "" then
		if TRP3_API.register and TRP3_API.register.sanitizeDisplayName then
			firstName = TRP3_API.register.sanitizeDisplayName(firstName);
		end
		if firstName and firstName ~= "" then
			return firstName;
		end
	end

	return unitID;
end

local function emitEavesdropLine(sender, languageName, text, frames)
	local eavesdropColor = "|cff88c5ff";
	local senderName = getSenderFirstName(sender);
	local line = eavesdropColor .. "(" .. senderName .. ": " .. colorRelationshipNamesForDisplay(text, eavesdropColor, languageName) .. ")|r";
	if frames and #frames > 0 then
		for _, frame in pairs(frames) do
			if frame and frame.AddMessage then
				local key = tostring(sender) .. "\031" .. tostring(languageName) .. "\031" .. tostring(text);
				if frame.TRP3_TonguesLastEavesdropKey ~= key or (getTimestamp() - (frame.TRP3_TonguesLastEavesdropAt or 0)) > 0.5 then
					frame.TRP3_TonguesLastEavesdropKey = key;
					frame.TRP3_TonguesLastEavesdropAt = getTimestamp();
					frame:AddMessage(line);
				end
			end
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage(line);
	end
end

local function emitTranslationLine(sender, languageName, text, request)
	if request and request.renderCallbacks then
		local rendered = {};
		for _, callback in pairs(request.renderCallbacks) do
			if type(callback) == "function" and not rendered[callback] then
				rendered[callback] = true;
				callback(colorRelationshipNamesForDisplay(text, nil, languageName), languageName);
			end
		end
		return;
	end
	local line = "|cff88c5ff[" .. tostring(sender or UNKNOWN) .. "]:|r " .. colorRelationshipNamesForDisplay(text, nil, languageName);
	local frames = request and request.frames;
	if frames and #frames > 0 then
		for _, frame in pairs(frames) do
			if frame and frame.AddMessage then
				frame:AddMessage(line);
			end
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage(line);
	end
end

local function resolveDisplayMessage(message, sender, chatFrame, eventLanguage, renderCallback, eventName)
	if type(message) ~= "string" then
		return message;
	end
	local taggedLanguage = string.match(message, "^%[([^%]]+)%]%s+");
	if not taggedLanguage then
		return colorRelationshipNamesForDisplay(message, nil, eventLanguage);
	end
	local languageName = taggedLanguage;
	if not languageName or (not Tongues.Language[languageName] and not isKnownBlizzardLanguage(languageName)) then
		return colorRelationshipNamesForDisplay(message, nil, languageName);
	end
	if not isPlayerSender(sender) then
		if getUnderstanding(languageName) > 0 or getConfigValue(CONFIG_EAVESDROP_MODE) then
			requestOriginal(sender, languageName, chatFrame, eventName, renderCallback, message);
		end
		if getUnderstanding(languageName) > 0 then
			return "";
		end
		return colorRelationshipNamesForDisplay(message, nil, languageName);
	end
	local originalMessage = findOriginalMessage(languageName, message);
	if not originalMessage or languageName ~= originalMessage.language then
		return colorRelationshipNamesForDisplay(message, nil, languageName);
	end
	return colorRelationshipNamesForDisplay(originalMessage.text, nil, languageName), languageName;
end
API.resolveDisplayMessage = resolveDisplayMessage;

local CHAT_TYPE_DISABLE_CONFIG = {
	SAY = CONFIG_DISABLE_SAY,
	YELL = CONFIG_DISABLE_YELL,
	WHISPER = CONFIG_DISABLE_WHISPER,
	PARTY = CONFIG_DISABLE_PARTY,
	PARTY_LEADER = CONFIG_DISABLE_PARTY,
	GUILD = CONFIG_DISABLE_GUILD,
	OFFICER = CONFIG_DISABLE_OFFICER,
	RAID = CONFIG_DISABLE_RAID,
	RAID_LEADER = CONFIG_DISABLE_RAID,
	RAID_WARNING = CONFIG_DISABLE_RAID_WARNING,
	BATTLEGROUND = CONFIG_DISABLE_BATTLEGROUND,
	BATTLEGROUND_LEADER = CONFIG_DISABLE_BATTLEGROUND,
	CHANNEL = CONFIG_DISABLE_CHANNEL,
};

local CHAT_EVENT_DISABLE_CONFIG = {
	CHAT_MSG_SAY = CONFIG_DISABLE_SAY,
	CHAT_MSG_YELL = CONFIG_DISABLE_YELL,
	CHAT_MSG_WHISPER = CONFIG_DISABLE_WHISPER,
	CHAT_MSG_WHISPER_INFORM = CONFIG_DISABLE_WHISPER,
	CHAT_MSG_PARTY = CONFIG_DISABLE_PARTY,
	CHAT_MSG_PARTY_LEADER = CONFIG_DISABLE_PARTY,
	CHAT_MSG_GUILD = CONFIG_DISABLE_GUILD,
	CHAT_MSG_OFFICER = CONFIG_DISABLE_OFFICER,
	CHAT_MSG_RAID = CONFIG_DISABLE_RAID,
	CHAT_MSG_RAID_LEADER = CONFIG_DISABLE_RAID,
	CHAT_MSG_RAID_WARNING = CONFIG_DISABLE_RAID_WARNING,
	CHAT_MSG_BATTLEGROUND = CONFIG_DISABLE_BATTLEGROUND,
	CHAT_MSG_BATTLEGROUND_LEADER = CONFIG_DISABLE_BATTLEGROUND,
	CHAT_MSG_CHANNEL = CONFIG_DISABLE_CHANNEL,
};

local function normalizeChannelName(channelName)
	return string.lower(tostring(channelName or ""));
end

local function isXtensionTooltipChannelName(channelName)
	return string.find(normalizeChannelName(channelName), "xtensionxtooltip2", 1, true) ~= nil;
end

local function getChannelNameFromIdentifier(channel)
	if channel == nil then
		return nil;
	end
	if tonumber(channel) and GetChannelName then
		local _, channelName = GetChannelName(tonumber(channel));
		return channelName;
	end
	return tostring(channel);
end

local function isXtensionTooltipChannel(channel)
	return isXtensionTooltipChannelName(getChannelNameFromIdentifier(channel));
end

local function isDisabledChatType(chatType, channel)
	chatType = tostring(chatType or "SAY"):upper();
	if chatType == "CHANNEL" and isXtensionTooltipChannel(channel) then
		return true;
	end
	local configKey = CHAT_TYPE_DISABLE_CONFIG[chatType];
	return configKey and getConfigValue(configKey);
end

local function isDisabledChatEvent(eventName, channelName)
	if eventName == "CHAT_MSG_CHANNEL" and isXtensionTooltipChannelName(channelName) then
		return true;
	end
	local configKey = CHAT_EVENT_DISABLE_CONFIG[eventName];
	return configKey and getConfigValue(configKey);
end

local function isDisabledInBattleground()
	if not getConfigValue(CONFIG_DISABLE_IN_BATTLEGROUNDS) then
		return false;
	end
	if IsInInstance then
		local inInstance, instanceType = IsInInstance();
		if inInstance and (instanceType == "pvp" or instanceType == "arena") then
			return true;
		end
	end
	if UnitInBattleground and UnitInBattleground("player") then
		return true;
	end
	return false;
end

local function canTranslateChatType(chatType, channel)
	chatType = tostring(chatType or "SAY"):upper();
	if isDisabledInBattleground() then
		return false;
	end
	if isDisabledChatType(chatType, channel) then
		return false;
	end
	return chatType == "SAY" or chatType == "YELL" or chatType == "PARTY" or chatType == "PARTY_LEADER"
		or chatType == "GUILD" or chatType == "OFFICER" or chatType == "RAID" or chatType == "RAID_LEADER"
		or chatType == "RAID_WARNING" or chatType == "WHISPER" or chatType == "CHANNEL"
		or chatType == "BATTLEGROUND" or chatType == "BATTLEGROUND_LEADER";
end

isKnownBlizzardLanguage = function(languageName)
	if not languageName or not GetNumLanguages or not GetLanguageByIndex then
		return false;
	end
	for index = 1, GetNumLanguages() do
		local blizzardLanguage = GetLanguageByIndex(index);
		if blizzardLanguage == languageName then
			return true;
		end
	end
	return false;
end

local function getSafePassthroughLanguage(languageName)
	if isKnownBlizzardLanguage(languageName) then
		return languageName;
	end
	return nil;
end

local function getSelectedBlizzardLanguage()
	if isKnownBlizzardLanguage(selectedBlizzardLanguage) then
		return selectedBlizzardLanguage;
	end
	local activeLanguage = getActiveLanguage();
	if isKnownBlizzardLanguage(activeLanguage) then
		selectedBlizzardLanguage = activeLanguage;
		return activeLanguage;
	end
	for index = 1, 10 do
		local editBox = _G["ChatFrame" .. index .. "EditBox"];
		if editBox and isKnownBlizzardLanguage(editBox.language) then
			selectedBlizzardLanguage = editBox.language;
			return editBox.language;
		end
	end
	return nil;
end

local function getNativeChatLanguage()
	local nativeLanguage = chooseDefaultLanguage();
	if isKnownBlizzardLanguage(nativeLanguage) then
		return nativeLanguage;
	end
	return nil;
end

local function sendTonguesAddonMessage(target, payload)
	if target and target ~= "" and payload and payload ~= "" then
		pcall(SendAddonMessage, ADDON_PREFIX, payload, "WHISPER", target);
	end
end

local function sendTonguesAddonDistribution(distribution, target, payload)
	if not distribution or distribution == "" or not payload or payload == "" then
		return;
	end
	if target and target ~= "" then
		pcall(SendAddonMessage, ADDON_PREFIX, payload, distribution, target);
	else
		pcall(SendAddonMessage, ADDON_PREFIX, payload, distribution);
	end
end

local function getBroadcastDistribution(chatType, channel)
	chatType = tostring(chatType or ""):upper();
	if chatType == "GUILD" or chatType == "OFFICER" then
		return "GUILD";
	elseif chatType == "PARTY" or chatType == "PARTY_LEADER" then
		return "PARTY";
	elseif chatType == "RAID" or chatType == "RAID_LEADER" or chatType == "RAID_WARNING" then
		return "RAID";
	elseif chatType == "BATTLEGROUND" or chatType == "BATTLEGROUND_LEADER" then
		return "BATTLEGROUND";
	elseif chatType == "CHANNEL" and channel then
		return "CHANNEL", channel;
	elseif chatType == "WHISPER" and channel then
		return "WHISPER", channel;
	end
end

local function handleOriginalResponse(sender, languageName, text, speakerFluency, requestMessageHash)
	languageName = strtrim(tostring(languageName or ""));
	local understanding = getUnderstanding(languageName);
	local speakerSkill = math.max(0, math.min(100, tonumber(speakerFluency) or 100));
	local requestKey = getMessageRequestHashKey(sender, languageName, requestMessageHash);
	local request = pendingOriginalRequests[requestKey];
	if not request then
		return;
	end
	if understanding <= 0 then
		if getConfigValue(CONFIG_EAVESDROP_MODE) then
			if speakerSkill < 100 or understanding < 100 then
				emitEavesdropLine(sender, languageName, text, request and request.frames);
			end
		end
		pendingOriginalRequests[requestKey] = nil;
		return;
	end
	local fluency = understanding;
	local shown = text;
	if fluency < 100 then
		shown = translateTextPreservingRelationshipNames(text, languageName, fluency);
	end
	emitTranslationLine(sender, languageName, shown, request);
	if getConfigValue(CONFIG_EAVESDROP_MODE) then
		if speakerSkill < 100 or understanding < 100 then
			emitEavesdropLine(sender, languageName, text, request and request.frames);
		end
	end
	pendingOriginalRequests[requestKey] = nil;
end

local function handleOriginalBroadcast(sender, languageName, text, speakerFluency, translatedMessageHash)
	local key = rememberOriginalBroadcast(sender, languageName, translatedMessageHash, text, speakerFluency);
	if pendingOriginalRequests[key] then
		handleOriginalResponse(sender, languageName, text, speakerFluency, translatedMessageHash);
	end
end

local function sendChunkedOriginalResponse(target, originalMessage, responseLanguage)
	local translatedHash = getMessageHash(originalMessage.translated);
	local header = "RSPC" .. MESSAGE_SEP .. tostring(responseLanguage or originalMessage.language) .. MESSAGE_SEP .. tostring(originalMessage.fluency or 100) .. MESSAGE_SEP .. translatedHash .. MESSAGE_SEP;
	local maxChunkLength = math.max(40, 240 - string.len(header) - 8);
	local total = math.max(1, math.ceil(string.len(originalMessage.text or "") / maxChunkLength));
	for part = 1, total do
		local chunk = string.sub(originalMessage.text or "", ((part - 1) * maxChunkLength) + 1, part * maxChunkLength);
		sendTonguesAddonMessage(target, header .. tostring(part) .. MESSAGE_SEP .. tostring(total) .. MESSAGE_SEP .. chunk);
	end
end

local function sendOriginalResponse(target, languageName, translatedMessageHash)
	if lastOriginalMessage and target and target ~= "" and not isDisabledInBattleground() then
		local originalMessage;
		if translatedMessageHash and translatedMessageHash ~= "" then
			originalMessage = findOriginalMessageByHash(languageName or lastOriginalMessage.language, translatedMessageHash);
		else
			originalMessage = lastOriginalMessage;
		end
		if not originalMessage then
			return;
		end
		local responseLanguage = languageName or originalMessage.language;
		local translatedHash = getMessageHash(originalMessage.translated);
		local payload = "RSP" .. MESSAGE_SEP .. tostring(responseLanguage) .. MESSAGE_SEP .. tostring(originalMessage.fluency or 100) .. MESSAGE_SEP .. translatedHash .. MESSAGE_SEP .. originalMessage.text;
		if string.len(payload) <= 240 then
			sendTonguesAddonMessage(target, payload);
		else
			sendChunkedOriginalResponse(target, originalMessage, responseLanguage);
		end
	end
end

local function sendOriginalBroadcast(languageName, originalText, translatedMessage, speakerFluency, chatType, channel)
	local distribution, target = getBroadcastDistribution(chatType, channel);
	if not distribution then
		return;
	end

	local translatedHash = getMessageHash(translatedMessage);
	local header = "BRC" .. MESSAGE_SEP .. tostring(languageName or "") .. MESSAGE_SEP .. tostring(speakerFluency or 100) .. MESSAGE_SEP .. translatedHash .. MESSAGE_SEP;
	local payload = header .. tostring(originalText or "");
	if string.len(payload) <= 240 then
		sendTonguesAddonDistribution(distribution, target, payload);
		return;
	end

	local maxChunkLength = math.max(40, 240 - string.len(header) - 8);
	local total = math.max(1, math.ceil(string.len(originalText or "") / maxChunkLength));
	for part = 1, total do
		local chunk = string.sub(originalText or "", ((part - 1) * maxChunkLength) + 1, part * maxChunkLength);
		sendTonguesAddonDistribution(distribution, target, header .. tostring(part) .. MESSAGE_SEP .. tostring(total) .. MESSAGE_SEP .. chunk);
	end
end

requestOriginal = function(sender, languageName, chatFrame, eventName, renderCallback, displayedMessage)
	if sender and sender ~= Globals.player and (getUnderstanding(languageName) > 0 or getConfigValue(CONFIG_EAVESDROP_MODE)) and not isDisabledInBattleground() then
		local displayedHash = getMessageHash(displayedMessage);
		local key = getMessageRequestKey(sender, languageName, displayedMessage);
		local request = pendingOriginalRequests[key] or {};
		addPendingFrame(request, chatFrame);
		if type(renderCallback) == "function" then
			if not request.renderCallbacks then
				request.renderCallbacks = {};
			end
			tinsert(request.renderCallbacks, renderCallback);
		end
		request.eventName = eventName or request.eventName;
		request.sender = sender;
		pendingOriginalRequests[key] = request;
		local broadcast = takeOriginalBroadcast(sender, languageName, displayedHash);
		if broadcast then
			handleOriginalResponse(sender, languageName, broadcast.text, broadcast.fluency, displayedHash);
			return;
		end
		if not request.lastSentAt or (getTimestamp() - request.lastSentAt) > 1 then
			request.lastSentAt = getTimestamp();
			sendTonguesAddonMessage(sender, "REQ" .. MESSAGE_SEP .. languageName .. MESSAGE_SEP .. displayedHash);
		end
	end
end

local function onAddonMessage(prefix, message, channel, sender)
	if prefix ~= ADDON_PREFIX or sender == Globals.player or isDisabledInBattleground() then
		return;
	end
	local broadcastCommand, broadcastLanguage, broadcastFluency, broadcastHash, broadcastPart, broadcastTotal, broadcastText = string.match(message or "", "^(BRC)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031?(.*)$");
	if not broadcastCommand then
		broadcastCommand, broadcastLanguage, broadcastFluency, broadcastHash, broadcastText = string.match(message or "", "^(BRC)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031?(.*)$");
	end
	if broadcastCommand == "BRC" then
		if tonumber(broadcastPart) and tonumber(broadcastTotal) then
			local chunkKey = getMessageRequestHashKey(sender, broadcastLanguage, broadcastHash);
			local chunkState = pendingOriginalResponseChunks[chunkKey] or { parts = {}, received = 0, total = tonumber(broadcastTotal) or 0, fluency = broadcastFluency, broadcast = true };
			local partIndex = tonumber(broadcastPart) or 0;
			if partIndex > 0 and not chunkState.parts[partIndex] then
				chunkState.parts[partIndex] = broadcastText or "";
				chunkState.received = chunkState.received + 1;
			end
			chunkState.total = tonumber(broadcastTotal) or chunkState.total;
			chunkState.fluency = broadcastFluency or chunkState.fluency;
			pendingOriginalResponseChunks[chunkKey] = chunkState;
			if chunkState.total > 0 and chunkState.received >= chunkState.total then
				local pieces = {};
				for index = 1, chunkState.total do
					tinsert(pieces, chunkState.parts[index] or "");
				end
				pendingOriginalResponseChunks[chunkKey] = nil;
				handleOriginalBroadcast(sender, broadcastLanguage, table.concat(pieces, ""), chunkState.fluency, broadcastHash);
			end
		else
			handleOriginalBroadcast(sender, broadcastLanguage, broadcastText, broadcastFluency, broadcastHash);
		end
		return;
	end
	local chunkCommand, chunkLanguage, chunkFluency, chunkHash, chunkPart, chunkTotal, chunkText = string.match(message or "", "^(RSPC)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031?(.*)$");
	if chunkCommand == "RSPC" then
		local chunkKey = getMessageRequestHashKey(sender, chunkLanguage, chunkHash);
		local chunkState = pendingOriginalResponseChunks[chunkKey] or { parts = {}, received = 0, total = tonumber(chunkTotal) or 0, fluency = chunkFluency };
		local partIndex = tonumber(chunkPart) or 0;
		if partIndex > 0 and not chunkState.parts[partIndex] then
			chunkState.parts[partIndex] = chunkText or "";
			chunkState.received = chunkState.received + 1;
		end
		chunkState.total = tonumber(chunkTotal) or chunkState.total;
		chunkState.fluency = chunkFluency or chunkState.fluency;
		pendingOriginalResponseChunks[chunkKey] = chunkState;
		if chunkState.total > 0 and chunkState.received >= chunkState.total then
			local pieces = {};
			for index = 1, chunkState.total do
				tinsert(pieces, chunkState.parts[index] or "");
			end
			pendingOriginalResponseChunks[chunkKey] = nil;
			handleOriginalResponse(sender, chunkLanguage, table.concat(pieces, ""), chunkState.fluency, chunkHash);
		end
		return;
	end
	local command, languageName, text, speakerFluency, requestMessage = string.match(message or "", "^([^\031]*)\031([^\031]*)\031([^\031]*)\031([^\031]*)\031?(.*)$");
	if not command then
		command, languageName, text, speakerFluency = string.match(message or "", "^([^\031]*)\031([^\031]*)\031([^\031]*)\031?(.*)$");
	end
	if not command then
		command, languageName = string.match(message or "", "^([^\031]*)\031([^\031]*)$");
	end
	if command == "REQ" then
		sendOriginalResponse(sender, languageName, text);
	elseif command == "RSP" and languageName and requestMessage and requestMessage ~= "" then
		handleOriginalResponse(sender, languageName, requestMessage, text, speakerFluency);
	end
end

local function incomingChatFilter(chatFrame, event, message, sender, languageNameFromEvent, channelName, ...)
	if type(message) ~= "string" or not getRegisteredConfigValue(CONFIG_ENABLED, true) or isDisabledInBattleground() or isDisabledChatEvent(event, channelName) then
		return false;
	end
	local languageName = strtrim(tostring(string.match(message, "^%[([^%]]+)%]%s+") or ""));
	if languageName and (Tongues.Language[languageName] or isKnownBlizzardLanguage(languageName)) and (getUnderstanding(languageName) > 0 or getConfigValue(CONFIG_EAVESDROP_MODE)) then
		requestOriginal(sender, languageName, chatFrame, event, nil, message);
	end
	return false;
end

local function installChatHooks()
	if API.chatHooksInstalled then
		return;
	end
	API.chatHooksInstalled = true;

	if TRP3_TonguesOriginalChatFrameMessageEventHandler then
		ChatFrame_MessageEventHandler = TRP3_TonguesOriginalChatFrameMessageEventHandler;
	end

	local function sendFinalChatMessage(message, chatType, language, channel, ...)
		local sendFunc = originalSendChatMessage;
		if IncognitoExtinguished and sendFunc == IncognitoExtinguished._sendWrapper
			and IncognitoExtinguished._sendOriginal
			and IncognitoExtinguished._sendOriginal ~= trp3SendChatMessageWrapper
			and IncognitoExtinguished._sendOriginal ~= sendFunc then
			sendFunc = IncognitoExtinguished._sendOriginal;
		end
		if sendingFinalChatMessage then
			return sendFunc(message, chatType, language, channel, ...);
		end
		if TRP3_API.incognito and TRP3_API.incognito.processOutgoingMessage then
			message = TRP3_API.incognito.processOutgoingMessage(message, chatType, channel);
		end
		sendingFinalChatMessage = true;
		local ok, result;
		if TRP3_API.chatSplitter and TRP3_API.chatSplitter.send then
			ok, result = pcall(TRP3_API.chatSplitter.send, sendFunc, message, chatType, language, channel, ...);
		else
			ok, result = pcall(sendFunc, message, chatType, language, channel, ...);
		end
		sendingFinalChatMessage = nil;
		if not ok then
			error(result);
		end
		return result;
	end

	trp3SendChatMessageWrapper = function(message, chatType, language, channel, ...)
		local canHandleChatType = getRegisteredConfigValue(CONFIG_ENABLED, true) and canTranslateChatType(chatType, channel);
		if canHandleChatType then
			local translatedMessage, translatedLanguage = translateOutgoingMessage(message, getActiveLanguage());
			if translatedLanguage then
				local fluency = getFluency(translatedLanguage);
				rememberOriginalMessage(translatedLanguage, message, translatedMessage, fluency);
				sendOriginalBroadcast(translatedLanguage, message, translatedMessage, fluency, chatType, channel);
				return sendFinalChatMessage(translatedMessage, chatType, nil, channel, ...);
			end
		end
		if not canHandleChatType then
			return sendFinalChatMessage(message, chatType, language, channel, ...);
		end
		local passthroughLanguage = getSelectedBlizzardLanguage() or getSafePassthroughLanguage(language);
		if passthroughLanguage then
			rememberOriginalMessage(passthroughLanguage, message, message, getFluency(passthroughLanguage));
		end
		return sendFinalChatMessage(message, chatType, passthroughLanguage, channel, ...);
	end
	SendChatMessage = trp3SendChatMessageWrapper;

	local events = {
		"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
		"CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
		"CHAT_MSG_RAID_WARNING", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_CHANNEL",
		"CHAT_MSG_BATTLEGROUND", "CHAT_MSG_BATTLEGROUND_LEADER"
	};
	for _, eventName in pairs(events) do
		ChatFrame_AddMessageEventFilter(eventName, incomingChatFilter);
	end

	if RegisterAddonMessagePrefix then
		RegisterAddonMessagePrefix(ADDON_PREFIX);
	end
	local frame = CreateFrame("Frame");
	frame:RegisterEvent("CHAT_MSG_ADDON");
	frame:SetScript("OnEvent", function(_, _, ...)
		onAddonMessage(...);
	end);
end

local function openLanguageDropdown(button)
	local values = {};
	for _, languageName in pairs(getLanguageList(false)) do
		tinsert(values, { languageName, languageName });
	end
	displayDropDown(button, values, function(value)
		API.setActiveLanguage(value);
	end, 0, true);
end

function API.openLanguageDropdown(button)
	openLanguageDropdown(button);
end

local function registerSyncHandlers()
	if syncHandlersRegistered then
		return;
	end
	syncHandlersRegistered = true;
	for configKey in pairs(CONFIG_TO_TONGUES_FIELD) do
		registerHandler(configKey, onConfigChanged);
	end
	for configKey in pairs(TRANSLATION_CONFIG_TO_FIELD) do
		registerHandler(configKey, onConfigChanged);
	end
	for configKey in pairs(SCREEN_CONFIG_TO_FIELD) do
		registerHandler(configKey, onConfigChanged);
	end
	registerHandler(CONFIG_TRANSLATORS, onConfigChanged);
end

local function installStandalonePolling()
	if API.standalonePollInstalled then
		return;
	end
	API.standalonePollInstalled = true;

	local elapsedTotal = 0;
	local frame = CreateFrame("Frame");
	frame:SetScript("OnUpdate", function(_, elapsed)
		elapsedTotal = elapsedTotal + (elapsed or 0);
		if elapsedTotal < 0.75 then
			return;
		end
		elapsedTotal = 0;
		local signature = getStandaloneSignature();
		if signature and lastStandaloneSignature and signature ~= lastStandaloneSignature and not syncSuspended then
			local now = GetTime and GetTime() or time();
			if not lastActiveLanguageChangeAt or (now - lastActiveLanguageChangeAt) > 2 then
				importStandaloneSettings(true);
			else
				lastStandaloneSignature = signature;
			end
		elseif signature and not lastStandaloneSignature then
			lastStandaloneSignature = signature;
		end
	end);
end

local function applyDisableChannelDefaults()
	if getConfigValue(CONFIG_DISABLE_DEFAULTS_APPLIED) then
		return;
	end
	setConfigValue(CONFIG_DISABLE_SAY, false);
	setConfigValue(CONFIG_DISABLE_YELL, false);
	setConfigValue(CONFIG_DISABLE_WHISPER, true);
	setConfigValue(CONFIG_DISABLE_PARTY, true);
	setConfigValue(CONFIG_DISABLE_GUILD, true);
	setConfigValue(CONFIG_DISABLE_OFFICER, true);
	setConfigValue(CONFIG_DISABLE_RAID, true);
	setConfigValue(CONFIG_DISABLE_RAID_WARNING, true);
	setConfigValue(CONFIG_DISABLE_BATTLEGROUND, true);
	setConfigValue(CONFIG_DISABLE_CHANNEL, true);
	setConfigValue(CONFIG_DISABLE_DEFAULTS_APPLIED, true);
end

local function applyYellDefaultEnabled()
	if getConfigValue(CONFIG_YELL_DEFAULT_ENABLED_APPLIED) then
		return;
	end
	setConfigValue(CONFIG_DISABLE_YELL, false);
	setConfigValue(CONFIG_YELL_DEFAULT_ENABLED_APPLIED, true);
end

local function applyEavesdropDefaultEnabled()
	if getConfigValue(CONFIG_EAVESDROP_DEFAULT_APPLIED) then
		return;
	end
	setConfigValue(CONFIG_EAVESDROP_MODE, true);
	setConfigValue(CONFIG_EAVESDROP_DEFAULT_APPLIED, true);
end

local function createConfigPage()
	registerTonguesConfigKeys();
	applyDisableChannelDefaults();
	applyYellDefaultEnabled();
	applyEavesdropDefaultEnabled();
	registerSyncHandlers();
	syncKnownGameLanguages();

	local dialects = safeDropdownFromKeys(API.getSortedKeys(Tongues.Dialect), true);
	local affects = safeDropdownFromKeys(API.getSortedKeys(Tongues.Affect), true);
	local filters = safeDropdownFromKeys(API.getSortedKeys(Tongues.Filter), true);
	local languages = {};
	refreshKnownLanguageDropdown(languages);
	ensureActiveLanguageIsKnown();
	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, _, dataType)
		if unitID == Globals.player_id and (not dataType or dataType == "languages") then
			refreshKnownLanguageDropdown(languages);
			ensureActiveLanguageIsKnown();
		end
	end);

	Config.registerConfigurationPage({
		id = "main_config_chatframe_tongues",
		menuText = "Tongues settings",
		pageText = "Tongues settings",
		elements = {
			{ inherit = "TRP3_ConfigH1", title = "Speak" },
			{ inherit = "TRP3_ConfigCheck", title = "Enable Tongues translation", configKey = CONFIG_ENABLED, help = "When enabled, chat you send in a selected profile language is translated before other players see it." },
			{ inherit = "TRP3_ConfigDropDown", title = "Language", listContent = languages, configKey = CONFIG_LANGUAGE, listCancel = true, help = "Choose the language your character is currently speaking. The Languages section of your profile controls how well you speak and understand each language." },
			{ inherit = "TRP3_ConfigDropDown", title = "Dialect", listContent = dialects, configKey = CONFIG_DIALECT, listCancel = true, help = "Adds an optional regional style to your spoken language. Choose <None> to speak the language normally." },
			{ inherit = "TRP3_ConfigCheck", title = "Dialect Drift", configKey = CONFIG_DIALECT_DRIFT, help = "Allows your dialect styling to vary slightly instead of always using the same pattern." },
			{ inherit = "TRP3_ConfigDropDown", title = "Affect", listContent = affects, configKey = CONFIG_AFFECT, listCancel = true, help = "Adds an optional speech effect, such as a voice style or speaking habit, on top of your language." },
			{ inherit = "TRP3_ConfigSlider", title = "Affect frequency", configKey = CONFIG_AFFECT_FREQUENCY, min = 0, max = 100, step = 1, integer = true, help = "Controls how often your selected affect appears. Lower values make it subtler." },
			{ inherit = "TRP3_ConfigDropDown", title = "Filter", listContent = filters, configKey = CONFIG_FILTER, listCancel = true, help = "Applies an optional final text style after language translation." },
			{ inherit = "TRP3_ConfigCheck", title = "Shapeshift Language", configKey = CONFIG_SHAPESHIFT_LANGUAGE, help = "Allows form-based language behavior when your character is shapeshifted." },
			{ inherit = "TRP3_ConfigCheck", title = "Lore Compatibility", configKey = CONFIG_LORE_COMPATIBILITY, help = "Keeps language choices closer to Warcraft lore expectations." },
			{ inherit = "TRP3_ConfigH1", title = "Disable in channels" },
			{ inherit = "TRP3_ConfigCheck", title = "Say", configKey = CONFIG_DISABLE_SAY },
			{ inherit = "TRP3_ConfigCheck", title = "Yell", configKey = CONFIG_DISABLE_YELL },
			{ inherit = "TRP3_ConfigCheck", title = "Whisper", configKey = CONFIG_DISABLE_WHISPER },
			{ inherit = "TRP3_ConfigCheck", title = "Party", configKey = CONFIG_DISABLE_PARTY },
			{ inherit = "TRP3_ConfigCheck", title = "Guild", configKey = CONFIG_DISABLE_GUILD },
			{ inherit = "TRP3_ConfigCheck", title = "Officer", configKey = CONFIG_DISABLE_OFFICER },
			{ inherit = "TRP3_ConfigCheck", title = "Raid", configKey = CONFIG_DISABLE_RAID },
			{ inherit = "TRP3_ConfigCheck", title = "Raid Warning", configKey = CONFIG_DISABLE_RAID_WARNING },
			{ inherit = "TRP3_ConfigCheck", title = "Battleground", configKey = CONFIG_DISABLE_BATTLEGROUND },
			{ inherit = "TRP3_ConfigCheck", title = "Custom Channels", configKey = CONFIG_DISABLE_CHANNEL },
			{ inherit = "TRP3_ConfigH1", title = "Advanced" },
			{ inherit = "TRP3_ConfigCheck", title = "Disable in battlegrounds", configKey = CONFIG_DISABLE_IN_BATTLEGROUNDS, help = "Turns off all Tongues translation while you are inside a battleground or arena." },
			{ inherit = "TRP3_ConfigCheck", title = "Eavesdrop mode", configKey = CONFIG_EAVESDROP_MODE, help = "Shows the plain message in parentheses when a language is spoken poorly or your character does not fully understand it." },
			{ inherit = "TRP3_ConfigCheck", title = "Highlight relationship names", configKey = CONFIG_RELATIONSHIP_NAMES, help = "Keeps names from your relationships readable in translated speech and colors them with their TRP profile color." },
			{ inherit = "TRP3_ConfigCheck", title = "Debugging", configKey = CONFIG_DEBUGGING },
			{ inherit = "TRP3_ConfigNote", title = "Add custom languages and adjust Speak or Understand values from your profile's You page, in the Languages section." },
		},
	});
end

function API.getSortedKeys(tableValue)
	local keys = {};
	for key in pairs(tableValue or {}) do
		tinsert(keys, key);
	end
	table.sort(keys);
	return keys;
end

pcall(mergeCustomTables);

local function reportStartupError(stepName, errorMessage)
	if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
		DEFAULT_CHAT_FRAME:AddMessage("|cffff5555TRP3 Tongues failed during " .. tostring(stepName) .. ": " .. tostring(errorMessage) .. "|r");
	end
end

local function runStartupStep(stepName, callback)
	local ok, errorMessage = pcall(callback);
	if not ok then
		reportStartupError(stepName, errorMessage);
	end
	return ok;
end

local function onStart()
	runStartupStep("mergeCustomTables", mergeCustomTables);
	runStartupStep("createConfigPage", createConfigPage);
	runStartupStep("importStandaloneSettings", function() importStandaloneSettings(false); end);
	runStartupStep("syncKnownGameLanguages", syncKnownGameLanguages);
	runStartupStep("refreshTonguesSettings", refreshTonguesSettings);
	runStartupStep("installChatHooks", installChatHooks);
	runStartupStep("installStandalonePolling", installStandalonePolling);
end

TRP3_API.module.registerModule({
	["name"] = "Tongues",
	["description"] = "Custom languages, language fluency, and automatic translated speech.",
	["version"] = 1.000,
	["id"] = "trp3_tongues",
	["onStart"] = onStart,
	["minVersion"] = 3,
});
