-- Preserve Blizzard chat functions if the standalone Tongues addon is still enabled.
if Tongues and Tongues.Hooks then
	TRP3_TonguesOriginalSendChatMessage = Tongues.Hooks.Send or SendChatMessage;
	TRP3_TonguesOriginalChatFrameMessageEventHandler = Tongues.Hooks.Receive or ChatFrame_MessageEventHandler;
else
	TRP3_TonguesOriginalSendChatMessage = SendChatMessage;
	TRP3_TonguesOriginalChatFrameMessageEventHandler = ChatFrame_MessageEventHandler;
end
