----------------------------------------------------------------------------------
-- Total RP 3
-- Directory
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- imports
local Globals, Events = TRP3_API.globals, TRP3_API.events;
local Utils = TRP3_API.utils;
local stEtN = Utils.str.emptyToNil;
local loc = TRP3_API.locale.getText;
local get = TRP3_API.profile.getData;
local assert, table, _G, date, pairs, error, tinsert, wipe, time = assert, table, _G, date, pairs, error, tinsert, wipe, time;
local isUnitIDKnown, getCharacterList = TRP3_API.register.isUnitIDKnown, TRP3_API.register.getCharacterList;
local unitIDToInfo, tsize = Utils.str.unitIDToInfo, Utils.table.size;
local handleMouseWheel = TRP3_API.ui.list.handleMouseWheel;
local initList = TRP3_API.ui.list.initList;
local getClassTexture = TRP3_API.ui.misc.getClassTexture;
local setTooltipForSameFrame = TRP3_API.ui.tooltip.setTooltipForSameFrame;
local isMenuRegistered = TRP3_API.navigation.menu.isMenuRegistered;
local registerMenu, selectMenu, openMainFrame = TRP3_API.navigation.menu.registerMenu, TRP3_API.navigation.menu.selectMenu, TRP3_API.navigation.openMainFrame;
local registerPage, setPage = TRP3_API.navigation.page.registerPage, TRP3_API.navigation.page.setPage;
local setupFieldSet = TRP3_API.ui.frame.setupFieldPanel;
local getUnitIDCharacter = TRP3_API.register.getUnitIDCharacter;
local getUnitIDProfile = TRP3_API.register.getUnitIDProfile;
local hasProfile = TRP3_API.register.hasProfile;
local getCompleteName, getPlayerCompleteName = TRP3_API.register.getCompleteName, TRP3_API.register.getPlayerCompleteName;
local TRP3_RegisterListEmpty = TRP3_RegisterListEmpty;
local getProfile, getProfileList = TRP3_API.register.getProfile, TRP3_API.register.getProfileList;
local getIgnoredList, unignoreID, isIDIgnored = TRP3_API.register.getIgnoredList, TRP3_API.register.unignoreID, TRP3_API.register.isIDIgnored;
local getRelationText, getRelationTooltipText = TRP3_API.register.relation.getRelationText, TRP3_API.register.relation.getRelationTooltipText;
local unregisterMenu = TRP3_API.navigation.menu.unregisterMenu;
local displayDropDown, showAlertPopup, showConfirmPopup = TRP3_API.ui.listbox.displayDropDown, TRP3_API.popup.showAlertPopup, TRP3_API.popup.showConfirmPopup;
local showTextInputPopup = TRP3_API.popup.showTextInputPopup;
local deleteProfile, deleteCharacter, getProfileList = TRP3_API.register.deleteProfile, TRP3_API.register.deleteCharacter, TRP3_API.register.getProfileList;
local toast = TRP3_API.ui.tooltip.toast;
local ignoreID = TRP3_API.register.ignoreID;
local refreshList;
local NOTIFICATION_ID_NEW_CHARACTER = TRP3_API.register.NOTIFICATION_ID_NEW_CHARACTER;
local getCurrentPageID = TRP3_API.navigation.page.getCurrentPageID;
local checkGlanceActivation = TRP3_API.register.checkGlanceActivation;
local getRelationColors = TRP3_API.register.relation.getRelationColors;
local safeMatch = TRP3_API.utils.str.safeMatch;
local getUnitIDDirectoryLite = TRP3_API.register.getUnitIDDirectoryLite;
local getConfigValue, setConfigValue, registerConfigKey, registerConfigHandler = TRP3_API.configuration.getValue, TRP3_API.configuration.setValue, TRP3_API.configuration.registerConfigKey, TRP3_API.configuration.registerHandler;
local pendingProfileOpen = {};

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Logic
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local REGISTER_LIST_PAGEID = "register_list";
local playerMenu = "main_10_player";
local currentlyOpenedProfilePrefix = TRP3_API.register.MENU_LIST_ID_TAB;
local REGISTER_PAGE = TRP3_API.register.MENU_LIST_ID;

local function openPage(profileID)
	local profile = getProfile(profileID);
	local linkedUnitID;
	if profile and profile.link then
		for unitID in pairs(profile.link) do
			linkedUnitID = unitID;
			break;
		end
	end
	if isMenuRegistered(currentlyOpenedProfilePrefix .. profileID) then
		-- If the character already has his "tab", simply open it
		selectMenu(currentlyOpenedProfilePrefix .. profileID);
	else
		-- Else, create a new menu entry and open it.
		local tabText = UNKNOWN;
		if profile.characteristics and profile.characteristics.FN then
			tabText = profile.characteristics.FN;
		elseif profile.link then
			for unitID, _ in pairs(profile.link) do
				if type(unitID) == "string" and isUnitIDKnown(unitID) then
					local liteInfo = getUnitIDDirectoryLite and getUnitIDDirectoryLite(unitID);
					local liteName = TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(liteInfo and liteInfo.name);
					if liteName then
						tabText = liteName;
						break
					end
				end
			end
		end
		registerMenu({
			id = currentlyOpenedProfilePrefix .. profileID,
			text = tabText,
			onSelected = function() setPage("player_main", {
				profile = profile,
				profileID = profileID,
				unitID = linkedUnitID,
			}) end,
			isChildOf = REGISTER_PAGE,
			closeable = true,
			icon = "Interface\\ICONS\\pet_type_humanoid",
		});
		selectMenu(currentlyOpenedProfilePrefix .. profileID);
	end
end

local function openPageByUnitID(unitID)
	if unitID == Globals.player_id then
		selectMenu(playerMenu);
	elseif isUnitIDKnown(unitID) and hasProfile(unitID) then
		local profile = getUnitIDProfile(unitID);
		if profile and profile.characteristics and profile.characteristics.FN then
			openPage(hasProfile(unitID));
		else
			pendingProfileOpen[unitID] = true;
			if TRP3_API.r and TRP3_API.r.sendQuery then
				TRP3_API.r.sendQuery(unitID);
				toast("Requesting profile for " .. tostring(unitID) .. "...", 3);
			end
		end
	elseif unitID and unitID ~= "" then
		pendingProfileOpen[unitID] = true;
		if TRP3_API.r and TRP3_API.r.sendQuery then
			TRP3_API.r.sendQuery(unitID);
			toast("Requesting profile for " .. tostring(unitID) .. "...", 3);
		end
	end
end
TRP3_API.register.openPageByUnitID = openPageByUnitID;

local ONLINE_ICON_TEXTURE = "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconIC.blp";
local OFFLINE_ICON_TEXTURE = "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconOOC.blp";
local TOTALRP3_ICON_TEXTURE = "Interface\\RaidFrame\\ReadyCheck-NotReady";
local CONFIG_SHOW_OFFLINE = "register_list_show_offline";
local CONFIG_HIDE_NSFW = "tooltip_char_hide_nsfw";

local PRESENCE_ONLINE = "Online";
local PRESENCE_OFFLINE = "Offline";
local PRESENCE_TOTALRP3 = "TotalRP3";

local function isHeartbeatOnlineNow(unitID)
	local checker = TRP3_API.map and TRP3_API.map.isHeartbeatOnline;
	return type(checker) == "function" and checker(unitID) or false;
end

local function hasHeartbeatHistory(character)
	return type(character) == "table"
		and (
			type(character.heartbeatAt) == "number"
			or (character.heartbeatName and character.heartbeatName ~= "")
			or (character.heartbeatVersion and character.heartbeatVersion ~= "")
			or (character.heartbeatColor and character.heartbeatColor ~= "")
			or (character.heartbeatIcon and character.heartbeatIcon ~= "")
			or (character.heartbeatFaction and character.heartbeatFaction ~= "")
			or (character.heartbeatInstance and character.heartbeatInstance ~= "")
		);
end

local function getPresenceData(unitID)
	if isHeartbeatOnlineNow(unitID) then
		return ONLINE_ICON_TEXTURE, PRESENCE_ONLINE;
	end
	if unitID and isUnitIDKnown(unitID) then
		local character = getUnitIDCharacter(unitID);
		if hasHeartbeatHistory(character) or (character and character.client == "TranquilRP3") then
			return OFFLINE_ICON_TEXTURE, PRESENCE_OFFLINE;
		end
		if character and character.client == "TotalRP3" and character.clientVersion and character.clientVersion ~= "" then
			return TOTALRP3_ICON_TEXTURE, PRESENCE_TOTALRP3;
		end
	end
	return OFFLINE_ICON_TEXTURE, PRESENCE_OFFLINE;
end

local function getPresenceRank(presenceText)
	if presenceText == PRESENCE_ONLINE then
		return 0;
	end
	return 1;
end

local function shouldHideNSFWProfile(profile)
	return getConfigValue(CONFIG_HIDE_NSFW) and profile and profile.character and profile.character.NSFW;
end

local function getBestPresenceForProfile(profile)
	local bestTexture, bestText = OFFLINE_ICON_TEXTURE, PRESENCE_OFFLINE;
	local bestRank = 99;

	for linkedUnitID, _ in pairs(profile.link or Globals.empty) do
		if type(linkedUnitID) ~= "string" or not isUnitIDKnown(linkedUnitID) then
			-- skip malformed legacy links
		else
		local linkedPresenceTexture, linkedPresenceText = getPresenceData(linkedUnitID);
		local linkedRank;
		if linkedPresenceText == PRESENCE_ONLINE then
			linkedRank = 0;
		elseif linkedPresenceText == PRESENCE_OFFLINE then
			linkedRank = 1;
		elseif linkedPresenceText == PRESENCE_TOTALRP3 then
			linkedRank = 2;
		else
			linkedRank = 3;
		end

		if linkedRank < bestRank then
			bestTexture = linkedPresenceTexture;
			bestText = linkedPresenceText;
			bestRank = linkedRank;
		end
		end
	end

	return bestTexture, bestText;
end


--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- UI
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local sortingType = 1;
local INFO_DISPLAY_RELATION = 1;
local INFO_DISPLAY_ZONE = 2;
local INFO_DISPLAY_GUILD = 3;
local currentInfoDisplay = INFO_DISPLAY_RELATION;

local function switchNameSorting()
	sortingType = sortingType == 2 and 1 or 2;
	refreshList();
end

local function switchInfoSorting()
	sortingType = sortingType == 4 and 3 or 4;
	refreshList();
end

local function switchCharacterSorting()
	sortingType = sortingType == 6 and 5 or 6;
	refreshList();
end

local function normalizeSortValue(value)
	return tostring(value or ""):lower();
end

local function nameComparator(elem1, elem2)
	local rank1 = elem1.sortPresenceRank or 1;
	local rank2 = elem2.sortPresenceRank or 1;
	if rank1 ~= rank2 then
		return rank1 < rank2;
	end
	return normalizeSortValue(elem1.sortName) < normalizeSortValue(elem2.sortName);
end

local function nameComparatorInverted(elem1, elem2)
	local rank1 = elem1.sortPresenceRank or 1;
	local rank2 = elem2.sortPresenceRank or 1;
	if rank1 ~= rank2 then
		return rank1 < rank2;
	end
	return normalizeSortValue(elem1.sortName) > normalizeSortValue(elem2.sortName);
end

local function infoComparator(elem1, elem2)
	return normalizeSortValue(elem1.sortRelation or elem1.sortInfo) < normalizeSortValue(elem2.sortRelation or elem2.sortInfo);
end

local function infoComparatorInverted(elem1, elem2)
	return normalizeSortValue(elem1.sortRelation or elem1.sortInfo) > normalizeSortValue(elem2.sortRelation or elem2.sortInfo);
end

local function characterComparator(elem1, elem2)
	return normalizeSortValue(elem1.sortCharacterName) < normalizeSortValue(elem2.sortCharacterName);
end

local function characterComparatorInverted(elem1, elem2)
	return normalizeSortValue(elem1.sortCharacterName) > normalizeSortValue(elem2.sortCharacterName);
end

local comparators = {
	nameComparator, nameComparatorInverted, infoComparator, infoComparatorInverted, characterComparator, characterComparatorInverted
}

local function getCurrentComparator()
	return comparators[sortingType];
end

local ARROW_DOWN = "Interface\\Buttons\\Arrow-Down-Up";
local ARROW_UP = "Interface\\Buttons\\Arrow-Up-Up";
local ARROW_SIZE = 15;

local function getCurrentInfoDisplayLabel()
	if currentInfoDisplay == INFO_DISPLAY_ZONE then
		return ZONE;
	elseif currentInfoDisplay == INFO_DISPLAY_GUILD then
		return GUILD;
	end
	return loc("REG_RELATION");
end

local function getComparatorArrows()
	local nameArrow, characterArrow, relationArrow = "", "", "";
	if sortingType == 1 then
		nameArrow = " |T" .. ARROW_DOWN .. ":" .. ARROW_SIZE .. "|t";
	elseif sortingType == 2 then
		nameArrow = " |T" .. ARROW_UP .. ":" .. ARROW_SIZE .. "|t";
	elseif sortingType == 3 then
		relationArrow = " |T" .. ARROW_DOWN .. ":" .. ARROW_SIZE .. "|t";
	elseif sortingType == 4 then
		relationArrow = " |T" .. ARROW_UP .. ":" .. ARROW_SIZE .. "|t";
	elseif sortingType == 5 then
		characterArrow = " |T" .. ARROW_DOWN .. ":" .. ARROW_SIZE .. "|t";
	elseif sortingType == 6 then
		characterArrow = " |T" .. ARROW_UP .. ":" .. ARROW_SIZE .. "|t";
	end
	return nameArrow, characterArrow, relationArrow;
end

local MODE_CHARACTER, MODE_IGNORE = 1, 3;
local selectedIDs = {};
local ICON_SIZE = 30;
local currentMode = 1;
local DATE_FORMAT = "%d/%m/%y %H:%M";
local IGNORED_ICON = Utils.str.texture("Interface\\Buttons\\UI-GroupLoot-Pass-Down", 15);
local GLANCE_ICON = Utils.str.texture("Interface\\MINIMAP\\TRACKING\\None", 15);
local NEW_ABOUT_ICON = Utils.str.texture("Interface\\Buttons\\UI-GuildButton-PublicNote-Up", 15);

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- UI : CHARACTERS
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
local characterLines = {};

local function getFirstKnownGuild(profile)
	for unitID, _ in pairs(profile.link or Globals.empty) do
		local character = type(unitID) == "string" and isUnitIDKnown(unitID) and getUnitIDCharacter(unitID) or nil;
		if character and character.guild and character.guild ~= "" then
			return character.guild;
		end
	end
	return "";
end

local function getKnownZone(profile)
	if profile.zone and profile.zone ~= "" then
		return profile.zone;
	end
	for unitID, _ in pairs(profile.link or Globals.empty) do
		local character = type(unitID) == "string" and isUnitIDKnown(unitID) and getUnitIDCharacter(unitID) or nil;
		if character and character.zone and character.zone ~= "" then
			return character.zone;
		end
	end
	return "";
end

local function getDisplayedInfoText(entry)
	if currentInfoDisplay == INFO_DISPLAY_ZONE then
		return entry.zoneText or "";
	elseif currentInfoDisplay == INFO_DISPLAY_GUILD then
		return entry.guildText or "";
	end
	return entry.relationText or "";
end

local function decorateCharacterLine(line, characterIndex)
	local entry = characterLines[characterIndex];
	line.entry = entry;
	line.id = entry and entry.profileID or entry and entry.unitID;

	local nameLabel = _G[line:GetName().."Name"];
	local infoLabel = _G[line:GetName().."Info"];
	local relationLabel = _G[line:GetName().."Info2"];
	local legacyInfo3Label = _G[line:GetName().."Info3"];
	local statusIcon = _G[line:GetName().."ClickFarRightStatusIcon"];
	local selectButton = _G[line:GetName().."Select"];

	if legacyInfo3Label then
		legacyInfo3Label:SetText("");
	end

	if entry.kind == "lite" then
		local liteInfo = entry.liteInfo or Globals.empty;
		local presenceTexture, presenceText = getPresenceData(entry.unitID);
		local displayName = entry.displayName or entry.unitID or UNKNOWN;
		local playerName = unitIDToInfo(entry.unitID) or entry.unitID or UNKNOWN;
		local zoneText = liteInfo.zone or UNKNOWN;
		local clientText = liteInfo.client or "TranquilRP3";
		local versionText = liteInfo.version or "";
		local tooltipTitle = displayName;
		local tooltipText = presenceText
			.. "\n|cff00ff00- " .. tostring(entry.unitID)
			.. "\n|r" .. zoneText;
		if versionText ~= "" then
			tooltipText = tooltipText .. "\n|cffffffff" .. clientText .. " v" .. versionText;
		end
		tooltipText = tooltipText .. "\n\n|cffffff00Click to request and open the full profile.";

		nameLabel:SetText(playerName);
		if liteInfo.colorCode and liteInfo.colorCode ~= "" then
			infoLabel:SetText("|cff" .. liteInfo.colorCode .. displayName .. "|r");
		else
			infoLabel:SetText(displayName);
		end
		relationLabel:SetText(getDisplayedInfoText(entry));
		statusIcon:SetTexture(presenceTexture);
		statusIcon:SetTexCoord(0.1, 0.9, 0.1, 0.9);
		statusIcon:Show();
		selectButton:SetChecked(false);
		selectButton:Hide();
		setTooltipForSameFrame(_G[line:GetName().."ClickMiddle"], "TOPLEFT", 0, 5, "Character", displayName);
		if currentInfoDisplay == INFO_DISPLAY_ZONE and liteInfo.zone and liteInfo.zone ~= "" then
			setTooltipForSameFrame(_G[line:GetName().."ClickRight"], "TOPLEFT", 0, 5, ZONE, liteInfo.zone);
		elseif currentInfoDisplay == INFO_DISPLAY_GUILD then
			setTooltipForSameFrame(_G[line:GetName().."ClickRight"]);
		else
			setTooltipForSameFrame(_G[line:GetName().."ClickRight"]);
		end
		setTooltipForSameFrame(_G[line:GetName().."ClickFarRight"], "TOPLEFT", 0, 5, "Status", presenceText);
		setTooltipForSameFrame(_G[line:GetName().."Click"], "TOPLEFT", 0, 5, tooltipTitle, tooltipText);
		return;
	end

	local profileID = entry.profileID;
	local profile = getProfile(profileID);

	local characterName = getCompleteName(profile.characteristics or {}, UNKNOWN, true);
	local coloredCharacterName = characterName;
	local leftTooltipTitle, leftTooltipText = characterName, "";
	if profile.characteristics and profile.characteristics.CH and profile.characteristics.CH ~= "" then
		coloredCharacterName = "|cff" .. profile.characteristics.CH .. characterName .. "|r";
	end

	nameLabel:SetText(entry.playerName or UNKNOWN);
	infoLabel:SetText(coloredCharacterName);
	if profile.characteristics and profile.characteristics.IC then
		leftTooltipTitle = Utils.str.icon(profile.characteristics.IC, ICON_SIZE) .. " " .. characterName;
	end

	local hasGlance = profile.misc and profile.misc.PE and checkGlanceActivation(profile.misc.PE);
	local hasNewAbout = profile.about and not profile.about.read;

	local atLeastOneIgnored = false;
	relationLabel:SetText("");
	statusIcon:Hide();
	if profile.link and tsize(profile.link) > 0 then
		leftTooltipText = leftTooltipText .. loc("REG_LIST_CHAR_TT_CHAR");
		for unitID, _ in pairs(profile.link) do
			if type(unitID) == "string" and isUnitIDKnown(unitID) then
			local unitName = unitIDToInfo(unitID);
			if isIDIgnored(unitID) then
				leftTooltipText = leftTooltipText .. "\n|cffff0000 - " .. unitName .. IGNORED_ICON .. " " .. loc("REG_LIST_CHAR_IGNORED");
				atLeastOneIgnored = true;
			else
				leftTooltipText = leftTooltipText .. "\n|cff00ff00 - " .. unitName;
			end
			end
		end
	else
		leftTooltipText = leftTooltipText .. "|cffffff00" .. loc("REG_LIST_CHAR_TT_CHAR_NO");
	end

	if profile.time and profile.zone then
		local formatDate = date(DATE_FORMAT, profile.time);
		leftTooltipText = leftTooltipText .. "\n|r" .. loc("REG_LIST_CHAR_TT_DATE"):format(formatDate, profile.zone);
	end

	local relation, relationRed, relationGreen, relationBlue = getRelationText(profileID), getRelationColors(profileID);
	local color = Utils.color.colorCode(relationRed * 255, relationGreen * 255, relationBlue * 255);
	if currentInfoDisplay == INFO_DISPLAY_RELATION and relation:len() > 0 then
		local relationTooltipTitle, relationTooltipText = relation, getRelationTooltipText(profileID, profile);
		setTooltipForSameFrame(_G[line:GetName().."ClickRight"], "TOPLEFT", 0, 5, relationTooltipTitle, color .. relationTooltipText);
	elseif currentInfoDisplay == INFO_DISPLAY_ZONE and entry.zoneText and entry.zoneText ~= "" then
		setTooltipForSameFrame(_G[line:GetName().."ClickRight"], "TOPLEFT", 0, 5, ZONE, entry.zoneText);
	elseif currentInfoDisplay == INFO_DISPLAY_GUILD and entry.guildText and entry.guildText ~= "" then
		setTooltipForSameFrame(_G[line:GetName().."ClickRight"], "TOPLEFT", 0, 5, GUILD, entry.guildText);
	else
		setTooltipForSameFrame(_G[line:GetName().."ClickRight"]);
	end
	if currentInfoDisplay == INFO_DISPLAY_RELATION and relation ~= "" then
		relationLabel:SetText(color .. relation);
	else
		relationLabel:SetText(getDisplayedInfoText(entry));
	end
	setTooltipForSameFrame(_G[line:GetName().."ClickMiddle"], "TOPLEFT", 0, 5, "Character", characterName);

	local statusTooltipText = entry.presenceTooltip or "Offline";
	if entry.presenceTexture then
		statusIcon:SetTexture(entry.presenceTexture);
		statusIcon:SetTexCoord(0.1, 0.9, 0.1, 0.9);
		statusIcon:Show();
		setTooltipForSameFrame(_G[line:GetName().."ClickFarRight"], "TOPLEFT", 0, 5, "Status", statusTooltipText);
	else
		setTooltipForSameFrame(_G[line:GetName().."ClickFarRight"]);
	end

	selectButton:SetChecked(selectedIDs[profileID]);
	selectButton:Show();

	setTooltipForSameFrame(_G[line:GetName().."Click"], "TOPLEFT", 0, 5, leftTooltipTitle, leftTooltipText .. "\n\n|cffffff00" .. loc("REG_LIST_CHAR_TT"));
end

local function getCharacterLines()
	local nameSearch = TRP3_RegisterListFilterCharactName:GetText():lower();
	local guildSearch = TRP3_RegisterListFilterCharactGuild:GetText():lower();
	local characterList = getCharacterList();
	local showOffline = getConfigValue(CONFIG_SHOW_OFFLINE);
	local fullSize = 0;
	local seenProfiles = {};
	wipe(characterLines);

	for unitID, character in pairs(characterList) do
		if not character.isCompanion and not isIDIgnored(unitID) then
			local profileID = hasProfile(unitID);
			if profileID and not seenProfiles[profileID] then
				seenProfiles[profileID] = true;

				local profile = getProfile(profileID);
				if not shouldHideNSFWProfile(profile) then
					fullSize = fullSize + 1;
					local nameIsConform, guildIsConform = false, false;
					local presenceIcon, presenceText = getBestPresenceForProfile(profile);
					local playerNames = {};
					for linkedUnitID, _ in pairs(profile.link or Globals.empty) do
						if type(linkedUnitID) == "string" and isUnitIDKnown(linkedUnitID) then
							local unitName = unitIDToInfo(linkedUnitID);
							if safeMatch(unitName:lower(), nameSearch) then
								nameIsConform = true;
							end
							tinsert(playerNames, unitName);
							local linkedCharacter = getUnitIDCharacter(linkedUnitID);
							if linkedCharacter.guild and safeMatch(linkedCharacter.guild:lower(), guildSearch) then
								guildIsConform = true;
							end
						end
					end
					table.sort(playerNames);
					local completeName = getCompleteName(profile.characteristics or {}, "", true);
					if not nameIsConform and safeMatch(completeName:lower(), nameSearch) then
						nameIsConform = true;
					end

					nameIsConform = nameIsConform or nameSearch:len() == 0;
					guildIsConform = guildIsConform or guildSearch:len() == 0;

					if nameIsConform and guildIsConform and (showOffline or presenceText == PRESENCE_ONLINE) then
						local relationText = getRelationText(profileID);
						local zoneText = getKnownZone(profile);
						local guildText = getFirstKnownGuild(profile);
						local characterSortName = completeName ~= "" and completeName or playerNames[1] or UNKNOWN;
						tinsert(characterLines, {
							kind = "profile",
							profileID = profileID,
							playerName = playerNames[1] or UNKNOWN,
							sortName = playerNames[1] or UNKNOWN,
							sortCharacterName = characterSortName,
							sortInfo = "",
							sortRelation = relationText,
							sortZone = zoneText,
							sortGuild = guildText,
							relationText = relationText,
							zoneText = zoneText,
							guildText = guildText,
							sortStatus = presenceText,
							sortPresenceRank = getPresenceRank(presenceText),
							presenceTexture = presenceIcon,
							presenceTooltip = presenceText,
						});
					end
				end
			elseif not profileID then
				local liteInfo = getUnitIDDirectoryLite and getUnitIDDirectoryLite(unitID);
				local liteName = TRP3_API.register.sanitizeDisplayName and TRP3_API.register.sanitizeDisplayName(liteInfo and liteInfo.name);
				if liteInfo and liteName then
					fullSize = fullSize + 1;
					local presenceTexture, presenceText = getPresenceData(unitID);
					local nameIsConform = nameSearch:len() == 0
						or safeMatch(liteName:lower(), nameSearch)
						or safeMatch(tostring(unitID):lower(), nameSearch);
					local guildIsConform = guildSearch:len() == 0;
					if nameIsConform and guildIsConform and (showOffline or presenceText == PRESENCE_ONLINE) then
						tinsert(characterLines, {
							kind = "lite",
							unitID = unitID,
							liteInfo = liteInfo,
							displayName = liteName,
							sortName = unitIDToInfo(unitID) or unitID or UNKNOWN,
							sortCharacterName = liteName,
							sortInfo = "",
							sortRelation = "",
							sortZone = liteInfo.zone or "",
							sortGuild = "",
							relationText = "",
							zoneText = liteInfo.zone or "",
							guildText = "",
							sortStatus = presenceText,
							sortPresenceRank = getPresenceRank(presenceText),
							presenceTexture = presenceTexture,
							presenceTooltip = presenceText,
						});
					end
				end
			end
		end
	end

	for _, entry in pairs(characterLines) do
		if currentInfoDisplay == INFO_DISPLAY_ZONE then
			entry.sortInfo = entry.sortZone or "";
		elseif currentInfoDisplay == INFO_DISPLAY_GUILD then
			entry.sortInfo = entry.sortGuild or "";
		else
			entry.sortInfo = entry.sortRelation or "";
		end
	end

	table.sort(characterLines, getCurrentComparator());

	local lineSize = #characterLines;
	if lineSize == 0 then
		if fullSize == 0 then
			TRP3_RegisterListEmpty:SetText(loc("REG_LIST_CHAR_EMPTY"));
		else
			TRP3_RegisterListEmpty:SetText(loc("REG_LIST_CHAR_EMPTY2"));
		end
	end
	setupFieldSet(TRP3_RegisterListCharactFilter, loc("REG_LIST_CHAR_FILTER"):format(lineSize, fullSize), 200);

	local nameArrow, characterArrow, relationArrow = getComparatorArrows();
	TRP3_RegisterListHeaderName:SetText("Player" .. nameArrow);
	TRP3_RegisterListHeaderInfo:SetText("Character" .. characterArrow);
	TRP3_RegisterListHeaderInfo2:SetText(getCurrentInfoDisplayLabel() .. relationArrow);
	TRP3_RegisterListHeaderInfo3:SetText("Status");
	TRP3_RegisterListHeaderInfoTT:Enable();
	TRP3_RegisterListHeaderNameTT:Enable();
	TRP3_RegisterListHeaderInfo2TT:Enable();
	TRP3_RegisterListHeaderInfo3TT:Disable();
	TRP3_RegisterListHeaderActions:Show();

	return characterLines;
end

local MONTH_IN_SECONDS = 2592000;

local function onCharactersActionSelected(value, button)
	-- PURGES
	if value == "purge_time" then
		local profiles = getProfileList();
		local profilesToPurge = {};
		local charactersToPurge = TRP3_API.register.getLiteIDsToPurge(MONTH_IN_SECONDS);
		for profileID, profile in pairs(profiles) do
			if profile.time and time() - profile.time > MONTH_IN_SECONDS then
				tinsert(profilesToPurge, profileID);
			end
		end
		if #profilesToPurge + #charactersToPurge == 0 then
			showAlertPopup(loc("REG_LIST_ACTIONS_PURGE_TIME_C"):format(loc("REG_LIST_ACTIONS_PURGE_EMPTY")));
		else
			showConfirmPopup(loc("REG_LIST_ACTIONS_PURGE_TIME_C"):format(loc("REG_LIST_ACTIONS_PURGE_COUNT"):format(#profilesToPurge + #charactersToPurge)), function()
				for _, profileID in pairs(profilesToPurge) do
					deleteProfile(profileID, true);
				end
				for _, unitID in pairs(charactersToPurge) do
					deleteCharacter(unitID);
				end
				Events.fireEvent(Events.REGISTER_DATA_UPDATED);
				Events.fireEvent(Events.REGISTER_PROFILE_DELETED);
				refreshList();
			end);
		end
	elseif value == "purge_unlinked" then
		local profiles = getProfileList();
		local profilesToPurge = {};
		local charactersToPurge = TRP3_API.register.getLiteIDsToPurge();
		for profileID, profile in pairs(profiles) do
			if not profile.link or tsize(profile.link) == 0 then
				tinsert(profilesToPurge, profileID);
			end
		end
		if #profilesToPurge + #charactersToPurge == 0 then
			showAlertPopup(loc("REG_LIST_ACTIONS_PURGE_UNLINKED_C"):format(loc("REG_LIST_ACTIONS_PURGE_EMPTY")));
		else
			showConfirmPopup(loc("REG_LIST_ACTIONS_PURGE_UNLINKED_C"):format(loc("REG_LIST_ACTIONS_PURGE_COUNT"):format(#profilesToPurge + #charactersToPurge)), function()
				for _, profileID in pairs(profilesToPurge) do
					deleteProfile(profileID, true);
				end
				for _, unitID in pairs(charactersToPurge) do
					deleteCharacter(unitID);
				end
				Events.fireEvent(Events.REGISTER_DATA_UPDATED);
				Events.fireEvent(Events.REGISTER_PROFILE_DELETED);
				refreshList();
			end);
		end
	elseif value == "purge_ignore" then
		local profilesToPurge, characterToPurge = TRP3_API.register.getIDsToPurge();
		if #profilesToPurge + #characterToPurge == 0 then
			showAlertPopup(loc("REG_LIST_ACTIONS_PURGE_IGNORE_C"):format(loc("REG_LIST_ACTIONS_PURGE_EMPTY")));
		else
			showConfirmPopup(loc("REG_LIST_ACTIONS_PURGE_IGNORE_C"):format(loc("REG_LIST_ACTIONS_PURGE_COUNT"):format(#profilesToPurge + #characterToPurge)), function()
				for _, profileID in pairs(profilesToPurge) do
					deleteProfile(profileID);
				end
				for _, unitID in pairs(characterToPurge) do
					deleteCharacter(unitID);
				end
				refreshList();
			end);
		end
	elseif value == "purge_all" then
		local list = getProfileList();
		local charactersToPurge = TRP3_API.register.getLiteIDsToPurge();
		showConfirmPopup(loc("REG_LIST_ACTIONS_PURGE_ALL_C"):format(tsize(list) + #charactersToPurge), function()
			for profileID, _ in pairs(list) do
				deleteProfile(profileID, true);
			end
			for _, unitID in pairs(charactersToPurge) do
				deleteCharacter(unitID);
			end
			Events.fireEvent(Events.REGISTER_DATA_UPDATED);
			Events.fireEvent(Events.REGISTER_PROFILE_DELETED);
		end);
	-- Mass actions
	elseif value == "actions_delete" then
		showConfirmPopup(loc("REG_LIST_ACTIONS_MASS_REMOVE_C"):format(tsize(selectedIDs)), function()
			for profileID, _ in pairs(selectedIDs) do
				deleteProfile(profileID, true);
			end
			Events.fireEvent(Events.REGISTER_DATA_UPDATED);
			Events.fireEvent(Events.REGISTER_PROFILE_DELETED);
			refreshList();
		end);
	elseif value == "actions_ignore" then
		local charactToIgnore = {};
		for profileID, _ in pairs(selectedIDs) do
			for unitID, _ in pairs(getProfile(profileID).link or Globals.empty) do
				charactToIgnore[unitID] = true;
			end
		end
		showTextInputPopup(loc("REG_LIST_ACTIONS_MASS_IGNORE_C"):format(tsize(charactToIgnore)), function(text)
			for unitID, _ in pairs(charactToIgnore) do
				ignoreID(unitID, text);
			end
			refreshList();
		end);
	end
end

local function onCharactersActions(self)
	local values = {};
	tinsert(values, {loc("REG_LIST_ACTIONS_PURGE"), {
			{loc("REG_LIST_ACTIONS_PURGE_TIME"), "purge_time"},
			{loc("REG_LIST_ACTIONS_PURGE_UNLINKED"), "purge_unlinked"},
			{loc("REG_LIST_ACTIONS_PURGE_IGNORE"), "purge_ignore"},
			{loc("REG_LIST_ACTIONS_PURGE_ALL"), "purge_all"},
		}});
	if tsize(selectedIDs) > 0 then
		tinsert(values, {loc("REG_LIST_ACTIONS_MASS"):format(tsize(selectedIDs)), {
				{loc("REG_LIST_ACTIONS_MASS_REMOVE"), "actions_delete"},
				{loc("REG_LIST_ACTIONS_MASS_IGNORE"), "actions_ignore"},
			}});
	end
	displayDropDown(self, values, onCharactersActionSelected, 0, true);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- UI : IGNORED
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function decorateIgnoredLine(line, unitID)
	line.id = unitID;
	line.entry = nil;
	_G[line:GetName().."Name"]:SetText(unitID);
	_G[line:GetName().."Info"]:SetText("");
	_G[line:GetName().."Info2"]:SetText("");
	_G[line:GetName().."ClickFarRightStatusIcon"]:Hide();
	_G[line:GetName().."Select"]:Hide();
	setTooltipForSameFrame(_G[line:GetName().."Click"], "TOPLEFT", 0, 5, unitID, loc("REG_LIST_IGNORE_TT"):format(getIgnoredList()[unitID]));
	setTooltipForSameFrame(_G[line:GetName().."ClickMiddle"]);
	setTooltipForSameFrame(_G[line:GetName().."ClickRight"]);
	setTooltipForSameFrame(_G[line:GetName().."ClickFarRight"]);
end

local function getIgnoredLines()
	if tsize(getIgnoredList()) == 0 then
		TRP3_RegisterListEmpty:SetText(loc("REG_LIST_IGNORE_EMPTY"));
	end
	TRP3_RegisterListHeaderName:SetText("Player");
	TRP3_RegisterListHeaderInfo:SetText("Character");
	TRP3_RegisterListHeaderInfoTT:Disable();
	TRP3_RegisterListHeaderNameTT:Disable();
	TRP3_RegisterListHeaderInfo2TT:Disable();
	TRP3_RegisterListHeaderInfo3TT:Disable();
	TRP3_RegisterListHeaderInfo2:SetText("");
	TRP3_RegisterListHeaderInfo3:SetText("");

	return getIgnoredList();
end

local function onInfoHeaderClicked(self)
	local values = {
		{ loc("REG_RELATION"), INFO_DISPLAY_RELATION },
		{ ZONE, INFO_DISPLAY_ZONE },
		{ GUILD, INFO_DISPLAY_GUILD },
	};
	displayDropDown(self, values, function(value)
		currentInfoDisplay = value;
		refreshList();
	end, 0, true);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- UI : LIST
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

function refreshList()
	local lines;
	TRP3_RegisterListEmpty:Hide();
	TRP3_RegisterListHeaderActions:Hide();

	if currentMode == MODE_CHARACTER then
		lines = getCharacterLines();
		TRP3_RegisterList.decorate = decorateCharacterLine;
	elseif currentMode == MODE_IGNORE then
		lines = getIgnoredLines();
		TRP3_RegisterList.decorate = decorateIgnoredLine;
	end

	-- Ensure lines is not nil to prevent errors
	if not lines then
		lines = {};
	end

	if tsize(lines) == 0 then
		TRP3_RegisterListEmpty:Show();
	end
	initList(TRP3_RegisterList, lines, TRP3_RegisterListSlider);
end

local function onLineClicked(self, button)
	if currentMode == MODE_CHARACTER then
		local entry = self:GetParent().entry;
		assert(entry, "No directory entry on line.");
		if entry.kind == "lite" then
			openPageByUnitID(entry.unitID);
		else
			assert(entry.profileID, "No profileID on line.");
			openPage(entry.profileID);
		end
	elseif currentMode == MODE_IGNORE then
		assert(self:GetParent().id, "No unitID on line.");
		unignoreID(self:GetParent().id);
		refreshList();
	end
end

local function onLineSelected(self, button)
	assert(self:GetParent().id, "No id on line.");
	if self:GetParent().entry and self:GetParent().entry.kind ~= "profile" then
		self:SetChecked(false);
		return;
	end
	local rawValue = self:GetChecked();
	-- 3.3.5 compatibility
	selectedIDs[self:GetParent().id] = rawValue == 1 or rawValue == true;
end

local function changeMode(tabWidget, value)
	currentMode = value;
	wipe(selectedIDs);
	TRP3_RegisterListCharactFilter:Hide();
	if currentMode == MODE_CHARACTER then
		TRP3_RegisterListCharactFilter:Show();
	end
	refreshList();
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Init
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local tabGroup;
local listRefreshTicker;

local function createTabBar()
	local frame = CreateFrame("Frame", "TRP3_RegisterMainTabBar", TRP3_RegisterList);
	frame:SetSize(400, 30);
	frame:SetPoint("TOPLEFT", 17, -5);
	frame:SetFrameLevel(0);
	tabGroup = TRP3_API.ui.frame.createTabPanel(frame,
	{
		{loc("REG_LIST_CHAR_TITLE"), 1, 150},
		{loc("REG_LIST_IGNORE_TITLE"), 3, 150},
	},
	changeMode
	);
	tabGroup:SelectTab(1);
end

TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_LOAD, function()
	registerConfigKey(CONFIG_SHOW_OFFLINE, true);
	registerConfigHandler(CONFIG_HIDE_NSFW, function()
		if getCurrentPageID() == REGISTER_LIST_PAGEID then
			refreshList();
		end
	end);

	-- To try, but I'm afraid for performances ...
	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, profileID, dataType)
		if getCurrentPageID() == REGISTER_LIST_PAGEID and unitID ~= Globals.player_id then
			refreshList();
		end
		if unitID and pendingProfileOpen[unitID] and hasProfile(unitID) then
			local profile = getUnitIDProfile(unitID);
			if profile and profile.characteristics and profile.characteristics.FN then
				pendingProfileOpen[unitID] = nil;
				openPage(hasProfile(unitID));
			end
		end
	end);
	
	Events.listenToEvent(Events.REGISTER_PROFILE_DELETED, function(profileID)
		if profileID then
			selectedIDs[profileID] = nil;
			if isMenuRegistered(currentlyOpenedProfilePrefix .. profileID) then
				unregisterMenu(currentlyOpenedProfilePrefix .. profileID);
			end
		end
		if getCurrentPageID() == REGISTER_LIST_PAGEID then
			refreshList();
		end
	end);

	registerMenu({
		id = REGISTER_PAGE,
		closeable = true,
		text = loc("REG_REGISTER"),
		onSelected = function() setPage(REGISTER_LIST_PAGEID); end,
	});

	registerPage({
		id = REGISTER_LIST_PAGEID,
		templateName = "TRP3_RegisterList",
		frameName = "TRP3_RegisterList",
		frame = TRP3_RegisterList,
		onPagePostShow = function() tabGroup:SelectTab(1); end,
	});

	TRP3_RegisterListSlider:SetValue(0);
	handleMouseWheel(TRP3_RegisterListContainer, TRP3_RegisterListSlider);
	local widgetTab = {};
	for i=1,14 do
		local widget = _G["TRP3_RegisterListLine"..i];
		local widgetClick = _G["TRP3_RegisterListLine"..i.."Click"];
		local widgetSelect = _G["TRP3_RegisterListLine"..i.."Select"];
		widgetSelect:SetScript("OnClick", onLineSelected);
		widgetClick:SetScript("OnClick", onLineClicked);
		widgetClick:SetHighlightTexture("Interface\\FriendsFrame\\UI-FriendsFrame-HighlightBar-Blue");
		widgetClick:SetAlpha(0.75);
		table.insert(widgetTab, widget);
	end
	TRP3_RegisterList.widgetTab = widgetTab;
	TRP3_RegisterListFilterCharactName:SetScript("OnEnterPressed", refreshList);
	TRP3_RegisterListFilterCharactGuild:SetScript("OnEnterPressed", refreshList);
	TRP3_RegisterListCharactFilterButton:SetScript("OnClick", function(self, button)
		if button == "RightButton" then
			TRP3_RegisterListFilterCharactName:SetText("");
			TRP3_RegisterListFilterCharactGuild:SetText("");
		end
		refreshList();
	end)
	setTooltipForSameFrame(TRP3_RegisterListCharactFilterButton, "LEFT", 0, 5, loc("REG_LIST_FILTERS"), loc("REG_LIST_FILTERS_TT"));
	TRP3_RegisterListFilterCharactNameText:SetText(loc("REG_LIST_NAME"));
	TRP3_RegisterListFilterCharactGuildText:SetText(loc("REG_LIST_GUILD"));
	_G[TRP3_RegisterListFilterShowOffline:GetName() .. "Text"]:SetText("Show Offline");
	TRP3_RegisterListFilterShowOffline:SetChecked(getConfigValue(CONFIG_SHOW_OFFLINE));
	TRP3_RegisterListFilterShowOffline:SetScript("OnClick", function(self)
		local enabled = self:GetChecked() == 1 or self:GetChecked() == true;
		setConfigValue(CONFIG_SHOW_OFFLINE, enabled);
		refreshList();
	end);
	TRP3_API.ui.frame.setupEditBoxesNavigation({TRP3_RegisterListFilterCharactName, TRP3_RegisterListFilterCharactGuild});

	TRP3_RegisterListHeaderNameTT:SetScript("OnClick", switchNameSorting);
	TRP3_RegisterListHeaderInfoTT:SetScript("OnClick", switchCharacterSorting);
	TRP3_RegisterListHeaderInfo2TT:SetScript("OnClick", onInfoHeaderClicked);
	TRP3_RegisterListHeaderInfo3TT:SetScript("OnClick", nil);

	setTooltipForSameFrame(TRP3_RegisterListHeaderActions, "TOP", 0, 0, loc("CM_ACTIONS"));
	TRP3_RegisterListHeaderActions:SetScript("OnClick", function(self)
		if currentMode == MODE_CHARACTER then
			onCharactersActions(self);
		end
	end);

	createTabBar();

	if not listRefreshTicker then
		listRefreshTicker = CreateFrame("Frame", "TRP3_RegisterListHeartbeatTicker");
		listRefreshTicker.elapsed = 0;
		listRefreshTicker:SetScript("OnUpdate", function(self, elapsed)
			self.elapsed = self.elapsed + elapsed;
			if self.elapsed < 5 then
				return;
			end
			self.elapsed = 0;
			if getCurrentPageID() == REGISTER_LIST_PAGEID and currentMode == MODE_CHARACTER then
				refreshList();
			end
		end);
	end

end);

TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_LOADED, function()
	if TRP3_API.target then
		TRP3_API.target.registerButton({
			id = "aa_player_a_page",
			configText = loc("TF_OPEN_CHARACTER"),
			onlyForType = TRP3_API.ui.misc.TYPE_CHARACTER,
			condition = function(targetType, unitID)
				return unitID == Globals.player_id or (isUnitIDKnown(unitID) and hasProfile(unitID));
			end,
			onClick = function(unitID)
				openMainFrame();
				openPageByUnitID(unitID);
			end,
			adapter = function(buttonStructure, unitID, currentTargetType)
				buttonStructure.tooltip = loc("REG_PLAYER");
				buttonStructure.tooltipSub =  "|cffffff00" .. loc("CM_CLICK") .. ": |r" .. loc("TF_OPEN_CHARACTER");
				buttonStructure.alert = nil;
				if unitID ~= Globals.player_id and hasProfile(unitID) then
					local profile = getUnitIDProfile(unitID);
					if profile.about and not profile.about.read then
						buttonStructure.tooltipSub =  "|cff00ff00" .. loc("REG_TT_NOTIF") .. "\n" .. buttonStructure.tooltipSub;
						buttonStructure.alert = true;
					end
				end
			end,
			alertIcon = "Interface\\GossipFrame\\AvailableQuestIcon",
			icon = "inv_inscription_scroll"
		});
		TRP3_API.target.registerButton({
			id = "ab_pet_page",
			configText = "Open pet profile",
			onlyForType = TRP3_API.ui.misc.TYPE_PET,
			condition = function(targetType, unitID)
				local _, ownerID = TRP3_API.register.companion and TRP3_API.register.companion.getUnitID and TRP3_API.register.companion.getUnitID("target");
				if not unitID or not TRP3_API.register.companion then
					return false;
				end
				if ownerID == Globals.player_id and TRP3_API.register.companion.openPage then
					return true;
				end
				return TRP3_API.register.companion.openProfile and TRP3_API.register.companion.getProfile and TRP3_API.register.companion.getProfile(unitID);
			end,
			onClick = function(unitID)
				local companionID, ownerID, companionName, ownerName, species = TRP3_API.register.companion.getUnitID("target");
				if companionID and ownerID == Globals.player_id then
					openMainFrame();
					TRP3_API.register.companion.openPage(companionID, ownerID, companionName, ownerName, species);
				elseif companionID then
					local _, profileID = TRP3_API.register.companion.getProfile(companionID);
					if profileID then
						openMainFrame();
						TRP3_API.register.companion.openProfile(profileID);
					end
				end
			end,
			adapter = function(buttonStructure)
				buttonStructure.tooltip = "Pet profile";
				buttonStructure.tooltipSub = "|cffffff00" .. loc("CM_CLICK") .. ": |rOpen this pet's profile";
				buttonStructure.alert = nil;
			end,
			icon = "Ability_Hunter_BeastCall"
		});
	end
end);
