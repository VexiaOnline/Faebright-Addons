----------------------------------------------------------------------------------
-- Total RP 3 / Tranquil RP 3
-- Character data exchange
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- TRP3 imports
local Globals = TRP3_API.globals;
local Utils = TRP3_API.utils;
local get = TRP3_API.profile.getData;
local Comm = TRP3_API.communication;
local loc = TRP3_API.locale.getText;
local log = Utils.log.log;
local Events = TRP3_API.events;
local getPlayerCharacter = TRP3_API.profile.getPlayerCharacter;
local getCharacterExchangeData = TRP3_API.dashboard.getCharacterExchangeData;
local registerInfoTypes = TRP3_API.register.registerInfoTypes;
local isIDIgnored, shouldUpdateInformation = TRP3_API.register.isIDIgnored, TRP3_API.register.shouldUpdateInformation;
local addCharacter = TRP3_API.register.addCharacter;
local saveCurrentProfileID, saveClientInformation, saveInformation = TRP3_API.register.saveCurrentProfileID, TRP3_API.register.saveClientInformation, TRP3_API.register.saveInformation;
local getPlayerCurrentProfileID = TRP3_API.profile.getPlayerCurrentProfileID;
local isUnitIDKnown = TRP3_API.register.isUnitIDKnown;
local playerAPI = TRP3_API.register.player;
local getCharExchangeData = playerAPI.getCharacteristicsExchangeData;
local getAboutExchangeData = playerAPI.getAboutExchangeData;
local getMiscExchangeData = playerAPI.getMiscExchangeData;
local getLanguagesExchangeData = playerAPI.getLanguagesExchangeData;
local getConfigValue = TRP3_API.configuration.getValue;

-- WoW imports
local UnitName, UnitIsPlayer, UnitFactionGroup, CheckInteractDistance = UnitName, UnitIsPlayer, UnitFactionGroup, CheckInteractDistance;
local tinsert, time, type, pairs, tonumber = tinsert, time, type, pairs, tonumber;

-- Config keys
local CONFIG_REGISTRE_AUTO_ADD = "register_auto_add";
local function configIsAutoAdd()
	return getConfigValue(CONFIG_REGISTRE_AUTO_ADD);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Vernum queries
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local LAST_QUERY = {};
local LAST_COMPANION_QUERY = {};
local COOLDOWN_DURATION = 30; -- Should be integer
local VERNUM_QUERY_PREFIX = "VQ";
local VERNUM_R_QUERY_PREFIX = "VR";
local INFO_TYPE_QUERY_PREFIX = "GI";
local INFO_TYPE_SEND_PREFIX = "SI";
local COMPANION_QUERY_PREFIX = "CQ";
local COMPANION_SEND_PREFIX = "CS";
local CORRECTION_REQUEST_PREFIX = "RC";
local MODERATION_UPDATE_PREFIX = "RM";
local PROFILE_REPORT_PREFIX = "RR";
local PROFILE_REPORT_ACK_PREFIX = "RA";
local MODERATION_BROADCAST_COMMAND = "TRP3MOD";
local VERNUM_QUERY_PRIORITY = "NORMAL";
local INFO_TYPE_QUERY_PRIORITY = "NORMAL";
local INFO_TYPE_SEND_PRIORITY = "BULK";
local COMPANION_QUERY_PRIORITY = "NORMAL";
local COMPANION_SEND_PRIORITY = "BULK";
local CORRECTION_REQUEST_PRIORITY = "NORMAL";
local MODERATION_UPDATE_PRIORITY = "NORMAL";
local PROFILE_REPORT_PRIORITY = "NORMAL";

local VERNUM_QUERY_INDEX_VERSION = 1;
local VERNUM_QUERY_INDEX_VERSION_DISPLAY = 2;
local VERNUM_QUERY_INDEX_CHARACTER_PROFILE = 3;
local VERNUM_QUERY_INDEX_CHARACTER_CHARACTERISTICS_V = 4;
local VERNUM_QUERY_INDEX_CHARACTER_ABOUT_V = 5;
local VERNUM_QUERY_INDEX_CHARACTER_MISC_V = 6;
local VERNUM_QUERY_INDEX_CHARACTER_CHARACTER_V = 7;
local VERNUM_QUERY_INDEX_CHARACTER_LANGUAGES_V = 8;

local queryInformationType, createVernumQuery;
local PROFILE_REPORT_REALM = "glitterwing";
local PROFILE_REPORT_MODERATORS = {
	"Takoy",
	"Veln",
	"Prynn",
	"Eura",
};

TRP3_Moderation = TRP3_Moderation or {};
TRP3_Moderation.hiddenProfiles = TRP3_Moderation.hiddenProfiles or {};
TRP3_ProfileReports = TRP3_ProfileReports or {};
TRP3_ProfileReports.pending = TRP3_ProfileReports.pending or {};

TRP3_API.register.moderation = TRP3_API.register.moderation or {};

local function normalizeModerationUnitID(unitID)
	unitID = tostring(unitID or "");
	unitID = unitID:gsub("^%s*(.-)%s*$", "%1");
	return string.lower(unitID);
end

local function getModerationUnitIDs(unitID, profile)
	local unitIDs = {};
	local normalized = normalizeModerationUnitID(unitID);
	if normalized ~= "" then
		unitIDs[normalized] = true;
	end
	if type(profile) == "table" and type(profile.link) == "table" then
		for linkedUnitID in pairs(profile.link) do
			normalized = normalizeModerationUnitID(linkedUnitID);
			if normalized ~= "" then
				unitIDs[normalized] = true;
			end
		end
	end
	return unitIDs;
end

local function setHiddenEntry(unitID, hidden, reason, moderator, timestamp)
	local normalized = normalizeModerationUnitID(unitID);
	if normalized == "" then
		return false;
	end
	timestamp = tonumber(timestamp) or time();
	local currentEntry = TRP3_Moderation.hiddenProfiles[normalized];
	if type(currentEntry) == "table" and tonumber(currentEntry.time) and tonumber(currentEntry.time) > timestamp then
		return false;
	end
	if hidden then
		TRP3_Moderation.hiddenProfiles[normalized] = {
			hidden = true,
			reason = tostring(reason or ""),
			moderator = tostring(moderator or ""),
			time = timestamp,
		};
	else
		TRP3_Moderation.hiddenProfiles[normalized] = {
			hidden = false,
			reason = "",
			moderator = tostring(moderator or ""),
			time = timestamp,
		};
	end
	return true;
end

local function applyModerationUpdate(update, senderID)
	if not TRP3_API.security or not TRP3_API.security.isDeveloperAdminName or not TRP3_API.security.isDeveloperAdminName(senderID) then
		log("Rejected moderation update from unauthorized sender: " .. tostring(senderID));
		return;
	end
	if type(update) ~= "table" or update.type ~= "profile_hidden" then
		return;
	end
	if setHiddenEntry(update.unitID, update.hidden == true, update.reason, senderID, update.time) then
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, tostring(update.unitID or ""), nil, nil);
	end
end

local function applyModerationBroadcast(senderID, unitID, hidden, timestamp)
	applyModerationUpdate({
		type = "profile_hidden",
		unitID = unitID,
		hidden = hidden == "1" or hidden == true,
		time = tonumber(timestamp) or time(),
	}, senderID);
end

function TRP3_API.register.moderation.isProfileHidden(unitID, profile)
	local unitIDs = getModerationUnitIDs(unitID, profile);
	if unitIDs[normalizeModerationUnitID(Globals.player_id)] then
		return nil;
	end
	for normalizedUnitID in pairs(unitIDs) do
		local entry = TRP3_Moderation.hiddenProfiles[normalizedUnitID];
		if type(entry) == "table" and entry.hidden then
			return entry, normalizedUnitID;
		end
	end
end

function TRP3_API.register.moderation.getHiddenEntry(unitID, profile)
	for normalizedUnitID in pairs(getModerationUnitIDs(unitID, profile)) do
		local entry = TRP3_Moderation.hiddenProfiles[normalizedUnitID];
		if type(entry) == "table" then
			return entry, normalizedUnitID;
		end
	end
end

function TRP3_API.register.moderation.setProfileHidden(unitID, hidden, reason, moderator)
	return setHiddenEntry(unitID, hidden == true, reason, moderator or Globals.player_id, time());
end

function TRP3_API.register.moderation.sendProfileHiddenUpdate(unitID, hidden, reason, target)
	if not TRP3_API.security or not TRP3_API.security.isDeveloperAdmin or not TRP3_API.security.isDeveloperAdmin() then
		return false, "Current character is not authorized to send moderation updates.";
	end
	local payload = {
		type = "profile_hidden",
		unitID = tostring(unitID or ""),
		hidden = hidden == true,
		reason = tostring(reason or ""),
		time = time(),
	};
	if payload.unitID == "" then
		return false, "No character selected.";
	end

	setHiddenEntry(payload.unitID, payload.hidden, payload.reason, Globals.player_id, payload.time);

	if target and target ~= "" then
		Comm.sendObject(MODERATION_UPDATE_PREFIX, payload, target, MODERATION_UPDATE_PRIORITY);
	elseif Comm.broadcast and Comm.broadcast.broadcast then
		Comm.broadcast.broadcast(MODERATION_BROADCAST_COMMAND, payload.unitID, payload.hidden and "1" or "0", payload.time);
	else
		for knownUnitID in pairs(TRP3_API.register.getCharacterList() or {}) do
			if knownUnitID ~= Globals.player_id then
				Comm.sendObject(MODERATION_UPDATE_PREFIX, payload, knownUnitID, MODERATION_UPDATE_PRIORITY);
			end
		end
	end
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, payload.unitID, nil, nil);
	return true;
end

function TRP3_API.register.moderation.broadcastHiddenProfiles()
	if not TRP3_API.security or not TRP3_API.security.isDeveloperAdmin or not TRP3_API.security.isDeveloperAdmin() then
		return false, "Current character is not authorized to broadcast moderation updates.";
	end
	if not Comm.broadcast or not Comm.broadcast.broadcast then
		return false, "Broadcast communication is not available.";
	end
	for unitID, entry in pairs(TRP3_Moderation.hiddenProfiles or {}) do
		if type(entry) == "table" then
			Comm.broadcast.broadcast(MODERATION_BROADCAST_COMMAND, unitID, entry.hidden and "1" or "0", entry.time or time());
		end
	end
	return true;
end

local CORRECTION_ROOTS = {
	about = true,
	character = true,
	characteristics = true,
	languages = true,
	misc = true,
};

local function copyTable(source)
	if type(source) ~= "table" then
		return source;
	end
	local copy = {};
	for key, value in pairs(source) do
		copy[key] = copyTable(value);
	end
	return copy;
end

local function normalizeRealmName(realmName)
	realmName = tostring(realmName or ""):gsub("^%s*(.-)%s*$", "%1");
	realmName = realmName:gsub("%s+", "");
	return string.lower(realmName);
end

local function getCurrentRealmKey()
	return normalizeRealmName(GetRealmName and GetRealmName() or "");
end

local function getFirstLinkedUnitID(profile)
	if type(profile) == "table" and type(profile.link) == "table" then
		for unitID in pairs(profile.link) do
			return unitID;
		end
	end
end

local function buildReportProfileSnapshot(profile)
	if type(profile) ~= "table" then
		return {};
	end
	return {
		characteristics = copyTable(profile.characteristics),
		character = copyTable(profile.character),
		about = copyTable(profile.about),
		misc = copyTable(profile.misc),
	};
end

local function isProfileReportModerator(unitID)
	local normalizedUnitID = normalizeModerationUnitID(unitID);
	for _, moderatorName in pairs(PROFILE_REPORT_MODERATORS) do
		if normalizeModerationUnitID(moderatorName) == normalizedUnitID then
			return true;
		end
	end
	return false;
end

local function sendProfileReportToModerators(report, targetModerator)
	if targetModerator and targetModerator ~= "" then
		Comm.sendObject(PROFILE_REPORT_PREFIX, report, targetModerator, PROFILE_REPORT_PRIORITY);
		return;
	end
	for _, moderatorName in pairs(PROFILE_REPORT_MODERATORS) do
		Comm.sendObject(PROFILE_REPORT_PREFIX, report, moderatorName, PROFILE_REPORT_PRIORITY);
	end
end

local function queuePendingProfileReport(report)
	if type(report) ~= "table" or not report.reportID then
		return;
	end
	TRP3_ProfileReports.pending[report.reportID] = {
		report = copyTable(report),
		createdAt = time(),
		lastAttemptAt = 0,
		attempts = 0,
	};
end

local function retryPendingProfileReports(targetModerator)
	if getCurrentRealmKey() ~= PROFILE_REPORT_REALM then
		return;
	end
	if targetModerator and not isProfileReportModerator(targetModerator) then
		return;
	end
	for reportID, entry in pairs(TRP3_ProfileReports.pending or {}) do
		if type(entry) == "table" and type(entry.report) == "table" then
			entry.attempts = (tonumber(entry.attempts) or 0) + 1;
			entry.lastAttemptAt = time();
			sendProfileReportToModerators(entry.report, targetModerator);
		else
			TRP3_ProfileReports.pending[reportID] = nil;
		end
	end
end

local function receiveProfileReportAck(ack, senderID)
	if not isProfileReportModerator(senderID) or type(ack) ~= "table" then
		return;
	end
	local reportID = tostring(ack.reportID or "");
	if reportID ~= "" and TRP3_ProfileReports.pending then
		TRP3_ProfileReports.pending[reportID] = nil;
	end
end

function TRP3_API.register.sendProfileReport(unitID, profileID, profile, reason)
	if getCurrentRealmKey() ~= PROFILE_REPORT_REALM then
		return false, "Profile reports are only available on Glitterwing.";
	end
	if type(profile) ~= "table" then
		return false, "No cached profile to report.";
	end
	unitID = tostring(unitID or getFirstLinkedUnitID(profile) or "");
	if unitID == "" then
		return false, "No reported character was found.";
	end
	if normalizeModerationUnitID(unitID) == normalizeModerationUnitID(Globals.player_id) then
		return false, "You cannot report your own profile.";
	end
	reason = tostring(reason or ""):gsub("^%s*(.-)%s*$", "%1");
	if reason == "" then
		return false, "A report reason is required.";
	end

	local reportedName = TRP3_API.register.getCompleteName(profile.characteristics or {}, unitID, true);
	local report = {
		version = 1,
		realm = GetRealmName and GetRealmName() or "Glitterwing",
		time = time(),
		reportID = tostring(Globals.player_id) .. "-" .. tostring(unitID) .. "-" .. tostring(time()),
		reporter = {
			unitID = Globals.player_id,
			name = TRP3_API.register.getPlayerCompleteName and TRP3_API.register.getPlayerCompleteName(true) or Globals.player_id,
		},
		reported = {
			unitID = unitID,
			name = reportedName,
			profileID = profileID,
		},
		reason = reason,
		snapshot = buildReportProfileSnapshot(profile),
	};
	queuePendingProfileReport(report);
	sendProfileReportToModerators(report);
	return true, "Profile report queued and will be delivered when a moderator is online.";
end

local function normalizeCorrectionData(correctionData)
	if type(correctionData) ~= "table" then
		return correctionData;
	end
	if type(correctionData.character) == "table" and correctionData.character.NSFW == false then
		correctionData = copyTable(correctionData);
		correctionData.character.NSFW = nil;
		correctionData.character.__TRP3_CLEAR_NSFW = true;
	end
	return correctionData;
end

local function debugCorrectionData(data)
	if type(data) ~= "table" then
		log("Correction data is not a table!");
		return;
	end
	local keys = {};
	for k in pairs(data) do
		table.insert(keys, k);
	end
	log("Incoming correction data keys: " .. table.concat(keys, ", "));
end

local function applyCorrectionData(correctionData)
	local profile = TRP3_API.profile.getPlayerCurrentProfile and TRP3_API.profile.getPlayerCurrentProfile();
	if type(profile) ~= "table" or type(profile.player) ~= "table" or type(correctionData) ~= "table" then
		return false;
	end
	correctionData = normalizeCorrectionData(correctionData);

	local changedTypes = {};
	for root, value in pairs(correctionData) do
		if CORRECTION_ROOTS[root] then
			if type(value) == "table" then
				profile.player[root] = copyTable(value);
				if root == "character" and profile.player[root].__TRP3_CLEAR_NSFW then
					profile.player[root].NSFW = nil;
					profile.player[root].__TRP3_CLEAR_NSFW = nil;
				end
				profile.player[root].v = (tonumber(profile.player[root].v) or 1) + 1;
			else
				profile.player[root] = value;
			end
			tinsert(changedTypes, root);
		end
	end

	if #changedTypes > 0 then
		for _, root in pairs(changedTypes) do
			Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, getPlayerCurrentProfileID(), root);
		end
		Events.fireEvent(Events.REGISTER_PROFILES_LOADED, profile);
	end
	return changedTypes;
end

local function incomingCorrectionRequest(request, senderID)
	if not TRP3_API.security or not TRP3_API.security.isDeveloperAdminName or not TRP3_API.security.isDeveloperAdminName(senderID) then
		log("Rejected profile correction request from unauthorized sender: " .. tostring(senderID));
		return;
	end
	if type(request) ~= "table" or type(request.data) ~= "table" then
		log("Invalid correction request structure");
		return;
	end

	debugCorrectionData(request.data);  -- Added debug

	local isSilent = request.silent == true;
	local sender = type(request.senderIdentity) == "string" and request.senderIdentity ~= "" and request.senderIdentity or tostring(senderID or UNKNOWN);

	if isSilent then
		local applied = applyCorrectionData(request.data);
		if type(applied) == "table" and #applied > 0 then
			TRP3_API.utils.message.displayMessage("Your profile has been updated.");
		else
			TRP3_API.utils.message.displayMessage("Your profile has been updated. (no changes)");
		end
		return;
	end

	-- ... rest of the function remains the same

	TRP3_API.popup.showConfirmPopup(
		"Profile correction request from " .. sender .. ".\n\nApply these changes to your current profile?",
		function()
			local applied = applyCorrectionData(request.data);
			if type(applied) == "table" and #applied > 0 then
				TRP3_API.utils.message.displayMessage("Applied profile correction request from " .. sender .. ": " .. table.concat(applied, ", ") .. ".");
			else
				TRP3_API.utils.message.displayMessage("No profile correction changes were applied.");
			end
		end
	);
end

function TRP3_API.register.sendProfileCorrectionRequest(target, correctionData, senderIdentity, silent)
	if not TRP3_API.security or not TRP3_API.security.isDeveloperAdmin or not TRP3_API.security.isDeveloperAdmin() then
		return false, "Current character is not authorized to send profile correction requests.";
	end
	if type(correctionData) ~= "table" then
		return false, "No correction data to send.";
	end

	local payload = {
		version = 1,
		senderIdentity = senderIdentity,
		time = time(),
		data = correctionData,
		silent = silent == true,
	};

	Comm.sendObject(CORRECTION_REQUEST_PREFIX, payload, target, CORRECTION_REQUEST_PRIORITY);
	return true;
end

local function queryVernum(unitName)
	local query = createVernumQuery();
	Comm.sendObject(VERNUM_QUERY_PREFIX, query, unitName, VERNUM_QUERY_PRIORITY);
end

local function queryMarySueProtocol(unitName)

end

local function getCompanionOwnerID(companionID)
	if type(companionID) == "string" then
		return companionID:match("^PET:([^:]+):");
	end
end

local function decodeExchangeData(data)
	if type(data) == "string" then
		local trace = Utils.pcall(Utils.serial.decompressCodedStructure, data);
		if trace and trace[1] then
			return trace[2];
		end
		return nil;
	end
	return data;
end

local function getCompanionExchangeData(companionID)
	if not TRP3_API.register.companion or not TRP3_API.register.companion.getProfile then
		return;
	end
	local profile, profileID = TRP3_API.register.companion.getProfile(companionID);
	if not profile then
		return;
	end
	return {
		profileID = profileID,
		profileName = profile.profileName,
		companion = profile.companion,
		characteristics = profile.characteristics,
		about = profile.about,
		misc = profile.misc,
		character = profile.character,
	};
end

local function sendCompanionQuery(companionID)
	local ownerID = getCompanionOwnerID(companionID);
	if ownerID and ownerID ~= Globals.player_id and not isIDIgnored(ownerID) and not Comm.isPlayerOfflineCached(ownerID) and (not LAST_COMPANION_QUERY[companionID] or time() - LAST_COMPANION_QUERY[companionID] > COOLDOWN_DURATION) then
		LAST_COMPANION_QUERY[companionID] = time();
		Comm.sendObject(COMPANION_QUERY_PREFIX, companionID, ownerID, COMPANION_QUERY_PRIORITY);
	end
end

local function incomingCompanionQuery(companionID, senderID)
	local ownerID = getCompanionOwnerID(companionID);
	if ownerID ~= Globals.player_id then
		return;
	end
	local data = getCompanionExchangeData(companionID);
	if data then
		Comm.sendObject(COMPANION_SEND_PREFIX, { companionID = companionID, data = data }, senderID, COMPANION_SEND_PRIORITY);
	end
end

local function incomingCompanionProfile(structure, senderID)
	if type(structure) ~= "table" or type(structure.companionID) ~= "string" or type(structure.data) ~= "table" then
		return;
	end
	local companionID = structure.companionID;
	local ownerID = getCompanionOwnerID(companionID);
	if ownerID ~= senderID then
		return;
	end
	local data = structure.data;
	data.characteristics = decodeExchangeData(data.characteristics);
	data.about = decodeExchangeData(data.about);
	data.misc = decodeExchangeData(data.misc);
	data.character = decodeExchangeData(data.character);
	local companionName = data.companion and data.companion.name or companionID:match("^PET:[^:]+:(.+)$");
	if TRP3_API.register.companion and TRP3_API.register.companion.saveRemoteProfile then
		TRP3_API.register.companion.saveRemoteProfile(companionID, ownerID, companionName, data.profileID or companionID, data);
	end
end

--- Vernum query builder
function createVernumQuery()
	local query = {};
	-- Keep the legacy TRP3 exchange protocol version neutral so stock TotalRP3
	-- clients do not interpret TranquilRP3 as a newer TotalRP3 release.
	query[VERNUM_QUERY_INDEX_VERSION] = 0;
	query[VERNUM_QUERY_INDEX_VERSION_DISPLAY] = Globals.version_display; -- Your TRP3 version (as it should be shown on tooltip)
	-- Character
	query[VERNUM_QUERY_INDEX_CHARACTER_PROFILE] = getPlayerCurrentProfileID() or "";
	query[VERNUM_QUERY_INDEX_CHARACTER_CHARACTERISTICS_V] = get("player/characteristics").v or 0;
	query[VERNUM_QUERY_INDEX_CHARACTER_ABOUT_V] = get("player/about").v or 0;
	query[VERNUM_QUERY_INDEX_CHARACTER_MISC_V] = get("player/misc").v or 0;
	query[VERNUM_QUERY_INDEX_CHARACTER_CHARACTER_V] = get("player/character").v or 1;
	query[VERNUM_QUERY_INDEX_CHARACTER_LANGUAGES_V] = (get("player/languages") and get("player/languages").v) or 1;

	return query;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Incoming vernum queries
-- Check version numbers and perform information queries
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local infoTypeTab = {
	registerInfoTypes.CHARACTERISTICS,
	registerInfoTypes.ABOUT,
	registerInfoTypes.MISC,
	registerInfoTypes.CHARACTER,
	registerInfoTypes.LANGUAGES
};

--- Incoming vernum query
-- This is received when another player has "mouseovered" you.
-- His main query is to receive your vernum tab. But you can already read his tab to query information.
local function incomingVernumQuery(structure, senderID, bResponse)
	-- First: Integrity check
	if type(structure) ~= "table"
	or #structure <= 0
	or type(structure[VERNUM_QUERY_INDEX_VERSION]) ~= "number"
	or type(structure[VERNUM_QUERY_INDEX_VERSION_DISPLAY]) ~= "string"
	or type(structure[VERNUM_QUERY_INDEX_CHARACTER_PROFILE]) ~= "string"
	then
		log("Incoming vernum integrity check fails. Sender: " .. senderID);
		return;
	end

	-- First send back or own vernum
	if not bResponse and (not LAST_QUERY[senderID] or time() - LAST_QUERY[senderID] > COOLDOWN_DURATION) then
		local query = createVernumQuery();
		Comm.sendObject(VERNUM_R_QUERY_PREFIX, query, senderID, VERNUM_QUERY_PRIORITY);
	end

	-- Data processing
	local senderVersionText = structure[VERNUM_QUERY_INDEX_VERSION_DISPLAY];
	local senderProfileID = structure[VERNUM_QUERY_INDEX_CHARACTER_PROFILE];

	if isUnitIDKnown(senderID) or configIsAutoAdd() then
		if not isUnitIDKnown(senderID) then
			addCharacter(senderID);
		end
		saveClientInformation(senderID, "TotalRP3", senderVersionText, false);
		saveCurrentProfileID(senderID, senderProfileID);

		-- Query specific data, depending on version number.
		local index = VERNUM_QUERY_INDEX_CHARACTER_CHARACTERISTICS_V;
		for _, infoType in pairs(infoTypeTab) do
			if (infoType ~= registerInfoTypes.LANGUAGES or structure[index] ~= nil) and shouldUpdateInformation(senderID, infoType, structure[index]) then
				log(("Should update: %s's %s"):format(senderID, infoType));
				queryInformationType(senderID, infoType);
			end
			index = index + 1;
		end

	end
end

--- Incoming vernum response
-- This is received when you asked a player for his vernum tab and he responses.
-- In that case we shouldn't query him anymore as it would bring an infinite loop.
local function incomingVernumResponseQuery(structure, senderID)
	incomingVernumQuery(structure, senderID, true);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Query for information
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local CURRENT_QUERY_EXCHANGES = {};

function queryInformationType(unitName, informationType)
	if CURRENT_QUERY_EXCHANGES[unitName] and CURRENT_QUERY_EXCHANGES[unitName][informationType] then
		return; -- Don't ask again for information that are incoming !
	end
	if not CURRENT_QUERY_EXCHANGES[unitName] then
		CURRENT_QUERY_EXCHANGES[unitName] = {};
	end
	CURRENT_QUERY_EXCHANGES[unitName][informationType] = time();
	Comm.sendObject(INFO_TYPE_QUERY_PREFIX, informationType, unitName, INFO_TYPE_QUERY_PRIORITY);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Incoming query for information, and send information
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function incomingInformationType(informationType, senderID)
	local data = nil;
	if informationType == registerInfoTypes.CHARACTERISTICS then
		data = getCharExchangeData();
	elseif informationType == registerInfoTypes.ABOUT then
		data = getAboutExchangeData();
	elseif informationType == registerInfoTypes.MISC then
		data = getMiscExchangeData();
	elseif informationType == registerInfoTypes.CHARACTER then
		data = getCharacterExchangeData();
	elseif informationType == registerInfoTypes.LANGUAGES and getLanguagesExchangeData then
		data = getLanguagesExchangeData();
	end
	if data then
		log(("Send %s info to %s"):format(informationType, senderID));
		Comm.sendObject(INFO_TYPE_SEND_PREFIX, {informationType, data}, senderID, INFO_TYPE_SEND_PRIORITY);
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Received information
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function incomingInformationTypeSent(structure, senderID)
	local informationType = structure[1];
	local data = structure[2];

	if not CURRENT_QUERY_EXCHANGES[senderID] or not CURRENT_QUERY_EXCHANGES[senderID][informationType] then
		return; -- We didn't ask for theses information ...
	end

	log(("Received %s's %s info !"):format(senderID, informationType));
	CURRENT_QUERY_EXCHANGES[senderID][informationType] = nil;

	local decodedData = data;
	-- If the data is a string, we assume that it was compressed.
	if type(data) == "string" then
		decodedData = Utils.serial.decompressCodedStructure(decodedData);
	end

	if informationType == registerInfoTypes.CHARACTERISTICS or informationType == registerInfoTypes.ABOUT
	or informationType == registerInfoTypes.MISC or informationType == registerInfoTypes.CHARACTER
	or informationType == registerInfoTypes.LANGUAGES then
		if informationType == registerInfoTypes.CHARACTER and decodedData and decodedData.NT then
			decodedData.NT = nil;
		end
		saveInformation(senderID, informationType, decodedData);
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- TRIGGERS
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

--- Send vernum request to the player
local function sendQuery(unitID)
	if unitID and unitID ~= Globals.player_id and not isIDIgnored(unitID) and not Comm.isPlayerOfflineCached(unitID) and (not LAST_QUERY[unitID] or time() - LAST_QUERY[unitID] > COOLDOWN_DURATION) then
		LAST_QUERY[unitID] = time();
		queryVernum(unitID);
		queryMarySueProtocol(unitID);
	end
end
TRP3_API.r.sendQuery = sendQuery;

-- disabling 264 and 271 checks allows for crossfaction
local function onMouseOverCharacter(unitID)
	-- if UnitFactionGroup("player") == UnitFactionGroup("mouseover") then
		sendQuery(unitID);
	-- end
end

local function onTargetChanged()
	local unitID = Utils.str.getUnitID("target");
	if UnitIsPlayer("target") then -- and UnitFactionGroup("player") == UnitFactionGroup("target") then
		sendQuery(unitID);
	elseif TRP3_API.ui.misc.getTargetType("target") == TYPE_PET and TRP3_API.register.companion and TRP3_API.register.companion.getUnitID then
		local companionID = TRP3_API.register.companion.getUnitID("target");
		if companionID then
			sendCompanionQuery(companionID);
		end
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Check size
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local ALERT_FOR_SIZE = 20;

local function checkPlayerDataWeight()
	local totalData = {getCharExchangeData(), getAboutExchangeData(), getMiscExchangeData(), getCharacterExchangeData()};
	local computedSize = Comm.estimateStructureLoad(totalData);
	if computedSize > ALERT_FOR_SIZE then
		log(("Profile too heavy ! It would take %s messages to send."):format(computedSize));
		if getConfigValue("heavy_profile_alert") then
			TRP3_API.ui.tooltip.toast(loc("REG_PLAYER_ALERT_HEAVY_SMALL"), 5);
		end
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- INIT
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local TYPE_CHARACTER = TRP3_API.ui.misc.TYPE_CHARACTER;
local TYPE_PET = TRP3_API.ui.misc.TYPE_PET;

function TRP3_API.register.inits.dataExchangeInit()
	if not TRP3_Register then
		TRP3_Register = {};
	end

	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, profileID)
		if unitID == Globals.player_id then
			checkPlayerDataWeight();
		end
	end);

	-- Listen to the mouse over event
	TRP3_API.events.listenToEvent(TRP3_API.events.MOUSE_OVER_CHANGED, function(targetID, targetMode)
		if targetMode == TYPE_CHARACTER and targetID then
			onMouseOverCharacter(targetID);
		elseif targetMode == TYPE_PET and targetID then
			sendCompanionQuery(targetID);
		end
	end);
	Utils.event.registerHandler("PLAYER_TARGET_CHANGED", onTargetChanged);

	-- Register prefix for data exchange
	Comm.registerProtocolPrefix(VERNUM_QUERY_PREFIX, incomingVernumQuery);
	Comm.registerProtocolPrefix(VERNUM_R_QUERY_PREFIX, incomingVernumResponseQuery);
	Comm.registerProtocolPrefix(INFO_TYPE_QUERY_PREFIX, incomingInformationType);
	Comm.registerProtocolPrefix(INFO_TYPE_SEND_PREFIX, incomingInformationTypeSent);
	Comm.registerProtocolPrefix(COMPANION_QUERY_PREFIX, incomingCompanionQuery);
	Comm.registerProtocolPrefix(COMPANION_SEND_PREFIX, incomingCompanionProfile);
	Comm.registerProtocolPrefix(CORRECTION_REQUEST_PREFIX, incomingCorrectionRequest);
	Comm.registerProtocolPrefix(MODERATION_UPDATE_PREFIX, applyModerationUpdate);
	Comm.registerProtocolPrefix(PROFILE_REPORT_PREFIX, function() end);
	Comm.registerProtocolPrefix(PROFILE_REPORT_ACK_PREFIX, receiveProfileReportAck);
	if Comm.broadcast and Comm.broadcast.registerCommand then
		Comm.broadcast.registerCommand(MODERATION_BROADCAST_COMMAND, applyModerationBroadcast);
	end

	Comm.broadcast.registerCommand(Comm.broadcast.HELLO_CMD, function(sender, version, versionDisplay)
		retryPendingProfileReports(sender);
	end);
	retryPendingProfileReports();
end
