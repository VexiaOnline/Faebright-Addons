----------------------------------------------------------------------------------
-- Total RP 3
-- Directory : Ignore API
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

local Events = TRP3_API.events;
local showTextInputPopup = TRP3_API.popup.showTextInputPopup;
local showColorBrowser = TRP3_API.popup.showColorBrowser;
local showIconBrowser = TRP3_API.popup.showIconBrowser;
local showConfirmPopup = TRP3_API.popup.showConfirmPopup;
local loc = TRP3_API.locale.getText;
local assert, tostring, time, wipe, strconcat, pairs, ipairs, tinsert, type, table, tonumber = assert, tostring, time, wipe, strconcat, pairs, ipairs, tinsert, type, table, tonumber;
local CloseDropDownMenus = CloseDropDownMenus;
local EMPTY = TRP3_API.globals.empty;
local UnitIsPlayer = UnitIsPlayer;
local get, getPlayerCurrentProfile, hasProfile = TRP3_API.profile.getData, TRP3_API.profile.getPlayerCurrentProfile, TRP3_API.register.hasProfile;
local getProfile, getUnitID, deleteProfile = TRP3_API.register.getProfile, TRP3_API.utils.str.getUnitID, TRP3_API.register.deleteProfile;
local displayDropDown = TRP3_API.ui.listbox.displayDropDown;
local registerInfoTypes = TRP3_API.register.registerInfoTypes;
local registerMenu, registerPage, setPage = TRP3_API.navigation.menu.registerMenu, TRP3_API.navigation.page.registerPage, TRP3_API.navigation.page.setPage;
local setupIconButton = TRP3_API.ui.frame.setupIconButton;
local setTooltipForSameFrame = TRP3_API.ui.tooltip.setTooltipForSameFrame;
local getCompleteName, getPlayerCompleteName;
local profiles, characters, blackList, whiteList;

local function ensureIgnoreState()
	if not TRP3_Register then
		TRP3_Register = {};
	end
	if not TRP3_Register.blackList then
		TRP3_Register.blackList = {};
	end
	if not TRP3_Register.whiteList then
		TRP3_Register.whiteList = {};
	end
	if not TRP3_Register.profiles then
		TRP3_Register.profiles = {};
	end
	if not TRP3_Register.character then
		TRP3_Register.character = {};
	end

	profiles = TRP3_Register.profiles;
	characters = TRP3_Register.character;
	blackList = TRP3_Register.blackList;
	whiteList = TRP3_Register.whiteList;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Relation
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local RELATIONS = {
	UNFRIENDLY = "UNFRIENDLY",
	NONE = "NONE",
	NEUTRAL = "NEUTRAL",
	BUSINESS = "BUSINESS",
	FRIEND = "FRIEND",
	LOVE = "LOVE",
	FAMILY = "FAMILY"
}
TRP3_API.register.relation = RELATIONS;

local CREATE_CUSTOM_RELATION = "__TRP3_CREATE_CUSTOM_RELATION";
local CUSTOM_RELATION_PREFIX = "CUSTOM_";
local DEFAULT_CUSTOM_RELATION_ICON = "Achievement_Reputation_06";
local setRelation;

local RELATIONS_TEXTURES = {
	[RELATIONS.UNFRIENDLY] = "Ability_DualWield",
	[RELATIONS.NONE] = "Ability_rogue_disguise",
	[RELATIONS.NEUTRAL] = "Achievement_Reputation_05",
	[RELATIONS.BUSINESS] = "Achievement_Reputation_08",
	[RELATIONS.FRIEND] = "Achievement_Reputation_06",
	[RELATIONS.LOVE] = "INV_ValentinesCandy",
	[RELATIONS.FAMILY] = "Achievement_Reputation_07"
}

local function ensureCustomRelations()
	local profile = getPlayerCurrentProfile();
	if not profile.customRelations then
		profile.customRelations = {};
	end
	return profile.customRelations;
end

local function getCustomRelations()
	local profile = getPlayerCurrentProfile();
	return (profile and profile.customRelations) or EMPTY;
end
TRP3_API.register.relation.getCustomRelations = getCustomRelations;

local function ensureRelationOverrides()
	local profile = getPlayerCurrentProfile();
	if not profile.relationOverrides then
		profile.relationOverrides = {};
	end
	return profile.relationOverrides;
end

local function getRelationOverrides()
	local profile = getPlayerCurrentProfile();
	return (profile and profile.relationOverrides) or EMPTY;
end

local function isCustomRelation(relation)
	return type(relation) == "string" and string.sub(relation, 1, string.len(CUSTOM_RELATION_PREFIX)) == CUSTOM_RELATION_PREFIX;
end

local function getCustomRelation(relation)
	if not isCustomRelation(relation) then
		return nil;
	end
	return getCustomRelations()[relation];
end

local function rgbToHex(red, green, blue)
	return ("%.2x%.2x%.2x"):format(math.floor((red or 255) + 0.5), math.floor((green or 255) + 0.5), math.floor((blue or 255) + 0.5));
end

local function hexToRgb(color)
	if type(color) ~= "string" or not string.match(color, "^%x%x%x%x%x%x$") then
		return 1, 1, 1;
	end
	return tonumber(string.sub(color, 1, 2), 16) / 255, tonumber(string.sub(color, 3, 4), 16) / 255, tonumber(string.sub(color, 5, 6), 16) / 255;
end

local function hexToColorBrowserRgb(color)
	if type(color) ~= "string" or not string.match(color, "^%x%x%x%x%x%x$") then
		return 255, 255, 255;
	end
	return tonumber(string.sub(color, 1, 2), 16), tonumber(string.sub(color, 3, 4), 16), tonumber(string.sub(color, 5, 6), 16);
end

local function getCustomRelationID(name)
	local key = string.upper(string.gsub(tostring(name or ""), "[^%w]+", "_"));
	key = string.gsub(key, "^_+", "");
	key = string.gsub(key, "_+$", "");
	if key == "" then
		key = "RELATION";
	end
	return CUSTOM_RELATION_PREFIX .. key .. "_" .. tostring(time());
end

local function runAfterFrames(callback, frames)
	frames = frames or 1;
	if C_Timer and C_Timer.After then
		C_Timer.After(frames * 0.1, callback);
		return;
	end
	local frame = CreateFrame("Frame");
	frame:SetScript("OnUpdate", function(self)
		frames = frames - 1;
		if frames <= 0 then
			self:SetScript("OnUpdate", nil);
			callback();
		end
	end);
end

local function showStandaloneColorBrowser(callback, red, green, blue)
	if not ColorPickerFrame or not ColorPickerFrame.SetColorRGB then
		showColorBrowser(callback, red, green, blue);
		return;
	end

	local okayButton = ColorPickerOkayButton or (ColorPickerFrame.GetName and _G[ColorPickerFrame:GetName() .. "OkayButton"]);
	local cancelButton = ColorPickerCancelButton or (ColorPickerFrame.GetName and _G[ColorPickerFrame:GetName() .. "CancelButton"]);
	local previousOkay = okayButton and okayButton:GetScript("OnClick");
	local previousCancel = cancelButton and cancelButton:GetScript("OnClick");
	local previousFunc = ColorPickerFrame.func;
	local previousOpacityFunc = ColorPickerFrame.opacityFunc;
	local previousCancelFunc = ColorPickerFrame.cancelFunc;
	local previousHasOpacity = ColorPickerFrame.hasOpacity;

	local function restoreScripts()
		if okayButton then
			okayButton:SetScript("OnClick", previousOkay);
		end
		if cancelButton then
			cancelButton:SetScript("OnClick", previousCancel);
		end
		ColorPickerFrame.func = previousFunc;
		ColorPickerFrame.opacityFunc = previousOpacityFunc;
		ColorPickerFrame.cancelFunc = previousCancelFunc;
		ColorPickerFrame.hasOpacity = previousHasOpacity;
	end

	ColorPickerFrame:SetColorRGB((red or 255) / 255, (green or 255) / 255, (blue or 255) / 255);
	ColorPickerFrame.hasOpacity = false;
	ColorPickerFrame.func = function() end;
	ColorPickerFrame.opacityFunc = function() end;
	ColorPickerFrame.cancelFunc = function(...)
		restoreScripts();
		if previousCancelFunc then
			previousCancelFunc(...);
		end
	end;

	if okayButton then
		okayButton:SetScript("OnClick", function(self, ...)
			local selectedRed, selectedGreen, selectedBlue = ColorPickerFrame:GetColorRGB();
			if previousOkay then
				previousOkay(self, ...);
			else
				ColorPickerFrame:Hide();
			end
			restoreScripts();
			callback(selectedRed * 255, selectedGreen * 255, selectedBlue * 255);
		end);
	end
	if cancelButton then
		cancelButton:SetScript("OnClick", function(self, ...)
			if previousCancel then
				previousCancel(self, ...);
			else
				ColorPickerFrame:Hide();
				restoreScripts();
			end
		end);
	end

	ColorPickerFrame:Show();
end

local function createCustomRelation(profileID, unitID, callback, useStandaloneColorBrowser)
	showTextInputPopup("Relationship name", function(text)
		local name = strtrim(tostring(text or ""));
		if name == "" then
			return;
		end
		runAfterFrames(function()
			local colorBrowser = useStandaloneColorBrowser and showStandaloneColorBrowser or showColorBrowser;
			colorBrowser(function(red, green, blue)
				local relationID = getCustomRelationID(name);
				ensureCustomRelations()[relationID] = {
					name = name,
					color = rgbToHex(red, green, blue),
					icon = DEFAULT_CUSTOM_RELATION_ICON,
				};
				if profileID then
					setRelation(profileID, relationID);
					if unitID then
						Events.fireEvent(Events.REGISTER_DATA_UPDATED, unitID, profileID, "characteristics");
					else
						Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, profileID, "characteristics");
					end
				end
				if callback then
					callback(relationID);
				end
			end, 0, 255, 0);
		end, 4);
	end);
end

local function updateCustomRelation(relationID, updates)
	local relation = ensureCustomRelations()[relationID];
	if not relation then
		return;
	end
	for key, value in pairs(updates or EMPTY) do
		relation[key] = value;
	end
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, nil, "relationship");
end
TRP3_API.register.relation.updateCustomRelation = updateCustomRelation;

local function deleteCustomRelation(relationID)
	local customRelations = ensureCustomRelations();
	if not customRelations[relationID] then
		return;
	end
	customRelations[relationID] = nil;
	local profile = getPlayerCurrentProfile();
	if profile and profile.relation then
		for profileID, relation in pairs(profile.relation) do
			if relation == relationID then
				profile.relation[profileID] = RELATIONS.NONE;
				Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, profileID, "characteristics");
			end
		end
	end
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, nil, "relationship");
end
TRP3_API.register.relation.deleteCustomRelation = deleteCustomRelation;

local function updateRelationOverride(relationID, updates)
	local override = ensureRelationOverrides()[relationID] or {};
	for key, value in pairs(updates or EMPTY) do
		override[key] = value;
	end
	ensureRelationOverrides()[relationID] = override;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, nil, "relationship");
end
TRP3_API.register.relation.updateRelationOverride = updateRelationOverride;

local function resetRelationOverride(relationID)
	ensureRelationOverrides()[relationID] = nil;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, nil, "relationship");
end
TRP3_API.register.relation.resetRelationOverride = resetRelationOverride;

setRelation = function(profileID, relation)
	local profile = getPlayerCurrentProfile();
	if not profile.relation then
		profile.relation = {};
	end
	profile.relation[profileID] = relation;
end
TRP3_API.register.relation.setRelation = setRelation;

local function getRelation(profileID)
	local relationTab = get("relation") or EMPTY;
	return relationTab[profileID] or RELATIONS.NONE;
end
TRP3_API.register.relation.getRelation = getRelation;

local function getRelationText(profileID)
	local relation = getRelation(profileID);
	local customRelation = getCustomRelation(relation);
	if customRelation then
		return customRelation.name or "";
	end
	local override = getRelationOverrides()[relation];
	if override and override.name and override.name ~= "" then
		return override.name;
	end
	if relation == RELATIONS.NONE then
		return "";
	end
	return loc("REG_RELATION_" .. relation);
end
TRP3_API.register.relation.getRelationText = getRelationText;

local function getRelationTooltipText(profileID, profile)
	local relation = getRelation(profileID);
	local customRelation = getCustomRelation(relation);
	if customRelation then
		return ("%s: %s"):format(getCompleteName(profile.characteristics or EMPTY, UNKNOWN, true), customRelation.name or "");
	end
	return loc("REG_RELATION_" .. getRelation(profileID) .. "_TT"):format(getPlayerCompleteName(true), getCompleteName(profile.characteristics or EMPTY, UNKNOWN, true));
end
TRP3_API.register.relation.getRelationTooltipText = getRelationTooltipText;

local function getRelationTexture(profileID)
	local relation = getRelation(profileID);
	local customRelation = getCustomRelation(relation);
	if customRelation then
		return customRelation.icon or DEFAULT_CUSTOM_RELATION_ICON;
	end
	local override = getRelationOverrides()[relation];
	if override and override.icon and override.icon ~= "" then
		return override.icon;
	end
	return RELATIONS_TEXTURES[relation];
end
TRP3_API.register.relation.getRelationTexture = getRelationTexture;

local function getRelationColors(profileID)
	local relation = getRelation(profileID);
	local customRelation = getCustomRelation(relation);
	if customRelation then
		return hexToRgb(customRelation.color);
	end
	local override = getRelationOverrides()[relation];
	if override and override.color and override.color ~= "" then
		return hexToRgb(override.color);
	end
	if relation == RELATIONS.NONE then
		return 1, 1, 1;
	elseif relation == RELATIONS.UNFRIENDLY then
		return 1, 0, 0;
	elseif relation == RELATIONS.NEUTRAL then
		return 0.5, 0.5, 1;
	elseif relation == RELATIONS.BUSINESS then
		return 1, 1, 0;
	elseif relation == RELATIONS.FRIEND then
		return 0, 1, 0;
	elseif relation == RELATIONS.LOVE then
		return 1, 0.5, 1;
	elseif relation == RELATIONS.FAMILY then
		return 1, 0.75, 0;
	end
end
TRP3_API.register.relation.getRelationColors = getRelationColors;

local function appendRelationOptions(values)
	tinsert(values, {loc("REG_RELATION_NONE"), RELATIONS.NONE});
	for _, relationID in ipairs({ RELATIONS.UNFRIENDLY, RELATIONS.NEUTRAL, RELATIONS.BUSINESS, RELATIONS.FRIEND, RELATIONS.LOVE, RELATIONS.FAMILY }) do
		local override = getRelationOverrides()[relationID];
		local label = override and override.name and override.name ~= "" and override.name or loc("REG_RELATION_" .. relationID);
		if override and override.color and override.color ~= "" then
			label = "|cff" .. override.color .. label .. "|r";
		end
		tinsert(values, {label, relationID});
	end
	for relationID, relationData in pairs(getCustomRelations()) do
		if relationData and relationData.name then
			local color = relationData.color or "ffffff";
			tinsert(values, {"|cff" .. color .. relationData.name .. "|r", relationID});
		end
	end
	tinsert(values, {"Create new relationship", CREATE_CUSTOM_RELATION});
end
TRP3_API.register.relation.appendRelationOptions = appendRelationOptions;
TRP3_API.register.relation.createCustomRelation = createCustomRelation;
TRP3_API.register.relation.CREATE_CUSTOM_RELATION = CREATE_CUSTOM_RELATION;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Relationship manager
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local RELATIONSHIP_MANAGER_PAGE_ID = "relationships_manager";
local relationshipPage;
local relationshipRows = {};
local BUILTIN_RELATION_ORDER = {
	RELATIONS.UNFRIENDLY,
	RELATIONS.NEUTRAL,
	RELATIONS.BUSINESS,
	RELATIONS.FRIEND,
	RELATIONS.LOVE,
	RELATIONS.FAMILY,
};

local BUILTIN_RELATION_COLORS = {
	[RELATIONS.UNFRIENDLY] = "ff0000",
	[RELATIONS.NEUTRAL] = "8080ff",
	[RELATIONS.BUSINESS] = "ffff00",
	[RELATIONS.FRIEND] = "00ff00",
	[RELATIONS.LOVE] = "ff80ff",
	[RELATIONS.FAMILY] = "ffbf00",
};

local getSortedCustomRelationshipIDs;

local function getRelationshipManagerEntries()
	local entries = {};
	for _, relationID in ipairs(BUILTIN_RELATION_ORDER) do
		tinsert(entries, {
			id = relationID,
			isBuiltin = true,
			data = getRelationOverrides()[relationID] or EMPTY,
		});
	end
	for _, relationID in ipairs(getSortedCustomRelationshipIDs()) do
		tinsert(entries, {
			id = relationID,
			isBuiltin = false,
			data = getCustomRelations()[relationID],
		});
	end
	return entries;
end

local function getRelationManagerDisplay(entry)
	local relationData = entry.data or EMPTY;
	if entry.isBuiltin then
		return {
			name = relationData.name or loc("REG_RELATION_" .. entry.id),
			color = relationData.color or BUILTIN_RELATION_COLORS[entry.id] or "ffffff",
			icon = relationData.icon or RELATIONS_TEXTURES[entry.id] or DEFAULT_CUSTOM_RELATION_ICON,
		};
	end
	return {
		name = relationData.name or "Relationship",
		color = relationData.color or "ffffff",
		icon = relationData.icon or DEFAULT_CUSTOM_RELATION_ICON,
	};
end

getSortedCustomRelationshipIDs = function()
	local ids = {};
	for relationID, relationData in pairs(getCustomRelations()) do
		if relationData and relationData.name then
			tinsert(ids, relationID);
		end
	end
	table.sort(ids, function(leftID, rightID)
		local left = getCustomRelations()[leftID] or EMPTY;
		local right = getCustomRelations()[rightID] or EMPTY;
		return tostring(left.name or ""):lower() < tostring(right.name or ""):lower();
	end);
	return ids;
end

local function getOrCreateRelationshipRow(index)
	if relationshipRows[index] then
		return relationshipRows[index];
	end

	local row = CreateFrame("Frame", "TRP3_RelationshipManagerRow" .. index, relationshipPage);
	row:SetSize(560, 38);
	if index == 1 then
		row:SetPoint("TOPLEFT", relationshipPage, "TOPLEFT", 34, -94);
	else
		row:SetPoint("TOPLEFT", relationshipRows[index - 1], "BOTTOMLEFT", 0, -6);
	end

	row.iconButton = CreateFrame("Button", row:GetName() .. "Icon", row, "TRP3_IconButton");
	row.iconButton:SetSize(28, 28);
	row.iconButton:SetPoint("LEFT", row, "LEFT", 0, 0);

	row.nameText = row:CreateFontString(row:GetName() .. "Name", "OVERLAY", "GameFontNormal");
	row.nameText:SetPoint("LEFT", row.iconButton, "RIGHT", 12, 0);
	row.nameText:SetWidth(230);
	row.nameText:SetJustifyH("LEFT");

	row.colorButton = CreateFrame("Button", row:GetName() .. "Color", row, "TRP3_ColorPickerButton");
	row.colorButton:SetSize(24, 24);
	row.colorButton:SetPoint("LEFT", row.nameText, "RIGHT", 14, 0);

	row.renameButton = CreateFrame("Button", row:GetName() .. "Rename", row, "TRP3_EditButton");
	row.renameButton:SetPoint("LEFT", row.colorButton, "RIGHT", 18, 0);

	row.deleteButton = CreateFrame("Button", row:GetName() .. "Delete", row, "TRP3_CloseEditButton");
	row.deleteButton:SetPoint("LEFT", row.renameButton, "RIGHT", 10, 0);

	relationshipRows[index] = row;
	return row;
end

local function refreshRelationshipManager()
	if not relationshipPage then
		return;
	end

	local entries = getRelationshipManagerEntries();
	if #entries == 0 then
		relationshipPage.emptyText:Show();
	else
		relationshipPage.emptyText:Hide();
	end

	for index, entry in ipairs(entries) do
		local relationID = entry.id;
		local display = getRelationManagerDisplay(entry);
		local row = getOrCreateRelationshipRow(index);
		local color = display.color or "ffffff";
		row.relationID = relationID;
		row:Show();
		setupIconButton(row.iconButton, display.icon or DEFAULT_CUSTOM_RELATION_ICON);
		row.nameText:SetText("|cff" .. color .. tostring(display.name or "Relationship") .. "|r");

		local red, green, blue = hexToColorBrowserRgb(color);
		row.colorButton.onSelection = nil;
		row.colorButton.setColor(red, green, blue);
		row.colorButton.onSelection = function(selectedRed, selectedGreen, selectedBlue)
			if selectedRed and selectedGreen and selectedBlue then
				if entry.isBuiltin then
					updateRelationOverride(relationID, { color = rgbToHex(selectedRed, selectedGreen, selectedBlue) });
				else
					updateCustomRelation(relationID, { color = rgbToHex(selectedRed, selectedGreen, selectedBlue) });
				end
				refreshRelationshipManager();
			end
		end;

		row.iconButton:SetScript("OnClick", function()
			showIconBrowser(function(icon)
				if entry.isBuiltin then
					updateRelationOverride(relationID, { icon = icon or RELATIONS_TEXTURES[relationID] or DEFAULT_CUSTOM_RELATION_ICON });
				else
					updateCustomRelation(relationID, { icon = icon or DEFAULT_CUSTOM_RELATION_ICON });
				end
				refreshRelationshipManager();
			end);
		end);
		setTooltipForSameFrame(row.iconButton, "TOP", 0, 0, "Icon", "Change this relationship's icon.");

		row.renameButton:SetScript("OnClick", function()
			showTextInputPopup("Relationship name", function(text)
				local name = strtrim(tostring(text or ""));
				if name ~= "" then
					if entry.isBuiltin then
						updateRelationOverride(relationID, { name = name });
					else
						updateCustomRelation(relationID, { name = name });
					end
					refreshRelationshipManager();
				end
			end, nil, display.name or "");
		end);
		setTooltipForSameFrame(row.renameButton, "TOP", 0, 0, "Rename");

		if entry.isBuiltin then
			row.deleteButton:SetScript("OnClick", function()
				resetRelationOverride(relationID);
				refreshRelationshipManager();
			end);
			setTooltipForSameFrame(row.deleteButton, "TOP", 0, 0, "Reset", "Restore the built-in name, color, and icon.");
		else
			row.deleteButton:SetScript("OnClick", function()
				showConfirmPopup("Delete relationship |cff" .. color .. tostring(display.name or "Relationship") .. "|r?", function()
					deleteCustomRelation(relationID);
					refreshRelationshipManager();
				end);
			end);
			setTooltipForSameFrame(row.deleteButton, "TOP", 0, 0, "Delete");
		end
	end

	for index = #entries + 1, #relationshipRows do
		relationshipRows[index]:Hide();
	end
end

local function createRelationshipManagerPage()
	if relationshipPage then
		return relationshipPage;
	end
	relationshipPage = CreateFrame("Frame", "TRP3_RelationshipsPage", UIParent);

	local title = relationshipPage:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge");
	title:SetPoint("TOPLEFT", relationshipPage, "TOPLEFT", 30, -28);
	title:SetText("Relationships");

	local createButton = CreateFrame("Button", "TRP3_RelationshipsCreateButton", relationshipPage, "TRP3_CommonButton");
	createButton:SetPoint("TOPRIGHT", relationshipPage, "TOPRIGHT", -34, -24);
	createButton:SetText("Create");
	createButton:SetScript("OnClick", function()
		createCustomRelation(nil, nil, refreshRelationshipManager);
	end);

	local header = relationshipPage:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall");
	header:SetPoint("TOPLEFT", relationshipPage, "TOPLEFT", 34, -72);
	header:SetText("Custom relationships");

	relationshipPage.emptyText = relationshipPage:CreateFontString(nil, "OVERLAY", "GameFontDisable");
	relationshipPage.emptyText:SetPoint("TOPLEFT", relationshipPage, "TOPLEFT", 34, -104);
	relationshipPage.emptyText:SetText("No custom relationships yet.");

	return relationshipPage;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Ignore list
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function isIDIgnored(ID)
	ensureIgnoreState();
	return blackList[ID] ~= nil;
end
TRP3_API.register.isIDIgnored = isIDIgnored;

local function ignoreID(unitID, reason)
	ensureIgnoreState();
	if reason:len() == 0 then
		reason = loc("TF_IGNORE_NO_REASON");
	end
	blackList[unitID] = reason;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, unitID, hasProfile(unitID), nil);
end
TRP3_API.register.ignoreID = ignoreID;

local function ignoreIDConfirm(unitID)
	showTextInputPopup(loc("TF_IGNORE_CONFIRM"):format(unitID), function(text)
		ignoreID(unitID, text);
	end);
end
TRP3_API.register.ignoreIDConfirm = ignoreIDConfirm;

local function getIgnoreReason(unitID)
	ensureIgnoreState();
	return blackList[unitID];
end
TRP3_API.register.getIgnoreReason = getIgnoreReason;

function TRP3_API.register.getIDsToPurge()
	ensureIgnoreState();
	local profileToPurge = {};
	local characterToPurge = {};
	for unitID, reason in pairs(blackList) do
		if characters[unitID] then
			tinsert(characterToPurge, unitID);
			if characters[unitID].profileID then
				tinsert(profileToPurge, characters[unitID].profileID);
			end
		end
	end
	return profileToPurge, characterToPurge;
end

function TRP3_API.register.unignoreID(unitID)
	ensureIgnoreState();
	blackList[unitID] = nil;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, unitID, hasProfile(unitID), nil);
end

function TRP3_API.register.getIgnoredList()
	ensureIgnoreState();
	return blackList;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Init
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function onRelationSelected(value)
	local unitID = getUnitID("target");
	if hasProfile(unitID) then
		if value == CREATE_CUSTOM_RELATION then
			local profileID = hasProfile(unitID);
			if CloseDropDownMenus then
				CloseDropDownMenus();
			end
			runAfterFrames(function()
				createCustomRelation(profileID, unitID, nil, true);
			end, 2);
			return;
		end
		setRelation(hasProfile(unitID), value);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, unitID, hasProfile(unitID), "characteristics");
	end
end

local function onTargetButtonClicked(unitID, _, _, button)
	local profileID = hasProfile(unitID);
	local values = {};
	tinsert(values, {loc("REG_RELATION"), nil});
	appendRelationOptions(values);
	displayDropDown(button, values, onRelationSelected, 0, true);
end

Events.listenToEvent(Events.WORKFLOW_ON_LOAD, function()
	getCompleteName, getPlayerCompleteName = TRP3_API.register.getCompleteName, TRP3_API.register.getPlayerCompleteName;
	ensureIgnoreState();
end);

TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_LOADED, function()
	createRelationshipManagerPage();
	registerPage({
		id = RELATIONSHIP_MANAGER_PAGE_ID,
		frame = relationshipPage,
		onPagePostShow = refreshRelationshipManager,
	});
	registerMenu({
		id = "main_40_relationships",
		text = "Relationships",
		onSelected = function() setPage(RELATIONSHIP_MANAGER_PAGE_ID); end,
	});

	if TRP3_API.target then
		-- Ignore button on target frame
		local player_id = TRP3_API.globals.player_id;
		TRP3_API.target.registerButton({
			id = "aa_player_z_ignore",
			configText = loc("TF_IGNORE"),
			onlyForType = TRP3_API.ui.misc.TYPE_CHARACTER,
			condition = function(targetType, unitID)
				return UnitIsPlayer("target") and unitID ~= player_id and not isIDIgnored(unitID);
			end,
			onClick = function(unitID)
				ignoreIDConfirm(unitID);
			end,
			tooltipSub = loc("TF_IGNORE_TT"),
			tooltip = loc("TF_IGNORE"),
			icon = "Achievement_BG_interruptX_flagcapture_attempts_1game"
		});

		TRP3_API.target.registerButton({
			id = "aa_player_d_relation",
			configText = loc("REG_RELATION"),
			onlyForType = TRP3_API.ui.misc.TYPE_CHARACTER,
			condition = function(targetType, unitID)
				return UnitIsPlayer("target") and unitID ~= player_id and hasProfile(unitID);
			end,
			onClick = onTargetButtonClicked,
			adapter = function(buttonStructure, unitID)
				local profileID = hasProfile(unitID);
				buttonStructure.tooltip = loc("REG_RELATION") .. ": " .. getRelationText(profileID);
				buttonStructure.tooltipSub = "|cff00ff00" .. getRelationTooltipText(profileID, getProfile(profileID)) .. "\n" .. loc("REG_RELATION_TARGET");
				buttonStructure.icon = getRelationTexture(profileID);
			end,
		});
	end
end);
