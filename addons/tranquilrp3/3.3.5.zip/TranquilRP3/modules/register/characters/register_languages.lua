----------------------------------------------------------------------------------
-- TranquilRP3
-- Character page : Languages
----------------------------------------------------------------------------------

local Globals, Utils, Events = TRP3_API.globals, TRP3_API.utils, TRP3_API.events;
local get = TRP3_API.profile.getData;
local getDefaultProfile = TRP3_API.profile.getDefaultProfile;
local getCurrentPageID = TRP3_API.navigation.page.getCurrentPageID;
local getPlayerCurrentProfileID = TRP3_API.profile.getPlayerCurrentProfileID;
local displayDropDown = TRP3_API.ui.listbox.displayDropDown;
local setTooltipForSameFrame = TRP3_API.ui.tooltip.setTooltipForSameFrame;
local showTextInputPopup = TRP3_API.popup.showTextInputPopup;
local loc = TRP3_API.locale.getText;
local CreateFrame = CreateFrame;
local UnitFactionGroup = UnitFactionGroup;

TRP3_API.register.languages = TRP3_API.register.languages or {};

getDefaultProfile().player.languages = {
	v = 1,
	FL = {},
	UN = {},
	CL = {},
	OR = {},
};

local languageLines = {};
local languageEditLines = {};
local languageConsultTitle;
local languageEditHeaderFrame;
local languageEditTitle;
local languageAddButton;
local currentCompressed;
local getLanguagesForDisplay;

local function getLanguageData(context)
	local profile = context and context.profile or get("player");
	if TRP3_API.tongues and TRP3_API.tongues.ensureLanguageData then
		return TRP3_API.tongues.ensureLanguageData(profile);
	end
	profile.languages = profile.languages or { v = 1, FL = {} };
	profile.languages.v = profile.languages.v or 1;
	profile.languages.FL = profile.languages.FL or {};
	profile.languages.UN = profile.languages.UN or {};
	for languageName, fluency in pairs(profile.languages.FL) do
		if profile.languages.UN[languageName] == nil then
			profile.languages.UN[languageName] = fluency;
		end
	end
	profile.languages.CL = profile.languages.CL or {};
	profile.languages.OR = profile.languages.OR or {};
	return profile.languages;
end

local function compressData()
	local data = get("player/languages") or getLanguageData({ profile = get("player") });
	local serial = Utils.serial.serialize(data);
	local compressed = Utils.serial.encodeCompressMessage(serial);
	if compressed:len() < serial:len() then
		currentCompressed = compressed;
	else
		currentCompressed = data;
	end
end

function TRP3_API.register.player.getLanguagesExchangeData()
	if TRP3_API.tongues and TRP3_API.tongues.syncKnownGameLanguages then
		TRP3_API.tongues.syncKnownGameLanguages();
	end
	compressData();
	return currentCompressed or get("player/languages") or getLanguageData({ profile = get("player") });
end

local function saveLanguageValue(languageName, fieldName, value)
	local data = get("player/languages") or getLanguageData({ profile = get("player") });
	data[fieldName] = data[fieldName] or {};
	if data[fieldName][languageName] ~= value then
		data[fieldName][languageName] = value;
		data.v = Utils.math.incrementNumber(data.v or 1, 2);
		compressData();
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, getPlayerCurrentProfileID(), "languages");
		if TRP3_API.tongues and TRP3_API.tongues.refreshSettings then
			TRP3_API.tongues.refreshSettings();
		end
	end
end

local function saveLanguageFluency(languageName, value)
	saveLanguageValue(languageName, "FL", value);
end

local function saveLanguageUnderstanding(languageName, value)
	saveLanguageValue(languageName, "UN", value);
end

local function saveLanguageOrder(languageOrder)
	local data = get("player/languages") or getLanguageData({ profile = get("player") });
	data.OR = {};
	local addedLanguages = {};
	for _, languageName in ipairs(languageOrder or {}) do
		if languageName and languageName ~= "" and not addedLanguages[languageName] then
			tinsert(data.OR, languageName);
			addedLanguages[languageName] = true;
		end
	end
	data.v = Utils.math.incrementNumber(data.v or 1, 2);
	compressData();
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, Globals.player_id, getPlayerCurrentProfileID(), "languages");
	if TRP3_API.tongues and TRP3_API.tongues.refreshSettings then
		TRP3_API.tongues.refreshSettings();
	end
end

local function refreshCharacteristicsDisplay()
	if TRP3_API.register.ui.refreshCharacteristicsDisplay then
		TRP3_API.register.ui.refreshCharacteristicsDisplay();
	end
end

local function onLanguageDelete(self)
	local frame = self and self:GetParent();
	if frame and frame.languageName then
		saveLanguageFluency(frame.languageName, 0);
		saveLanguageUnderstanding(frame.languageName, 0);
		local languages = getLanguagesForDisplay({ profile = get("player"), isPlayer = true }, false);
		saveLanguageOrder(languages);
		refreshCharacteristicsDisplay();
	end
end

local function onLanguageMove(self)
	local frame = self and self:GetParent();
	local moveDirection = self and self.moveDirection;
	if not frame or not frame.languageName or not frame.languageIndex or not moveDirection then
		return;
	end

	local languages = getLanguagesForDisplay({ profile = get("player"), isPlayer = true }, false);
	local fromIndex = frame.languageIndex;
	local toIndex = fromIndex + moveDirection;
	if toIndex < 1 or toIndex > #languages then
		return;
	end

	languages[fromIndex], languages[toIndex] = languages[toIndex], languages[fromIndex];
	saveLanguageOrder(languages);
	refreshCharacteristicsDisplay();
end

local function getLanguageControlSuffix(languageField)
	if languageField == "UN" then
		return "Understand";
	end
	return "Speak";
end

local function updateLanguageControls(frame, languageField, value, saveValue, sourceControl)
	if not frame or frame.updating then
		return;
	end
	value = math.floor(tonumber(value) or 0);
	if value < 0 then
		value = 0;
	elseif value > 100 then
		value = 100;
	end

	local suffix = getLanguageControlSuffix(languageField);
	local slider = _G[frame:GetName() .. suffix .. "Slider"];
	local box = _G[frame:GetName() .. suffix .. "Value"];

	frame.updating = true;
	if box and sourceControl ~= box then
		box:SetText(value .. "%");
	end
	if slider and sourceControl ~= slider then
		slider:SetValue(value);
	end
	frame.updating = nil;

	if saveValue and frame.isPlayer and frame.languageName then
		if languageField == "UN" then
			saveLanguageUnderstanding(frame.languageName, value);
		else
			saveLanguageFluency(frame.languageName, value);
		end
	end
end

local function clampPercentage(value)
	value = math.floor(tonumber(value) or 0);
	if value < 0 then
		return 0;
	elseif value > 100 then
		return 100;
	end
	return value;
end

local function commitLanguageValueBox(box)
	if not box or not box.ownerFrame or box.ownerFrame.updating then
		return;
	end
	local value = clampPercentage((box:GetText() or ""):match("%d+"));
	box:SetText(value .. "%");
	box:ClearFocus();
	updateLanguageControls(box.ownerFrame, box.languageField, value, true, box);
end

local function onSliderChanged(slider, value)
	if not slider.languageName or not slider.ownerFrame or slider.ownerFrame.updating then
		return;
	end
	updateLanguageControls(slider.ownerFrame, slider.languageField, value or slider:GetValue(), true, slider);
end

local function setupLanguageValueBox(box, frame, slider)
	box:SetWidth(45);
	box:SetHeight(18);
	box:SetAutoFocus(false);
	box:SetMaxLetters(4);
	box:SetFontObject(GameFontNormalSmall);
	box:SetJustifyH("LEFT");
	box.ownerFrame = frame;
	box.slider = slider;
	box.languageField = slider.languageField;
	box:SetScript("OnEnterPressed", commitLanguageValueBox);
	box:SetScript("OnEscapePressed", function(self)
		local value = self.slider and self.slider:GetValue() or 0;
		self:SetText(clampPercentage(value) .. "%");
		self:ClearFocus();
	end);
	box:SetScript("OnEditFocusGained", function(self)
		self:HighlightText();
	end);
	box:SetScript("OnEditFocusLost", function(self)
		commitLanguageValueBox(self);
		self:HighlightText(0, 0);
	end);
end

local function setupLanguageSlider(slider, frame, languageField)
	slider:SetWidth(120);
	slider:SetMinMaxValues(0, 100);
	slider:SetValueStep(1);
	if slider.SetObeyStepOnDrag then
		slider:SetObeyStepOnDrag(true);
	end
	slider.ownerFrame = frame;
	slider.languageField = languageField;
	slider:SetScript("OnValueChanged", onSliderChanged);
	_G[slider:GetName() .. "Low"]:SetText("");
	_G[slider:GetName() .. "High"]:SetText("");
	_G[slider:GetName() .. "Text"]:SetText("");
end

local function createLanguageLine(index, parent, prefix, cache)
	local frame = CreateFrame("Frame", prefix .. index, parent);
	frame:SetHeight(56);
	frame:SetWidth(500);

	local icon = frame:CreateTexture(frame:GetName() .. "Icon", "ARTWORK");
	icon:SetWidth(24);
	icon:SetHeight(24);
	icon:SetPoint("LEFT", frame, "LEFT", 8, 0);

	local divider = frame:CreateTexture(frame:GetName() .. "Divider", "ARTWORK");
	divider:SetHeight(1);
	divider:SetPoint("TOPLEFT", frame, "TOPLEFT", 4, -2);
	divider:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -28, -2);
	divider:SetTexture(1, 1, 1, 0.1);

	local name = frame:CreateFontString(frame:GetName() .. "Name", "OVERLAY", "GameFontNormal");
	name:SetPoint("LEFT", icon, "RIGHT", 8, 0);
	name:SetWidth(110);
	name:SetJustifyH("LEFT");

	local speakLabel = frame:CreateFontString(frame:GetName() .. "SpeakLabel", "OVERLAY", "GameFontNormalSmall");
	speakLabel:SetPoint("LEFT", name, "RIGHT", 8, 10);
	speakLabel:SetWidth(72);
	speakLabel:SetJustifyH("LEFT");
	speakLabel:SetText("Speak");

	local speakSlider = CreateFrame("Slider", frame:GetName() .. "SpeakSlider", frame, "OptionsSliderTemplate");
	speakSlider:SetPoint("LEFT", speakLabel, "RIGHT", 8, 0);
	setupLanguageSlider(speakSlider, frame, "FL");

	local speakValueText = CreateFrame("EditBox", frame:GetName() .. "SpeakValue", frame, "InputBoxTemplate");
	speakValueText:SetPoint("LEFT", speakSlider, "RIGHT", 18, 0);
	setupLanguageValueBox(speakValueText, frame, speakSlider);

	local understandLabel = frame:CreateFontString(frame:GetName() .. "UnderstandLabel", "OVERLAY", "GameFontNormalSmall");
	understandLabel:SetPoint("LEFT", name, "RIGHT", 8, -14);
	understandLabel:SetWidth(72);
	understandLabel:SetJustifyH("LEFT");
	understandLabel:SetText("Understand");

	local understandSlider = CreateFrame("Slider", frame:GetName() .. "UnderstandSlider", frame, "OptionsSliderTemplate");
	understandSlider:SetPoint("LEFT", understandLabel, "RIGHT", 8, 0);
	setupLanguageSlider(understandSlider, frame, "UN");

	local understandValueText = CreateFrame("EditBox", frame:GetName() .. "UnderstandValue", frame, "InputBoxTemplate");
	understandValueText:SetPoint("LEFT", understandSlider, "RIGHT", 18, 0);
	setupLanguageValueBox(understandValueText, frame, understandSlider);

	cache[index] = frame;
	return frame;
end

local function createLanguageMoveButton(frame, suffix, normalTexture, pushedTexture, direction)
	local button = CreateFrame("Button", frame:GetName() .. suffix, frame);
	button:SetWidth(18);
	button:SetHeight(18);
	button:SetNormalTexture(normalTexture);
	button:SetPushedTexture(pushedTexture or normalTexture);
	button:SetDisabledTexture(normalTexture);
	button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD");
	button.moveDirection = direction;
	button:SetScript("OnClick", onLanguageMove);
	setTooltipForSameFrame(button, "TOP", 0, 5, direction < 0 and "Move up" or "Move down");
	return button;
end

getLanguagesForDisplay = function(context, editMode)
	if context and context.isPlayer and TRP3_API.tongues and TRP3_API.tongues.syncKnownGameLanguages then
		TRP3_API.tongues.syncKnownGameLanguages();
	end

	local data = getLanguageData(context or { profile = get("player") });
	local languages = TRP3_API.tongues and TRP3_API.tongues.getLanguageList and TRP3_API.tongues.getLanguageList(false) or {};
	local availableLanguages = {};
	local displayLanguages = {};
	for _, languageName in ipairs(languages) do
		local fluency = tonumber(data.FL[languageName]) or 0;
		local understanding = tonumber(data.UN[languageName]) or fluency;
		if editMode or fluency > 0 or understanding > 0 then
			availableLanguages[languageName] = true;
		end
	end

	local addedLanguages = {};
	for _, languageName in ipairs(data.OR or {}) do
		if availableLanguages[languageName] and not addedLanguages[languageName] then
			tinsert(displayLanguages, languageName);
			addedLanguages[languageName] = true;
		end
	end

	for _, languageName in ipairs(languages) do
		if availableLanguages[languageName] and not addedLanguages[languageName] then
			tinsert(displayLanguages, languageName);
			addedLanguages[languageName] = true;
		end
	end

	return displayLanguages, data;
end

local function configureLanguageLine(frame, languageName, fluency, understanding, isEditable)
	frame.isPlayer = isEditable;
	frame.languageName = languageName;
	frame.updating = true;
	frame:Show();
	_G[frame:GetName() .. "Icon"]:SetTexture("Interface\\ICONS\\" .. ((TRP3_API.tongues and TRP3_API.tongues.getLanguageIcon and TRP3_API.tongues.getLanguageIcon(languageName)) or "INV_Misc_Note_01"));
	if _G[frame:GetName() .. "Divider"] then
		if (frame.languageIndex or 1) > 1 then
			_G[frame:GetName() .. "Divider"]:Show();
		else
			_G[frame:GetName() .. "Divider"]:Hide();
		end
	end
	_G[frame:GetName() .. "Name"]:SetText(languageName);
	_G[frame:GetName() .. "SpeakSlider"].languageName = languageName;
	_G[frame:GetName() .. "SpeakSlider"]:SetValue(fluency);
	_G[frame:GetName() .. "SpeakSlider"]:EnableMouse(isEditable);
	_G[frame:GetName() .. "SpeakValue"]:SetText(fluency .. "%");
	_G[frame:GetName() .. "SpeakValue"]:EnableMouse(isEditable);
	_G[frame:GetName() .. "SpeakValue"]:SetTextColor(isEditable and 1 or 0.8, isEditable and 1 or 0.8, isEditable and 1 or 0.8);
	_G[frame:GetName() .. "UnderstandSlider"].languageName = languageName;
	_G[frame:GetName() .. "UnderstandSlider"]:SetValue(understanding);
	_G[frame:GetName() .. "UnderstandSlider"]:EnableMouse(isEditable);
	_G[frame:GetName() .. "UnderstandValue"]:SetText(understanding .. "%");
	_G[frame:GetName() .. "UnderstandValue"]:EnableMouse(isEditable);
	_G[frame:GetName() .. "UnderstandValue"]:SetTextColor(isEditable and 1 or 0.8, isEditable and 1 or 0.8, isEditable and 1 or 0.8);
	if isEditable then
		if not frame.moveUpButton then
			frame.moveUpButton = createLanguageMoveButton(frame, "MoveUp", "Interface\\Buttons\\Arrow-Up-Up", "Interface\\Buttons\\Arrow-Up-Down", -1);
			frame.moveUpButton:SetPoint("LEFT", _G[frame:GetName() .. "SpeakValue"], "RIGHT", 8, 2);
			frame.moveDownButton = createLanguageMoveButton(frame, "MoveDown", "Interface\\Buttons\\Arrow-Down-Up", "Interface\\Buttons\\Arrow-Down-Down", 1);
			frame.moveDownButton:SetPoint("TOP", frame.moveUpButton, "BOTTOM", 0, -2);
		end
		if not frame.deleteButton then
			frame.deleteButton = CreateFrame("Button", frame:GetName() .. "Delete", frame, "TRP3_CloseEditButton");
			frame.deleteButton:SetPoint("LEFT", frame.moveUpButton, "RIGHT", 8, -10);
			frame.deleteButton:SetScript("OnClick", onLanguageDelete);
			setTooltipForSameFrame(frame.deleteButton, "TOP", 0, 5, loc("CM_REMOVE"));
		end
		frame.moveUpButton.languageName = languageName;
		frame.moveUpButton.languageIndex = frame.languageIndex;
		frame.moveUpButton.moveDirection = -1;
		frame.moveDownButton.languageName = languageName;
		frame.moveDownButton.languageIndex = frame.languageIndex;
		frame.moveDownButton.moveDirection = 1;
		if (frame.languageIndex or 1) <= 1 then
			frame.moveUpButton:Disable();
		else
			frame.moveUpButton:Enable();
		end
		if (frame.languageIndex or 1) >= (frame.languageCount or frame.languageIndex or 1) then
			frame.moveDownButton:Disable();
		else
			frame.moveDownButton:Enable();
		end
		frame.moveUpButton:Show();
		frame.moveDownButton:Show();
		frame.deleteButton:Show();
	else
		if frame.moveUpButton then
			frame.moveUpButton:Hide();
		end
		if frame.moveDownButton then
			frame.moveDownButton:Hide();
		end
		if frame.deleteButton then
			frame.deleteButton:Hide();
		end
	end
	frame.updating = nil;
end

local function ensureTitle(name, parent)
	local title = _G[name];
	if not title then
		title = parent:CreateFontString(name, "OVERLAY", "GameFontNormalLarge");
		title:SetWidth(500);
		title:SetHeight(30);
		title:SetJustifyH("LEFT");
		title:SetText("Languages");
		title:SetTextColor(0.95, 0.95, 0.95);
	end
	return title;
end

function TRP3_API.register.languages.renderConsult(parent, previous, context, margin)
	languageConsultTitle = ensureTitle("TRP3_RegisterCharact_CharactPanel_LanguagesTitle", parent);
	for _, frame in pairs(languageLines) do frame:Hide(); end
	if context and context.isCompanion then
		languageConsultTitle:Hide();
		return previous, false, margin;
	end

	local languages, data = getLanguagesForDisplay(context, false);
	if #languages == 0 then
		languageConsultTitle:Hide();
		return previous, false, margin;
	end

	languageConsultTitle:ClearAllPoints();
	languageConsultTitle:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, margin);
	languageConsultTitle:Show();
	previous = languageConsultTitle;

	for index, languageName in ipairs(languages) do
		local frame = languageLines[index] or createLanguageLine(index, parent, "TRP3_RegisterCharact_LanguageInfoLine", languageLines);
		frame.languageIndex = index;
		frame.languageCount = #languages;
		frame:ClearAllPoints();
		frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, 0);
		frame:SetPoint("RIGHT", 0, 0);
		local fluency = tonumber(data.FL[languageName]) or 0;
		configureLanguageLine(frame, languageName, fluency, tonumber(data.UN[languageName]) or fluency, false);
		previous = frame;
	end

	return previous, true, 0;
end

local function getLanguageDropdown()
	local _, data = getLanguagesForDisplay({ profile = get("player"), isPlayer = true }, true);
	local languages = TRP3_API.tongues and TRP3_API.tongues.getLanguageList and TRP3_API.tongues.getLanguageList(false) or {};
	local availableLanguages = {};
	local availableMap = {};
	local values = {};
	tinsert(values, { "Add language" });
	tinsert(values, { "Create Custom Language", "__custom" });
	for _, languageName in ipairs(languages) do
		if (tonumber(data.FL[languageName]) or 0) <= 0 and (tonumber(data.UN[languageName]) or 0) <= 0 then
			tinsert(availableLanguages, languageName);
			availableMap[languageName] = true;
		end
	end

	local function buildFactionSubmenu(languageOrder)
		local submenu = {};
		for _, languageName in ipairs(languageOrder) do
			if availableMap[languageName] then
				tinsert(submenu, { languageName, languageName });
			end
		end
		return submenu;
	end

	local allianceLanguages = { "Common", "Darnassian", "Dwarvish", "Gnomish", "Draenei" };
	local hordeLanguages = { "Orcish", "Taurahe", "Troll", "Gutterspeak", "Thalassian" };
	local firstFactionLanguages, firstFactionTitle, secondFactionLanguages, secondFactionTitle;
	if UnitFactionGroup("player") == "Horde" then
		firstFactionLanguages, firstFactionTitle = hordeLanguages, "Horde languages";
		secondFactionLanguages, secondFactionTitle = allianceLanguages, "Alliance languages";
	else
		firstFactionLanguages, firstFactionTitle = allianceLanguages, "Alliance languages";
		secondFactionLanguages, secondFactionTitle = hordeLanguages, "Horde languages";
	end

	local firstFactionSubmenu = buildFactionSubmenu(firstFactionLanguages);
	local secondFactionSubmenu = buildFactionSubmenu(secondFactionLanguages);
	if #firstFactionSubmenu > 0 then
		tinsert(values, { firstFactionTitle, firstFactionSubmenu });
	end
	if #secondFactionSubmenu > 0 then
		tinsert(values, { secondFactionTitle, secondFactionSubmenu });
	end

	local factionLanguageMap = {};
	for _, languageName in ipairs(allianceLanguages) do factionLanguageMap[languageName] = true; end
	for _, languageName in ipairs(hordeLanguages) do factionLanguageMap[languageName] = true; end

	local otherLanguages = {};
	for _, languageName in ipairs(availableLanguages) do
		if not factionLanguageMap[languageName] then
			tinsert(otherLanguages, languageName);
		end
	end
	if #otherLanguages <= 18 then
		for _, languageName in ipairs(otherLanguages) do
			tinsert(values, { languageName, languageName });
		end
	elseif #otherLanguages > 0 then
		local groupSize = 12;
		local index = 1;
		while index <= #otherLanguages do
			local submenu = {};
			local firstLanguage = otherLanguages[index];
			local lastLanguage = otherLanguages[math.min(index + groupSize - 1, #otherLanguages)];
			for groupedIndex = index, math.min(index + groupSize - 1, #otherLanguages) do
				local languageName = otherLanguages[groupedIndex];
				tinsert(submenu, { languageName, languageName });
			end
			tinsert(values, { firstLanguage .. " - " .. lastLanguage, submenu });
			index = index + groupSize;
		end
	end
	return values;
end

local function createCustomLanguage()
	local languages = getLanguagesForDisplay({ profile = get("player"), isPlayer = true }, false);
	showTextInputPopup("Custom language name", function(text)
		local languageName = TRP3_API.tongues and TRP3_API.tongues.createCustomLanguage and TRP3_API.tongues.createCustomLanguage(text);
		if languageName then
			saveLanguageFluency(languageName, 100);
			saveLanguageUnderstanding(languageName, 100);
			tinsert(languages, languageName);
			saveLanguageOrder(languages);
			refreshCharacteristicsDisplay();
		end
	end);
end

local function onLanguageAdd(languageName)
	if languageName == "__custom" then
		createCustomLanguage();
	elseif languageName then
		local languages = getLanguagesForDisplay({ profile = get("player"), isPlayer = true }, false);
		saveLanguageFluency(languageName, 100);
		saveLanguageUnderstanding(languageName, 100);
		tinsert(languages, languageName);
		saveLanguageOrder(languages);
		refreshCharacteristicsDisplay();
	end
end

local function showLanguageDropdown()
	displayDropDown(languageAddButton, getLanguageDropdown(), onLanguageAdd, 0, true);
end

function TRP3_API.register.languages.renderEdit(parent, previous)
	TRP3_API.register.languages.hideEdit();
	if not languageEditHeaderFrame then
		languageEditHeaderFrame = CreateFrame("Frame", "TRP3_RegisterCharact_Edit_CharactPanel_RegisterLanguagesFrame", parent);
		languageEditHeaderFrame:SetWidth(500);
		languageEditHeaderFrame:SetHeight(30);
	end
	languageEditTitle = ensureTitle("TRP3_RegisterCharact_CharactPanel_Edit_LanguagesTitle", languageEditHeaderFrame);
	languageEditTitle:ClearAllPoints();
	languageEditTitle:SetPoint("TOPLEFT", languageEditHeaderFrame, "TOPLEFT", 0, 0);
	languageEditTitle:SetPoint("BOTTOMRIGHT", languageEditHeaderFrame, "BOTTOMRIGHT", 0, 0);
	if not languageAddButton then
		languageAddButton = CreateFrame("Button", "TRP3_RegisterCharact_Edit_LanguageAdd", parent, "TRP3_AddButton");
		languageAddButton:SetText("Add language");
		languageAddButton:SetScript("OnClick", showLanguageDropdown);
	end
	for _, frame in pairs(languageEditLines) do frame:Hide(); end

	local languages, data = getLanguagesForDisplay({ profile = get("player"), isPlayer = true }, false);

	languageEditHeaderFrame:ClearAllPoints();
	languageEditHeaderFrame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -10);
	languageEditHeaderFrame:SetPoint("RIGHT", 0, 0);
	languageEditHeaderFrame:Show();
	languageAddButton:ClearAllPoints();
	languageAddButton:SetPoint("RIGHT", languageEditHeaderFrame, "RIGHT", 0, 0);
	languageAddButton:Show();

	previous = languageEditHeaderFrame;
	for index, languageName in ipairs(languages) do
		local frame = languageEditLines[index] or createLanguageLine(index, parent, "TRP3_RegisterCharact_LanguageEditLine", languageEditLines);
		frame.languageIndex = index;
		frame.languageCount = #languages;
		frame:ClearAllPoints();
		frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, 0);
		frame:SetPoint("RIGHT", 0, 0);
		local fluency = tonumber(data.FL[languageName]) or 0;
		configureLanguageLine(frame, languageName, fluency, tonumber(data.UN[languageName]) or fluency, true);
		previous = frame;
	end

	return previous;
end

function TRP3_API.register.languages.hideEdit()
	if languageEditHeaderFrame then
		languageEditHeaderFrame:Hide();
	end
	if languageEditTitle then
		languageEditTitle:Hide();
	end
	if languageAddButton then
		languageAddButton:Hide();
	end
	for _, frame in pairs(languageEditLines) do
		frame:Hide();
	end
end

function TRP3_API.register.inits.languagesInit()
	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, _, dataType)
		if getCurrentPageID() == "player_main" and unitID == Globals.player_id and dataType == "languages" then
			compressData();
		end
	end);

	Events.listenToEvent(Events.REGISTER_PROFILES_LOADED, compressData);
	compressData();
end

function TRP3_API.tongues.getLanguageIcon(languageName)
	local icons = TRP3_API.tongues.LANGUAGE_ICONS or {};
	return icons[languageName] or "INV_Misc_Book_09";
end
