----------------------------------------------------------------------------------
-- Total RP 3
-- Directory : main API
-- ---------------------------------------------------------------------------
-- Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
-- http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
----------------------------------------------------------------------------------

-- Public accessor
TRP3_API.register = {
	inits = {},
	player = {},
	ui = {},
	NOTIFICATION_ID_NEW_CHARACTER = "add_character",
};

TRP3_API.register.MENU_LIST_ID = "main_30_register";
TRP3_API.register.MENU_LIST_ID_TAB = "main_31_";

-- imports
local Globals = TRP3_API.globals;
local Utils = TRP3_API.utils;
local stEtN = Utils.str.emptyToNil;
local loc = TRP3_API.locale.getText;
local log = Utils.log.log;
local buildZoneText = Utils.str.buildZoneText;
local getUnitID = Utils.str.getUnitID;
local unitIDToInfo = Utils.str.unitIDToInfo;
local UnitRace, UnitIsPlayer, UnitClass, UnitExists = UnitRace, UnitIsPlayer, UnitClass, UnitExists;
local UnitFactionGroup, UnitSex, GetGuildInfo, UnitName, UnitIsUnit, UnitCreatureFamily, UnitCreatureType = UnitFactionGroup, UnitSex, GetGuildInfo, UnitName, UnitIsUnit, UnitCreatureFamily, UnitCreatureType;
local get = TRP3_API.profile.getData;
local getPlayerCharacter = TRP3_API.profile.getPlayerCharacter;
local Config = TRP3_API.configuration;
local registerConfigKey = Config.registerConfigKey;
local getConfigValue = Config.getValue;
local Events = TRP3_API.events;
local assert, tostring, time, wipe, strconcat, pairs, tinsert = assert, tostring, time, wipe, strconcat, pairs, tinsert;
local registerMenu, selectMenu = TRP3_API.navigation.menu.registerMenu, TRP3_API.navigation.menu.selectMenu;
local registerPage, setPage = TRP3_API.navigation.page.registerPage, TRP3_API.navigation.page.setPage;
local getCurrentContext, getCurrentPageID = TRP3_API.navigation.page.getCurrentContext, TRP3_API.navigation.page.getCurrentPageID;
local showCharacteristicsTab, showAboutTab, showMiscTab, showNotesTab;
local UnitIsPVP = UnitIsPVP;

local EMPTY = Globals.empty;
-- Saved variables references
local profiles, characters;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- SCHEMA
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

TRP3_API.register.registerInfoTypes = {
	CHARACTERISTICS = "characteristics",
	ABOUT = "about",
	MISC = "misc",
	CHARACTER = "character",
	NOTES = "notes",
	LANGUAGES = "languages",
}

local registerInfoTypes = TRP3_API.register.registerInfoTypes;
local deleteProfile;
local COMPANION_PROFILE_PREFIX = "PET:";

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Tools
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function getProfile(profileID)
	assert(profiles[profileID], "Unknown profile ID: " .. tostring(profileID));
	return profiles[profileID];
end

TRP3_API.register.getProfile = getProfile;

local function isHeartbeatProfileID(profileID)
	return type(profileID) == "string" and string.match(profileID, "^%[HB%]") ~= nil;
end

local function profileHasLinks(profile)
	if not profile or not profile.link then
		return false;
	end
	for _ in pairs(profile.link) do
		return true;
	end
	return false;
end

local function deleteProfileIfOrphaned(profileID)
	if profileID and profiles[profileID] and isHeartbeatProfileID(profileID) and not profileHasLinks(profiles[profileID]) then
		deleteProfile(profileID, true);
	end
end

local function clearHeartbeatProfile(unitID)
	assert(unitID and characters and characters[unitID], "Unknown character: " .. tostring(unitID));

	local character = characters[unitID];
	local profileID = character.profileID;
	if not isHeartbeatProfileID(profileID) then
		return;
	end

	if profiles[profileID] and profiles[profileID].link then
		profiles[profileID].link[unitID] = nil;
	end
	character.profileID = nil;
	deleteProfileIfOrphaned(profileID);
end

TRP3_API.register.clearHeartbeatProfile = clearHeartbeatProfile;

deleteProfile = function(profileID, dontFireEvents)
	assert(profiles[profileID], "Unknown profile ID: " .. tostring(profileID));
	-- We shouldn't keep unbounded characters.
	for character, _ in pairs(profiles[profileID].link or EMPTY) do
		if characters[character] and characters[character].profileID == profileID then
			wipe(characters[character]);
			characters[character] = nil;
		end
	end
	local mspOwners = nil;
	if profiles[profileID].msp then
		mspOwners = {};
		for ownerID, _ in pairs(profiles[profileID].link or EMPTY) do
			tinsert(mspOwners, ownerID);
		end
	end
	wipe(profiles[profileID]);
	profiles[profileID] = nil;
	if not dontFireEvents then
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, profileID, nil);
		Events.fireEvent(Events.REGISTER_PROFILE_DELETED, profileID, mspOwners);
	end
end

TRP3_API.register.deleteProfile = deleteProfile;

local function deleteCharacter(unitID)
	assert(characters[unitID], "Unknown unitID: " .. tostring(unitID));
	if characters[unitID].profileID and profiles[characters[unitID].profileID] and profiles[characters[unitID].profileID].link then
		profiles[characters[unitID].profileID].link[unitID] = nil;
	end
	wipe(characters[unitID]);
	characters[unitID] = nil;
end

TRP3_API.register.deleteCharacter = deleteCharacter;

local function isUnitIDKnown(unitID)
	assert(unitID, "Nil unitID");
	return characters and characters[unitID] ~= nil;
end

TRP3_API.register.isUnitIDKnown = isUnitIDKnown;

local function hasProfile(unitID)
	assert(isUnitIDKnown(unitID), "Unknown character: " .. tostring(unitID));
	return characters[unitID].profileID;
end

TRP3_API.register.hasProfile = hasProfile;

local function profileExists(unitID)
	return isUnitIDKnown(unitID) and hasProfile(unitID) and profiles[characters[unitID].profileID];
end

TRP3_API.register.profileExists = profileExists;

local function createUnitIDProfile(unitID)
	assert(characters[unitID].profileID, "UnitID don't have a profileID: " .. unitID);
	assert(not profiles[characters[unitID].profileID], "Profile already exist: " .. characters[unitID].profileID);
	profiles[characters[unitID].profileID] = {};
	profiles[characters[unitID].profileID].link = {};
	return profiles[characters[unitID].profileID];
end

TRP3_API.register.createUnitIDProfile = createUnitIDProfile;

local function getUnitIDProfile(unitID)
	assert(profileExists(unitID), "No profile for character: " .. tostring(unitID));
	return profiles[characters[unitID].profileID];
end

TRP3_API.register.getUnitIDProfile = getUnitIDProfile;

local function getUnitIDCharacter(unitID)
	assert(isUnitIDKnown(unitID), "Unknown character: " .. tostring(unitID));
	return characters[unitID];
end

TRP3_API.register.getUnitIDCharacter = getUnitIDCharacter;

local function buildDirectoryLiteInfo(character)
	if not character then
		return nil;
	end

	local legacy = character.directoryLite;
	local info = {
		name = character.heartbeatName or legacy and legacy.name or nil,
		colorCode = character.heartbeatColor or legacy and legacy.colorCode or nil,
		icon = character.heartbeatIcon or legacy and legacy.icon or nil,
		zone = character.zone or legacy and legacy.zone or nil,
		x = character.zoneX or legacy and legacy.x or nil,
		y = character.zoneY or legacy and legacy.y or nil,
		mapId = character.mapID or legacy and legacy.mapId or nil,
		version = character.heartbeatVersion or legacy and legacy.version or nil,
		ic = character.heartbeatIC or legacy and legacy.ic or nil,
		faction = character.heartbeatFaction or legacy and legacy.faction or nil,
		instanceTag = character.heartbeatInstance or legacy and legacy.instanceTag or nil,
		client = character.client or legacy and legacy.client or nil,
	};

	if not info.name and not info.colorCode and not info.icon and not info.zone and not info.x and not info.y
		and not info.mapId and not info.version and not info.ic and not info.faction and not info.instanceTag and not info.client then
		return nil;
	end

	return info;
end

local function getUnitIDDirectoryLite(unitID)
	assert(isUnitIDKnown(unitID), "Unknown character: " .. tostring(unitID));
	local character = getUnitIDCharacter(unitID);
	return buildDirectoryLiteInfo(character);
end

TRP3_API.register.getUnitIDDirectoryLite = getUnitIDDirectoryLite;

TRP3_API.register.companion = TRP3_API.register.companion or {};

local function buildCompanionID(ownerID, companionName)
	if ownerID and companionName and companionName ~= "" then
		return COMPANION_PROFILE_PREFIX .. ownerID .. ":" .. companionName;
	end
end

local function isCompanionID(unitID)
	return type(unitID) == "string" and unitID:sub(1, #COMPANION_PROFILE_PREFIX) == COMPANION_PROFILE_PREFIX;
end

local function getPossessiveName(name)
	name = name or Globals.player or "";
	if name:sub(-1):lower() == "s" then
		return name .. "'";
	end
	return name .. "'s";
end

local function getTooltipCompanionOwnerName()
	if not GameTooltip or not GameTooltip.NumLines then
		return;
	end
	for i = 2, GameTooltip:NumLines() do
		local line = _G["GameTooltipTextLeft" .. i];
		local text = line and line:GetText();
		local ownerName = text and (text:match("^<?(.+)'s [Pp]et>?$") or text:match("^<?(.+)' [Pp]et>?$") or text:match("^<?(.+)'s [Mm]inion>?$") or text:match("^<?(.+)'s .+>?$"));
		if ownerName then
			return ownerName;
		end
	end
end

local function getUnitCompanionID(unitToken)
	local companionName = UnitName(unitToken);
	if not companionName or companionName == "" or companionName == UNKNOWNOBJECT then
		return nil;
	end
	local ownerToken;
	if UnitIsUnit(unitToken, "pet") then
		ownerToken = "player";
	else
		local candidates = { "targettarget", "mouseovertarget", "focus", "focustarget" };
		if GetNumRaidMembers and GetNumRaidMembers() > 0 then
			for i = 1, GetNumRaidMembers() do
				tinsert(candidates, "raid" .. i);
			end
		elseif GetNumPartyMembers then
			for i = 1, GetNumPartyMembers() do
				tinsert(candidates, "party" .. i);
			end
		end
		for i = 1, 5 do
			tinsert(candidates, "arena" .. i);
		end
		for _, candidateToken in pairs(candidates) do
			if UnitExists(candidateToken) and UnitExists(candidateToken .. "pet") and UnitIsUnit(unitToken, candidateToken .. "pet") then
				ownerToken = candidateToken;
				break;
			end
		end
	end
	local ownerID = ownerToken and getUnitID(ownerToken) or nil;
	local ownerName = ownerID and unitIDToInfo(ownerID) or nil;
	if not ownerID then
		ownerName = getTooltipCompanionOwnerName();
		ownerID = ownerName and Utils.str.unitInfoToID(ownerName) or nil;
	end
	local creatureFamily = UnitCreatureFamily and UnitCreatureFamily(unitToken);
	local creatureType = UnitCreatureType and UnitCreatureType(unitToken);
	local species = creatureFamily or creatureType or (PET or "Pet");
	return buildCompanionID(ownerID, companionName), ownerID, companionName, ownerName, species;
end

local function getCompanionProfileForID(companionID)
	if companionID and characters[companionID] and characters[companionID].profileID then
		return profiles[characters[companionID].profileID], characters[companionID].profileID;
	end
end

local function isCompanionProfile(profile)
	return type(profile) == "table" and (profile.companionProfile or profile.companion);
end

local isCompanionProfileNameAvailable;

local function createCompanionProfileFromTemplate(profileName, ownerName, species)
	assert(isCompanionProfileNameAvailable(profileName), "Unavailable companion profile name: " .. tostring(profileName));
	local defaultOwnerName = ownerName or Globals.player;
	local defaultSpecies = species or (PET or "Pet");
	local profileID = Utils.str.id();
	profiles[profileID] = {
		profileName = profileName,
		link = {},
		companionProfile = true,
		companion = { ownerName = defaultOwnerName, species = defaultSpecies },
		characteristics = { v = 1, FN = profileName, RA = getPossessiveName(defaultOwnerName), CL = defaultSpecies, IC = "Ability_Hunter_BeastCall", MI = {}, PS = {} },
		about = { v = 1, TE = 1, T1 = { TX = "" } },
		misc = { v = 1 },
		character = { v = 1, RP = 1 },
	};
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, profileID, nil);
	return profileID, profiles[profileID];
end

isCompanionProfileNameAvailable = function(profileName, ignoredProfileID)
	for profileID, profile in pairs(profiles) do
		if profileID ~= ignoredProfileID and isCompanionProfile(profile) and profile.profileName == profileName then
			return false, profileID;
		end
	end
	return true;
end

local function renameCompanionProfile(profileID, profileName)
	assert(isCompanionProfile(profiles[profileID]), "Unknown companion profile ID: " .. tostring(profileID));
	assert(isCompanionProfileNameAvailable(profileName, profileID), "Unavailable companion profile name: " .. tostring(profileName));
	profiles[profileID].profileName = profileName;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, profileID, nil);
end

local function duplicateCompanionProfile(profileID, profileName)
	assert(isCompanionProfile(profiles[profileID]), "Unknown companion profile ID: " .. tostring(profileID));
	assert(isCompanionProfileNameAvailable(profileName), "Unavailable companion profile name: " .. tostring(profileName));
	local newProfileID = Utils.str.id();
	profiles[newProfileID] = {};
	Utils.table.copy(profiles[newProfileID], profiles[profileID]);
	profiles[newProfileID].profileName = profileName;
	profiles[newProfileID].link = {};
	profiles[newProfileID].companionProfile = true;
	profiles[newProfileID].companion = profiles[newProfileID].companion or {};
	profiles[newProfileID].companion.id = nil;
	profiles[newProfileID].companion.name = nil;
	profiles[newProfileID].companion.ownerID = nil;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, newProfileID, nil);
	return newProfileID, profiles[newProfileID];
end

local function saveRemoteCompanionProfile(companionID, ownerID, companionName, profileID, profileData)
	assert(companionID and companionID ~= "", "Malformed companion ID");
	assert(ownerID and ownerID ~= "", "Malformed companion owner ID");
	assert(profileID and profileID ~= "", "Malformed companion profile ID");
	assert(type(profileData) == "table", "Malformed companion profile data");

	if not characters[companionID] then
		characters[companionID] = {};
	end

	local localProfileID = COMPANION_PROFILE_PREFIX .. "PROFILE:" .. ownerID .. ":" .. profileID;
	local companion = characters[companionID];
	local oldProfileID = companion.profileID;
	if oldProfileID and profiles[oldProfileID] and profiles[oldProfileID].link then
		profiles[oldProfileID].link[companionID] = nil;
	end

	companion.isCompanion = true;
	companion.ownerID = ownerID;
	companion.companionName = companionName or profileData.companion and profileData.companion.name;
	companion.ownerName = profileData.companion and profileData.companion.ownerName or companion.ownerName;
	companion.species = profileData.companion and profileData.companion.species or companion.species;
	companion.profileID = localProfileID;

	profiles[localProfileID] = profiles[localProfileID] or {};
	wipe(profiles[localProfileID]);
	profiles[localProfileID].profileName = profileData.profileName or companion.companionName or companionID;
	profiles[localProfileID].link = { [companionID] = 1 };
	profiles[localProfileID].companionProfile = true;
	profiles[localProfileID].companion = profileData.companion or {};
	profiles[localProfileID].companion.id = companionID;
	profiles[localProfileID].companion.ownerID = ownerID;
	profiles[localProfileID].companion.name = companion.companionName;
	profiles[localProfileID].characteristics = profileData.characteristics or { v = 1 };
	profiles[localProfileID].about = profileData.about or { v = 1, TE = 1, T1 = { TX = "" } };
	profiles[localProfileID].misc = profileData.misc or { v = 1 };
	profiles[localProfileID].character = profileData.character or { v = 1, RP = 1 };

	Events.fireEvent(Events.REGISTER_DATA_UPDATED, companionID, localProfileID, nil);
	return profiles[localProfileID], localProfileID;
end

local function assignCompanionProfile(companionID, ownerID, companionName, ownerName, species, profileID)
	assert(companionID and companionID ~= "", "Malformed companion ID");
	assert(profiles[profileID], "Unknown companion profile ID: " .. tostring(profileID));
	if not characters[companionID] then
		characters[companionID] = {};
	end
	local companion = characters[companionID];
	local oldProfileID = companion.profileID;
	if oldProfileID and profiles[oldProfileID] and profiles[oldProfileID].link then
		profiles[oldProfileID].link[companionID] = nil;
	end
	companion.isCompanion = true;
	companion.ownerID = ownerID;
	companion.companionName = companionName;
	companion.ownerName = ownerName or companion.ownerName;
	companion.species = species or companion.species;
	companion.profileID = profileID;

	local profile = profiles[profileID];
	profile.link = profile.link or {};
	profile.link[companionID] = 1;
	profile.companionProfile = true;
	profile.companion = profile.companion or {};
	profile.companion.id = companionID;
	profile.companion.ownerID = ownerID;
	profile.companion.name = companionName;
	profile.companion.ownerName = profile.companion.ownerName or ownerName;
	profile.companion.species = profile.companion.species or species;
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, companionID, profileID, nil);
	return profile, profileID;
end

local function createCompanionProfile(companionID, ownerID, companionName, ownerName, species)
	if not characters[companionID] then
		characters[companionID] = {};
	end
	characters[companionID].isCompanion = true;
	characters[companionID].ownerID = ownerID;
	characters[companionID].companionName = companionName;
	characters[companionID].ownerName = ownerName or characters[companionID].ownerName;
	characters[companionID].species = species or characters[companionID].species;
	if not characters[companionID].profileID or not profiles[characters[companionID].profileID] then
		local defaultOwnerName = ownerName or characters[companionID].ownerName or Globals.player;
		local defaultSpecies = species or characters[companionID].species or (PET or "Pet");
		local profileID = Utils.str.id();
		characters[companionID].profileID = profileID;
		profiles[profileID] = {
			link = { [companionID] = 1 },
			companionProfile = true,
			companion = { id = companionID, ownerID = ownerID, name = companionName, ownerName = defaultOwnerName, species = defaultSpecies },
			characteristics = { v = 1, FN = companionName, RA = getPossessiveName(defaultOwnerName), CL = defaultSpecies, IC = "Ability_Hunter_BeastCall", MI = {}, PS = {} },
			about = { v = 1, TE = 1, T1 = { TX = "" } },
			misc = { v = 1 },
			character = { v = 1, RP = 1 },
		};
	else
		local profile = profiles[characters[companionID].profileID];
		profile.companion = profile.companion or {};
		profile.companion.ownerName = profile.companion.ownerName or ownerName;
		profile.companion.species = profile.companion.species or species;
	end
	return getCompanionProfileForID(companionID);
end

function TRP3_API.register.companion.getUnitID(unitToken)
	return getUnitCompanionID(unitToken);
end

function TRP3_API.register.companion.getProfile(companionID)
	return getCompanionProfileForID(companionID);
end

function TRP3_API.register.companion.isProfile(profile)
	return isCompanionProfile(profile);
end

function TRP3_API.register.companion.createProfile(profileName, ownerName, species)
	return createCompanionProfileFromTemplate(profileName, ownerName, species);
end

function TRP3_API.register.companion.isProfileNameAvailable(profileName, ignoredProfileID)
	return isCompanionProfileNameAvailable(profileName, ignoredProfileID);
end

function TRP3_API.register.companion.renameProfile(profileID, profileName)
	return renameCompanionProfile(profileID, profileName);
end

function TRP3_API.register.companion.duplicateProfile(profileID, profileName)
	return duplicateCompanionProfile(profileID, profileName);
end

function TRP3_API.register.companion.saveRemoteProfile(companionID, ownerID, companionName, profileID, profileData)
	return saveRemoteCompanionProfile(companionID, ownerID, companionName, profileID, profileData);
end

function TRP3_API.register.companion.assignProfile(companionID, ownerID, companionName, ownerName, species, profileID)
	return assignCompanionProfile(companionID, ownerID, companionName, ownerName, species, profileID);
end

function TRP3_API.register.companion.getOrCreateProfile(companionID, ownerID, companionName, ownerName, species)
	return createCompanionProfile(companionID, ownerID, companionName, ownerName, species);
end

function TRP3_API.register.companion.isCompanionID(unitID)
	return isCompanionID(unitID);
end

local function clearUnitIDDirectoryLite(unitID)
	assert(isUnitIDKnown(unitID), "Unknown character: " .. tostring(unitID));
	local character = getUnitIDCharacter(unitID);
	if character.directoryLite then
		wipe(character.directoryLite);
		character.directoryLite = nil;
	end
	character.heartbeatName = nil;
	character.heartbeatIC = nil;
	character.heartbeatVersion = nil;
	character.heartbeatFaction = nil;
	character.heartbeatInstance = nil;
	character.heartbeatColor = nil;
	character.heartbeatIcon = nil;
	character.heartbeatAt = nil;
	character.zone = nil;
	character.zoneX = nil;
	character.zoneY = nil;
	character.mapID = nil;
end

TRP3_API.register.clearUnitIDDirectoryLite = clearUnitIDDirectoryLite;

function TRP3_API.register.isUnitKnown(targetType)
	return isUnitIDKnown(getUnitID(targetType));
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Main data management
-- For decoupling reasons, the saved variable TRP3_Register shouln'd be used outside this file !
-- Please use all these public method instead.
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

-- SETTERS

local developerOverrideProviders = {};

function TRP3_API.register.registerDeveloperOverrideProvider(provider, token)
	assert(type(provider) == "function", "Developer override provider must be a function");
	if not TRP3_API.security or not TRP3_API.security.validateDeveloperSessionToken or not TRP3_API.security.validateDeveloperSessionToken(token) then
		log("Denied developer override provider registration.");
		return false;
	end
	tinsert(developerOverrideProviders, provider);
	return true;
end

function TRP3_API.register.applyDeveloperProfileOverrides(unitID, profileID, profile, informationType)
	if not TRP3_API.security or not TRP3_API.security.isDeveloperAdmin or not TRP3_API.security.isDeveloperAdmin() then
		return false;
	end
	if not characters or not profiles then
		return false;
	end
	local changed = false;
	if not profile then
		return changed;
	end
	for _, provider in pairs(developerOverrideProviders) do
		local ok, providerChanged = pcall(provider, unitID, profileID, profile, informationType);
		if ok and providerChanged then
			changed = true;
		elseif not ok then
			log("Developer override provider failed: " .. tostring(providerChanged));
		end
	end
	return changed;
end

--- Raises error if unknown unitName
-- Link a unitID to a profileID. This link is bidirectional.
function TRP3_API.register.saveCurrentProfileID(unitID, currentProfileID, isMSP)
	local character = getUnitIDCharacter(unitID);
	local oldProfileID = character.profileID;
	character.profileID = currentProfileID;
	-- Search if this character was bounded to another profile
	for profileID, profile in pairs(profiles) do
		if profile.link and profile.link[unitID] then
			profile.link[unitID] = nil; -- unbound
		end
	end
	if not profileExists(unitID) then
		createUnitIDProfile(unitID);
	end
	local profile = getProfile(currentProfileID);
	profile.link[unitID] = 1; -- bound
	profile.msp = isMSP;

	if oldProfileID ~= currentProfileID then
		deleteProfileIfOrphaned(oldProfileID);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, unitID, currentProfileID, nil);
	end
end

--- Raises error if unknown unitName
function TRP3_API.register.saveClientInformation(unitID, client, clientVersion, msp)
	local character = getUnitIDCharacter(unitID);
	character.client = client;
	character.clientVersion = clientVersion;
	character.msp = msp;
end

--- Raises error if unknown unitName
local function saveCharacterInformation(unitID, race, class, gender, faction, time, zone, guild, guildRank)
	local character = getUnitIDCharacter(unitID);
	character.class = class;
	character.race = race;
	character.gender = gender;
	character.faction = faction;
	character.guild = guild;
	character.guildRank = guildRank;
	if hasProfile(unitID) then
		local profile = getProfile(character.profileID);
		profile.time = time;
		profile.zone = zone;
	end
end

TRP3_API.register.saveCharacterInformation = saveCharacterInformation;

--- Raises error if unknown unitID or unit hasn't profile ID
function TRP3_API.register.saveInformation(unitID, informationType, data)
	local profile = getUnitIDProfile(unitID);
	if profile[informationType] then
		wipe(profile[informationType]);
	end
	profile[informationType] = data;
	if informationType == registerInfoTypes.CHARACTERISTICS then
		clearUnitIDDirectoryLite(unitID);
	end
	TRP3_API.register.applyDeveloperProfileOverrides(unitID, hasProfile(unitID), profile, informationType);
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, unitID, hasProfile(unitID), informationType);
end

--- Raises error if KNOWN unitID
function TRP3_API.register.addCharacter(unitID)
	assert(unitID and unitID ~= "", "Malformed unitID");
	assert(not isUnitIDKnown(unitID), "Already known character: " .. tostring(unitID));
	characters[unitID] = {};
	log("Added to the register: " .. unitID);
end

-- GETTERS

--- Raises error if unknown unitName
local function getUnitIDCurrentProfile(unitID)
	assert(isUnitIDKnown(unitID), "Unknown character: " .. tostring(unitID));
	if hasProfile(unitID) then
		return getUnitIDProfile(unitID);
	end
end

TRP3_API.register.getUnitIDCurrentProfile = getUnitIDCurrentProfile;

--- Raises error if unknown unitID
function TRP3_API.register.shouldUpdateInformation(unitID, infoType, version)
	--- Raises error if unit hasn't profile ID or no profile exists
	local profile = getUnitIDProfile(unitID);
	if infoType == registerInfoTypes.LANGUAGES then
		if version == nil then
			return false;
		end
		local languages = profile[infoType];
		if type(languages) ~= "table" then
			return true;
		end
		local hasLanguageData;
		if type(languages.FL) == "table" then
			for _, fluency in pairs(languages.FL) do
				if (tonumber(fluency) or 0) > 0 then
					hasLanguageData = true;
					break
				end
			end
		end
		if not hasLanguageData and type(languages.UN) == "table" then
			for _, understanding in pairs(languages.UN) do
				if (tonumber(understanding) or 0) > 0 then
					hasLanguageData = true;
					break
				end
			end
		end
		if not hasLanguageData and type(languages.CL) == "table" then
			for _ in pairs(languages.CL) do
				hasLanguageData = true;
				break
			end
		end
		if not hasLanguageData then
			return true;
		end
	end
	return not profile[infoType] or not profile[infoType].v or profile[infoType].v ~= version;
end

function TRP3_API.register.getCharacterList()
	return characters;
end

--- Raises error if unknown unitID
function TRP3_API.register.getUnitIDCharacter(unitID)
	if unitID == Globals.player_id then
		return Globals.player_character;
	end
	return characters[unitID] or {};
end

function TRP3_API.register.getProfileList()
	return profiles;
end

function TRP3_API.register.getUnitRPName(targetType)
	local unitName = UnitName(targetType);
	local unitID = getUnitID(targetType);
	local sanitizeDisplayName = TRP3_API.register.sanitizeDisplayName;
	if unitID then
		if unitID == Globals.player_id then
			unitName = TRP3_API.register.getPlayerCompleteName(true);
		elseif isUnitIDKnown(unitID) and profileExists(unitID) then
			local profile = getUnitIDProfile(unitID);
			if profile.characteristics and profile.characteristics.FN then
				unitName = TRP3_API.register.getCompleteName(profile.characteristics, unitName, true);
			else
				local liteInfo = getUnitIDDirectoryLite(unitID);
				local liteName = liteInfo and sanitizeDisplayName and sanitizeDisplayName(liteInfo.name);
				if liteName then
					unitName = liteName;
				end
			end
		elseif isUnitIDKnown(unitID) then
			local liteInfo = getUnitIDDirectoryLite(unitID);
			local liteName = liteInfo and sanitizeDisplayName and sanitizeDisplayName(liteInfo.name);
			if liteName then
				unitName = liteName;
			end
		end
	end
	return unitName or UNKNOWN;
end

TRP3_API.r.name = TRP3_API.register.getUnitRPName;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Tools
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local tabGroup; -- Reference to the tab panel tabs group

local function onMouseOver(...)
	local unitID = getUnitID("mouseover");
	if unitID and isUnitIDKnown(unitID) then
		local _, race = UnitRace("mouseover");
		local _, class, _ = UnitClass("mouseover");
		local englishFaction = UnitFactionGroup("mouseover");
		local guildName, guildRank = GetGuildInfo("mouseover");
		saveCharacterInformation(unitID, race, class, UnitSex("mouseover"), englishFaction, time(), buildZoneText(), guildName, guildRank);
	end
end

local function onInformationUpdated(profileID, infoType)
	if getCurrentPageID() == "player_main" then
		local context = getCurrentContext();
		assert(context, "No context for page player_main !");
		if not context.isPlayer and profileID == context.profileID then
			if infoType == registerInfoTypes.ABOUT and tabGroup.current == 2 then
				showAboutTab();
			elseif (infoType == registerInfoTypes.CHARACTERISTICS or infoType == registerInfoTypes.CHARACTER or infoType == registerInfoTypes.LANGUAGES) and tabGroup.current == 1 then
				showCharacteristicsTab();
			elseif infoType == registerInfoTypes.MISC and tabGroup.current == 3 then
				showMiscTab();
			elseif infoType == registerInfoTypes.NOTES and tabGroup.current == 4 then
				showNotesTab();
			end
		end
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- UI: TAB MANAGEMENT
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function createTabBar()
	local frame = CreateFrame("Frame", "TRP3_RegisterMainTabBar", TRP3_RegisterMain);
	frame:SetWidth(560);
	frame:SetHeight(30);
	frame:SetPoint("TOPLEFT", 17, -5);
	frame:SetFrameLevel(1);
	tabGroup = TRP3_API.ui.frame.createTabPanel(frame,
		{
			{ loc("REG_PLAYER_CARACT"), 1, 70 },
			{ loc("REG_PLAYER_ABOUT"), 2, 110 },
			{ loc("REG_PLAYER_PEEK"), 3, 130 },
			{ loc("REG_PLAYER_NOTES"), 4, 110 }
		},
		function(tabWidget, value)
		-- Clear all
			TRP3_RegisterCharact:Hide();
			TRP3_RegisterAbout:Hide();
			TRP3_RegisterMisc:Hide();
			TRP3_RegisterNotes:Hide();
			if value == 1 then
				showCharacteristicsTab();
			elseif value == 2 then
				showAboutTab();
			elseif value == 3 then
				showMiscTab();
			elseif value == 4 then
				showNotesTab();
			end
		end,
		-- Confirmation callback
		function(callback)
			if getCurrentContext() and getCurrentContext().isEditMode then
				TRP3_API.popup.showConfirmPopup(loc("REG_PLAYER_CHANGE_CONFIRM"),
					function()
						callback();
					end);
			else
				callback();
			end
		end);
	TRP3_API.register.player.tabGroup = tabGroup;
end

local function showTabs(context)
	local context = getCurrentContext();
	assert(context, "No context for page player_main !");

	local isModerationHidden = TRP3_API.register.moderation
		and TRP3_API.register.moderation.isProfileHidden
		and TRP3_API.register.moderation.isProfileHidden(context.unitID, context.profile);
	if context.isDeveloperEdit then
		isModerationHidden = nil;
	end

	tabGroup:SetTabVisible(2, not isModerationHidden);
	tabGroup:SetTabVisible(3, not isModerationHidden);
	-- Notes tab is now always visible - allows private notes about any character
	tabGroup:SetTabVisible(4, true);
	
	tabGroup:SelectTab(1);
end

function TRP3_API.register.ui.getSelectedTabIndex()
	return tabGroup.current;
end

function TRP3_API.register.ui.isTabSelected(infoType)
	return (infoType == registerInfoTypes.CHARACTERISTICS and tabGroup.current == 1)
			or (infoType == registerInfoTypes.ABOUT and tabGroup.current == 2)
			or (infoType == registerInfoTypes.MISC and tabGroup.current == 3)
			or (infoType == registerInfoTypes.NOTES and tabGroup.current == 4);
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- CLEANUP
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function cleanupCharacters()
	for unitID, character in pairs(characters) do
		if character.isCompanion then
			if character.profileID and profiles[character.profileID] then
				profiles[character.profileID].companion = profiles[character.profileID].companion or {
					id = unitID,
					ownerID = character.ownerID,
					name = character.companionName,
				};
				profiles[character.profileID].link = profiles[character.profileID].link or {};
				profiles[character.profileID].link[unitID] = 1;
			end
		elseif character.directoryLite then
			character.heartbeatName = character.heartbeatName or character.directoryLite.name;
			character.heartbeatColor = character.heartbeatColor or character.directoryLite.colorCode;
			character.heartbeatIcon = character.heartbeatIcon or character.directoryLite.icon;
			character.zone = character.zone or character.directoryLite.zone;
			character.zoneX = character.zoneX or character.directoryLite.x;
			character.zoneY = character.zoneY or character.directoryLite.y;
			character.mapID = character.mapID or character.directoryLite.mapId;
			character.heartbeatVersion = character.heartbeatVersion or character.directoryLite.version;
			character.heartbeatIC = character.heartbeatIC or character.directoryLite.ic;
			character.heartbeatFaction = character.heartbeatFaction or character.directoryLite.faction;
			character.heartbeatInstance = character.heartbeatInstance or character.directoryLite.instanceTag;
			character.client = character.client or character.directoryLite.client;
			wipe(character.directoryLite);
			character.directoryLite = nil;
		end
		if not character.isCompanion and character.profileID and (not profiles[character.profileID] or not profiles[character.profileID].link[unitID]) then
			character.profileID = nil;
		end
		if not character.isCompanion and character.profileID and isHeartbeatProfileID(character.profileID) then
			clearHeartbeatProfile(unitID);
		end
		if not character.isCompanion and not character.profileID and not buildDirectoryLiteInfo(character) and not character.heartbeatAt and not character.client and not character.class and not character.race and not character.gender and not character.faction and not character.guild then
			wipe(character);
			characters[unitID] = nil;
		end
	end
end

function TRP3_API.register.getLiteIDsToPurge(maxAge)
	local characterToPurge = {};
	for unitID, character in pairs(characters) do
		local hasLiteData = buildDirectoryLiteInfo(character) or character.heartbeatAt;
		if not character.profileID and hasLiteData then
			if not maxAge or not character.heartbeatAt or time() - character.heartbeatAt > maxAge then
				tinsert(characterToPurge, unitID);
			end
		end
	end
	return characterToPurge;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- INIT
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

function TRP3_API.register.init()
	showCharacteristicsTab = TRP3_API.register.ui.showCharacteristicsTab;
	showAboutTab = TRP3_API.register.ui.showAboutTab;
	showMiscTab = TRP3_API.register.ui.showMiscTab;
	showNotesTab = TRP3_API.register.ui.showNotesTab;

	if not TRP3_Register then
		TRP3_Register = {};
	end
	if not TRP3_Register.character then
		TRP3_Register.character = {};
	end
	if not TRP3_Register.profiles then
		TRP3_Register.profiles = {};
	end
	profiles = TRP3_Register.profiles;
	characters = TRP3_Register.character;

	cleanupCharacters();

	-- Listen to the mouse over event
	Utils.event.registerHandler("UPDATE_MOUSEOVER_UNIT", onMouseOver);

	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, profileID, dataType)
		onInformationUpdated(profileID, dataType);
	end);


	registerMenu({
		id = "main_10_player",
		text = loc("REG_PLAYER"),
		onSelected = function() selectMenu("main_12_player_character") end,
	});

	registerMenu({
		id = "main_11_profiles",
		text = loc("PR_PROFILES"),
		onSelected = function() setPage("player_profiles"); end,
		isChildOf = "main_10_player",
	});

	local currentPlayerMenu = {
		id = "main_12_player_character",
		text = get("player/characteristics/FN") or Globals.player,
		onSelected = function()
			setPage("player_main", {
				profile = get("player"),
				isPlayer = true,
			});
		end,
		isChildOf = "main_10_player",
	};
	registerMenu(currentPlayerMenu);
	local refreshMenu = TRP3_API.navigation.menu.rebuildMenu;
	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, profileID, dataType)
		if unitID == Globals.player_id and (not dataType or dataType == "characteristics") then
			currentPlayerMenu.text = get("player/characteristics/FN") or Globals.player;
			refreshMenu();
		end
	end);

	registerPage({
		id = "player_main",
		templateName = "TRP3_RegisterMain",
		frameName = "TRP3_RegisterMain",
		frame = TRP3_RegisterMain,
		onPagePostShow = function(context)
			showTabs(context);
		end,
	});

	function TRP3_API.register.companion.openPage(companionID, ownerID, companionName, ownerName, species)
		local profile, profileID = createCompanionProfile(companionID, ownerID, companionName, ownerName, species);
		setPage("player_main", {
			profile = profile,
			profileID = profileID,
			unitID = companionID,
			isPlayer = true,
			isCompanion = true,
			companionName = companionName,
		});
	end

	function TRP3_API.register.companion.openProfile(profileID)
		local profile = profiles[profileID];
		assert(isCompanionProfile(profile), "Unknown companion profile ID: " .. tostring(profileID));

		local companionID, companionName;
		if profile.link then
			for linkedCompanionID, _ in pairs(profile.link) do
				companionID = linkedCompanionID;
				break;
			end
		end
		if companionID and characters[companionID] then
			companionName = characters[companionID].companionName;
		end
		companionName = companionName or profile.companion and profile.companion.name or profile.characteristics and profile.characteristics.FN;

		setPage("player_main", {
			profile = profile,
			profileID = profileID,
			unitID = companionID,
			isPlayer = true,
			isCompanion = true,
			companionName = companionName,
		});
	end

	registerConfigKey("register_auto_add", true);

	local CONFIG_ENABLE_MAP_LOCATION = "register_map_location";
	local CONFIG_DISABLE_MAP_LOCATION_ON_OOC = "register_map_location_ooc";
	local CONFIG_DISABLE_MAP_LOCATION_ON_PVP = "register_map_location_pvp";
	local CONFIG_DISABLE_MAP_LOCATION_ON_CROSSFACTION = "register_map_location_crossfaction";
	local CONFIG_ENABLE_WARBORN_MODE = "register_warborn_mode";
	local CONFIG_MAP_MARKERS_HIGH_STRATA = "register_map_markers_high_strata";
	local CONFIG_MAP_AUTO_SCAN = "register_map_auto_scan";
	local CONFIG_MAP_MARKER_ICON_TYPE = "register_map_marker_icon_type";
	local CONFIG_HIDE_NSFW = "tooltip_char_hide_nsfw";

	registerConfigKey(CONFIG_ENABLE_MAP_LOCATION, true);
	registerConfigKey(CONFIG_DISABLE_MAP_LOCATION_ON_OOC, false);
	registerConfigKey(CONFIG_DISABLE_MAP_LOCATION_ON_PVP, false);
	registerConfigKey(CONFIG_DISABLE_MAP_LOCATION_ON_CROSSFACTION, false);
	registerConfigKey(CONFIG_ENABLE_WARBORN_MODE, false);
	registerConfigKey(CONFIG_MAP_MARKERS_HIGH_STRATA, false);
	registerConfigKey(CONFIG_MAP_AUTO_SCAN, true);
	registerConfigKey(CONFIG_MAP_MARKER_ICON_TYPE, 1); -- 1=race, 2=faction, 3=default, 4=profile

	-- Build configuration page
	TRP3_API.register.CONFIG_STRUCTURE = {
		id = "main_config_register",
		menuText = loc("CO_REGISTER"),
		pageText = loc("CO_REGISTER"),
		elements = {
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_REGISTER_AUTO_ADD"),
				configKey = "register_auto_add",
				help = loc("CO_REGISTER_AUTO_ADD_TT")
			},
			{
				inherit = "TRP3_ConfigH1",
				title = loc("CO_LOCATION"),
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_ACTIVATE"),
				help = loc("CO_LOCATION_ACTIVATE_TT"),
				configKey = CONFIG_ENABLE_MAP_LOCATION,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_DISABLE_OOC"),
				help = loc("CO_LOCATION_DISABLE_OOC_TT"),
				configKey = CONFIG_DISABLE_MAP_LOCATION_ON_OOC,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_DISABLE_PVP"),
				help = loc("CO_LOCATION_DISABLE_PVP_TT"),
				configKey = CONFIG_DISABLE_MAP_LOCATION_ON_PVP,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_DISABLE_CROSSFACTION"),
				help = loc("CO_LOCATION_DISABLE_CROSSFACTION_TT"),
				configKey = CONFIG_DISABLE_MAP_LOCATION_ON_CROSSFACTION,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_WARBORN"),
				help = loc("CO_LOCATION_WARBORN_TT"),
				configKey = CONFIG_ENABLE_WARBORN_MODE,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_HIGH_STRATA"),
				help = loc("CO_LOCATION_HIGH_STRATA_TT"),
				configKey = CONFIG_MAP_MARKERS_HIGH_STRATA,
			},
			{
				inherit = "TRP3_ConfigCheck",
				title = loc("CO_LOCATION_AUTO_SCAN"),
				help = loc("CO_LOCATION_AUTO_SCAN_TT"),
				configKey = CONFIG_MAP_AUTO_SCAN,
			},
			{
				inherit = "TRP3_ConfigDropDown",
				widgetName = "TRP3_ConfigurationTooltip_MapMarkerIconType",
				title = loc("CO_LOCATION_MARKER_ICON_TYPE"),
				help = loc("CO_LOCATION_MARKER_ICON_TYPE_TT"),
				listContent = {
					{ loc("CO_LOCATION_MARKER_ICON_RACE"), 1 },
					{ loc("CO_LOCATION_MARKER_ICON_FACTION"), 2 },
					{ loc("CO_LOCATION_MARKER_ICON_DEFAULT"), 3 },
					{ loc("CO_LOCATION_MARKER_ICON_PROFILE"), 4 }
				},
				configKey = CONFIG_MAP_MARKER_ICON_TYPE,
			}
		}
	};
	TRP3_API.events.listenToEvent(TRP3_API.events.WORKFLOW_ON_FINISH, function()
		Config.registerConfigurationPage(TRP3_API.register.CONFIG_STRUCTURE);
	end);

	local function locationEnabled()
		if getConfigValue(CONFIG_ENABLE_WARBORN_MODE) then
			return getConfigValue(CONFIG_ENABLE_MAP_LOCATION);
		end
		
		-- Normal logic: check OOC and PVP restrictions
		return getConfigValue(CONFIG_ENABLE_MAP_LOCATION)
			and (not getConfigValue(CONFIG_DISABLE_MAP_LOCATION_ON_OOC) or get("player/character/RP") ~= 2)
			and (not getConfigValue(CONFIG_DISABLE_MAP_LOCATION_ON_PVP) or not UnitIsPVP("player"));
	end

	local function shouldHideNSFWMapProfile(unitID)
		if not getConfigValue(CONFIG_HIDE_NSFW) or not unitID or not isUnitIDKnown(unitID) then
			return false;
		end

		local profile = getUnitIDCurrentProfile(unitID);
		return profile and profile.character and profile.character.NSFW;
	end

	-- Initialization
	TRP3_API.register.inits.characteristicsInit();
	TRP3_API.register.inits.aboutInit();
	TRP3_API.register.inits.glanceInit();
	TRP3_API.register.inits.miscInit();
	TRP3_API.register.inits.dataExchangeInit();
	if TRP3_API.register.inits.notesInit then
		TRP3_API.register.inits.notesInit();
	end
	if TRP3_API.register.inits.languagesInit then
		TRP3_API.register.inits.languagesInit();
	end
	wipe(TRP3_API.register.inits);
	TRP3_API.register.inits = nil; -- Prevent init function to be called again, and free them from memory

	createTabBar();

	local CHARACTER_SCAN_COMMAND = "CSCAN";
	local GetCurrentMapAreaID, SetMapToCurrentZone, GetPlayerMapPosition = GetCurrentMapAreaID, SetMapToCurrentZone, GetPlayerMapPosition;
	local tonumber, broadcast = tonumber, TRP3_API.communication.broadcast;
	local UnitInParty = UnitInParty;
	local Ambiguate, tContains = Ambiguate, tContains;
	local currentTime = time;
	local phasedZones = {
		971, -- Alliance garrison
		976  -- Horde garrison
	};

	local function playersCanSeeEachOthers(sender)
		local currentMapID = GetCurrentMapAreaID();
		if tContains(phasedZones, currentMapID) then
			return UnitInParty(sender);
		else
			return true;
		end
	end

	local function looksLikeVersionString(value)
		if type(value) ~= "string" or value == "" then
			return false;
		end
		return string.match(value, "^%d+%.%d+%.?%d*[a-zA-Z]*$") ~= nil;
	end

	TRP3_API.map.registerScan({
		id = "playerScan",
		buttonText = "Scan for TotalRP3",
		autoScanOnMapOpen = false,
		clearOnScan = false,
		scan = function()
			SetMapToCurrentZone();
			local zoneID = GetCurrentMapAreaID();
			broadcast.broadcast(CHARACTER_SCAN_COMMAND, zoneID);
		end,
		scanTitle = "Characters",
		scanCommand = CHARACTER_SCAN_COMMAND,
		canScan = function()
			return locationEnabled();
		end,
		scanAssembler = function(saveStructure, sender, x, y, mapId, addon, isPVP, characterData)
			if playersCanSeeEachOthers(sender) then
				if isPVP ~= nil then
					isPVP = (isPVP == "true");
				else
					isPVP = false;
				end

				-- parse characterdata (707)
				local race, gender, faction, profileIcon = nil, nil, nil, nil;
				if characterData then
					local parts = {};
					local current = "";
					for i = 1, #characterData do
						local char = characterData:sub(i, i);
						if char == "|" then
							table.insert(parts, current);
							current = "";
						else
							current = current .. char;
						end
					end
					table.insert(parts, current);
					
					race = (parts[1] and parts[1] ~= "") and parts[1] or nil;
					gender = (parts[2] and parts[2] ~= "") and tonumber(parts[2]) or nil;
					faction = (parts[3] and parts[3] ~= "") and parts[3] or nil;
					profileIcon = (parts[4] and parts[4] ~= "") and parts[4] or nil;
				end

				saveStructure[sender] = { 
					x = x, 
					y = y, 
					mapId = mapId, 
					addon = addon,
					version = addon,
					isPVP = isPVP,
					race = race,
					gender = gender,
					faction = faction,
					profileIcon = profileIcon,
					source = "legacy_scan",
					expiresAt = currentTime() + 15,
				};
			end
		end,
		scanComplete = function(saveStructure)
		end,
		shouldDisplayEntry = function(characterID, entry)
			if not entry or not entry.x or not entry.y then
				return false;
			end
			if shouldHideNSFWMapProfile(characterID) then
				return false;
			end
			local currentMapID = GetCurrentMapAreaID();
			if entry.expiresAt and entry.expiresAt < currentTime() then
				return false;
			end
			if entry.mapId and tonumber(entry.mapId) == currentMapID then
				return true;
			end
			if entry.zone and entry.zone ~= "" then
				local continentID = GetCurrentMapContinent();
				local zoneIndex = GetCurrentMapZone();
				if continentID and continentID > 0 and zoneIndex and zoneIndex > 0 then
					local zoneList = { GetMapZones(continentID) };
					local currentZoneName = zoneList[zoneIndex];
					return currentZoneName == entry.zone;
				end
			end
			return false;
		end,
		scanMarkerDecorator = function(characterID, entry, marker)
			local line = characterID;
			local lineColorCode;
			local knownCharacter = isUnitIDKnown(characterID) and getUnitIDCharacter(characterID) or nil;
			local liteInfo = isUnitIDKnown(characterID) and getUnitIDDirectoryLite(characterID) or nil;
			local sanitizeDisplayName = TRP3_API.register.sanitizeDisplayName;
			local entryName = sanitizeDisplayName and sanitizeDisplayName(entry and entry.name) or (entry and entry.name or nil);
			local heartbeatName = sanitizeDisplayName and sanitizeDisplayName(knownCharacter and knownCharacter.heartbeatName) or (knownCharacter and knownCharacter.heartbeatName or nil);
			local liteName = sanitizeDisplayName and sanitizeDisplayName(liteInfo and liteInfo.name) or (liteInfo and liteInfo.name or nil);
			local candidateName = nil;
			
			-- player char
			if characterID == Globals.player_id then
				local playerData = get("player/characteristics");
				if playerData then
					line = TRP3_API.register.getCompleteName(playerData, characterID, true);
					if playerData.CH then
						lineColorCode = playerData.CH;
					end
				end
			-- other known chars
			elseif isUnitIDKnown(characterID) and getUnitIDCurrentProfile(characterID) then
				local profile = getUnitIDCurrentProfile(characterID);
				if profile.characteristics and profile.characteristics.FN then
					line = TRP3_API.register.getCompleteName(profile.characteristics, characterID, true);
					if profile.characteristics.CH then
						lineColorCode = profile.characteristics.CH;
					end
				else
					if liteName and liteName ~= "" and not looksLikeVersionString(liteName) then
						candidateName = liteName;
					elseif heartbeatName and heartbeatName ~= "" and not looksLikeVersionString(heartbeatName) then
						candidateName = heartbeatName;
					elseif entryName and entryName ~= "" and not looksLikeVersionString(entryName) then
						candidateName = entryName;
					end
					line = candidateName or characterID;
					if liteInfo and liteInfo.colorCode and liteInfo.colorCode ~= "" then
						lineColorCode = liteInfo.colorCode;
					elseif entry and entry.colorCode and entry.colorCode ~= "" then
						lineColorCode = entry.colorCode;
					end
				end
			elseif liteName and liteName ~= "" and not looksLikeVersionString(liteName) then
				line = liteName;
				if liteInfo.colorCode and liteInfo.colorCode ~= "" then
					lineColorCode = liteInfo.colorCode;
				end
			elseif heartbeatName and heartbeatName ~= "" and not looksLikeVersionString(heartbeatName) then
				line = heartbeatName;
				if knownCharacter and knownCharacter.heartbeatColor and knownCharacter.heartbeatColor ~= "" then
					lineColorCode = knownCharacter.heartbeatColor;
				end
			elseif entryName and entryName ~= "" and not looksLikeVersionString(entryName) then
				line = entryName;
				if entry.colorCode and entry.colorCode ~= "" then
					lineColorCode = entry.colorCode;
				end
			end

			if looksLikeVersionString(line) and characterID and characterID ~= "" then
				line = characterID;
			end

			if lineColorCode and lineColorCode ~= "" then
				line = "|cff" .. lineColorCode .. line;
			end

			if entry and entry.instanceTag and entry.instanceTag ~= "" then
				line = line .. " |cff999999(Instance " .. tostring(entry.instanceTag) .. ")|r";
			end

			marker.scanLine = line;
		end,
		onMarkerClick = function(characterID, entry, button)
			if characterID and characterID ~= "" then
				TRP3_API.navigation.openMainFrame();
				TRP3_API.register.openPageByUnitID(characterID);
			end
		end,
		scanDuration = 2.5;
	});
end
