----------------------------------------------------------------------------------
-- Total RP 3
-- Character page : Miscellaneous
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- imports
local Utils, Events, Globals = TRP3_API.utils, TRP3_API.events, TRP3_API.globals;
local stEtN = Utils.str.emptyToNil;
local color, getIcon, tableRemove = Utils.str.color, Utils.str.icon, Utils.table.remove;
local loc = TRP3_API.locale.getText;
local get = TRP3_API.profile.getData;
local tcopy, tsize = Utils.table.copy, Utils.table.size;
local assert, table, wipe, _G = assert, table, wipe, _G;
local getDefaultProfile = TRP3_API.profile.getDefaultProfile;
local showIconBrowser = TRP3_API.popup.showIconBrowser;
local tinsert, pairs, type, tostring = tinsert, pairs, type, tostring;
local setupListBox = TRP3_API.ui.listbox.setupListBox;
local setTooltipForSameFrame, toast = TRP3_API.ui.tooltip.setTooltipForSameFrame, TRP3_API.ui.tooltip.toast;
local getCurrentContext, getCurrentPageID = TRP3_API.navigation.page.getCurrentContext, TRP3_API.navigation.page.getCurrentPageID;
local setupIconButton, getPlayerCurrentProfileID = TRP3_API.ui.frame.setupIconButton, TRP3_API.profile.getPlayerCurrentProfileID;
local setupFieldSet = TRP3_API.ui.frame.setupFieldPanel;
local showPopup = TRP3_API.popup.showPopup;
local hasProfile = TRP3_API.register.hasProfile;
local refreshTooltip = TRP3_API.ui.tooltip.refresh;
local compressData;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- SCHEMA
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

getDefaultProfile().player.misc = {
	v = 1,
	PE = {},
	ST = {},
}

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- RP Style
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local STYLE_FIELDS;
local function buildStyleStructure()
	STYLE_FIELDS = {
		{
			id = "1",
			name = loc("REG_PLAYER_STYLE_FREQ"),
			values = {
				{loc("REG_PLAYER_STYLE_FREQ_1"), 1},
				{loc("REG_PLAYER_STYLE_FREQ_2"), 2},
				{loc("REG_PLAYER_STYLE_FREQ_3"), 3},
				{loc("REG_PLAYER_STYLE_FREQ_4"), 4},
				{loc("REG_PLAYER_STYLE_FREQ_5"), 5},
				{loc("REG_PLAYER_STYLE_HIDE"), 0},
			}
		},
		{
			id = "2",
			name = loc("REG_PLAYER_STYLE_INJURY"),
			values = {
				{YES, 1},
				{NO, 2},
				{loc("REG_PLAYER_STYLE_PERMI"), 3},
				{loc("REG_PLAYER_STYLE_HIDE"), 0},
			}
		},
		{
			id = "3",
			name = loc("REG_PLAYER_STYLE_DEATH"),
			values = {
				{YES, 1},
				{NO, 2},
				{loc("REG_PLAYER_STYLE_PERMI"), 3},
				{loc("REG_PLAYER_STYLE_HIDE"), 0},
			}
		},
		{
			id = "4",
			name = loc("REG_PLAYER_STYLE_ROMANCE"),
			values = {
				{YES, 1},
				{NO, 2},
				{loc("REG_PLAYER_STYLE_PERMI"), 3},
				{loc("REG_PLAYER_STYLE_HIDE"), 0},
			}
		},
		{
			id = "5",
			name = loc("REG_PLAYER_STYLE_BATTLE"),
			values = {
				{loc("REG_PLAYER_STYLE_BATTLE_1"), 1},
				{loc("REG_PLAYER_STYLE_BATTLE_3"), 3},
				{loc("REG_PLAYER_STYLE_BATTLE_4"), 4},
				{loc("REG_PLAYER_STYLE_HIDE"), 0},
			}
		},
		{
			id = "6",
			name = loc("REG_PLAYER_STYLE_GUILD"),
			values = {
				{loc("REG_PLAYER_STYLE_GUILD_IC"), 1},
				{loc("REG_PLAYER_STYLE_GUILD_OOC"), 2},
				{loc("REG_PLAYER_STYLE_HIDE"), 0},
			}
		},
	};
end

local styleLines = {};

local function onEditStyle(choice, frame)
	frame = frame:GetParent();
	assert(frame.fieldData, "No data in frame !");
	local context = getCurrentContext();
	assert(context, "No context for page player_main !");
	if context.isPlayer and not context.isCompanion then
		local dataTab = context.profile and context.profile.misc or get("player/misc");
		local old = dataTab.ST[frame.fieldData.id];
		dataTab.ST[frame.fieldData.id] = choice;
		if old ~= choice then
			-- version increment
			assert(type(dataTab.v) == "number", "Error: No version in draftData or not a number.");
			dataTab.v = Utils.math.incrementNumber(dataTab.v, 2);
			compressData();
		end
	end
end

local function displayRPStyle(context)
	if context.isCompanion then
		for _, frame in pairs(styleLines) do
			frame:Hide();
		end
		TRP3_RegisterMiscViewRPStyle:Hide();
		return;
	end
	TRP3_RegisterMiscViewRPStyle:Show();
	local dataTab = context.profile.misc or Globals.empty;
	local styleData = dataTab.ST or {};

	-- Hide all
	for _, frame in pairs(styleLines) do
		frame:Hide();
	end

	local previous;
	local count = 0;
	for index, fieldData in pairs(STYLE_FIELDS) do
		local frame = styleLines[index];
		if frame == nil then
			frame = CreateFrame("Frame", "TRP3_RegisterMiscViewRPStyle_line"..index, TRP3_RegisterMiscViewRPStyle, "TRP3_RegisterRPStyleMain_Edit_Line");
			setupListBox(_G[frame:GetName().."Values"], fieldData.values, onEditStyle, nil, 180, true);
			frame.fieldData = fieldData;
			tinsert(styleLines, frame);
		end

		local selectedValue = styleData[fieldData.id] or 0;

		if context.isPlayer or selectedValue ~= 0 then
			-- Position
			frame:ClearAllPoints();
			if previous == nil then
				frame:SetPoint("TOPLEFT", TRP3_RegisterMiscViewRPStyle, "TOPLEFT", 25, -12);
			else
				frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, 0);
			end
			frame:SetPoint("LEFT", 0, 0);
			frame:SetPoint("RIGHT", 0, 0);

			-- Value
			_G[frame:GetName().."FieldName"]:SetText(fieldData.name);
			local dropDown = _G[frame:GetName().."Values"];
			local readOnlyValue = _G[frame:GetName().."FieldValue"];
			if context.isPlayer then
				dropDown:SetSelectedValue(selectedValue);
				dropDown:Show();
				readOnlyValue:Hide();
			else
				dropDown:Hide();
				readOnlyValue:Show();
				local valueText = nil;
				for _, data in pairs(fieldData.values) do
					if data[2] == selectedValue then
						valueText = data[1];
						break;
					end
				end
				readOnlyValue:SetText(valueText);
			end

			frame:Show();
			previous = frame;
			count = count + 1;
		end
	end

	TRP3_RegisterMiscViewRPStyleEmpty:Hide();
	if not context.isPlayer and count == 0 then
		TRP3_RegisterMiscViewRPStyleEmpty:Show();
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- PEEK
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local GLANCE_NOT_USED_ICON = "INV_Misc_QuestionMark";
local PLAYER_GLANCE_SLOT_COUNT = 5;
local COMPANION_GLANCE_SLOT_COUNT = 3;

local function getGlanceSlotCount(context)
	return context and context.isCompanion and COMPANION_GLANCE_SLOT_COUNT or PLAYER_GLANCE_SLOT_COUNT;
end

local function getGlanceSlotButton(slot, slotCount)
	if slotCount == COMPANION_GLANCE_SLOT_COUNT then
		return _G["TRP3_RegisterMiscViewGlanceSlot" .. (slot + 1)];
	end
	return _G["TRP3_RegisterMiscViewGlanceSlot" .. slot];
end

local function layoutGlanceSlots(slotCount)
	for i=1,PLAYER_GLANCE_SLOT_COUNT do
		local button = _G["TRP3_RegisterMiscViewGlanceSlot" .. i];
		button:ClearAllPoints();
		button:Hide();
	end

	if slotCount == COMPANION_GLANCE_SLOT_COUNT then
		TRP3_RegisterMiscViewGlanceSlot2:Show();
		TRP3_RegisterMiscViewGlanceSlot3:Show();
		TRP3_RegisterMiscViewGlanceSlot4:Show();
		TRP3_RegisterMiscViewGlanceSlot3:SetPoint("CENTER", 0, 0);
		TRP3_RegisterMiscViewGlanceSlot2:SetPoint("RIGHT", TRP3_RegisterMiscViewGlanceSlot3, "LEFT", -10, 0);
		TRP3_RegisterMiscViewGlanceSlot4:SetPoint("LEFT", TRP3_RegisterMiscViewGlanceSlot3, "RIGHT", 10, 0);
	else
		for i=1,PLAYER_GLANCE_SLOT_COUNT do
			_G["TRP3_RegisterMiscViewGlanceSlot" .. i]:Show();
		end
		TRP3_RegisterMiscViewGlanceSlot5:SetPoint("RIGHT", -45, 0);
		TRP3_RegisterMiscViewGlanceSlot4:SetPoint("RIGHT", TRP3_RegisterMiscViewGlanceSlot5, "LEFT", -10, 0);
		TRP3_RegisterMiscViewGlanceSlot3:SetPoint("RIGHT", TRP3_RegisterMiscViewGlanceSlot4, "LEFT", -10, 0);
		TRP3_RegisterMiscViewGlanceSlot2:SetPoint("RIGHT", TRP3_RegisterMiscViewGlanceSlot3, "LEFT", -10, 0);
		TRP3_RegisterMiscViewGlanceSlot1:SetPoint("RIGHT", TRP3_RegisterMiscViewGlanceSlot2, "LEFT", -10, 0);
	end
end

local function setupGlanceButton(button, active, icon, title, text, isMine)
	button:Enable();
	button.isCurrentMine = isMine;
	button:SetNormalTexture("Interface\\ICONS\\" .. (icon or GLANCE_NOT_USED_ICON));
	if active then
		button:SetAlpha(1);
		if not isMine then
			setTooltipForSameFrame(button, "RIGHT", 0, 5, title or "...", text);
		else
			setTooltipForSameFrame(button, "RIGHT", 0, 5, title or "...", (text or "..."));
		end
	else
		button:SetAlpha(0.1);
		if not isMine then
			button:Disable();
		else
			setTooltipForSameFrame(button, "RIGHT", 0, 5, loc("REG_PLAYER_GLANCE_UNUSED"));
		end
	end
end
TRP3_API.register.setupGlanceButton = setupGlanceButton;

local function displayPeek(context)
	TRP3_AtFirstGlanceEditor:Hide();
	local dataTab = context.profile.misc or Globals.empty;
	local slotCount = getGlanceSlotCount(context);
	layoutGlanceSlots(slotCount);
	for i=1,slotCount do
		local glanceData = (dataTab.PE or {})[tostring(i)] or {};
		local button = getGlanceSlotButton(i, slotCount);
		button.slot = tostring(i);
		button.data = glanceData;
		setupGlanceButton(button, glanceData.AC, glanceData.IC, glanceData.TI, glanceData.TX, context.isPlayer);
	end
	if context.isPlayer then
		TRP3_RegisterMiscViewGlanceHelp:Show();
	else
		TRP3_RegisterMiscViewGlanceHelp:Hide();
	end
end


function TRP3_API.register.checkGlanceActivation(dataTab)
	for i=1, 5, 1 do
		if dataTab[tostring(i)] and dataTab[tostring(i)].AC then
			return true
		end
	end
	return false;
end

function TRP3_API.register.getGlanceIconTextures(dataTab, size)
	local text = "";
	for i=1, 5, 1 do
		local index = tostring(i);
		if dataTab[index] and dataTab[index].AC then
			text = text .. "|TInterface\\ICONS\\".. (dataTab[index].IC or Globals.icons.default) .. ":" .. size .. "|t "
		end
	end
	return text;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Peek editor
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local draftData = {};
local displayDropDown, setGlanceSlotPreset = TRP3_API.ui.listbox.displayDropDown;

local function getPeekDataTab(targetID, profileID)
	local context = getCurrentContext();
	if targetID and profileID and TRP3_API.register and TRP3_API.register.getProfile then
		local profile = TRP3_API.register.getProfile(profileID);
		profile.misc = profile.misc or { v = 1 };
		return profile.misc, targetID, profileID, TRP3_API.register.companion and TRP3_API.register.companion.isProfile(profile);
	end

	local dataTab = context and context.profile and context.profile.misc or get("player/misc");
	if context and context.profile and not dataTab then
		context.profile.misc = { v = 1 };
		dataTab = context.profile.misc;
	end
	return dataTab, (context and context.unitID) or Globals.player_id, context and context.profileID or getPlayerCurrentProfileID(), context and context.isCompanion;
end

local function applyPeekSlot(slot, ic, ac, ti, tx, swap, targetID, profileID)
	TRP3_AtFirstGlanceEditor:Hide();
	assert(slot, "No selection ...");
	local dataTab, eventUnitID, eventProfileID, isCompanion = getPeekDataTab(targetID, profileID);
	if isCompanion and tonumber(slot) and tonumber(slot) > COMPANION_GLANCE_SLOT_COUNT then
		return;
	end
	if not dataTab.PE then
		dataTab.PE = {};
	end
	if not dataTab.PE[slot] then
		dataTab.PE[slot] = {};
	end
	local peekTab = dataTab.PE[slot];
	if swap then
		peekTab.AC = not peekTab.AC;
	else
		peekTab.IC = ic;
		peekTab.AC = ac;
		peekTab.TI = ti;
		peekTab.TX = tx;
	end
	-- version increment
	assert(type(dataTab.v) == "number", "Error: No version in draftData or not a number.");
	dataTab.v = Utils.math.incrementNumber(dataTab.v, 2);
	if not isCompanion then
		compressData();
	end
	-- Refresh display & target frame
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, eventUnitID, eventProfileID, "misc");
	if not isCompanion and TRP3_API.register.checkCurrentProfileForNSFW then
		TRP3_API.register.checkCurrentProfileForNSFW();
	end
end
TRP3_API.register.applyPeekSlot = applyPeekSlot;

local function swapGlanceSlot(from, to, targetID, profileID)
	TRP3_AtFirstGlanceEditor:Hide();
	local dataTab, eventUnitID, eventProfileID, isCompanion = getPeekDataTab(targetID, profileID);
	if isCompanion and ((tonumber(from) and tonumber(from) > COMPANION_GLANCE_SLOT_COUNT) or (tonumber(to) and tonumber(to) > COMPANION_GLANCE_SLOT_COUNT)) then
		return;
	end
	TRP3_API.register.glance.swapDataFromSlots(dataTab, from, to);
	-- Refresh display & target frame
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, eventUnitID, eventProfileID, "misc");
	if not isCompanion then
		compressData();
	end
end
TRP3_API.register.swapGlanceSlot = swapGlanceSlot;

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Currently
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local TRP3_RegisterMiscViewCurrentlyIC, TRP3_RegisterMiscViewCurrentlyOOC = TRP3_RegisterMiscViewCurrentlyICScrollText, TRP3_RegisterMiscViewCurrentlyOOCScrollText;
local TRP3_RegisterMiscViewCurrentlyICPronouns, TRP3_RegisterMiscViewCurrentlyOOCPronouns = TRP3_RegisterMiscViewCurrentlyICPronouns, TRP3_RegisterMiscViewCurrentlyOOCPronouns;
local IC_PRONOUNS_PLACEHOLDER = "";
local OOC_PRONOUNS_PLACEHOLDER = "";

local function buildInfoLabel(baseLabel, pronouns)
	if pronouns and pronouns:len() > 0 then
		return ("%s (%s)"):format(baseLabel, pronouns);
	end
	return baseLabel;
end

local function setPronounsPlaceholder(box, placeholder, value)
	if not box then
		return;
	end
	if value and value ~= "" then
		box.isPlaceholder = nil;
		box:SetTextColor(1, 1, 1);
		box:SetText(value);
	else
		box.isPlaceholder = true;
		box:SetTextColor(0.65, 0.65, 0.65);
		box:SetText(placeholder);
	end
end

local function setPronounsEditBoxEnabled(box, enabled)
	if not box then
		return;
	end

	box.disabled = not enabled;
	box:EnableMouse(enabled);

	if enabled then
		box:SetTextColor(1, 1, 1);
	else
		box:ClearFocus();
		box:SetTextColor(0.65, 0.65, 0.65);
	end
end

local function displayCurrently(context)
	local isCompanion = context.isCompanion;
	local icFrame = _G.TRP3_RegisterMiscViewCurrentlyIC;
	local oocFrame = _G.TRP3_RegisterMiscViewCurrentlyOOC;
	-- workaround as Enable/Disable methods don't work on scroll text elements 
	if context.isPlayer then
		TRP3_RegisterMiscViewCurrentlyIC:EnableMouse(true);
		TRP3_RegisterMiscViewCurrentlyOOC:EnableMouse(not isCompanion);
		setPronounsEditBoxEnabled(TRP3_RegisterMiscViewCurrentlyICPronouns, true);
		setPronounsEditBoxEnabled(TRP3_RegisterMiscViewCurrentlyOOCPronouns, not isCompanion);
		TRP3_RegisterMiscViewCurrentlyICHelp:Show();
		if isCompanion then
			TRP3_RegisterMiscViewCurrentlyOOCHelp:Hide();
		else
			TRP3_RegisterMiscViewCurrentlyOOCHelp:Show();
		end
	else
		TRP3_RegisterMiscViewCurrentlyIC:EnableMouse(false);
		TRP3_RegisterMiscViewCurrentlyIC:ClearFocus();
		TRP3_RegisterMiscViewCurrentlyOOC:EnableMouse(false);
		TRP3_RegisterMiscViewCurrentlyOOC:ClearFocus();
		setPronounsEditBoxEnabled(TRP3_RegisterMiscViewCurrentlyICPronouns, false);
		setPronounsEditBoxEnabled(TRP3_RegisterMiscViewCurrentlyOOCPronouns, false);
		TRP3_RegisterMiscViewCurrentlyICHelp:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCHelp:Hide();
	end

	local dataTab = context.profile.character or Globals.empty;
	if isCompanion then
		dataTab.CO = nil;
		dataTab.PROOC = nil;
	end
	TRP3_RegisterMiscViewCurrentlyIC:SetText(dataTab.CU or "");
	TRP3_RegisterMiscViewCurrentlyOOC:SetText(dataTab.CO or "");
	setPronounsPlaceholder(TRP3_RegisterMiscViewCurrentlyICPronouns, IC_PRONOUNS_PLACEHOLDER, dataTab.PRIC);
	setPronounsPlaceholder(TRP3_RegisterMiscViewCurrentlyOOCPronouns, OOC_PRONOUNS_PLACEHOLDER, dataTab.PROOC);
	if isCompanion then
		icFrame:ClearAllPoints();
		icFrame:SetPoint("TOP", 0, -68);
		icFrame:SetPoint("BOTTOM", 0, 10);
		icFrame:SetPoint("LEFT", 10, 0);
		icFrame:SetPoint("RIGHT", -10, 0);
		TRP3_RegisterMiscViewCurrentlyICScrollText:ClearAllPoints();
		TRP3_RegisterMiscViewCurrentlyICScrollText:SetPoint("TOPLEFT");
		if icFrame:GetWidth() and icFrame:GetWidth() > 40 then
			TRP3_RegisterMiscViewCurrentlyICScrollText:SetWidth(icFrame:GetWidth() - 40);
		end
		TRP3_RegisterMiscViewCurrentlyICScroll:SetVerticalScroll(0);
		if TRP3_RegisterMiscViewCurrentlyICScrollText.SetJustifyV then
			TRP3_RegisterMiscViewCurrentlyICScrollText:SetJustifyV("TOP");
		end
		TRP3_RegisterMiscViewCurrentlyICScrollText:SetCursorPosition(0);
		oocFrame:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCScrollText:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCScroll:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCTitle:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCHelp:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCPronouns:Hide();
		TRP3_RegisterMiscViewCurrentlyOOCFocusDummy:Hide();
	else
		icFrame:ClearAllPoints();
		icFrame:SetPoint("TOP", 0, -68);
		icFrame:SetPoint("BOTTOM", 0, 10);
		icFrame:SetPoint("LEFT", 10, 0);
		icFrame:SetWidth(255);
		TRP3_RegisterMiscViewCurrentlyICScrollText:ClearAllPoints();
		TRP3_RegisterMiscViewCurrentlyICScrollText:SetPoint("TOPLEFT");
		TRP3_RegisterMiscViewCurrentlyICScrollText:SetWidth(215);
		oocFrame:Show();
		TRP3_RegisterMiscViewCurrentlyOOCScrollText:Show();
		TRP3_RegisterMiscViewCurrentlyOOCScroll:Show();
		TRP3_RegisterMiscViewCurrentlyOOCTitle:Show();
		TRP3_RegisterMiscViewCurrentlyOOCPronouns:Show();
		TRP3_RegisterMiscViewCurrentlyOOCFocusDummy:Show();
	end
	if not context.isPlayer and dataTab.CU and dataTab.CU:len() > 0 then
		setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyIC, "TOP", 0, 5, buildInfoLabel(loc("DB_STATUS_CURRENTLY"), dataTab.PRIC), dataTab.CU);
	else
		setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyIC);
	end
	if not context.isPlayer and dataTab.CO and dataTab.CO:len() > 0 then
		setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyOOC, "TOP", 0, 5, buildInfoLabel(loc("DB_STATUS_CURRENTLY_OOC"), dataTab.PROOC), dataTab.CO);
	else
		setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyOOC);
	end
end

local function onCurrentlyChanged()
	local context = getCurrentContext();
	if context.isPlayer then
		local character = context.profile and context.profile.character or get("player/character");
		local old = character.CU;
		character.CU = TRP3_RegisterMiscViewCurrentlyIC:GetText();
		if old ~= character.CU then
			character.v = Utils.math.incrementNumber(character.v or 1, 2);
			Events.fireEvent(Events.REGISTER_DATA_UPDATED, context.unitID or Globals.player_id, context.profileID or getPlayerCurrentProfileID(), "character");
			if TRP3_API.register.checkCurrentProfileForNSFW then
				TRP3_API.register.checkCurrentProfileForNSFW();
			end
		end
	end
end

local function onOOCInfoChanged()
	local context = getCurrentContext();
	if context.isPlayer and not context.isCompanion then
		local character = context.profile and context.profile.character or get("player/character");
		local old = character.CO;
		character.CO = TRP3_RegisterMiscViewCurrentlyOOC:GetText();
		if old ~= character.CO then
			character.v = Utils.math.incrementNumber(character.v or 1, 2);
			Events.fireEvent(Events.REGISTER_DATA_UPDATED, context.unitID or Globals.player_id, context.profileID or getPlayerCurrentProfileID(), "character");
			if TRP3_API.register.checkCurrentProfileForNSFW then
				TRP3_API.register.checkCurrentProfileForNSFW();
			end
		end
	end
end

local function onICPronounsChanged()
	local context = getCurrentContext();
	if context.isPlayer then
		local character = context.profile and context.profile.character or get("player/character");
		local old = character.PRIC;
		local text = TRP3_RegisterMiscViewCurrentlyICPronouns:GetText();
		if TRP3_RegisterMiscViewCurrentlyICPronouns.isPlaceholder then
			text = "";
		end
		character.PRIC = stEtN(text);
		if old ~= character.PRIC then
			character.v = Utils.math.incrementNumber(character.v or 1, 2);
			Events.fireEvent(Events.REGISTER_DATA_UPDATED, context.unitID or Globals.player_id, context.profileID or getPlayerCurrentProfileID(), "character");
			if TRP3_API.register.checkCurrentProfileForNSFW then
				TRP3_API.register.checkCurrentProfileForNSFW();
			end
		end
	end
end

local function onOOCPronounsChanged()
	local context = getCurrentContext();
	if context.isPlayer and not context.isCompanion then
		local character = context.profile and context.profile.character or get("player/character");
		local old = character.PROOC;
		local text = TRP3_RegisterMiscViewCurrentlyOOCPronouns:GetText();
		if TRP3_RegisterMiscViewCurrentlyOOCPronouns.isPlaceholder then
			text = "";
		end
		character.PROOC = stEtN(text);
		if old ~= character.PROOC then
			character.v = Utils.math.incrementNumber(character.v or 1, 2);
			Events.fireEvent(Events.REGISTER_DATA_UPDATED, context.unitID or Globals.player_id, context.profileID or getPlayerCurrentProfileID(), "character");
			if TRP3_API.register.checkCurrentProfileForNSFW then
				TRP3_API.register.checkCurrentProfileForNSFW();
			end
		end
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Misc logic
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function showMiscTab()
	local context = getCurrentContext();
	assert(context, "No context for page player_main !");
	assert(context.profile, "No profile in context");
	TRP3_RegisterMisc:Show();
	if context.isCompanion then
		context.profile.misc = context.profile.misc or {};
		context.profile.misc.ST = nil;
		context.profile.character = context.profile.character or {};
		context.profile.character.CO = nil;
		context.profile.character.PROOC = nil;
	end
	displayCurrently(context);
	displayPeek(context);
	displayRPStyle(context);
end
TRP3_API.register.ui.showMiscTab = showMiscTab;

local currentCompressed;

function compressData()
	local data = get("player/misc");
	local dataToSend = {
		v = data.v,
		ST = data.ST,
		PE = {},
	};
	-- Only send used slot !
	for slotIndex, slot in pairs(data.PE) do
		if slot.AC then
			dataToSend.PE[slotIndex] = slot;
		end
	end

	local serial = Utils.serial.serialize(dataToSend);
	local compressed = Utils.serial.encodeCompressMessage(serial);

	--	print(("Compressed data : %s / %s (%i%%)"):format(compressed:len(), serial:len(), compressed:len() / serial:len() * 100));
	if compressed:len() < serial:len() then
		currentCompressed = compressed;
	else
		currentCompressed = dataToSend;
	end
end

function TRP3_API.register.player.getMiscExchangeData()
	return currentCompressed;
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- Init
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

function TRP3_API.register.inits.miscInit()
	buildStyleStructure();

	setupFieldSet(TRP3_RegisterMiscViewGlance, loc("REG_PLAYER_GLANCE"), 150);
	setupFieldSet(TRP3_RegisterMiscViewCurrently, loc("REG_PLAYER_CURRENT"), 150);
	TRP3_AtFirstGlanceEditorApply:SetText(loc("CM_APPLY"));
	TRP3_AtFirstGlanceEditorNameText:SetText(loc("REG_PLAYER_GLANCE_TITLE"));
	TRP3_RegisterMiscViewRPStyleEmpty:SetText(loc("REG_PLAYER_STYLE_EMPTY"));

	TRP3_API.ui.tooltip.setTooltipAll(TRP3_AtFirstGlanceEditorActive, "TOP", 0, 0, loc("REG_PLAYER_GLANCE_USE"));

	TRP3_RegisterMiscViewCurrentlyICTitle:SetText(loc("DB_STATUS_CURRENTLY"));
	setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyICHelp, "LEFT", 0, 10, loc("DB_STATUS_CURRENTLY"), loc("DB_STATUS_CURRENTLY_TT"));
	TRP3_RegisterMiscViewCurrentlyIC:SetScript("OnTextChanged", onCurrentlyChanged);
	IC_PRONOUNS_PLACEHOLDER = loc("DB_STATUS_CURRENTLY_PRONOUNS_IC");
	TRP3_RegisterMiscViewCurrentlyICPronounsText:SetText("");
	setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyICPronouns, "TOP", 0, 5, loc("DB_STATUS_CURRENTLY_PRONOUNS_IC"), loc("DB_STATUS_CURRENTLY_PRONOUNS_IC_TT"));
	TRP3_RegisterMiscViewCurrentlyICPronouns:SetScript("OnTextChanged", onICPronounsChanged);
	TRP3_RegisterMiscViewCurrentlyICPronouns:SetScript("OnEditFocusGained", function(self)
		if self.isPlaceholder then
			self.isPlaceholder = nil;
			self:SetText("");
			self:SetTextColor(1, 1, 1);
		end
		self:HighlightText();
	end);
	TRP3_RegisterMiscViewCurrentlyICPronouns:SetScript("OnEditFocusLost", function(self)
		if self:GetText() == "" then
			setPronounsPlaceholder(self, IC_PRONOUNS_PLACEHOLDER, nil);
		else
			self:SetTextColor(1, 1, 1);
		end
		self:HighlightText(0, 0);
	end);
	TRP3_RegisterMiscViewCurrentlyICPronouns:SetMaxLetters(32);

	TRP3_RegisterMiscViewCurrentlyOOCTitle:SetText(loc("DB_STATUS_CURRENTLY_OOC"));
	setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyOOCHelp, "LEFT", 0, 10, loc("DB_STATUS_CURRENTLY_OOC"), loc("DB_STATUS_CURRENTLY_OOC_TT"));
	TRP3_RegisterMiscViewCurrentlyOOC:SetScript("OnTextChanged", onOOCInfoChanged);
	OOC_PRONOUNS_PLACEHOLDER = loc("DB_STATUS_CURRENTLY_PRONOUNS_OOC");
	TRP3_RegisterMiscViewCurrentlyOOCPronounsText:SetText("");
	setTooltipForSameFrame(TRP3_RegisterMiscViewCurrentlyOOCPronouns, "TOP", 0, 5, loc("DB_STATUS_CURRENTLY_PRONOUNS_OOC"), loc("DB_STATUS_CURRENTLY_PRONOUNS_OOC_TT"));
	TRP3_RegisterMiscViewCurrentlyOOCPronouns:SetScript("OnTextChanged", onOOCPronounsChanged);
	TRP3_RegisterMiscViewCurrentlyOOCPronouns:SetScript("OnEditFocusGained", function(self)
		if self.isPlaceholder then
			self.isPlaceholder = nil;
			self:SetText("");
			self:SetTextColor(1, 1, 1);
		end
		self:HighlightText();
	end);
	TRP3_RegisterMiscViewCurrentlyOOCPronouns:SetScript("OnEditFocusLost", function(self)
		if self:GetText() == "" then
			setPronounsPlaceholder(self, OOC_PRONOUNS_PLACEHOLDER, nil);
		else
			self:SetTextColor(1, 1, 1);
		end
		self:HighlightText(0, 0);
	end);
	TRP3_RegisterMiscViewCurrentlyOOCPronouns:SetMaxLetters(32);

	setTooltipForSameFrame(TRP3_RegisterMiscViewGlanceHelp, "LEFT", 0, 10, loc("REG_PLAYER_GLANCE"), loc("REG_PLAYER_GLANCE_CONFIG"));

	for index=1,5,1 do
		-- DISPLAY
		local button = _G["TRP3_RegisterMiscViewGlanceSlot" .. index];
		button:SetDisabledTexture("Interface\\ICONS\\" .. GLANCE_NOT_USED_ICON);
		button:GetDisabledTexture():SetDesaturated(1);
		button:SetScript("OnClick", TRP3_API.register.glance.onGlanceSlotClick);
		button:SetScript("OnDoubleClick", TRP3_API.register.glance.onGlanceDoubleClick);
		button:RegisterForClicks("LeftButtonUp", "RightButtonUp");
		button:RegisterForDrag("LeftButton");
		button:SetScript("OnDragStart", TRP3_API.register.glance.onGlanceDragStart);
		button:SetScript("OnDragStop", TRP3_API.register.glance.onGlanceDragStop);
		button.slot = tostring(index);
		button.targetType = TRP3_API.ui.misc.TYPE_CHARACTER;
	end

	-- RP style
	setupFieldSet(TRP3_RegisterMiscViewRPStyle, loc("REG_PLAYER_STYLE_RPSTYLE"), 150);

	Events.listenToEvent(Events.REGISTER_DATA_UPDATED, function(unitID, _, dataType)
		local context = getCurrentContext();
		if getCurrentPageID() == "player_main" and context and (unitID == Globals.player_id or unitID == context.unitID or context.isCompanion) and (not dataType or dataType == "misc") then
			TRP3_API.popup.hidePopups();
			assert(context, "No context for page player_main !");
			displayPeek(context);
		end
	end);

	Events.listenToEvent(Events.REGISTER_PROFILES_LOADED, compressData); -- On profile change, compress the new data
	compressData();
end
