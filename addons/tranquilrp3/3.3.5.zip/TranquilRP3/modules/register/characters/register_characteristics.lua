----------------------------------------------------------------------------------
-- Total RP 3 / Tranquil RP 3
-- Character page : Characteristics
-- ---------------------------------------------------------------------------
-- Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
-- http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
----------------------------------------------------------------------------------

-- imports
local Globals, Utils, Comm, Events = TRP3_API.globals, TRP3_API.utils, TRP3_API.communication, TRP3_API.events;
local stEtN = Utils.str.emptyToNil;
local stNtE = Utils.str.nilToEmpty;
local get = TRP3_API.profile.getData;
local getProfile = TRP3_API.register.getProfile;
local tcopy, tsize = Utils.table.copy, Utils.table.size;
local numberToHexa, hexaToNumber = Utils.color.numberToHexa, Utils.color.hexaToNumber;
local loc = TRP3_API.locale.getText;
local getDefaultProfile = TRP3_API.profile.getDefaultProfile;
local showIconBrowser = TRP3_API.popup.showIconBrowser;
local assert, type, wipe, strconcat, pairs, tinsert, tremove, _G, strtrim = assert, type, wipe, strconcat, pairs, tinsert, tremove, _G, strtrim;
local strjoin, unpack, getKeys = strjoin, unpack, Utils.table.keys;
local getTiledBackground = TRP3_API.ui.frame.getTiledBackground;
local setupDropDownMenu = TRP3_API.ui.listbox.setupDropDownMenu;
local setTooltipForSameFrame = TRP3_API.ui.tooltip.setTooltipForSameFrame;
local getCurrentContext = TRP3_API.navigation.page.getCurrentContext;
local setupIconButton = TRP3_API.ui.frame.setupIconButton;
local setupFieldSet = TRP3_API.ui.frame.setupFieldPanel;
local getUnitIDCharacter = TRP3_API.register.getUnitIDCharacter;
local getUnitIDProfile, getPlayerCurrentProfile = TRP3_API.register.getUnitIDProfile, TRP3_API.profile.getPlayerCurrentProfile;
local hasProfile, getRelationTexture = TRP3_API.register.hasProfile, TRP3_API.register.relation.getRelationTexture;
local getUnitIDDirectoryLite = TRP3_API.register.getUnitIDDirectoryLite;
local RELATIONS = TRP3_API.register.relation;
local getRelationText, getRelationTooltipText, setRelation = RELATIONS.getRelationText, RELATIONS.getRelationTooltipText, RELATIONS.setRelation;
local CreateFrame = CreateFrame;
local TRP3_RegisterCharact_CharactPanel_Empty = TRP3_RegisterCharact_CharactPanel_Empty;
local displayDropDown = TRP3_API.ui.listbox.displayDropDown;
local setTooltipAll = TRP3_API.ui.tooltip.setTooltipAll;
local showConfirmPopup, showTextInputPopup = TRP3_API.popup.showConfirmPopup, TRP3_API.popup.showTextInputPopup;
local deleteProfile = TRP3_API.register.deleteProfile;
local selectMenu = TRP3_API.navigation.menu.selectMenu;
local unregisterMenu = TRP3_API.navigation.menu.unregisterMenu;
local ignoreID = TRP3_API.register.ignoreID;
local buildZoneText = Utils.str.buildZoneText;
local setupEditBoxesNavigation = TRP3_API.ui.frame.setupEditBoxesNavigation;
local GetGuildInfo = GetGuildInfo;
local GetRealmName = GetRealmName;
local UnitFactionGroup = UnitFactionGroup;

local TRAIT_PRESETS_UNKNOWN;
local TRAIT_PRESETS;
local TRAIT_PRESETS_DROPDOWN;
local FACTION_BADGE_ALLIANCE = "f1";
local FACTION_BADGE_HORDE = "f2";
local FACTION_BADGE_INDEPENDENT = "f3";
local FACTION_BADGE_TEXTURES = {
	[FACTION_BADGE_ALLIANCE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_alliance.blp",
	[FACTION_BADGE_HORDE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_horde.blp",
	[FACTION_BADGE_INDEPENDENT] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_neutral.blp",
};
local FACTION_BADGE_TT_TEXTURES = {
	[FACTION_BADGE_ALLIANCE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_alliance_tt.blp",
	[FACTION_BADGE_HORDE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_horde_tt.blp",
	[FACTION_BADGE_INDEPENDENT] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\trp_faction_neutral_tt.blp",
};
local FACTION_BADGE_MAP_TEXTURES = {
	[FACTION_BADGE_ALLIANCE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconAlliance.blp",
	[FACTION_BADGE_HORDE] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconHorde.blp",
	[FACTION_BADGE_INDEPENDENT] = "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconTRP.blp",
};
local FACTION_BADGE_OOC_TEXTURE = "Interface\\AddOns\\TranquilRP3\\resources\\images\\WorldMapPlayerIconOOC.blp";
local DEV_BADGE_REALM = "glitterwing";
local DEV_BADGE_NAMES = {
	takoy = true,
	veln = true,
	prynn = true,
};
local DEV_BADGE_SHORT_LABEL = "TRP Developer";
local DEV_BADGE_LONG_LABEL = "TranquilRP3 Developer";
local DEV_BADGE_GRADIENT = {
	"63D7FF",
	"FF8FC6",
	"FFF9FC",
};

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- SCHEMA
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

getDefaultProfile().player.characteristics = {
	v = 1,
	RA = Globals.player_race_loc,
	CL = Globals.player_class_loc,
	FN = Globals.player,
	IC = TRP3_API.ui.misc.getUnitTexture(Globals.player_character.race, UnitSex("player")),
	CH = (function()
		local classColorTable = RAID_CLASS_COLORS[Globals.player_character.class];
		if classColorTable then
			return ("%02x%02x%02x"):format(classColorTable.r*255, classColorTable.g*255, classColorTable.b*255);
		end
		return "ffffff"; -- fallback to white
	end)(),
	GT = nil,
	GR = nil,
	FC = (function()
		local faction = UnitFactionGroup("player");
		if faction == "Alliance" then
			return FACTION_BADGE_ALLIANCE;
		elseif faction == "Horde" then
			return FACTION_BADGE_HORDE;
		end
		return FACTION_BADGE_INDEPENDENT;
	end)(),
	FH = nil,
	MI = {},
	PS = {}
};

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- COMPRESSION
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local currentCompressed;

local function compressData()
	local dataTab = get("player/characteristics");
	local serial = Utils.serial.serialize(dataTab);
	local compressed = Utils.serial.encodeCompressMessage(serial);
	if compressed:len() < serial:len() then
		currentCompressed = compressed;
		--		Utils.log.log(("Compressed data is better: %s / %s (%i%%)"):format(compressed:len(), serial:len(), compressed:len() / serial:len() * 100));
	else
		currentCompressed = nil;
	end
end

function TRP3_API.register.player.getCharacteristicsExchangeData()
	if currentCompressed ~= nil then
		return currentCompressed;
	else
		return get("player/characteristics");
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- CHARACTERISTICS - CONSULT
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local registerCharFrame = {};
local registerCharLocals = {
	RA = "REG_PLAYER_RACE",
	CL = "REG_PLAYER_CLASS",
	AG = "REG_PLAYER_AGE",
	EC = "REG_PLAYER_EYE",
	HE = "REG_PLAYER_HEIGHT",
	WE = "REG_PLAYER_WEIGHT",
	BP = "REG_PLAYER_BIRTHPLACE",
	RE = "REG_PLAYER_RESIDENCE"
};
local miscCharFrame = {};
local psychoCharFrame = {};
local factionBadgeButton, factionBadgePreview, factionBadgeHideCheckbox;
local nsfwProfileCheckbox;

local function getDefaultFactionBadge()
	local faction = UnitFactionGroup("player");
	if faction == "Alliance" then
		return FACTION_BADGE_ALLIANCE;
	elseif faction == "Horde" then
		return FACTION_BADGE_HORDE;
	end
	return FACTION_BADGE_INDEPENDENT;
end

local LEGACY_RACE_FACTION_MAP = {
	Human = FACTION_BADGE_ALLIANCE,
	Dwarf = FACTION_BADGE_ALLIANCE,
	NightElf = FACTION_BADGE_ALLIANCE,
	Nightelf = FACTION_BADGE_ALLIANCE,
	["Night Elf"] = FACTION_BADGE_ALLIANCE,
	Gnome = FACTION_BADGE_ALLIANCE,
	Draenei = FACTION_BADGE_ALLIANCE,
	Orc = FACTION_BADGE_HORDE,
	Scourge = FACTION_BADGE_HORDE,
	Undead = FACTION_BADGE_HORDE,
	Tauren = FACTION_BADGE_HORDE,
	Troll = FACTION_BADGE_HORDE,
	BloodElf = FACTION_BADGE_HORDE,
	Bloodelf = FACTION_BADGE_HORDE,
	["Blood Elf"] = FACTION_BADGE_HORDE,
};

local function normalizeLegacyRaceName(race)
	race = tostring(race or "");
	race = race:gsub("%s+", ""):gsub("[^%a]", ""):lower();
	return race;
end

local NORMALIZED_LEGACY_RACE_FACTION_MAP = {
	human = FACTION_BADGE_ALLIANCE,
	dwarf = FACTION_BADGE_ALLIANCE,
	nightelf = FACTION_BADGE_ALLIANCE,
	gnome = FACTION_BADGE_ALLIANCE,
	draenei = FACTION_BADGE_ALLIANCE,
	worgen = FACTION_BADGE_ALLIANCE,
	highelf = FACTION_BADGE_ALLIANCE,
	orc = FACTION_BADGE_HORDE,
	scourge = FACTION_BADGE_HORDE,
	undead = FACTION_BADGE_HORDE,
	tauren = FACTION_BADGE_HORDE,
	troll = FACTION_BADGE_HORDE,
	bloodelf = FACTION_BADGE_HORDE,
	goblin = FACTION_BADGE_HORDE,
};

local function getFactionBadgeFromRace(race)
	return LEGACY_RACE_FACTION_MAP[race] or NORMALIZED_LEGACY_RACE_FACTION_MAP[normalizeLegacyRaceName(race)];
end

local function getFactionBadgeFromFaction(faction)
	faction = tostring(faction or "");
	local factionLower = faction:lower();
	if faction == FACTION_BADGE_ALLIANCE or factionLower == "alliance" then
		return FACTION_BADGE_ALLIANCE;
	elseif faction == FACTION_BADGE_HORDE or factionLower == "horde" then
		return FACTION_BADGE_HORDE;
	elseif faction == FACTION_BADGE_INDEPENDENT or factionLower == "independent" or factionLower == "neutral" then
		return FACTION_BADGE_INDEPENDENT;
	end
end

local function inferLegacyFactionBadge(character, dataTab)
	local raceBadge = getFactionBadgeFromRace(character and character.race) or getFactionBadgeFromRace(dataTab and dataTab.RA);
	if raceBadge then
		return raceBadge;
	end

	return getFactionBadgeFromFaction(character and character.faction);
end

local function normalizeFactionBadge(factionCode)
	return getFactionBadgeFromFaction(factionCode) or getDefaultFactionBadge();
end

local function normalizeOptionalFactionBadge(factionCode)
	return getFactionBadgeFromFaction(factionCode);
end

local function getFactionBadgeLabel(factionCode)
	factionCode = normalizeFactionBadge(factionCode);
	if factionCode == FACTION_BADGE_ALLIANCE then
		return loc("REG_PLAYER_FACTION_ALLIANCE");
	elseif factionCode == FACTION_BADGE_HORDE then
		return loc("REG_PLAYER_FACTION_HORDE");
	end
	return loc("REG_PLAYER_FACTION_INDEPENDENT");
end

local function getFactionBadgeTexture(factionCode, tooltipVersion)
	factionCode = normalizeFactionBadge(factionCode);
	if tooltipVersion then
		return FACTION_BADGE_TT_TEXTURES[factionCode];
	end
	return FACTION_BADGE_TEXTURES[factionCode];
end

local function getFactionBadgeMapTexture(factionCode, isOOC)
	if isOOC then
		return FACTION_BADGE_OOC_TEXTURE;
	end
	factionCode = normalizeFactionBadge(factionCode);
	return FACTION_BADGE_MAP_TEXTURES[factionCode] or FACTION_BADGE_MAP_TEXTURES[FACTION_BADGE_INDEPENDENT];
end

TRP3_API.register.getProfileFactionBadge = normalizeFactionBadge;

local function getContextCharacter(context)
	if not context then
		return nil;
	end
	if context.isPlayer then
		return Globals.player_character;
	end
	if context.profile and context.profile.link then
		for unitID, _ in pairs(context.profile.link) do
			if type(unitID) == "string" and TRP3_API.register.isUnitIDKnown(unitID) then
				return getUnitIDCharacter(unitID);
			end
		end
	end
	return nil;
end

local function sanitizeDisplayName(name)
	name = strtrim(tostring(name or ""));
	if name == "" then
		return nil;
	end

	name = name:gsub("|T.-|t%s*", "");
	name = name:gsub("|c%x%x%x%x%x%x%x%x", "");
	name = name:gsub("|r", "");
	name = name:gsub("^%[?c?ff%x%x%x%x%x%x", "");
	name = name:gsub("%^+", "");
	name = name:gsub("%s+", " ");
	name = strtrim(name);

	if name == "" then
		return nil;
	end

	return name;
end

TRP3_API.register.sanitizeDisplayName = sanitizeDisplayName;

local function sanitizeIconName(icon)
	icon = strtrim(tostring(icon or ""));
	if icon == "" then
		return nil;
	end

	icon = icon:gsub("|T", "");
	icon = icon:gsub("|t", "");
	icon = icon:gsub(":%d+:%d+.*$", "");
	icon = icon:gsub("^Interface\\ICONS\\", "");
	icon = icon:gsub("^Interface/ICONS/", "");
	icon = icon:match("([^\\/]+)$") or icon;
	icon = strtrim(icon);

	if icon == "" then
		return nil;
	end

	return icon;
end

TRP3_API.register.sanitizeIconName = sanitizeIconName;

local function getCompleteName(characteristicsTab, name, hideTitle)
	if not characteristicsTab then
		return name;
	end
	local text = "";
	if not hideTitle and characteristicsTab.TI then
		text = strconcat(characteristicsTab.TI, " ");
	end
	text = strconcat(text, characteristicsTab.FN or name);
	if characteristicsTab.LN then
		text = strconcat(text, " ", characteristicsTab.LN);
	end
	return text;
end

TRP3_API.register.getCompleteName = getCompleteName;

local function getPlayerCompleteName(hideTitle)
	local profile = getPlayerCurrentProfile();
	return getCompleteName(profile.player.characteristics, Globals.player, hideTitle);
end

TRP3_API.register.getPlayerCompleteName = getPlayerCompleteName;

local function normalizeDeveloperBadgeToken(value)
	value = tostring(value or ""):lower();
	value = value:gsub("[%s%-_]+", "");
	return value;
end

local function getDeveloperBadgeNameToken(value)
	value = strtrim(tostring(value or ""));
	value = value:gsub("|T.-|t%s*", "");
	value = value:gsub("|c%x%x%x%x%x%x%x%x", "");
	value = value:gsub("|r", "");
	value = value:gsub(":.*$", "");
	value = value:gsub("%-.*$", "");
	if value ~= "" then
		return normalizeDeveloperBadgeToken(value);
	end
end

local function hexToRGB(hex)
	return tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16);
end

local function interpolateChannel(a, b, progress)
	return math.floor(a + ((b - a) * progress) + 0.5);
end

local function getGradientHex(progress)
	if progress <= 0 then
		return DEV_BADGE_GRADIENT[1];
	elseif progress >= 1 then
		return DEV_BADGE_GRADIENT[#DEV_BADGE_GRADIENT];
	end

	local segmentCount = #DEV_BADGE_GRADIENT - 1;
	local scaled = progress * segmentCount;
	local leftIndex = math.floor(scaled) + 1;
	local segmentProgress = scaled - math.floor(scaled);
	local leftHex = DEV_BADGE_GRADIENT[leftIndex];
	local rightHex = DEV_BADGE_GRADIENT[leftIndex + 1] or leftHex;
	local lr, lg, lb = hexToRGB(leftHex);
	local rr, rg, rb = hexToRGB(rightHex);

	return ("%02X%02X%02X"):format(
		interpolateChannel(lr, rr, segmentProgress),
		interpolateChannel(lg, rg, segmentProgress),
		interpolateChannel(lb, rb, segmentProgress)
	);
end

local function buildGradientText(text)
	local visibleCount = 0;
	local result = {};

	for index = 1, #text do
		local char = text:sub(index, index);
		if char ~= " " then
			visibleCount = visibleCount + 1;
		end
	end

	if visibleCount == 0 then
		return text;
	end

	local visibleIndex = 0;
	for index = 1, #text do
		local char = text:sub(index, index);
		if char == " " then
			tinsert(result, char);
		else
			local progress = visibleCount == 1 and 0 or ((visibleIndex) / (visibleCount - 1));
			tinsert(result, "|cff" .. getGradientHex(progress) .. char .. "|r");
			visibleIndex = visibleIndex + 1;
		end
	end

	return table.concat(result);
end

local function getDeveloperBadgeCharacterName(unitID, characteristics)
	return getDeveloperBadgeNameToken(unitID) or getDeveloperBadgeNameToken(characteristics and characteristics.FN);
end

local function isDeveloperBadgeRealm()
	return normalizeDeveloperBadgeToken(GetRealmName and GetRealmName() or "") == DEV_BADGE_REALM;
end

local function getDeveloperBadgeInfo(unitID, characteristics)
	if not isDeveloperBadgeRealm() then
		return nil;
	end

	local characterName = getDeveloperBadgeCharacterName(unitID, characteristics);
	if not characterName or not DEV_BADGE_NAMES[characterName] then
		return nil;
	end

	return {
		shortText = buildGradientText(DEV_BADGE_SHORT_LABEL),
		longText = buildGradientText(DEV_BADGE_LONG_LABEL),
	};
end

TRP3_API.register.getDeveloperBadgeInfo = getDeveloperBadgeInfo;

local NSFW_KEYWORDS = {
	"18+", "69", "a/b/o", "ab/o", "adult themes", "aftercare", "ageplay", "alluring", "anal", "anus", "arousal", "aroused",
	"ass", "bare", "bdsm", "bimbo", "bimbod", "bimbofication", "bloodplay", "blowjob", "bondage", "boobs", "bra", "breasts", "breed", "breeding",
	"bulge", "busty", "butt", "chest puppies", "chestpuppies", "claiming", "climax", "clit", "cnc", "cock", "consensual non-consent", "coquette", "cowgirl",
	"creampie", "cuck", "cuckold", "cum", "cunt", "curvaceous", "daddykink", "deepthroat", "dick", "dirty rp", "doggystyle",
	"dom", "dominant", "domme", "dommy", "double penetration", "dubcon", "ecchi", "edging", "erection", "erogenous", "erotic", "erotica", "erp",
	"estrus", "exaggerated curves", "exhibition", "exhibitionism", "explicit", "f-list", "f-list.net", "facefuck", "facesitting", "facials", "feralplay", "fetish",
	"fisting", "flirt", "flirtatious", "flirty", "foot worship", "footfetish", "freeuse", "frisky", "fuck me", "fucktoy", "gangbang", "giantess", "gore", "hard limits",
	"hardon", "heavy breasts", "hentai", "horny", "impregnation", "incubus", "inflation", "intimate", "jiggle", "jiggling",
	"kink", "kinks", "kinky", "kittenplay", "knifeplay", "knotting", "lactation", "latex", "length", "lewd", "lewdness", "libido",
	"lingerie", "lust", "lustful", "masochism", "masochist", "mating", "mating press", "maturerp", "milking", "mindcontrol", "minx",
	"mistress", "mommykink", "mrp", "naked", "naughty", "nesting", "netorare", "no list", "noncon", "nsfw", "nsfwrp",
	"ntr", "nude", "nudity", "oral", "orgasm", "orgy", "overstimulation", "ownership", "paddle", "panties", "pegging", "petplay", "pheromones",
	"pillowy", "piss", "plaything", "pole dance", "primalplay", "provocative", "puppyplay", "pussy",
	"queening", "rapeplay", "ravish", "rimming", "risque", "sadism", "sadist", "scat", "scent marking", "seduce",
	"seduction", "seductive", "seed", "semen", "sensual", "sensuous", "sex", "sexual", "shaft", "shibari", "sinful", "size difference", "slave", "slut", "smut", "smutrp",
	"soaked", "soft flesh", "soft limits", "spanking", "strapon", "strip", "stripping", "sub", "subby", "submissive", "succubus", "suggestive",
	"taboo", "tantalizing", "tease", "tempter", "tentacle", "tf", "thick thighs", "thicc", "threesome", "throatfuck", "throbbing", "tits",
	"torture", "total power exchange", "touch starved", "tpe", "transformation", "unbirth", "underwear", "use me", "vagina", "vaginal", "vixen", "voluptuous", "vore", "voyeur", "voyeurism",
	"watersports", "whore", "yearning", "yes list",
};

local pendingNSFWPromptCallback;
local pendingNSFWDetectedKeyword;
local pendingNSFWDetectionText;
local lastDismissedNSFWDetectionText;

local function normalizeNSFWDetectionText(text)
	local normalizedText = string.lower(tostring(text or ""));
	normalizedText = string.gsub(normalizedText, "|c%x%x%x%x%x%x%x%x", "");
	normalizedText = string.gsub(normalizedText, "|r", "");
	normalizedText = string.gsub(normalizedText, "<.->", " ");
	normalizedText = string.gsub(normalizedText, "[^%w%s]", " ");
	normalizedText = string.gsub(normalizedText, "%s+", " ");
	return normalizedText;
end

local function collectNSFWDetectionText(value, parts, seenTables)
	local valueType = type(value);
	if valueType == "string" then
		tinsert(parts, tostring(value));
	elseif valueType == "table" and not seenTables[value] then
		seenTables[value] = true;
		for key, nestedValue in pairs(value) do
			if key ~= "IC" and key ~= "FC" and key ~= "CH" and key ~= "EH" then
				collectNSFWDetectionText(nestedValue, parts, seenTables);
			end
		end
	end
end

local function buildNSFWDetectionText(profile, overrides)
	local parts = {};
	local seenTables = {};
	profile = profile or get("player");
	overrides = overrides or {};

	collectNSFWDetectionText(overrides.characteristics or profile.characteristics, parts, seenTables);
	collectNSFWDetectionText(overrides.character or profile.character, parts, seenTables);
	collectNSFWDetectionText(overrides.about or profile.about, parts, seenTables);
	collectNSFWDetectionText(overrides.misc or profile.misc, parts, seenTables);

	return normalizeNSFWDetectionText(table.concat(parts, " "));
end

local function profileLooksNSFW(profile, overrides)
	local detectionText = buildNSFWDetectionText(profile, overrides);
	for _, keyword in ipairs(NSFW_KEYWORDS) do
		local normalizedKeyword = normalizeNSFWDetectionText(keyword);
		if normalizedKeyword ~= "" and string.find(detectionText, "%f[%w]" .. normalizedKeyword .. "%f[%W]") then
			return true, keyword;
		end
	end
	return false, nil;
end

local function markCurrentProfileNSFW()
	local context = getCurrentContext();
	if not context or not context.profile or context.isCompanion then
		return;
	end
	context.profile.character = context.profile.character or { v = 1, RP = 1 };
	if context.profile.character.NSFW then
		return;
	end
	context.profile.character.NSFW = true;
	context.profile.character.v = Utils.math.incrementNumber(context.profile.character.v or 1, 2);
	if nsfwProfileCheckbox then
		nsfwProfileCheckbox:SetChecked(true);
	end
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, context.unitID or Globals.player_id, context.profileID, "character");
end

StaticPopupDialogs["TRP3_NSFW_DETECTED_CONFIRM"] = {
	text = "Possible NSFW text was detected in this profile.\n\nContent considered NSFW should be marked as NSFW.\n\nMark this profile as NSFW?",
	button1 = "Mark NSFW",
	button2 = "Keep SFW",
	button3 = "Cancel",
	OnAccept = function()
		markCurrentProfileNSFW();
		local callback = pendingNSFWPromptCallback;
		pendingNSFWPromptCallback = nil;
		pendingNSFWDetectedKeyword = nil;
		pendingNSFWDetectionText = nil;
		lastDismissedNSFWDetectionText = nil;
		if callback then
			callback();
		end
	end,
	OnCancel = function()
		local callback = pendingNSFWPromptCallback;
		lastDismissedNSFWDetectionText = pendingNSFWDetectionText;
		pendingNSFWPromptCallback = nil;
		pendingNSFWDetectedKeyword = nil;
		pendingNSFWDetectionText = nil;
		if callback then
			callback();
		end
	end,
	OnAlt = function()
		pendingNSFWPromptCallback = nil;
		pendingNSFWDetectedKeyword = nil;
		pendingNSFWDetectionText = nil;
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
	preferredIndex = 3,
};

function TRP3_API.register.promptForNSFWIfNeeded(callback, overrides)
	local context = getCurrentContext();
	if not context or not context.isPlayer or context.isCompanion or not context.profile then
		if callback then
			callback();
		end
		return false;
	end
	context.profile.character = context.profile.character or { v = 1, RP = 1 };
	if context.profile.character.NSFW then
		if callback then
			callback();
		end
		return false;
	end

	if StaticPopup_Visible and StaticPopup_Visible("TRP3_NSFW_DETECTED_CONFIRM") then
		return true;
	end

	local detectionText = buildNSFWDetectionText(context.profile, overrides);
	if lastDismissedNSFWDetectionText == detectionText then
		if callback then
			callback();
		end
		return false;
	end

	local detected, keyword = profileLooksNSFW(context.profile, overrides);
	if not detected then
		if callback then
			callback();
		end
		return false;
	end

	pendingNSFWPromptCallback = callback;
	pendingNSFWDetectedKeyword = keyword or "";
	pendingNSFWDetectionText = detectionText;
	StaticPopup_Show("TRP3_NSFW_DETECTED_CONFIRM");
	return true;
end

function TRP3_API.register.checkCurrentProfileForNSFW()
	TRP3_API.register.promptForNSFWIfNeeded(nil);
end

local function refreshPsycho(psychoLine, value, traitID, customColors)
	local normalizedValue = math.max(0, math.min(10, (value or 5)));
	
	-- Get dynamic colors for this trait
	local colors = nil;
	if customColors and customColors.leftColor and customColors.rightColor then
		colors = customColors;
	elseif traitID and traitID > 0 and traitID <= #TRAIT_PRESETS then
		colors = TRAIT_PRESETS[traitID];
	elseif traitID and traitID == 0 then
		colors = TRAIT_PRESETS_UNKNOWN;
	end
	
	-- Get the container frame (which holds the backdrop and StatusBars)
	local container = _G[psychoLine:GetName() .. "Bar"];
	if container then
		-- Get the actual StatusBars from within the container
		-- The StatusBar is named $parentStatusBar, so it becomes [ContainerName]StatusBar
		local statusBar = container.StatusBar or _G[container:GetName() .. "StatusBar"];
		local backgroundBar = container.BackgroundBar or _G[container:GetName() .. "BackgroundBar"];
		
		-- Handle the background bar (always full, use right trait color or default red)
		if backgroundBar then
			backgroundBar:SetValue(10);
			if colors then
				backgroundBar:SetStatusBarColor(colors.rightColor[1], colors.rightColor[2], colors.rightColor[3], 0.8);
			else
				backgroundBar:SetStatusBarColor(0.8, 0.2, 0.2, 0.8); -- Default red
			end
			backgroundBar:SetAlpha(1);
			backgroundBar:Show();
		end
		
		-- Handle the main status bar (use left trait color or default green, varies with value)
		if statusBar then
			statusBar:SetValue(normalizedValue);
			
			-- Set color based on trait or default green
			if colors then
				statusBar:SetStatusBarColor(colors.leftColor[1], colors.leftColor[2], colors.leftColor[3], 0.8);
			else
				statusBar:SetStatusBarColor(0.2, 0.8, 0.2, 0.8); -- Default green
			end
			
			-- Make sure everything is visible
			statusBar:SetAlpha(1);
			statusBar:Show();
		end
		
		if container.Thumb then
			local containerWidth = container:GetWidth();
			local inset = 10;
			local barWidth = containerWidth - inset;
			local fillPercent = normalizedValue / 10;
			local thumbPos = (fillPercent - 0.5) * barWidth;
			container.Thumb:ClearAllPoints();
			container.Thumb:SetPoint("CENTER", container, "CENTER", thumbPos, 0);
		end
		
		container:SetAlpha(1);
		container:Show();
	end
	
	psychoLine.VA = normalizedValue;
end

local function setBkg(backgroundIndex)
	local backdrop = TRP3_RegisterCharact_CharactPanel:GetBackdrop();
	backdrop.bgFile = getTiledBackground(backgroundIndex);
	TRP3_RegisterCharact_CharactPanel:SetBackdrop(backdrop);
end

local function ensureFactionBadgeWatermark(panel, key)
	if not panel[key] then
		panel[key] = panel:CreateTexture(nil, "ARTWORK");
		panel[key]:SetSize(190, 190);
		panel[key]:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -18, 18);
		panel[key]:SetAlpha(0.3);
	end
	return panel[key];
end

local function updateFactionBadgeWatermark(panel, factionCode, hiddenOnProfile, alwaysShow)
	local texture = ensureFactionBadgeWatermark(panel, "factionBadgeWatermark");
	if hiddenOnProfile and not alwaysShow then
		texture:Hide();
		return;
	end
	factionCode = normalizeOptionalFactionBadge(factionCode);
	if not factionCode then
		texture:Hide();
		return;
	end
	texture:SetTexture(getFactionBadgeTexture(factionCode, true));
	texture:SetAlpha(factionCode == FACTION_BADGE_INDEPENDENT and 0.22 or 0.3);
	texture:Show();
end

local function ensureDeveloperBadgeLabel(panel)
	if not panel.developerBadgeLabel then
		panel.developerBadgeLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal");
		panel.developerBadgeLabel:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -28, -14);
		panel.developerBadgeLabel:SetWidth(330);
		panel.developerBadgeLabel:SetJustifyH("RIGHT");
		panel.developerBadgeLabel:SetText("");
	end
	return panel.developerBadgeLabel;
end

local function getGuildDisplayInfo(dataTab, context)
	local customGuildTitle = stEtN(strtrim(dataTab.GT or ""));
	local customGuildRank = stEtN(strtrim(dataTab.GR or ""));
	local contextCharacter = getContextCharacter(context);
	local guildTitle, guildRank;

	if context and context.isPlayer then
		guildTitle, guildRank = GetGuildInfo("player");
	elseif contextCharacter then
		guildTitle = contextCharacter.guild;
		guildRank = contextCharacter.guildRank;
	end

	return customGuildTitle or guildTitle, customGuildRank or guildRank, customGuildTitle ~= nil, customGuildRank ~= nil;
end

local function applyDirectoryLiteToCharacteristics(dataTab, context)
	if not context or not context.profile or not context.profile.link then
		return dataTab;
	end
	for unitID, _ in pairs(context.profile.link) do
		local liteInfo = type(unitID) == "string" and TRP3_API.register.isUnitIDKnown(unitID) and getUnitIDDirectoryLite and getUnitIDDirectoryLite(unitID);
		if liteInfo and (liteInfo.name or liteInfo.colorCode or liteInfo.icon) then
			dataTab = dataTab or {};
			local liteName = sanitizeDisplayName(liteInfo.name);
			if liteName then
				dataTab.FN = dataTab.FN or liteName;
			end
			if liteInfo.colorCode and liteInfo.colorCode ~= "" then
				dataTab.CH = dataTab.CH or liteInfo.colorCode;
			end
			local liteIcon = sanitizeIconName(liteInfo.icon);
			if liteIcon then
				dataTab.IC = dataTab.IC or liteIcon;
			end
			break
		end
	end
	return dataTab;
end

local function setConsultDisplay(context)
	local dataTab = context.profile.characteristics or Globals.empty;
	dataTab = applyDirectoryLiteToCharacteristics(dataTab, context);
	local hasCharac, hasPsycho, hasMisc, margin;
	local contextUnitID = context.isPlayer and not context.isDeveloperEdit and Globals.player_id or nil;
	local developerBadge;
	assert(type(dataTab) == "table", "Error: Nil characteristics data or not a table.");
	if not contextUnitID and context.profile and context.profile.link then
		for unitID, _ in pairs(context.profile.link) do
			if type(unitID) == "string" and TRP3_API.register.isUnitIDKnown(unitID) then
				contextUnitID = unitID;
				break
			end
		end
	end
	developerBadge = getDeveloperBadgeInfo(contextUnitID, dataTab);
	-- Icon, complete name and titles
	local completeName = getCompleteName(dataTab, UNKNOWN);
	local titleText = dataTab.FT or "";
	local developerBadgeLabel = ensureDeveloperBadgeLabel(TRP3_RegisterCharact_CharactPanel);
	local badgeText = "";
	TRP3_RegisterCharact_NamePanel_Name:SetText("|cff" .. (dataTab.CH or "ffffff") .. completeName);
	TRP3_RegisterCharact_NamePanel_Title:SetText(titleText);
	setupIconButton(TRP3_RegisterCharact_NamePanel_Icon, dataTab.IC or Globals.icons.profile_default);
	if context.profile.character and context.profile.character.NSFW then
		badgeText = "|cffff6666NSFW|r";
	end
	if developerBadge then
		if badgeText ~= "" then
			badgeText = badgeText .. "  " .. developerBadge.longText;
		else
			badgeText = developerBadge.longText;
		end
	end
	if badgeText ~= "" then
		developerBadgeLabel:SetText(badgeText);
		developerBadgeLabel:Show();
	else
		developerBadgeLabel:Hide();
	end

	setBkg(dataTab.bkg or 1);
	if context.isCompanion then
		updateFactionBadgeWatermark(TRP3_RegisterCharact_CharactPanel, nil, true, false);
	else
		updateFactionBadgeWatermark(TRP3_RegisterCharact_CharactPanel, dataTab.FC or inferLegacyFactionBadge(getContextCharacter(context), dataTab), dataTab.FH, false);
	end

	-- hide all
	for _, regCharFrame in pairs(registerCharFrame) do
		regCharFrame:Hide();
	end
	TRP3_RegisterCharact_CharactPanel_PsychoTitle:Hide();
	TRP3_RegisterCharact_CharactPanel_MiscTitle:Hide();

	-- Previous var helps for layout building
	local previous = TRP3_RegisterCharact_CharactPanel_RegisterTitle;
	TRP3_RegisterCharact_CharactPanel_RegisterTitle:Hide();

	-- Which directory chars must be shown ?
	local shownCharacteristics = {};
	local shownValues = {};
	for _, attribute in pairs({ "RA", "CL", "AG", "EC", "HE", "WE", "BP", "RE" }) do
		if strtrim(dataTab[attribute] or ""):len() > 0 then
			tinsert(shownCharacteristics, attribute);
			shownValues[attribute] = dataTab[attribute];
		end
	end
	if #shownCharacteristics > 0 then
		hasCharac = true;
		TRP3_RegisterCharact_CharactPanel_RegisterTitle:Show();
		margin = 0;
	else
		margin = 50;
	end

	-- Show directory chars values
	for frameIndex, charName in pairs(shownCharacteristics) do
		local frame = registerCharFrame[frameIndex];
		if frame == nil then
			frame = CreateFrame("Frame", "TRP3_RegisterCharact_RegisterInfoLine" .. frameIndex, TRP3_RegisterCharact_CharactPanel_Container, "TRP3_RegisterCharact_RegisterInfoLine");
			tinsert(registerCharFrame, frame);
		end
		frame:ClearAllPoints();
		frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, 10);
		frame:SetPoint("RIGHT", 0, 0);
		_G[frame:GetName() .. "FieldName"]:SetText(loc(registerCharLocals[charName]));
		if charName == "EC" then
			local hexa = dataTab.EH or "ffffff"
			_G[frame:GetName() .. "FieldValue"]:SetText("|cff" .. hexa .. shownValues[charName] .. "|r");
		elseif charName == "CL" then
			local hexa = dataTab.CH or "ffffff";
			_G[frame:GetName() .. "FieldValue"]:SetText("|cff" .. hexa .. shownValues[charName] .. "|r");
		else
			_G[frame:GetName() .. "FieldValue"]:SetText(shownValues[charName]);
		end
		frame:Show();
		previous = frame;
	end

	-- extended character info
	local guildTitle, guildRank, hasCustomGuildTitle, hasCustomGuildRank;
	if not context.isCompanion then
		guildTitle, guildRank, hasCustomGuildTitle, hasCustomGuildRank = getGuildDisplayInfo(dataTab, context);
	end
	local miscLines = {};
	if guildRank then
		tinsert(miscLines, {
			field = loc("REG_PLAYER_GUILD_RANK") .. (hasCustomGuildRank and " (" .. loc("REG_TT_GUILD_CUSTOM") .. ")" or ""),
			value = guildRank,
		});
	end
	if guildTitle then
		tinsert(miscLines, {
			field = loc("REG_PLAYER_GUILD_TITLE") .. (hasCustomGuildTitle and " (" .. loc("REG_TT_GUILD_CUSTOM") .. ")" or ""),
			value = guildTitle,
		});
	end
	if type(dataTab.MI) == "table" then
		for _, miscStructure in pairs(dataTab.MI) do
			tinsert(miscLines, {
				misc = miscStructure,
			});
		end
	end
	if #miscLines > 0 then
		hasMisc = true;
		TRP3_RegisterCharact_CharactPanel_MiscTitle:Show();
		TRP3_RegisterCharact_CharactPanel_MiscTitle:ClearAllPoints();
		TRP3_RegisterCharact_CharactPanel_MiscTitle:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, margin);
		previous = TRP3_RegisterCharact_CharactPanel_MiscTitle;

		for frameIndex, miscLine in pairs(miscLines) do
			local frame = miscCharFrame[frameIndex];
			if frame == nil then
				frame = CreateFrame("Frame", "TRP3_RegisterCharact_MiscInfoLine" .. frameIndex, TRP3_RegisterCharact_CharactPanel_Container, "TRP3_RegisterCharact_RegisterInfoLine");
				tinsert(miscCharFrame, frame);
			end
			frame:ClearAllPoints();
			frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -5);
			frame:SetPoint("RIGHT", 0, 0);

			local fieldName = _G[frame:GetName() .. "FieldName"];
			local fieldValue = _G[frame:GetName() .. "FieldValue"];
			fieldName:ClearAllPoints();

			if miscLine.misc then
				local miscStructure = miscLine.misc;
				if not frame.miscIcon then
					frame.miscIcon = CreateFrame("Frame", frame:GetName() .. "MiscIcon", frame, "TRP3_SimpleIcon");
					frame.miscIcon:SetSize(32, 32);
					frame.miscIcon:SetPoint("LEFT", frame, "LEFT", 0, 0);
				end

				local iconTexture = _G[frame.miscIcon:GetName() .. "Icon"];
				if iconTexture then
					iconTexture:SetTexture("Interface\\ICONS\\" .. (miscStructure.IC or Globals.icons.default));
				end
				frame.miscIcon:Show();
				fieldName:SetText(miscStructure.NA or "");
				fieldName:SetPoint("LEFT", frame.miscIcon, "RIGHT", 5, 0);
				fieldValue:SetText(miscStructure.VA or "");
			else
				if frame.miscIcon then
					frame.miscIcon:Hide();
				end
				fieldName:SetText(miscLine.field or "");
				fieldName:SetPoint("LEFT", frame, "LEFT", 37, 0);
				fieldValue:SetText(miscLine.value or "");
			end
			frame:Show();
			previous = frame;
		end
	end

	-- traits
	if type(dataTab.PS) == "table" and #dataTab.PS > 0 then
		hasPsycho = true;
		TRP3_RegisterCharact_CharactPanel_PsychoTitle:Show();
		TRP3_RegisterCharact_CharactPanel_PsychoTitle:ClearAllPoints();
		TRP3_RegisterCharact_CharactPanel_PsychoTitle:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, margin);
		margin = 0;
		previous = TRP3_RegisterCharact_CharactPanel_PsychoTitle;

		for frameIndex, psychoStructure in pairs(dataTab.PS) do
			local frame = psychoCharFrame[frameIndex];
			local value = psychoStructure.VA;
			if frame == nil then
				frame = CreateFrame("Frame", "TRP3_RegisterCharact_PsychoInfoLine" .. frameIndex, TRP3_RegisterCharact_CharactPanel_Container, "TRP3_RegisterCharact_PsychoInfoDisplayLine");
				tinsert(psychoCharFrame, frame);
			end

			-- Preset pointer
			local originalID = psychoStructure.ID;
			if psychoStructure.ID then
				psychoStructure = TRAIT_PRESETS[psychoStructure.ID] or TRAIT_PRESETS_UNKNOWN;
			end

			frame:ClearAllPoints();
			frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, 0);
			frame:SetPoint("RIGHT", 0, 0);
			
			-- Update text labels with dynamic colors
			local leftText = _G[frame:GetName() .. "LeftText"];
			local rightText = _G[frame:GetName() .. "RightText"];
			
			leftText:SetText(psychoStructure.LT or "");
			rightText:SetText(psychoStructure.RT or "");
			
			local colors = nil;
			if originalID and originalID > 0 and originalID <= #TRAIT_PRESETS then
				colors = TRAIT_PRESETS[originalID];
			elseif originalID and originalID == 0 then
				colors = TRAIT_PRESETS_UNKNOWN;
			end
			
			if colors then
				leftText:SetTextColor(colors.leftColor[1], colors.leftColor[2], colors.leftColor[3]);
				rightText:SetTextColor(colors.rightColor[1], colors.rightColor[2], colors.rightColor[3]);
			elseif not originalID then
				if psychoStructure.LC and psychoStructure.LC ~= "" then
					local leftR, leftG, leftB = hexaToNumber(psychoStructure.LC);
					if leftR and leftG and leftB then
						leftText:SetTextColor(leftR/255, leftG/255, leftB/255);
					else
						leftText:SetTextColor(1.0, 0.9, 0.0); -- Default yellow if hex conversion fails
					end
				else
					leftText:SetTextColor(1.0, 0.9, 0.0);
				end
				
				if psychoStructure.RC and psychoStructure.RC ~= "" then
					local rightR, rightG, rightB = hexaToNumber(psychoStructure.RC);
					if rightR and rightG and rightB then
						rightText:SetTextColor(rightR/255, rightG/255, rightB/255);
					else
						rightText:SetTextColor(0.6, 0.8, 1.0); -- Default blue if hex conversion fails
					end
				else
					rightText:SetTextColor(0.6, 0.8, 1.0);
				end
			end
			
			-- Update icons using TRP3_SimpleIcon template
			local leftIcon = _G[frame:GetName() .. "LeftIcon"];
			local rightIcon = _G[frame:GetName() .. "RightIcon"];
			
			-- Handle TRP3_SimpleIcon template icons
			if leftIcon then
				local iconTexture = _G[leftIcon:GetName() .. "Icon"];
				if iconTexture then
					iconTexture:SetTexture("Interface\\ICONS\\" .. (psychoStructure.LI or Globals.icons.default));
				end
			end
			
			if rightIcon then
				local iconTexture = _G[rightIcon:GetName() .. "Icon"];
				if iconTexture then
					iconTexture:SetTexture("Interface\\ICONS\\" .. (psychoStructure.RI or Globals.icons.default));
				end
			end
			
			local customColors = nil;
			if not originalID then
				local leftColor = {0.2, 0.8, 0.2}; -- Default green
				local rightColor = {0.8, 0.2, 0.2}; -- Default red
				
				if psychoStructure.LC and psychoStructure.LC ~= "" then
					local r, g, b = hexaToNumber(psychoStructure.LC);
					if r and g and b then
						leftColor = {r/255, g/255, b/255};
					end
				end
				
				if psychoStructure.RC and psychoStructure.RC ~= "" then
					local r, g, b = hexaToNumber(psychoStructure.RC);
					if r and g and b then
						rightColor = {r/255, g/255, b/255};
					end
				end
				
				customColors = {
					leftColor = leftColor,
					rightColor = rightColor
				};
			end
			
			refreshPsycho(frame, value or 5, originalID, customColors);
			frame:Show();
			previous = frame;
		end
	end

	if not context.isCompanion and TRP3_API.register.languages and TRP3_API.register.languages.renderConsult then
		local hasLanguages;
		previous, hasLanguages, margin = TRP3_API.register.languages.renderConsult(TRP3_RegisterCharact_CharactPanel_Container, previous, context, margin);
		hasCharac = hasCharac or hasLanguages;
	end

	if not hasCharac and not hasPsycho and not hasMisc then
		TRP3_RegisterCharact_CharactPanel_Empty:Show();
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- CHARACTERISTICS - EDIT
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local setEditDisplay;

local draftData = nil;
local psychoEditCharFrame = {};
local miscEditCharFrame = {};
local customGuildEditFrame = nil;

local function saveInDraft()
	assert(type(draftData) == "table", "Error: Nil draftData or not a table.");
	local context = getCurrentContext();
	draftData.TI = stEtN(strtrim(TRP3_RegisterCharact_Edit_TitleField:GetText()));
	draftData.FN = stEtN(strtrim(TRP3_RegisterCharact_Edit_FirstField:GetText())) or (context and context.isCompanion and context.companionName) or Globals.player;
	draftData.LN = stEtN(strtrim(TRP3_RegisterCharact_Edit_LastField:GetText()));
	draftData.FT = stEtN(strtrim(TRP3_RegisterCharact_Edit_FullTitleField:GetText()));
	draftData.RA = stEtN(TRP3_RegisterCharact_Edit_RaceField:GetText());
	draftData.CL = stEtN(TRP3_RegisterCharact_Edit_ClassField:GetText());
	draftData.AG = stEtN(strtrim(TRP3_RegisterCharact_Edit_AgeField:GetText()));
	draftData.EC = stEtN(strtrim(TRP3_RegisterCharact_Edit_EyeField:GetText()));
	draftData.HE = stEtN(strtrim(TRP3_RegisterCharact_Edit_HeightField:GetText()));
	draftData.WE = stEtN(strtrim(TRP3_RegisterCharact_Edit_WeightField:GetText()));
	draftData.RE = stEtN(strtrim(TRP3_RegisterCharact_Edit_ResidenceField:GetText()));
	draftData.BP = stEtN(strtrim(TRP3_RegisterCharact_Edit_BirthplaceField:GetText()));
	if context and context.isCompanion then
		draftData.FC = nil;
		draftData.FH = nil;
		draftData.GR = nil;
		draftData.GT = nil;
	elseif factionBadgeHideCheckbox then
		draftData.FC = normalizeFactionBadge(draftData.FC);
		draftData.FH = factionBadgeHideCheckbox:GetChecked() and true or nil;
	end
	if not (context and context.isCompanion) and customGuildEditFrame and customGuildEditFrame:IsShown() then
		draftData.GR = stEtN(_G[customGuildEditFrame:GetName() .. "NameField"]:GetText());
		draftData.GT = stEtN(_G[customGuildEditFrame:GetName() .. "ValueField"]:GetText());
	end
	for index, psychoStructure in pairs(draftData.PS) do
		if psychoEditCharFrame[index] then
			psychoStructure.VA = psychoEditCharFrame[index].VA;
			if not psychoStructure.ID then
				psychoStructure.LT = stEtN(_G[psychoEditCharFrame[index]:GetName() .. "LeftField"]:GetText()) or loc("REG_PLAYER_LEFTTRAIT");
				psychoStructure.RT = stEtN(_G[psychoEditCharFrame[index]:GetName() .. "RightField"]:GetText()) or loc("REG_PLAYER_RIGHTTRAIT");
				local leftIcon = _G[psychoEditCharFrame[index]:GetName() .. "LeftIcon"];
				local rightIcon = _G[psychoEditCharFrame[index]:GetName() .. "RightIcon"];
				if leftIcon and leftIcon.IC then
					psychoStructure.LI = leftIcon.IC;
				end
				if rightIcon and rightIcon.IC then
					psychoStructure.RI = rightIcon.IC;
				end
				
				-- custom trait colours
				local leftColorButton = _G[psychoEditCharFrame[index]:GetName() .. "LeftColor"];
				local rightColorButton = _G[psychoEditCharFrame[index]:GetName() .. "RightColor"];
				if leftColorButton and leftColorButton.colorR then
					psychoStructure.LC = numberToHexa(leftColorButton.colorR, leftColorButton.colorG, leftColorButton.colorB);
				end
				if rightColorButton and rightColorButton.colorR then
					psychoStructure.RC = numberToHexa(rightColorButton.colorR, rightColorButton.colorG, rightColorButton.colorB);
				end
			else
				-- Don't save preset data !
				psychoStructure.LT = nil;
				psychoStructure.RT = nil;
				psychoStructure.LI = nil;
				psychoStructure.RI = nil;
			end
		end
	end
	-- Save Misc
	for index, miscStructure in pairs(draftData.MI) do
		miscStructure.VA = stEtN(_G[miscEditCharFrame[index]:GetName() .. "ValueField"]:GetText()) or loc("CM_VALUE");
		miscStructure.NA = stEtN(_G[miscEditCharFrame[index]:GetName() .. "NameField"]:GetText()) or loc("CM_NAME");
	end
end

local function onPlayerIconSelected(icon)
	draftData.IC = icon;
	setupIconButton(TRP3_RegisterCharact_Edit_NamePanel_Icon, draftData.IC or Globals.icons.profile_default);
end

local function onEyeColorSelected(red, green, blue)
	if red and green and blue then
		local hexa = strconcat(numberToHexa(red), numberToHexa(green), numberToHexa(blue))
		draftData.EH = hexa;
	else
		draftData.EH = nil;
	end
end

local function onClassColorSelected(red, green, blue)
	if red and green and blue then
		local hexa = strconcat(numberToHexa(red), numberToHexa(green), numberToHexa(blue))
		draftData.CH = hexa;
	else
		draftData.CH = nil;
	end
end

local function onPsychoClick(frame, value, modif)
	local currentValue = value or 10;
	local newValue = currentValue + modif;

	if newValue >= 0 and newValue <= 10 then
		refreshPsycho(frame, newValue);
	end
end

local function onLeftClick(button)
	onPsychoClick(button:GetParent(), button:GetParent().VA or 10, -1);
end

local function onRightClick(button)
	onPsychoClick(button:GetParent(), button:GetParent().VA or 10, 1);
end

local function refreshEditIcon(frame)
	setupIconButton(frame, frame.IC or Globals.icons.profile_default);
end

local function onMiscDelete(self)
	assert(self and self:GetParent(), "Badly initialiazed remove button, reference");
	local frame = self:GetParent();
	assert(frame.miscIndex and draftData.MI[frame.miscIndex], "Badly initialiazed remove button, index");
	saveInDraft();
	wipe(draftData.MI[frame.miscIndex]);
	tremove(draftData.MI, frame.miscIndex);
	setEditDisplay();
end

local function miscAdd(NA, VA, IC)
	saveInDraft();
	tinsert(draftData.MI, {
		NA = NA,
		VA = VA,
		IC = IC,
	});
	setEditDisplay();
end

local function clearCustomGuildFields()
	saveInDraft();
	draftData.GT = nil;
	draftData.GR = nil;
	setEditDisplay();
end

local function refreshFactionBadgeControls()
	if not draftData or not factionBadgeButton or not factionBadgePreview then
		return;
	end
	draftData.FC = normalizeFactionBadge(draftData.FC);
	local factionTexture = getFactionBadgeTexture(draftData.FC, false);
	local previewTexture = getFactionBadgeMapTexture(draftData.FC, false);
	local buttonIcon = _G[factionBadgeButton:GetName() .. "Icon"];
	if buttonIcon then
		buttonIcon:SetTexture(factionTexture);
	end
	local previewIcon = _G[factionBadgePreview:GetName() .. "Icon"];
	if previewIcon then
		previewIcon:SetTexture(previewTexture);
	end
	if factionBadgeHideCheckbox then
		factionBadgeHideCheckbox:SetChecked(draftData.FH and true or false);
	end
	updateFactionBadgeWatermark(TRP3_RegisterCharact_Edit_CharactPanel, draftData.FC, draftData.FH, false);
end

local function onFactionSelected(factionCode)
	draftData.FC = normalizeFactionBadge(factionCode);
	refreshFactionBadgeControls();
end

local function openFactionBadgeMenu(button)
	local values = {
		{"|T" .. FACTION_BADGE_TEXTURES[FACTION_BADGE_INDEPENDENT] .. ":18|t " .. loc("REG_PLAYER_FACTION_INDEPENDENT"), FACTION_BADGE_INDEPENDENT},
		{"|T" .. FACTION_BADGE_TEXTURES[FACTION_BADGE_ALLIANCE] .. ":18|t " .. loc("REG_PLAYER_FACTION_ALLIANCE"), FACTION_BADGE_ALLIANCE},
		{"|T" .. FACTION_BADGE_TEXTURES[FACTION_BADGE_HORDE] .. ":18|t " .. loc("REG_PLAYER_FACTION_HORDE"), FACTION_BADGE_HORDE},
	};
	displayDropDown(button, values, onFactionSelected, 0, true);
end

local function setCustomGuildFields()
	saveInDraft();
	local guildTitle, guildRank = GetGuildInfo("player");
	draftData.GT = draftData.GT or guildTitle or "";
	draftData.GR = draftData.GR or guildRank or "";

	setEditDisplay();
end

local MISC_PRESET = {
	{
		list = loc("REG_TT_GUILD_CUSTOM"),
		field = "CUSTOM_GUILD",
	},
	{
		NA = loc("REG_PLAYER_MSP_HOUSE"),
		VA = "",
		IC = "inv_misc_kingsring1"
	},
	{
		NA = loc("REG_PLAYER_MSP_NICK"),
		VA = "",
		IC = "Ability_Hunter_BeastCall"
	},
	{
		NA = loc("REG_PLAYER_MSP_MOTTO"),
		VA = "",
		IC = "INV_Inscription_ScrollOfWisdom_01"
	},
	{
		NA = loc("REG_PLAYER_TRP2_TRAITS"),
		VA = "",
		IC = "spell_shadow_mindsteal"
	},
	{
		NA = loc("REG_PLAYER_TRP2_PIERCING"),
		VA = "",
		IC = "inv_jewelry_ring_14"
	},
	{
		NA = loc("REG_PLAYER_TRP2_TATTOO"),
		VA = "",
		IC = "INV_Inscription_inkblack01"
	},
	{
		list = "|cff00ff00" .. loc("REG_PLAYER_ADD_NEW"),
		NA = loc("CM_NAME"),
		VA = loc("CM_VALUE"),
		IC = "TEMP"
	},
}

local function miscAddDropDownSelection(index)
	local preset = MISC_PRESET[index];
	if preset.field then
		setCustomGuildFields();
	else
		miscAdd(preset.NA, preset.VA, preset.IC);
	end
end

local function miscAddDropDown()
	local values = {};
	tinsert(values, { loc("REG_PLAYER_MISC_ADD") });
	for index, preset in pairs(MISC_PRESET) do
		tinsert(values, { preset.list or preset.NA, index });
	end
	displayDropDown(TRP3_RegisterCharact_Edit_MiscAdd, values, miscAddDropDownSelection, 0, true);
end

local function psychoAdd(presetID)
	saveInDraft();
	if presetID == "new" then
		tinsert(draftData.PS, {
			LT = loc("REG_PLAYER_LEFTTRAIT"),
			LI = Globals.icons.default,
			RT = loc("REG_PLAYER_RIGHTTRAIT"),
			RI = Globals.icons.default,
			VA = 5,
		});
	else
		tinsert(draftData.PS, { ID = presetID, VA = 5 });
	end
	setEditDisplay();
end

local function onPsychoDelete(self)
	assert(self and self:GetParent(), "Badly initialiazed remove button, reference");
	local frame = self:GetParent();
	assert(frame.psychoIndex and draftData.PS[frame.psychoIndex], "Badly initialiazed remove button, index");
	saveInDraft();
	wipe(draftData.PS[frame.psychoIndex]);
	tremove(draftData.PS, frame.psychoIndex);
	setEditDisplay();
end

function setEditDisplay()
	-- Copy character's data into draft structure : We never work directly on saved_variable structures !
	if not draftData then
		local context = getCurrentContext();
		local dataTab = context and context.profile and context.profile.characteristics or get("player/characteristics");
		assert(type(dataTab) == "table", "Error: Nil characteristics data or not a table.");
		draftData = {};
		tcopy(draftData, dataTab);
	end
	draftData.MI = draftData.MI or {};
	draftData.PS = draftData.PS or {};

	setupIconButton(TRP3_RegisterCharact_Edit_NamePanel_Icon, draftData.IC or Globals.icons.profile_default);
	TRP3_RegisterCharact_Edit_TitleField:SetText(draftData.TI or "");
	TRP3_RegisterCharact_Edit_FirstField:SetText(draftData.FN or (getCurrentContext().isCompanion and getCurrentContext().companionName) or Globals.player);
	TRP3_RegisterCharact_Edit_LastField:SetText(draftData.LN or "");
	TRP3_RegisterCharact_Edit_FullTitleField:SetText(draftData.FT or "");

	TRP3_RegisterCharact_Edit_RaceField:SetText(draftData.RA or "");
	TRP3_RegisterCharact_Edit_ClassField:SetText(draftData.CL or "");
	TRP3_RegisterCharact_Edit_AgeField:SetText(draftData.AG or "");
	TRP3_RegisterCharact_Edit_EyeField:SetText(draftData.EC or "");

	TRP3_RegisterCharact_Edit_EyeButton.setColor(hexaToNumber(draftData.EH))
	TRP3_RegisterCharact_Edit_ClassButton.setColor(hexaToNumber(draftData.CH));

	TRP3_RegisterCharact_Edit_HeightField:SetText(draftData.HE or "");
	TRP3_RegisterCharact_Edit_WeightField:SetText(draftData.WE or "");
	TRP3_RegisterCharact_Edit_ResidenceField:SetText(draftData.RE or "");
	TRP3_RegisterCharact_Edit_BirthplaceField:SetText(draftData.BP or "");
	TRP3_RegisterCharact_Edit_GuildRankField:Hide();
	TRP3_RegisterCharact_Edit_GuildTitleField:Hide();
	TRP3_RegisterCharact_Edit_GuildClear:Hide();
	if nsfwProfileCheckbox then
		if getCurrentContext().isCompanion then
			nsfwProfileCheckbox:Hide();
		else
			nsfwProfileCheckbox:SetChecked(getCurrentContext().profile.character and getCurrentContext().profile.character.NSFW and true or false);
			nsfwProfileCheckbox:Show();
		end
	end
	if getCurrentContext().isCompanion then
		draftData.FC = nil;
		draftData.FH = nil;
		draftData.GR = nil;
		draftData.GT = nil;
		if factionBadgeButton then factionBadgeButton:Hide(); end
		if factionBadgePreview then factionBadgePreview:Hide(); end
		if factionBadgeHideCheckbox then factionBadgeHideCheckbox:Hide(); end
		if customGuildEditFrame then customGuildEditFrame:Hide(); end
		updateFactionBadgeWatermark(TRP3_RegisterCharact_Edit_CharactPanel, nil, true, false);
	else
		draftData.FC = normalizeFactionBadge(draftData.FC);
		if factionBadgeButton then factionBadgeButton:Show(); end
		if factionBadgePreview then factionBadgePreview:Show(); end
		if factionBadgeHideCheckbox then factionBadgeHideCheckbox:Show(); end
		refreshFactionBadgeControls();
	end

	TRP3_RegisterCharact_Edit_CharactPanel_RegisterMiscFrame:ClearAllPoints();
	TRP3_RegisterCharact_Edit_CharactPanel_RegisterMiscFrame:SetPoint("TOPLEFT", TRP3_RegisterCharact_Edit_HeightField, "BOTTOMLEFT", -33, -20);
	TRP3_RegisterCharact_Edit_CharactPanel_RegisterMiscFrame:SetPoint("TOPRIGHT", TRP3_RegisterCharact_Edit_WeightField, "BOTTOMRIGHT", 0, -20);

	-- Misc
	local hasCustomGuildRow = draftData.GR ~= nil or draftData.GT ~= nil;
	local previous = TRP3_RegisterCharact_CharactPanel_Edit_MiscTitle;
	if hasCustomGuildRow then
		if customGuildEditFrame == nil then
			customGuildEditFrame = CreateFrame("Frame", "TRP3_RegisterCharact_CustomGuildEditLine", TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_RegisterCharact_MiscEditLine");
			_G[customGuildEditFrame:GetName() .. "Delete"]:SetScript("OnClick", clearCustomGuildFields);
			setTooltipForSameFrame(_G[customGuildEditFrame:GetName() .. "Delete"], "TOP", 0, 5, loc("CM_REMOVE"));
			if _G[customGuildEditFrame:GetName() .. "Icon"] then
				_G[customGuildEditFrame:GetName() .. "Icon"].IC = "INV_Misc_Note_01";
				_G[customGuildEditFrame:GetName() .. "Icon"]:SetScript("OnClick", nil);
				refreshEditIcon(_G[customGuildEditFrame:GetName() .. "Icon"]);
			end
		end
		if _G[customGuildEditFrame:GetName() .. "NameFieldText"] then
			_G[customGuildEditFrame:GetName() .. "NameFieldText"]:SetText(loc("REG_PLAYER_GUILD_RANK"));
		end
		if _G[customGuildEditFrame:GetName() .. "ValueFieldText"] then
			_G[customGuildEditFrame:GetName() .. "ValueFieldText"]:SetText(loc("REG_PLAYER_GUILD_TITLE"));
		end
		_G[customGuildEditFrame:GetName() .. "NameField"]:SetText(draftData.GR or "");
		_G[customGuildEditFrame:GetName() .. "ValueField"]:SetText(draftData.GT or "");
		customGuildEditFrame:ClearAllPoints();
		customGuildEditFrame:SetPoint("TOPLEFT", TRP3_RegisterCharact_CharactPanel_Edit_MiscTitle, "BOTTOMLEFT", 0, -6);
		customGuildEditFrame:SetPoint("RIGHT", 0, 0);
		customGuildEditFrame:Show();
		previous = customGuildEditFrame;
	elseif customGuildEditFrame then
		customGuildEditFrame:Hide();
	end
	for _, frame in pairs(miscEditCharFrame) do frame:Hide(); end
	for frameIndex, miscStructure in pairs(draftData.MI) do
		local frame = miscEditCharFrame[frameIndex];
		if frame == nil then
			frame = CreateFrame("Frame", "TRP3_RegisterCharact_MiscEditLine" .. frameIndex, TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_RegisterCharact_MiscEditLine");
			if _G[frame:GetName() .. "NameFieldText"] then
				_G[frame:GetName() .. "NameFieldText"]:SetText("");
			end
			if _G[frame:GetName() .. "ValueFieldText"] then
				_G[frame:GetName() .. "ValueFieldText"]:SetText("");
			end
			_G[frame:GetName() .. "Delete"]:SetScript("OnClick", onMiscDelete);
			setTooltipForSameFrame(_G[frame:GetName() .. "Delete"], "TOP", 0, 5, loc("CM_REMOVE"));
			tinsert(miscEditCharFrame, frame);
		end
		_G[frame:GetName() .. "Icon"]:SetScript("OnClick", function()
			showIconBrowser(function(icon)
				miscStructure.IC = icon;
				setupIconButton(_G[frame:GetName() .. "Icon"], icon or Globals.icons.default);
			end);
		end);

		frame.miscIndex = frameIndex;
		_G[frame:GetName() .. "Icon"].IC = miscStructure.IC or Globals.icons.default;
		if _G[frame:GetName() .. "NameFieldText"] then
			_G[frame:GetName() .. "NameFieldText"]:SetText("");
		end
		if _G[frame:GetName() .. "ValueFieldText"] then
			_G[frame:GetName() .. "ValueFieldText"]:SetText("");
		end
		_G[frame:GetName() .. "NameField"]:SetText(miscStructure.NA or loc("CM_NAME"));
		_G[frame:GetName() .. "ValueField"]:SetText(miscStructure.VA or loc("CM_VALUE"));
		refreshEditIcon(_G[frame:GetName() .. "Icon"]);
		frame:ClearAllPoints();
		frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -6);
		frame:SetPoint("RIGHT", 0, 0);
		frame:Show();
		previous = frame;
	end
	TRP3_RegisterCharact_Edit_MiscAdd:Show();

	-- traits
	local traitsAnchorLeft = previous;
	local traitsAnchorRight = previous;
	TRP3_RegisterCharact_Edit_CharactPanel_RegisterTraitsFrame:ClearAllPoints();
	TRP3_RegisterCharact_Edit_CharactPanel_RegisterTraitsFrame:SetPoint("TOPLEFT", traitsAnchorLeft, "BOTTOMLEFT", 0, -10);
	TRP3_RegisterCharact_Edit_CharactPanel_RegisterTraitsFrame:SetPoint("TOPRIGHT", traitsAnchorRight, "BOTTOMRIGHT", 0, -10);
	previous = TRP3_RegisterCharact_Edit_CharactPanel_RegisterTraitsFrame;
	for _, frame in pairs(psychoEditCharFrame) do frame:Hide(); end
	for frameIndex, psychoStructure in pairs(draftData.PS) do
		local frame = psychoEditCharFrame[frameIndex];
		if frame == nil then
			frame = CreateFrame("Frame", "TRP3_RegisterCharact_PsychoEditLine" .. frameIndex, TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_RegisterCharact_PsychoInfoEditLine");
			_G[frame:GetName() .. "Delete"]:SetScript("OnClick", onPsychoDelete);
			setTooltipForSameFrame(_G[frame:GetName() .. "LeftIcon"], "TOP", 0, 5, loc("UI_ICON_SELECT"), loc("REG_PLAYER_PSYCHO_LEFTICON_TT"));
			setTooltipForSameFrame(_G[frame:GetName() .. "RightIcon"], "TOP", 0, 5, loc("UI_ICON_SELECT"), loc("REG_PLAYER_PSYCHO_RIGHTICON_TT"));
			setTooltipForSameFrame(_G[frame:GetName() .. "Delete"], "TOP", 0, 5, loc("CM_REMOVE"));
			tinsert(psychoEditCharFrame, frame);
		end

		if psychoStructure.ID then
			local preset = TRAIT_PRESETS[psychoStructure.ID] or TRAIT_PRESETS_UNKNOWN;

			_G[frame:GetName() .. "LeftIcon"]:Hide();
			_G[frame:GetName() .. "RightIcon"]:Hide();

			local leftText = _G[frame:GetName() .. "LeftText"];
			local rightText = _G[frame:GetName() .. "RightText"];
			leftText:Show();
			rightText:Show();
			leftText:SetText(preset.LT or "");
			rightText:SetText(preset.RT or "");
			
			-- Apply dynamic colors in edit mode too
			local colors = nil;
			if psychoStructure.ID and psychoStructure.ID > 0 and psychoStructure.ID <= #TRAIT_PRESETS then
				colors = TRAIT_PRESETS[psychoStructure.ID];
			elseif psychoStructure.ID and psychoStructure.ID == 0 then
				colors = TRAIT_PRESETS_UNKNOWN;
			end
			
			if colors then
				leftText:SetTextColor(colors.leftColor[1], colors.leftColor[2], colors.leftColor[3]);
				rightText:SetTextColor(colors.rightColor[1], colors.rightColor[2], colors.rightColor[3]);
			else
				-- Fallback colors
				leftText:SetTextColor(1.0, 0.9, 0.0); -- Yellow
				rightText:SetTextColor(0.6, 0.8, 1.0); -- Light blue
			end

			_G[frame:GetName() .. "LeftField"]:Hide();
			_G[frame:GetName() .. "RightField"]:Hide();
			
			if not frame.simpleLeftIcon then
				frame.simpleLeftIcon = CreateFrame("Frame", frame:GetName() .. "SimpleLeftIcon", frame, "TRP3_SimpleIcon");
				frame.simpleLeftIcon:SetSize(32, 32);
				frame.simpleLeftIcon:SetPoint("RIGHT", _G[frame:GetName() .. "Bar"], "LEFT", -7, 0);
			end
			if not frame.simpleRightIcon then
				frame.simpleRightIcon = CreateFrame("Frame", frame:GetName() .. "SimpleRightIcon", frame, "TRP3_SimpleIcon");
				frame.simpleRightIcon:SetSize(32, 32);
				frame.simpleRightIcon:SetPoint("LEFT", _G[frame:GetName() .. "Bar"], "RIGHT", 7, 0);
			end

			frame.simpleLeftIcon:Show();
			frame.simpleRightIcon:Show();

			local leftIconTexture = _G[frame.simpleLeftIcon:GetName() .. "Icon"];
			local rightIconTexture = _G[frame.simpleRightIcon:GetName() .. "Icon"];
			
			if leftIconTexture then
				leftIconTexture:SetTexture("Interface\\ICONS\\" .. (preset.LI or Globals.icons.default));
			end
			if rightIconTexture then
				rightIconTexture:SetTexture("Interface\\ICONS\\" .. (preset.RI or Globals.icons.default));
			end
			
			if frame.leftColorButton then frame.leftColorButton:Hide(); end
			if frame.rightColorButton then frame.rightColorButton:Hide(); end
			
			local barContainer = _G[frame:GetName() .. "Bar"];
			if barContainer then
				barContainer:SetSize(120, 18);
			end
		else
			local leftIcon = _G[frame:GetName() .. "LeftIcon"];
			local rightIcon = _G[frame:GetName() .. "RightIcon"];

			leftIcon:Show();
			rightIcon:Show();

			_G[frame:GetName() .. "LeftText"]:Hide();
			_G[frame:GetName() .. "RightText"]:Hide();

			_G[frame:GetName() .. "LeftField"]:Show();
			_G[frame:GetName() .. "RightField"]:Show();
			_G[frame:GetName() .. "LeftField"]:SetText(psychoStructure.LT or "");
			_G[frame:GetName() .. "RightField"]:SetText(psychoStructure.RT or "");
			
			local leftField = _G[frame:GetName() .. "LeftField"];
			local rightField = _G[frame:GetName() .. "RightField"];
			
			if leftField and psychoStructure.LC and psychoStructure.LC ~= "" then
				local leftR, leftG, leftB = hexaToNumber(psychoStructure.LC);
				if leftR and leftG and leftB then
					leftField:SetTextColor(leftR/255, leftG/255, leftB/255);
				end
			end
			
			if rightField and psychoStructure.RC and psychoStructure.RC ~= "" then
				local rightR, rightG, rightB = hexaToNumber(psychoStructure.RC);
				if rightR and rightG and rightB then
					rightField:SetTextColor(rightR/255, rightG/255, rightB/255);
				end
			end

			if frame.simpleLeftIcon then frame.simpleLeftIcon:Hide(); end
			if frame.simpleRightIcon then frame.simpleRightIcon:Hide(); end

			leftIcon:SetScript("OnClick", function(self)
				showIconBrowser(function(icon)
					psychoStructure.LI = icon;
					self.IC = icon;
					setupIconButton(self, icon or Globals.icons.default);
				end);
			end);
			rightIcon:SetScript("OnClick", function(self)
				showIconBrowser(function(icon)
					psychoStructure.RI = icon;
					self.IC = icon;
					setupIconButton(self, icon or Globals.icons.default);
				end);
			end);
			
			-- Set icons from saved data
			leftIcon.IC = psychoStructure.LI or Globals.icons.default;
			rightIcon.IC = psychoStructure.RI or Globals.icons.default;
			
			refreshEditIcon(leftIcon);
			refreshEditIcon(rightIcon);
			
			-- custom trait colour pickers
			if not frame.leftColorButton then
				local slider = _G[frame:GetName() .. "Slider"];
				frame.leftColorButton = CreateFrame("Button", frame:GetName() .. "LeftColor", frame, "TRP3_ColorPickerButton");
				frame.leftColorButton:SetSize(18, 18);
				frame.leftColorButton:SetPoint("RIGHT", slider, "LEFT", 14, 0);

				if slider then
					frame.leftColorButton:SetFrameLevel(slider:GetFrameLevel() + 1);
				end
			end
			
			if not frame.rightColorButton then
				local slider = _G[frame:GetName() .. "Slider"];
				frame.rightColorButton = CreateFrame("Button", frame:GetName() .. "RightColor", frame, "TRP3_ColorPickerButton");
				frame.rightColorButton:SetSize(18, 18);
				frame.rightColorButton:SetPoint("LEFT", slider, "RIGHT", -14, 0);

				if slider then
					frame.rightColorButton:SetFrameLevel(slider:GetFrameLevel() + 1);
				end
			end
			
			local function onLeftColorSelected(red, green, blue)
				if red and green and blue then
					local hexa = strconcat(numberToHexa(red), numberToHexa(green), numberToHexa(blue));
					psychoStructure.LC = hexa;
					
					local leftField = _G[frame:GetName() .. "LeftField"];
					if leftField then
						leftField:SetTextColor(red/255, green/255, blue/255);
					end
					
					local customColors = {
						leftColor = {red/255, green/255, blue/255},
						rightColor = psychoStructure.RC and psychoStructure.RC ~= "" and (function() 
							local r, g, b = hexaToNumber(psychoStructure.RC); 
							return (r and g and b) and {r/255, g/255, b/255} or {0.8, 0.2, 0.2};
						end)() or {0.8, 0.2, 0.2}
					};
					refreshPsycho(frame, psychoStructure.VA or 5, psychoStructure.ID, customColors);
				else
					psychoStructure.LC = nil;
				end
			end
			
			local function onRightColorSelected(red, green, blue)
				if red and green and blue then
					local hexa = strconcat(numberToHexa(red), numberToHexa(green), numberToHexa(blue));
					psychoStructure.RC = hexa;
					
					local rightField = _G[frame:GetName() .. "RightField"];
					if rightField then
						rightField:SetTextColor(red/255, green/255, blue/255);
					end
					
					local customColors = {
						leftColor = psychoStructure.LC and psychoStructure.LC ~= "" and (function() 
							local r, g, b = hexaToNumber(psychoStructure.LC); 
							return (r and g and b) and {r/255, g/255, b/255} or {0.8, 0.2, 0.2};
						end)() or {0.8, 0.2, 0.2},
						rightColor = {red/255, green/255, blue/255}
					};
					refreshPsycho(frame, psychoStructure.VA or 5, psychoStructure.ID, customColors);
				else
					psychoStructure.RC = nil;
				end
			end
			
			frame.leftColorButton.onSelection = onLeftColorSelected;
			frame.rightColorButton.onSelection = onRightColorSelected;
			
			local leftRed, leftGreen, leftBlue = 1.0, 0.9, 0.0; -- yellow
			local rightRed, rightGreen, rightBlue = 0.6, 0.8, 1.0; -- blue
			
			if psychoStructure.LC and psychoStructure.LC ~= "" then
				local tempR, tempG, tempB = hexaToNumber(psychoStructure.LC);
				if tempR and tempG and tempB then
					leftRed, leftGreen, leftBlue = tempR/255, tempG/255, tempB/255;
				else
					psychoStructure.LC = ("%02x%02x%02x"):format(leftRed*255, leftGreen*255, leftBlue*255);
				end
			else
				psychoStructure.LC = ("%02x%02x%02x"):format(leftRed*255, leftGreen*255, leftBlue*255);
			end
			
			if psychoStructure.RC and psychoStructure.RC ~= "" then
				local tempR, tempG, tempB = hexaToNumber(psychoStructure.RC);
				if tempR and tempG and tempB then
					rightRed, rightGreen, rightBlue = tempR/255, tempG/255, tempB/255;
				else
					psychoStructure.RC = ("%02x%02x%02x"):format(rightRed*255, rightGreen*255, rightBlue*255);
				end
			else
				psychoStructure.RC = ("%02x%02x%02x"):format(rightRed*255, rightGreen*255, rightBlue*255);
			end
			
			if psychoStructure.LC and psychoStructure.LC ~= "" then
				local leftColorR, leftColorG, leftColorB = hexaToNumber(psychoStructure.LC);
				if leftColorR and leftColorG and leftColorB then
					frame.leftColorButton.setColor(leftColorR, leftColorG, leftColorB);
				else
					frame.leftColorButton.setColor(leftRed*255, leftGreen*255, leftBlue*255);
				end
			else
				frame.leftColorButton.setColor(leftRed*255, leftGreen*255, leftBlue*255);
			end
			
			if psychoStructure.RC and psychoStructure.RC ~= "" then
				local rightColorR, rightColorG, rightColorB = hexaToNumber(psychoStructure.RC);
				if rightColorR and rightColorG and rightColorB then
					frame.rightColorButton.setColor(rightColorR, rightColorG, rightColorB);
				else
					frame.rightColorButton.setColor(rightRed*255, rightGreen*255, rightBlue*255);
				end
			else
				frame.rightColorButton.setColor(rightRed*255, rightGreen*255, rightBlue*255);
			end
			
			frame.leftColorButton:Show();
			frame.rightColorButton:Show();
			
			-- custom trait bar is smaller to make room for color picker buttons
			local barContainer = _G[frame:GetName() .. "Bar"];
			if barContainer then
				barContainer:SetSize(80, 18);
			end
		end

		-- store trait index for reference
		frame.psychoIndex = frameIndex;
		frame:ClearAllPoints();
		frame:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, 0);
		frame:SetPoint("RIGHT", 0, 0);

		local slider = _G[frame:GetName() .. "Slider"];
		if slider then
			slider:SetValue(psychoStructure.VA or 5);
			slider:SetScript("OnValueChanged", function(self, value)
				local parentFrame = self:GetParent();
				local customColors = nil;
				if not psychoStructure.ID then
					local leftColor = {0.2, 0.8, 0.2}; -- Default green
					local rightColor = {0.8, 0.2, 0.2}; -- Default red
					
					if psychoStructure.LC and psychoStructure.LC ~= "" then
						local r, g, b = hexaToNumber(psychoStructure.LC);
						if r and g and b then
							leftColor = {r/255, g/255, b/255};
						end
					end
					
					if psychoStructure.RC and psychoStructure.RC ~= "" then
						local r, g, b = hexaToNumber(psychoStructure.RC);
						if r and g and b then
							rightColor = {r/255, g/255, b/255};
						end
					end
					
					customColors = {
						leftColor = leftColor,
						rightColor = rightColor
					};
				end
				refreshPsycho(parentFrame, value, psychoStructure.ID, customColors);
			end);
		end
		
		local customColors = nil;
		if not psychoStructure.ID then
			local leftColor = {0.2, 0.8, 0.2}; -- Default green
			local rightColor = {0.8, 0.2, 0.2}; -- Default red
			
			if psychoStructure.LC and psychoStructure.LC ~= "" then
				local r, g, b = hexaToNumber(psychoStructure.LC);
				if r and g and b then
					leftColor = {r/255, g/255, b/255};
				end
			end
			
			if psychoStructure.RC and psychoStructure.RC ~= "" then
				local r, g, b = hexaToNumber(psychoStructure.RC);
				if r and g and b then
					rightColor = {r/255, g/255, b/255};
				end
			end
			
			customColors = {
				leftColor = leftColor,
				rightColor = rightColor
			};
		end
		
		refreshPsycho(frame, psychoStructure.VA or 5, psychoStructure.ID, customColors);
		frame:Show();
		previous = frame;
	end
	-- PsychoAdd button uses XML anchors relative to PsychoTitle, just ensure it's shown
	TRP3_RegisterCharact_Edit_PsychoAdd:Show();

	-- Languages
	if not getCurrentContext().isCompanion and TRP3_API.register.languages and TRP3_API.register.languages.renderEdit then
		TRP3_API.register.languages.renderEdit(TRP3_RegisterCharact_Edit_CharactPanel_Container, previous);
	elseif TRP3_API.register.languages and TRP3_API.register.languages.hideEdit then
		TRP3_API.register.languages.hideEdit();
	end
end

local function setupRelationButton(profileID, profile)
	setupIconButton(TRP3_RegisterCharact_ActionButton, getRelationTexture(profileID));
	setTooltipAll(TRP3_RegisterCharact_ActionButton, "LEFT", 0, 0, loc("CM_ACTIONS"), loc("REG_RELATION_BUTTON_TT"):format(getRelationText(profileID), getRelationTooltipText(profileID, profile)));
end

local function saveCharacteristics()
	saveInDraft();

	local context = getCurrentContext();
	local dataTab = context and context.profile and context.profile.characteristics or get("player/characteristics");
	assert(type(dataTab) == "table", "Error: Nil characteristics data or not a table.");
	wipe(dataTab);
	-- By simply copy the draftData we get everything we need about ordering and structures.
	tcopy(dataTab, draftData);
	-- version increment
	assert(type(dataTab.v) == "number", "Error: No version in draftData or not a number.");
	dataTab.v = Utils.math.incrementNumber(dataTab.v, 2);

	if not context.isCompanion then
		compressData();
	end
	Events.fireEvent(Events.REGISTER_DATA_UPDATED, (context and context.unitID) or Globals.player_id, context and context.profileID, "characteristics");

	if nsfwProfileCheckbox and context and context.profile and context.profile.character and not context.isCompanion then
		local nsfwStatus = nsfwProfileCheckbox:GetChecked() and true or nil;
		if context.profile.character.NSFW ~= nsfwStatus then
			context.profile.character.NSFW = nsfwStatus;
			context.profile.character.v = Utils.math.incrementNumber(context.profile.character.v or 1, 2);
			Events.fireEvent(Events.REGISTER_DATA_UPDATED, context.unitID or Globals.player_id, context.profileID, "character");
		end
	end
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- CHARACTERISTICS - LOGIC
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local reportProfile;
local reportProfileButton;

local function ensureReportProfileButton()
	if reportProfileButton then
		return reportProfileButton;
	end
	reportProfileButton = CreateFrame("Button", "TRP3_RegisterCharact_ReportProfileButton", TRP3_RegisterCharact_NamePanel, "UIPanelButtonTemplate");
	reportProfileButton:SetWidth(76);
	reportProfileButton:SetHeight(22);
	reportProfileButton:SetPoint("TOPRIGHT", TRP3_RegisterCharact_NamePanel, "TOPRIGHT", -12, -14);
	reportProfileButton:SetText("Report");
	reportProfileButton:SetScript("OnClick", function()
		local context = getCurrentContext();
		if context and context.profile and reportProfile then
			reportProfile(context);
		end
	end);
	reportProfileButton:Hide();
	return reportProfileButton;
end

local function refreshDisplay()
	local context = getCurrentContext();
	assert(context, "No context for page player_main !");
	assert(context.profile, "No profile in context");

	-- Hide all
	ensureReportProfileButton():Hide();
	TRP3_RegisterCharact_NamePanel:Hide();
	TRP3_RegisterCharact_CharactPanel:Hide();
	TRP3_RegisterCharact_ActionButton:Hide();
	TRP3_RegisterCharact_CharactPanel_Empty:Hide();
	TRP3_RegisterCharact_Edit_NamePanel:Hide();
	TRP3_RegisterCharact_Edit_CharactPanel:Hide();
	for _, frame in pairs(registerCharFrame) do frame:Hide(); end
	for _, frame in pairs(psychoCharFrame) do frame:Hide(); end
	for _, frame in pairs(miscCharFrame) do frame:Hide(); end

	local moderationEntry = TRP3_API.register.moderation
		and TRP3_API.register.moderation.isProfileHidden
		and TRP3_API.register.moderation.isProfileHidden(context.unitID, context.profile);
	if context.isDeveloperEdit then
		moderationEntry = nil;
	end
	if moderationEntry then
		TRP3_RegisterCharact_CharactPanel_Empty:SetText("|cffffd36bProfile hidden by moderation.|r");
		TRP3_RegisterCharact_CharactPanel_Empty:Show();
		return;
	end
	TRP3_RegisterCharact_CharactPanel_Empty:SetText(loc("REG_PLAYER_NO_CHAR"));

	-- IsSelf ?
	TRP3_RegisterCharact_NamePanel_EditButton:Hide();
	if context.isPlayer then
		TRP3_RegisterCharact_NamePanel_EditButton:Show();
	else
		assert(context.profileID, "No profileID in context");
		TRP3_RegisterCharact_ActionButton:Show();
		setupRelationButton(context.profileID, context.profile);
		if not context.isDeveloperEdit then
			ensureReportProfileButton():Show();
		end
	end

	if context.isEditMode then
		assert(context.isPlayer, "Trying to show Characteristics edition but is not mine ...");
		TRP3_RegisterCharact_Edit_NamePanel:Show();
		TRP3_RegisterCharact_Edit_CharactPanel:Show();
		setEditDisplay();
	else
		TRP3_RegisterCharact_NamePanel:Show();
		TRP3_RegisterCharact_CharactPanel:Show();
		setConsultDisplay(context);
	end
end

TRP3_API.register.ui.refreshCharacteristicsDisplay = refreshDisplay;

local toast = TRP3_API.ui.tooltip.toast;
local reportReasonFrame;
local reportReasonEditBox;

local function getReportUnitID(context)
	if context.unitID and context.unitID ~= "" then
		return context.unitID;
	end
	if context.profile and context.profile.link then
		for unitID in pairs(context.profile.link) do
			return unitID;
		end
	end
end

local function getNormalizedRealmName()
	local realmName = tostring(GetRealmName and GetRealmName() or "");
	realmName = realmName:gsub("^%s*(.-)%s*$", "%1");
	realmName = realmName:gsub("%s+", "");
	return string.lower(realmName);
end

local function ensureReportReasonFrame()
	if reportReasonFrame then
		return reportReasonFrame;
	end

	reportReasonFrame = CreateFrame("Frame", "TRP3_ReportProfileReasonFrame", UIParent);
	reportReasonFrame:SetWidth(520);
	reportReasonFrame:SetHeight(320);
	reportReasonFrame:SetPoint("CENTER");
	reportReasonFrame:SetFrameStrata("DIALOG");
	reportReasonFrame:SetBackdrop({
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile = true,
		tileSize = 32,
		edgeSize = 32,
		insets = { left = 11, right = 12, top = 12, bottom = 11 },
	});
	reportReasonFrame:EnableMouse(true);
	reportReasonFrame:Hide();

	local title = reportReasonFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge");
	title:SetPoint("TOPLEFT", 24, -22);
	title:SetText("Report Profile");

	local help = reportReasonFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall");
	help:SetPoint("TOPLEFT", 24, -52);
	help:SetWidth(468);
	help:SetJustifyH("LEFT");
	help:SetJustifyV("TOP");
	help:SetText("Describe why this profile is being reported. This will be sent to TranquilRP3 moderators with the reported profile details.");

	local scrollFrame = CreateFrame("ScrollFrame", "TRP3_ReportProfileReasonScrollFrame", reportReasonFrame, "UIPanelScrollFrameTemplate");
	scrollFrame:SetPoint("TOPLEFT", reportReasonFrame, "TOPLEFT", 28, -96);
	scrollFrame:SetPoint("BOTTOMRIGHT", reportReasonFrame, "BOTTOMRIGHT", -46, 58);
	scrollFrame:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true,
		tileSize = 16,
		edgeSize = 12,
		insets = { left = 4, right = 4, top = 4, bottom = 4 },
	});
	scrollFrame:SetBackdropColor(0, 0, 0, 0.55);

	reportReasonEditBox = CreateFrame("EditBox", "TRP3_ReportProfileReasonEditBox", scrollFrame);
	reportReasonEditBox:SetMultiLine(true);
	reportReasonEditBox:SetAutoFocus(false);
	reportReasonEditBox:SetFontObject(ChatFontNormal);
	reportReasonEditBox:SetWidth(430);
	reportReasonEditBox:SetHeight(160);
	reportReasonEditBox:SetTextInsets(6, 6, 6, 6);
	reportReasonEditBox:SetScript("OnEscapePressed", function(self)
		self:ClearFocus();
	end);
	scrollFrame:SetScrollChild(reportReasonEditBox);

	local cancelButton = CreateFrame("Button", nil, reportReasonFrame, "UIPanelButtonTemplate");
	cancelButton:SetWidth(88);
	cancelButton:SetHeight(24);
	cancelButton:SetPoint("BOTTOMRIGHT", reportReasonFrame, "BOTTOMRIGHT", -24, 24);
	cancelButton:SetText(CANCEL);
	cancelButton:SetScript("OnClick", function()
		reportReasonFrame:Hide();
	end);

	local sendButton = CreateFrame("Button", nil, reportReasonFrame, "UIPanelButtonTemplate");
	sendButton:SetWidth(108);
	sendButton:SetHeight(24);
	sendButton:SetPoint("RIGHT", cancelButton, "LEFT", -10, 0);
	sendButton:SetText("Send Report");
	sendButton:SetScript("OnClick", function()
		local context = reportReasonFrame.context;
		local reason = reportReasonEditBox:GetText();
		if not context then
			reportReasonFrame:Hide();
			return;
		end
		local unitID = getReportUnitID(context);
		local ok, err = TRP3_API.register.sendProfileReport(unitID, context.profileID, context.profile, reason);
		if ok then
			toast(err or "Profile report queued for TranquilRP3 moderators.", 3);
			reportReasonFrame:Hide();
		else
			toast(err or "Unable to send profile report.", 4);
		end
	end);

	return reportReasonFrame;
end

local function showReportReasonFrame(context, reportedName)
	local frame = ensureReportReasonFrame();
	frame.context = context;
	reportReasonEditBox:SetText("");
	reportReasonEditBox:SetFocus();
	frame:Show();
end

reportProfile = function(context)
	if not TRP3_API.register.sendProfileReport then
		toast("Profile reports are not available.", 3);
		return;
	end
	if getNormalizedRealmName() ~= "glitterwing" then
		toast("Profile reports are only available on Glitterwing.", 3);
		return;
	end
	local unitID = getReportUnitID(context);
	local reportedName = getCompleteName(context.profile.characteristics or {}, unitID or UNKNOWN, true);
	showConfirmPopup(
		"Report this profile to TranquilRP3 moderators on Glitterwing?\n\nYour character name, the reported character name, your report reason, and the reported profile details will be sent to authorized moderators for review.",
		function()
			showReportReasonFrame(context, reportedName);
		end
	);
end

local function onActionSelected(value, button)
	local context = getCurrentContext();
	assert(context, "No context for page player_main !");
	assert(context.profile, "No profile in context");
	assert(context.profileID, "No profileID in context");

	if value == 1 then
		local profil = getProfile(context.profileID);
		showConfirmPopup(loc("REG_DELETE_WARNING"):format(Utils.str.color("g") .. getCompleteName(profil.characteristics or {}, UNKNOWN, true) .. "|r"),
			function()
				deleteProfile(context.profileID);
			end);
	elseif value == 2 then
		showTextInputPopup(loc("REG_PLAYER_IGNORE_WARNING"):format(strjoin("\n", unpack(getKeys(context.profile.link)))), function(text)
			for unitID, _ in pairs(context.profile.link) do
				ignoreID(unitID, text);
			end
			toast(loc("REG_IGNORE_TOAST"), 2);
		end);
	elseif value == 3 then
		reportProfile(context);
	elseif value == RELATIONS.CREATE_CUSTOM_RELATION then
		RELATIONS.createCustomRelation(context.profileID, nil, function()
			setupRelationButton(context.profileID, context.profile);
		end);
	elseif type(value) == "string" then
		setRelation(context.profileID, value);
		setupRelationButton(context.profileID, context.profile);
		Events.fireEvent(Events.REGISTER_DATA_UPDATED, nil, context.profileID, "characteristics");
	end
end

local function onActionClicked(button)
	local context = getCurrentContext();
	assert(context, "No context for page player_main !");
	assert(context.profile, "No profile in context");

	local values = {};
	tinsert(values, { loc("PR_DELETE_PROFILE"), 1 });
	if context.profile.link and tsize(context.profile.link) > 0 then
		tinsert(values, { loc("REG_PLAYER_IGNORE"):format(tsize(context.profile.link)), 2 });
	end
	if not context.isPlayer and not context.isDeveloperEdit then
		tinsert(values, { "Report Profile", 3 });
	end
	local relationValues = {};
	RELATIONS.appendRelationOptions(relationValues);
	tinsert(values, {
		loc("REG_RELATION"),
		relationValues,
	});
	displayDropDown(button, values, onActionSelected, 0, true);
end



local function showCharacteristicsTab()
	TRP3_RegisterCharact:Show();
	getCurrentContext().isEditMode = false;
	refreshDisplay();
end

TRP3_API.register.ui.showCharacteristicsTab = showCharacteristicsTab;

local function onEdit()
	if draftData then
		wipe(draftData);
		draftData = nil;
	end
	getCurrentContext().isEditMode = true;
	refreshDisplay();
end

local function onSave()
	saveInDraft();
	TRP3_API.register.promptForNSFWIfNeeded(function()
		saveCharacteristics();
		showCharacteristicsTab();
	end, {
		characteristics = draftData,
	});
end

--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
-- CHARACTERISTICS - INIT
--*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*

local function initStructures()
	TRAIT_PRESETS_UNKNOWN = {
		LT = loc("CM_UNKNOWN"),
		RT = loc("CM_UNKNOWN"),
		LI = "INV_Misc_QuestionMark",
		RI = "INV_Misc_QuestionMark",
		leftColor = {1.0, 1.0, 0.4}, -- Yellow for both text and bar
		rightColor = {0.55, 0.55, 0.95} -- Light blue for both text and bar
	};

	TRAIT_PRESETS = {
		{
			LT = loc("REG_PLAYER_TRAIT_CHAOTIC"),
			RT = loc("REG_PLAYER_TRAIT_LOYAL"),
			LI = "Ability_Rogue_WrongfullyAccused",
			RI = "Ability_Paladin_SanctifiedWrath",
			leftColor = {0.6, 0.2, 0.8}, -- Purple
			rightColor = {0.2, 0.6, 1.0} -- Blue
		},
		{
			LT = loc("REG_PLAYER_TRAIT_CHASTE"),
			RT = loc("REG_PLAYER_TRAIT_LUSTFUL"),
			LI = "INV_Belt_27",
			RI = "Spell_Shadow_SummonSuccubus",
			leftColor = {1.0, 1.0, 1.0}, -- White
			rightColor = {1.0, 0.2, 0.2} -- Red
		},
		{
			LT = loc("REG_PLAYER_TRAIT_FORGIVING"),
			RT = loc("REG_PLAYER_TRAIT_VENGEFUL"),
			LI = "INV_RoseBouquet01",
			RI = "Ability_Hunter_SniperShot",
			leftColor = {0.4, 0.8, 0.4}, -- Green
			rightColor = {1.0, 0.6, 0.2} -- Orange
		},
		{
			LT = loc("REG_PLAYER_TRAIT_GENEROUS"),
			RT = loc("REG_PLAYER_TRAIT_SELFISH"),
			LI = "INV_Misc_Gift_02",
			RI = "INV_Misc_Coin_02",
			leftColor = {1.0, 0.8, 0.2}, -- Gold
			rightColor = {0.8, 0.2, 0.2} -- Dark Red
		},
		{
			LT = loc("REG_PLAYER_TRAIT_SINCERE"),
			RT = loc("REG_PLAYER_TRAIT_DECEPTIVE"),
			LI = "INV_Misc_Toy_07",
			RI = "Ability_Rogue_Disguise",
			leftColor = {0.5, 0.8, 1.0}, -- Light Blue
			rightColor = {0.5, 0.2, 0.6} -- Dark Purple
		},
		{
			LT = loc("REG_PLAYER_TRAIT_MERCIFUL"),
			RT = loc("REG_PLAYER_TRAIT_CRUEL"),
			LI = "INV_ValentinesCandySack",
			RI = "Ability_Warrior_Trauma",
			leftColor = {1.0, 0.6, 0.8}, -- Pink
			rightColor = {0.7, 0.1, 0.1} -- Dark Red
		},
		{
			LT = loc("REG_PLAYER_TRAIT_SPIRITUAL"),
			RT = loc("REG_PLAYER_TRAIT_RATIONAL"),
			LI = "Spell_Holy_HolyGuidance",
			RI = "INV_Gizmo_02",
			leftColor = {1.0, 0.9, 0.3}, -- Yellow
			rightColor = {0.3, 0.8, 0.8} -- Cyan
		},
		{
			LT = loc("REG_PLAYER_TRAIT_PRAGMATIC"),
			RT = loc("REG_PLAYER_TRAIT_DIPLOMATIC"),
			LI = "Ability_Rogue_HonorAmongstThieves",
			RI = "INV_Misc_GroupNeedMore",
			leftColor = {0.7, 0.5, 0.3}, -- Brown
			rightColor = {0.6, 0.9, 0.6} -- Light Green
		},
		{
			LT = loc("REG_PLAYER_TRAIT_THOUGHTFUL"),
			RT = loc("REG_PLAYER_TRAIT_IMPULSIVE"),
			LI = "Spell_Shadow_Brainwash",
			RI = "Achievement_BG_CaptureFlag_EOS",
			leftColor = {0.3, 0.5, 0.8}, -- Dark Blue
			rightColor = {1.0, 0.5, 0.1} -- Bright Orange
		},
		{
			LT = loc("REG_PLAYER_TRAIT_ASCETIC"),
			RT = loc("REG_PLAYER_TRAIT_HEDONISTIC"),
			LI = "INV_Misc_Food_PineNut",
			RI = "INV_Misc_Food_99",
			leftColor = {0.7, 0.7, 0.7}, -- Gray
			rightColor = {0.9, 0.3, 0.7} -- Magenta
		},
		{
			LT = loc("REG_PLAYER_TRAIT_VALOROUS"),
			RT = loc("REG_PLAYER_TRAIT_COWARDLY"),
			LI = "Ability_Paladin_BeaconofLight",
			RI = "Ability_Druid_Cower",
			leftColor = {1.0, 0.9, 0.1}, -- Bright Gold
			rightColor = {0.5, 0.5, 0.5} -- Dark Gray
		},
		-- Warcraft Chronicles Cosmology traits
		{
			LT = loc("REG_PLAYER_TRAIT_LIGHT"),
			RT = loc("REG_PLAYER_TRAIT_SHADOW"),
			LI = "Spell_Holy_DivineIllumination",
			RI = "Spell_Shadow_ShadowWordPain",
			leftColor = {1.0, 0.9, 0.2}, -- Yellow/Gold (Holy)
			rightColor = {0.5, 0.2, 0.8} -- Purple-ish (Void)
		},
		{
			LT = loc("REG_PLAYER_TRAIT_LIFE"),
			RT = loc("REG_PLAYER_TRAIT_DEATH"),
			LI = "Spell_Nature_HealingTouch",
			RI = "Spell_Shadow_RaiseDead",
			leftColor = {0.2, 0.8, 0.6}, -- Green/Teal (Nature)
			rightColor = {0.5, 0.5, 0.5} -- Gray (Necromancy)
		},
		{
			LT = loc("REG_PLAYER_TRAIT_ORDER"),
			RT = loc("REG_PLAYER_TRAIT_DISORDER"),
			LI = "Spell_Arcane_MassDispel",
			RI = "Spell_Fire_FelImmolation",
			leftColor = {0.2, 0.5, 1.0}, -- Blue (Arcane)
			rightColor = {0.5, 0.8, 0.2} -- Green (Fel)
		},
	};

	TRAIT_PRESETS_DROPDOWN = {
		{ loc("REG_PLAYER_TRAIT_SOCIAL") },
		{ loc("REG_PLAYER_TRAIT_CHAOTIC") .. " - " .. loc("REG_PLAYER_TRAIT_LOYAL"), 1 },
		{ loc("REG_PLAYER_TRAIT_CHASTE") .. " - " .. loc("REG_PLAYER_TRAIT_LUSTFUL"), 2 },
		{ loc("REG_PLAYER_TRAIT_FORGIVING") .. " - " .. loc("REG_PLAYER_TRAIT_VENGEFUL"), 3 },
		{ loc("REG_PLAYER_TRAIT_GENEROUS") .. " - " .. loc("REG_PLAYER_TRAIT_SELFISH"), 4 },
		{ loc("REG_PLAYER_TRAIT_SINCERE") .. " - " .. loc("REG_PLAYER_TRAIT_DECEPTIVE"), 5 },
		{ loc("REG_PLAYER_TRAIT_MERCIFUL") .. " - " .. loc("REG_PLAYER_TRAIT_CRUEL"), 6 },
		{ loc("REG_PLAYER_TRAIT_SPIRITUAL") .. " - " .. loc("REG_PLAYER_TRAIT_RATIONAL"), 7 },
		{ loc("REG_PLAYER_TRAIT_PERSONAL") },
		{ loc("REG_PLAYER_TRAIT_PRAGMATIC") .. " - " .. loc("REG_PLAYER_TRAIT_DIPLOMATIC"), 8 },
		{ loc("REG_PLAYER_TRAIT_THOUGHTFUL") .. " - " .. loc("REG_PLAYER_TRAIT_IMPULSIVE"), 9 },
		{ loc("REG_PLAYER_TRAIT_ASCETIC") .. " - " .. loc("REG_PLAYER_TRAIT_HEDONISTIC"), 10 },
		{ loc("REG_PLAYER_TRAIT_VALOROUS") .. " - " .. loc("REG_PLAYER_TRAIT_COWARDLY"), 11 },
		{ loc("REG_PLAYER_TRAIT_COSMIC") },
		{ loc("REG_PLAYER_TRAIT_LIGHT") .. " - " .. loc("REG_PLAYER_TRAIT_SHADOW"), 12 },
		{ loc("REG_PLAYER_TRAIT_LIFE") .. " - " .. loc("REG_PLAYER_TRAIT_DEATH"), 13 },
		{ loc("REG_PLAYER_TRAIT_ORDER") .. " - " .. loc("REG_PLAYER_TRAIT_DISORDER"), 14 },
		{ loc("REG_PLAYER_TRAIT_CUSTOM") },
		{ loc("REG_PLAYER_TRAIT_CREATENEW"), "new" },
	};
end

function TRP3_API.register.inits.characteristicsInit()
	initStructures();

	if not factionBadgeButton then
		factionBadgeButton = CreateFrame("Button", "TRP3_RegisterCharact_Edit_FactionButton", TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_SimpleIconButton");
		factionBadgeButton:SetSize(28, 28);
		factionBadgeButton:SetPoint("TOPRIGHT", TRP3_RegisterCharact_Edit_CharactPanel_RegisterTitleFrame, "TOPRIGHT", -48, -2);
		factionBadgeButton:SetScript("OnClick", function(self) openFactionBadgeMenu(self); end);
	end
	if not factionBadgePreview then
		factionBadgePreview = CreateFrame("Frame", "TRP3_RegisterCharact_Edit_FactionPreview", TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_SimpleIcon");
		factionBadgePreview:SetSize(24, 24);
		factionBadgePreview:SetPoint("LEFT", factionBadgeButton, "RIGHT", 8, 0);
	end
	if not factionBadgeHideCheckbox then
		factionBadgeHideCheckbox = CreateFrame("CheckButton", "TRP3_RegisterCharact_Edit_FactionHide", TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_CheckBox");
		factionBadgeHideCheckbox:SetPoint("RIGHT", factionBadgeButton, "LEFT", -120, 0);
		local checkboxText = _G[factionBadgeHideCheckbox:GetName() .. "Text"];
		if checkboxText then
			checkboxText:SetText(loc("REG_PLAYER_FACTION_HIDE"));
		end
		factionBadgeHideCheckbox:SetScript("OnClick", function(self)
			if draftData then
				draftData.FH = self:GetChecked() and true or nil;
				refreshFactionBadgeControls();
			end
		end);
	end
	if not nsfwProfileCheckbox then
		nsfwProfileCheckbox = CreateFrame("CheckButton", "TRP3_RegisterCharact_Edit_NSFW", TRP3_RegisterCharact_Edit_CharactPanel_Container, "TRP3_CheckBox");
		nsfwProfileCheckbox:SetPoint("BOTTOMLEFT", factionBadgeHideCheckbox, "TOPLEFT", 0, -5);
		local checkboxText = _G[nsfwProfileCheckbox:GetName() .. "Text"];
		if checkboxText then
			checkboxText:SetText("NSFW");
		end
	end

	-- UI
	TRP3_RegisterCharact_Edit_MiscAdd:SetScript("OnClick", miscAddDropDown);
	TRP3_RegisterCharact_Edit_NamePanel_Icon:SetScript("OnClick", function() showIconBrowser(onPlayerIconSelected) end);
	TRP3_RegisterCharact_NamePanel_Edit_CancelButton:SetScript("OnClick", showCharacteristicsTab);
	TRP3_RegisterCharact_NamePanel_Edit_SaveButton:SetScript("OnClick", onSave);
	TRP3_RegisterCharact_NamePanel_EditButton:SetScript("OnClick", onEdit);
	TRP3_RegisterCharact_ActionButton:SetScript("OnClick", onActionClicked);
	TRP3_RegisterCharact_Edit_GuildClear:SetScript("OnClick", clearCustomGuildFields);
	TRP3_RegisterCharact_Edit_ResidenceButton:SetScript("OnClick", function()
		TRP3_RegisterCharact_Edit_ResidenceField:SetText(buildZoneText());
	end);
	TRP3_RegisterCharact_Edit_BirthplaceButton:SetScript("OnClick", function()
		TRP3_RegisterCharact_Edit_BirthplaceField:SetText(buildZoneText());
	end);
	TRP3_RegisterCharact_Edit_ClassButton.onSelection = onClassColorSelected;
	TRP3_RegisterCharact_Edit_EyeButton.onSelection = onEyeColorSelected;

	setupDropDownMenu(TRP3_RegisterCharact_Edit_PsychoAdd, TRAIT_PRESETS_DROPDOWN, psychoAdd, 0, true, false);

	-- Localz
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_NamePanel_Icon, "RIGHT", 0, 5, loc("REG_PLAYER_ICON"), loc("REG_PLAYER_ICON_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_TitleFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_TITLE"), loc("REG_PLAYER_TITLE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_FirstFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_FIRSTNAME"), loc("REG_PLAYER_FIRSTNAME_TT"):format(Globals.player));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_LastFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_LASTNAME"), loc("REG_PLAYER_LASTNAME_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_FullTitleFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_FULLTITLE"), loc("REG_PLAYER_FULLTITLE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_RaceFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_RACE"), loc("REG_PLAYER_RACE_TT"):format(Globals.player_race_loc));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_ClassFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_CLASS"), loc("REG_PLAYER_CLASS_TT"):format(Globals.player_class_loc));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_AgeFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_AGE"), loc("REG_PLAYER_AGE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_BirthplaceFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_BIRTHPLACE"), loc("REG_PLAYER_BIRTHPLACE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_ResidenceFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_RESIDENCE"), loc("REG_PLAYER_RESIDENCE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_EyeFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_EYE"), loc("REG_PLAYER_EYE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_HeightFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_HEIGHT"), loc("REG_PLAYER_HEIGHT_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_WeightFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_WEIGHT"), loc("REG_PLAYER_WEIGHT_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_GuildTitleFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_GUILD_TITLE"), loc("REG_PLAYER_GUILD_TITLE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_GuildRankFieldHelp, "RIGHT", 0, 5, loc("REG_PLAYER_GUILD_RANK"), loc("REG_PLAYER_GUILD_RANK_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_GuildClear, "TOP", 0, 5, loc("CM_REMOVE"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_FactionButton, "TOP", 0, 5, loc("REG_PLAYER_FACTION_BADGE"), loc("REG_PLAYER_FACTION_BADGE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_FactionPreview, "TOP", 0, 5, loc("REG_PLAYER_FACTION_PREVIEW"), loc("REG_PLAYER_FACTION_PREVIEW_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_FactionHide, "TOP", 0, 5, loc("REG_PLAYER_FACTION_HIDE"), loc("REG_PLAYER_FACTION_HIDE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_NSFW, "TOP", 0, 5, loc("DB_STATUS_NSFW"), loc("DB_STATUS_NSFW_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_ResidenceButton, "RIGHT", 0, 5, loc("REG_PLAYER_HERE"), loc("REG_PLAYER_HERE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_BirthplaceButton, "RIGHT", 0, 5, loc("REG_PLAYER_HERE"), loc("REG_PLAYER_HERE_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_EyeButton, "RIGHT", 0, 5, loc("REG_PLAYER_EYE"), loc("REG_PLAYER_COLOR_TT"));
	setTooltipForSameFrame(TRP3_RegisterCharact_Edit_ClassButton, "RIGHT", 0, 5, loc("REG_PLAYER_COLOR_CLASS"), loc("REG_PLAYER_COLOR_CLASS_TT") .. loc("REG_PLAYER_COLOR_TT"));

	setupFieldSet(TRP3_RegisterCharact_NamePanel, loc("REG_PLAYER_NAMESTITLES"), 150);
	setupFieldSet(TRP3_RegisterCharact_Edit_NamePanel, loc("REG_PLAYER_NAMESTITLES"), 150);
	setupFieldSet(TRP3_RegisterCharact_CharactPanel, loc("REG_PLAYER_CHARACTERISTICS"), 150);
	setupFieldSet(TRP3_RegisterCharact_Edit_CharactPanel, loc("REG_PLAYER_CHARACTERISTICS"), 150);

	setupEditBoxesNavigation({
		TRP3_RegisterCharact_Edit_RaceField,
		TRP3_RegisterCharact_Edit_ClassField,
		TRP3_RegisterCharact_Edit_AgeField,
		TRP3_RegisterCharact_Edit_ResidenceField,
		TRP3_RegisterCharact_Edit_EyeField,
		TRP3_RegisterCharact_Edit_BirthplaceField,
		TRP3_RegisterCharact_Edit_HeightField,
		TRP3_RegisterCharact_Edit_WeightField
	})

	setupEditBoxesNavigation({
		TRP3_RegisterCharact_Edit_TitleField,
		TRP3_RegisterCharact_Edit_FirstField,
		TRP3_RegisterCharact_Edit_LastField,
		TRP3_RegisterCharact_Edit_FullTitleField
	});

	TRP3_RegisterCharact_CharactPanel_Empty:SetText(loc("REG_PLAYER_NO_CHAR"));
	TRP3_RegisterCharact_Edit_MiscAdd:SetText(loc("REG_PLAYER_MISC_ADD"));
	TRP3_RegisterCharact_Edit_PsychoAdd:SetText(loc("REG_PLAYER_PSYCHO_ADD"));
	TRP3_RegisterCharact_NamePanel_Edit_CancelButton:SetText(loc("CM_CANCEL"));
	TRP3_RegisterCharact_NamePanel_Edit_SaveButton:SetText(loc("CM_SAVE"));
	TRP3_RegisterCharact_NamePanel_EditButton:SetText(loc("CM_EDIT"));
	TRP3_RegisterCharact_Edit_TitleFieldText:SetText(loc("REG_PLAYER_TITLE"));
	TRP3_RegisterCharact_Edit_FirstFieldText:SetText(loc("REG_PLAYER_FIRSTNAME"));
	TRP3_RegisterCharact_Edit_LastFieldText:SetText(loc("REG_PLAYER_LASTNAME"));
	TRP3_RegisterCharact_Edit_FullTitleFieldText:SetText(loc("REG_PLAYER_FULLTITLE"));
	TRP3_RegisterCharact_CharactPanel_RegisterTitle:SetText(loc("REG_PLAYER_REGISTER"));
	TRP3_RegisterCharact_CharactPanel_Edit_RegisterTitle:SetText(loc("REG_PLAYER_REGISTER"));
	TRP3_RegisterCharact_CharactPanel_PsychoTitle:SetText(loc("REG_PLAYER_OTHER"));
	TRP3_RegisterCharact_CharactPanel_Edit_PsychoTitle:SetText(loc("REG_PLAYER_OTHER"));
	TRP3_RegisterCharact_CharactPanel_MiscTitle:SetText(loc("REG_PLAYER_MORE_INFO"));
	TRP3_RegisterCharact_CharactPanel_Edit_MiscTitle:SetText(loc("REG_PLAYER_MORE_INFO"));
	TRP3_RegisterCharact_Edit_RaceFieldText:SetText(loc("REG_PLAYER_RACE"));
	TRP3_RegisterCharact_Edit_ClassFieldText:SetText(loc("REG_PLAYER_CLASS"));
	TRP3_RegisterCharact_Edit_AgeFieldText:SetText(loc("REG_PLAYER_AGE"));
	TRP3_RegisterCharact_Edit_EyeFieldText:SetText(loc("REG_PLAYER_EYE"));
	TRP3_RegisterCharact_Edit_HeightFieldText:SetText(loc("REG_PLAYER_HEIGHT"));
	TRP3_RegisterCharact_Edit_WeightFieldText:SetText(loc("REG_PLAYER_WEIGHT"));
	TRP3_RegisterCharact_Edit_GuildTitleFieldText:SetText(loc("REG_PLAYER_GUILD_TITLE"));
	TRP3_RegisterCharact_Edit_GuildRankFieldText:SetText(loc("REG_PLAYER_GUILD_RANK"));
	TRP3_RegisterCharact_Edit_ResidenceFieldText:SetText(loc("REG_PLAYER_RESIDENCE"));
	TRP3_RegisterCharact_Edit_BirthplaceFieldText:SetText(loc("REG_PLAYER_BIRTHPLACE"));

	Events.listenToEvent(Events.REGISTER_PROFILES_LOADED, compressData); -- On profile change, compress the new data
	compressData();
end
