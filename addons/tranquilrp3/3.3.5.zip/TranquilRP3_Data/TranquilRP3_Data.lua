----------------------------------------------------------------------------------
-- Total RP 3: Data storage
--	---------------------------------------------------------------------------
--	Copyright 2014 Sylvain Cossement (telkostrasz@telkostrasz.be)
--
--	Licensed under the Apache License, Version 2.0 (the "License");
--	you may not use this file except in compliance with the License.
--	You may obtain a copy of the License at
--
--		http://www.apache.org/licenses/LICENSE-2.0
--
--	Unless required by applicable law or agreed to in writing, software
--	distributed under the License is distributed on an "AS IS" BASIS,
--	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
--	See the License for the specific language governing permissions and
--	limitations under the License.
----------------------------------------------------------------------------------

-- This is a dummy addon in order to separate data from other players from the main saved variable.
-- We decided to do this due to the WoW bug happening when a save variable file is too large: can't be load and loss of all data.
-- By keeping the data external data aside from our own, we reduce de chances to lose our beautiful descriptions when the register is too large for example.

if type(TRP3_Register_TranquilRP3) ~= "table" then
	TRP3_Register_TranquilRP3 = {};
end
